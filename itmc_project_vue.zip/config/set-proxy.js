const paths = [
  "/hapi",
  "/Pic",
  "/trip-sms"
];

const useStrategy = {
  // target:"http://local.itmc.sinopec.com:35516",
  target:"http://image.baidu.com",
  changeOrigin: true,
  pathRewrite:{
    '^/hapi': '',
    '^/Pic':'/pic',
    '^/trip-sms':'/trip-sms'
  }
};

const proxyTableObj = {};

paths.forEach(path => {
  proxyTableObj[path] = Object.assign({}, useStrategy)
});
module.exports = proxyTableObj;
