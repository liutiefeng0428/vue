// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'
import Antd from 'ant-design-vue'
import "ant-design-vue/dist/antd.css";
import 'babel-polyfill'

// 引入样式
import 'vue-easytable/libs/themes-base/index.css'
// 导入 table 和 分页组件
import {VTable,VPagination} from 'vue-easytable'
// import gloableF from './utils/gloableF'


Vue.use(Antd)
Vue.config.productionTip = false

// 注册到全局 easytable
Vue.component(VTable.name, VTable)
Vue.component(VPagination.name, VPagination)
// Vue.prototype.$gloableF=gloableF
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
