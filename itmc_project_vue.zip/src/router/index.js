import Vue from 'vue'
import Router from 'vue-router'

// const List = r => require.ensure([], () => r(require('@/components/List')),'List');
// const Collapse = r => require.ensure([], () => r(require('@/components/Collapse')),'Collapse');
const ProjectContract = r => require.ensure([], () => r(require('@/views/contract/ProjectContract1')),'ProjectContract');
const AddProjectContract = r => require.ensure([], () => r(require('@/views/contract/AddProjectContract')),'AddProjectContract');
const CostContract = r => require.ensure([], () => r(require('@/views/contract/CostContract')),'CostContract');
const ContractDetail = r => require.ensure([], () => r(require('@/views/contract/ContractDetail1')),'ContractDetail');
// const UserList = r => require.ensure([], () => r(require('@/views/list/UserList')),'UserList');
//const Gather = r => require.ensure([], () => r(require('@/views/demand/Gather')),'Gather');
const ProjectBank = r => require.ensure([], () => r(require('@/views/management/ProjectBank')),'ProjectBank');
// 左侧菜单iframe嵌入
const Summary = r => require.ensure([], () => r(require('@/views/demand/Summary')),'Summary');
const Retroaction = r => require.ensure([], () => r(require('@/views/demand/Retroaction')),'Retroaction');
const PlanCheck = r => require.ensure([], () => r(require('@/views/plan/PlanCheck')),'PlanCheck');
const PlanReport = r => require.ensure([], () => r(require('@/views/plan/PlanReport')),'PlanReport');
const FeedBack = r => require.ensure([], () => r(require('@/views/demand/FeedBack')),'FeedBack');
const PlanPlate = r => grequire.ensure([], () => r(require('@/views/advise/PlanPlate')),'PlanPlate');
const PlanReview = r => require.ensure([], () => r(require('@/views/advise/PlanReview')),'PlanReview');
const PlanClassify = r => require.ensure([], () => r(require('@/views/advise/PlanClassify')),'PlanClassify');
const RightError = r => require.ensure([], () => r(require('@/views/error/RightError')),'RightError');

const PlanSummary = r => require.ensure([], () => r(require('@/views/advise/PlanSummary')),'PlanSummary');
 const PlanClassify2 = r => require.ensure([], () => r(require('@/views/advise/PlanClassify2')),'PlanClassify2');
const PlanChannel = r => require.ensure([], () => r(require('@/views/advise/PlanChannel')),'PlanChannel');
const InvestRelease = r => require.ensure([], () => r(require('@/views/investmentBatches/InvestRelease')),'InvestRelease');
const InvestReport = r => require.ensure([], () => r(require('@/views/investmentBatches/InvestReport')),'InvestReport');
const InvestSummary = r => require.ensure([], () => r(require('@/views/investmentBatches/InvestSummary')),'InvestSummary');
const ProjectBatch = r => require.ensure([], () => r(require('@/views/vivid/ProjectBatch')),'ProjectBatch');
const ProjectQuotas = r => require.ensure([], () => r(require('@/views/vivid/ProjectQuotas')),'ProjectQuotas');
const ProjectRate = r => require.ensure([], () => r(require('@/views/vivid/ProjectRate')),'ProjectRate');
const ProjectCard = r => require.ensure([], () => r(require('@/views/vivid/ProjectCard')),'ProjectCard');
const ProjectApprove = r => require.ensure([], () => r(require('@/views/vivid/ProjectApprove')),'ProjectApprove');
const ProLibrary = r => require.ensure([], () => r(require('@/views/management/ProLibrary')),'ProLibrary');
const ReportReply = r => require.ensure([], () => r(require('@/views/management/ReportReply')),'ReportReply');
const CostIf = r => require.ensure([], () => r(require('@/views/contract/CostIf')),'CostIf');
const ContractIf = r => require.ensure([], () => r(require('@/views/contract/ContractIf')),'ContractIf');
const Gather = r => require.ensure([], () => r(require('@/views/demand/Gather1')),'Gather1');
//字典查询
const DictList = r => require.ensure([], () => r(require('@/views/isystem/DictList')),'DictList');
//费用预算
const ReportEdit = r => require.ensure([], () => r(require('@/views/costBudget/ReportEdit')),'ReportEdit');
const ReportAdd = r => require.ensure([], () => r(require('@/views/costBudget/ReportAdd')),'ReportAdd');
const ReportAddCopy = r => require.ensure([], () => r(require('@/views/costBudget/ReportAddCopy')),'ReportAddCopyversion-detail');
const Quotas = r => require.ensure([], () => r(require('@/views/costBudget/Quotas')),'Quotas');
const QuotasEdit = r => require.ensure([], () => r(require('@/views/costBudget/QuotasEdit')),'QuotasEdit');
const VersionEdit = r => require.ensure([], () => r(require('@/views/costBudget/VersionEdit')),'VersionEdit');
const QuotasAdd = r => require.ensure([], () => r(require('@/views/costBudget/QuotasAdd')),'QuotasAdd');
// const VersionAdd = r => require.ensure([], () => r(require('@/views/costBudget/VersionAdd')),'VersionAdd');
const QuotasVersion = r => require.ensure([], () => r(require('@/views/costBudget/QuotasVersion')),'QuotasVersion');
const QuotasReport = r => require.ensure([], () => r(require('@/views/costBudget/QuotasReport')),'QuotasReport');
const QuotasVersionDetail = r => require.ensure([], () => r(require('@/views/costBudget/QuotasVersionDetail')),'QuotasVersionDetail');
const QuotasReportDetail = r => require.ensure([], () => r(require('@/views/costBudget/QuotasReportDetail')),'QuotasReportDetail');
const ReportList = r => require.ensure([], () => r(require('@/views/costBudget/ReportList')),'ReportList');
const DepartmentCheck = r => require.ensure([], () => r(require('@/views/costBudget/DepartmentCheck')),'DepartmentCheck');
const SubmissionPlan = r => require.ensure([], () => r(require('@/views/projectManage/SubmissionPlan')),'SubmissionPlan');
const SubmissionHistory = r => require.ensure([], () => r(require('@/views/projectManage/SubmissionHistory')),'SubmissionHistory');
const EditSubmission = r => require.ensure([], () => r(require('@/views/projectManage/EditSubmission')),'EditSubmission');
const ProjectOneVersion = r => require.ensure([], () => r(require('@/views/projectManage/ProjectOneVersion')),'ProjectOneVersion');
const GatherVersion = r => require.ensure([], () => r(require('@/views/projectManage/GatherVersion')),'GatherVersion');
const ManageVersion = r => require.ensure([], () => r(require('@/views/projectManage/ManageVersion')),'ManageVersion');

const Supplementary = r => require.ensure([], () => r(require('@/views/projectManage/Supplementary')),'Supplementary');
const EditSupplementary = r => require.ensure([], () => r(require('@/views/projectManage/EditSupplementary')),'EditSupplementary');
const NewSubmission = r => require.ensure([], () => r(require('@/views/projectManage/NewSubmission')),'NewSubmission');
const continuSubmission = r => require.ensure([], () => r(require('@/views/projectManage/continuSubmission')),'continuSubmission');
const ContractList = r => require.ensure([], () => r(require('@/views/projectManage/ContractList')),'ContractList');
const CostType = r => require.ensure([], () => r(require('@/views/projectManage/CostType')),'CostType');
const InvestmentPlan = r => require.ensure([], () => r(require('@/views/Investment/InvestmentPlan')),'InvestmentPlan');
const Declare = r => require.ensure([], () => r(require('@/views/Investment/Declare')),'Declare');
const SubTotal = r => require.ensure([], () => r(require('@/views/Investment/SubTotal')),'SubTotal');
const EditionManagement = r => require.ensure([], () => r(require('@/views/Investment/EditionManagement')),'EditionManagement');
const PlanProjectDetail = r => require.ensure([], () => r(require('@/views/Investment/PlanProjectDetail')),'PlanProjectDetail');
const CheckNewProject = r => require.ensure([], () => r(require('@/views/Investment/CheckNewProject')),'CheckNewProject');
const CheckNewPlan = r => require.ensure([], () => r(require('@/views/Investment/CheckNewPlan')),'CheckNewPlan');
const DepartmentLimits = r => require.ensure([], () => r(require('@/views/limits/DepartmentLimits')),'DepartmentLimits');
const LimitsApply = r => require.ensure([], () => r(require('@/views/limits/LimitsApply')),'LimitsApply');

const ProcurementList = r => require.ensure([], () => r(require('@/views/procurement/ProcurementList')),'ProcurementList');
const BusinessNegotiationDetail = r => require.ensure([], () => r(require('@/views/procurement/BusinessNegotiationDetail')),'BusinessNegotiationDetail');
const BusinessNegotiationAdd = r => require.ensure([], () => r(require('@/views/procurement/BusinessNegotiationAdd')),'BusinessNegotiationAdd');
const TenderingDetail = r => require.ensure([], () => r(require('@/views/procurement/TenderingDetail')),'TenderingDetail');
const TenderingAdd = r => require.ensure([], () => r(require('@/views/procurement/TenderingAdd')),'TenderingAdd');
const ComparisoDetail = r => require.ensure([], () => r(require('@/views/procurement/ComparisoDetail')),'ComparisoDetail');
const ComparisoAdd = r => require.ensure([], () => r(require('@/views/procurement/ComparisoAdd')),'ComparisoAdd');
const ResourceList = r => require.ensure([], () => r(require('@/views/ResourceManage/ResourceList')),'ResourceList');
const ResourceDetail = r => require.ensure([], () => r(require('@/views/ResourceManage/ResourceDetail')),'ResourceDetail');
const ResourceAdd = r => require.ensure([], () => r(require('@/views/ResourceManage/ResourceAdd')),'ResourceAdd');
const ShowEquipment = r => require.ensure([], () => r(require('@/views/procurement/ShowEquipment')),'ShowEquipment');

const OperationMenu = r => require.ensure([], () => r(require('@/components/operation/Menu')),'OperationMenu');
const Kyprocess = r => require.ensure([], () => r(require('@/views/process/Kyprocess')),'Kyprocess');
const DealtList = r => require.ensure([], () => r(require('@/views/dealt/DealtList')),'DealtList');
const ProcessList = r => require.ensure([], () => r(require('@/views/dealt/ProcessList')),'ProcessList');
// wjq
const ProcessDesign = r => require.ensure([], () => r(require('@/views/supplier/processDesign')),'ProcessDesign');


// wjq --- new routers sortManager
const SupplierManager = r => require.ensure([], () => r(require('@/views/supplier/supplierManager')),'SupplierManager');
const BusinessManager = r => require.ensure([], () => r(require('@/views/supplier/businessManager')),'BusinessManager');
const SortManager = r => require.ensure([], () => r(require('@/views/supplier/sortManager')),'SortManager');
const Add = r => require.ensure([], () => r(require('@/views/supplier/sortComponents/add')),'Add');

Vue.use(Router)

// 路径
const routes = [
  {
    path: '/',
    name: 'Retroaction',
    component: Retroaction,
    meta: { title: '需求反馈' },
    redirect: '/retroaction',
  },
  {
    name: 'supplier',
    path: '/supplier',
    component: SupplierManager,
    meta: {
      title: '供应商',
      index:1
    }
  },
  {
    name: 'business',
    path: '/business',
    component: BusinessManager,
    meta: {
      title: '企业上报',
      index:1
    }
  },
  {
    name: 'sortManager',
    path: '/sortManager',
    component: SortManager,
    meta: {
      title: '项目分类管理',
      index:1
    }
  },
  {
    name: 'add',
    path: '/add',
    component: Add,
    meta: {
      title: '项目分类管理',
      index:1
    }
  },
  {
    name: 'Summary',
    path: '/summary',
    component: Summary,
    meta: {
      title: '需求上报',
      index:1
    }
  },
  {
    name: 'Retroaction',
    path: '/retroaction',
    component: Retroaction,
    meta: {
      title: '需求反馈1',
      index:1
    }
  },
  {
    name: 'PlanCheck',
    path: '/plan-check',
    component: PlanCheck,
    meta: {
      title: '建议计划查询',
      index:1
    }
  },
  {
    name: 'PlanReport',
    path: '/plan-report',
    component: PlanReport,
    meta: {
      title: '建议需求反馈1',
      index:1
    }
  },

  {
    name: 'Gather',
    path: '/gather',
    component: Gather,
    meta: {
      title: '需求汇总',
      index:1
    }
  },
  {
    name: 'FeedBack',
    path: '/feed-back',
    component: FeedBack,
    meta: {
      title: '需求反馈',
      index:1
    }
  },
  {
    name: 'PlanPlate',
    path: '/plan-plate',
    component: PlanPlate,
    meta: {
      title: '按建设性质和板块统计',
      index:1
    }
  },
  {
    name: 'PlanClassify',
    path: '/plan-classify',
    component: PlanClassify,
    meta: {
      title: '总部信息化投资计划',
      index:1
    }
  },
  {
    name: 'RightError',
    path: '/right-error',
    component: RightError,
    meta: {
      title: '没有设置权限',
      index:1
    }
  },
  {
    name: 'PlanReview',
    path: '/plan-review',
    component: PlanReview,
    meta: {
      title: '年度建议计划复核',
      index:1
    }
  },
  {
    name: 'PlanSummary',
    path: '/plan-summary',
    component: PlanSummary,
    meta: {
      title: '年度建议计划汇总',
      index:1
    }
  },
   {
     name: 'PlanClassify2',
    path: '/plan-classify2',
     component: PlanClassify2,
     meta: {
     title: '各事业部(专业公司)投资建议计划',
      index:1
    }
   },
  {
    name: 'PlanChannel',
    path: '/plan-channel',
    component: PlanChannel,
    meta: {
      title: '按投资渠道统计',
      index:1
    }
  },
  {
    name: 'InvestRelease',
    path: '/invest-release',
    component: InvestRelease,
    meta: {
      title: '投资下达和完成情况',
      index:1
    }
  },
  {
    name: 'InvestReport',
    path: '/invest-report',
    component: InvestReport,
    meta: {
      title: '上报与确认',
      index:1
    }
  },
  {
    name: 'InvestSummary',
    path: '/invest-summary',
    component: InvestSummary,
    meta: {
      title: '汇总与发布',
      index:1
    }
  },
  {
    name: 'ProjectQuotas',
    path: '/project-quotas',
    component: ProjectQuotas,
    meta: {
      title: '编制阶段',
      index:1
    }
  },
  {
    name: 'ProjectRate',
    path: '/project-rate',
    component: ProjectRate,
    meta: {
      title: '项目形象进度管理',
      index:1
    }
  },
  {
    name: 'ProjectCard',
    path: '/project-card',
    component: ProjectCard,
    meta: {
      title: '项目卡片',
      index:1
    }
  },
  {
    name: 'ProjectCard',
    path: '/project-card',
    component: ProjectCard,
    meta: {
      title: '项目卡片',
      index:1
    }
  },
  {
    name: 'ProjectApprove',
    path: '/project-approve',
    component: ProjectApprove,
    meta: {
      title: '审批页面',
      index:1
    }
  },
  {
    name: 'ProjectBatch',
    path: '/project-batch',
    component: ProjectBatch,
    meta: {
      title: '批次申请',
      index:1
    }
  },
  {
    name: 'ProLibrary',
    path: '/pro-library',
    component: ProLibrary,
    meta: {
      title: '正式项目库',
      index:1
    }
  },
  {
    name: 'ReportReply',
    path: '/report-reply',
    component: ReportReply,
    meta: {
      title: '上报与批复',
      index:1
    }
  },
  {
    name: 'DictList',
    path: '/dict-list',
    component: DictList,
    meta: {
      title: '字典表',
      index:1
    }
  },
  {
    name: 'ContractIf',
    path: '/contract-if',
    component: ContractIf,
    meta: {
      title: '项目合同',
      index:1
    }
  },
  {
    name: 'CostIf',
    path: '/cost-if',
    component: CostIf,
    meta: {
      title: '费用合同',
      index:1
    }
  },
  {
    name: 'ProjectContract',
    path: '/project-contract',
    component: ProjectContract,
    meta: {
      title: '项目合同',
      index:1
    }
  },
  {
    name: 'AddProjectContract',
    path: '/add-contract',
    component: AddProjectContract,
    meta: {
      title: '项目合同新增',
      index:2
    }
  },
  {
    name: 'CostContract',
    path: '/cost-contract',
    component: CostContract,
    meta: {
      title: '费用合同',
      index:1
    }
  },
  {
    name: 'ContractDetail',
    path: '/contract-detial',
    component: ContractDetail,
    meta: {
      title: '费用合同详情',
      index:1
    }
  },
  // {
  //   name: 'UserList',
  //   path: '/user-list',
  //   component: UserList,
  //   meta: {
  //     title: '用户列表测试',
  //     index:1
  //   }
  // },
  // {
  //   name: 'List',
  //   path: '/list',
  //   component: List,
  //   meta: {
  //     title: '列表',
  //     index:1
  //   }
  // },
  // {
  //   name: 'Collapse',
  //   path: '/Collapse',
  //   component: Collapse,
  //   meta: {
  //     title: '折叠',
  //     index:1
  //   }
  // },

  //费用预算
  {
    name: 'ReportEdit',
    path: '/report-edit',
    component: ReportEdit,
    meta: {
      title: '编辑费用预算',
      index:2
    }
  },
  {
    name: 'ReportAdd',
    path: '/report-add',
    component: ReportAdd,
    meta: {
      title: '添加费用预算',
      index:2
    }
  },
  {
    name: 'Quotas',
    path: '/quotas',
    component: Quotas,
    meta: {
      title: '年度费用预算编制',
      index:1
    }
  },
  {
    name: 'QuotasEdit',
    path: '/quotas-edit',
    component: QuotasEdit,
    meta: {
      title: '年度费用预算编制编辑(上报)',
      index:2
    }
  },
  {
    name: 'VersionEdit',
    path: '/version-edit',
    component: VersionEdit,
    meta: {
      title: '各版本编辑',
      index:2
    }
  },
  {
    name: 'QuotasAdd',
    path: '/quotas-add',
    component: QuotasAdd,
    meta: {
      title: '年度费用预算编制添加(上报)',
      index:2
    }
  },
 /* {
    name: 'VersionAdd',
    path: '/version-add',
    component: VersionAdd,
    meta: {
      title: '各版本添加',
      index:2
    }
  },*/
  {
    name: 'QuotasVersion',
    path: '/quotas-ve',
    component: QuotasVersion,
    meta: {
      title: '年度费用预算-汇总（各版本）',
      index:1
    }
  },
  {
    name: 'QuotasVersionDetail',
    path: '/version-detail',
    component: QuotasVersionDetail,
    meta: {
      title: '年度费用预算-汇总（各版本）明细（二级）',
      index:1
    }
  },
  {
    name: 'QuotasReport',
    path: '/quotas-rp',
    component: QuotasReport,
    meta: {
      title: '年度费用预算-汇总（各处室上报）',
      index:1
    }
  },
  {
    name: 'QuotasReportDetail',
    path: '/report-detail',
    component: QuotasReportDetail,
    meta: {
      title: '年度费用预算-汇总（各处室上报）明细（二级）',
      index:1
    }
  },
  {
    name: 'ReportList',
    path: '/report-list',
    component: ReportList,
    meta: {
      title: '各处室上报列表',
      index:1
    }
  },
  {
    name: 'DepartmentCheck',
    path: '/department-check',
    component: DepartmentCheck,
    meta: {
      title: '各处室查看各处室上报查看',
      index:1
    }
  },
  {
    name: 'SubmissionPlan',
    path: '/submission-plan',
    component: SubmissionPlan,
    meta: {
      title: '报送建议计划',
      index:1
    }
  },
  {
    name: 'SubmissionHistory',
    path: '/sub-history',
    component: SubmissionHistory,
    meta: {
      title: '报送建议计划(历史记录)',
      index:1
    }
  },
  {
    name: 'EditSubmission',
    path: '/sub-edit',
    component: EditSubmission,
    meta: {
      title: '报送建议计划(历史记录)',
      index:1
    }
  },
  {
    name: 'ProjectOneVersion',
    path: '/project-one',
    component: ProjectOneVersion,
    meta: {
      title: '项目一处版本',
      index:1
    }
  },
  {
    name: 'GatherVersion',
    path: '/gather-version',
    component: GatherVersion,
    meta: {
      title: '汇总版本',
      index:1
    }
  },
  {
    name: 'ManageVersion',
    path: '/manage-version',
    component: ManageVersion,
    meta: {
      title: '综合管理处版本',
      index:1
    }
  },
  {
    name: 'Supplementary',
    path: '/supplementary-project',
    component: Supplementary,
    meta: {
      title: '追加项目计划',
      index:1
    }
  },
  {
    name: 'EditSupplementary',
    path: '/edit-supplementary',
    component: EditSupplementary,
    meta: {
      title: '编辑正式项目计划',
      index:1
    }
  },
  {
    name: 'NewSubmission',
    path: '/new-submission',
    component: NewSubmission,
    meta: {
      title: '编辑建议项目计划（新开）',
      index:1
    }
  },
  {
    name: 'continuSubmission',
    path: '/continu-submission',
    component: continuSubmission,
    meta: {
      title: '编辑建议项目计划（续建）',
      index:1
    }
  },
  {
    name: 'ContractList',
    path: '/contract-list',
    component: ContractList,
    meta: {
      title: '项目合同管理列表',
      index:1
    }
  },
  {
    name: 'CostType',
    path: '/cost-type',
    component: CostType,
    meta: {
      title: '费用合同管理列表',
      index:1
    }
  },
  {
    name: 'Declare',
    path: '/declare',
    component: Declare,
    meta: {
      title: '申报列表',
      index:1
    }
  },
  {
    name: 'SubTotal',
    path: '/sub-total',
    component: SubTotal,
    meta: {
      title: '分类汇总',
      index:1
    }
  },
  {
    name: 'EditionManagement',
    path: '/edition-management',
    component: EditionManagement,
    meta: {
      title: '编制版本管理',
      index:1
    }
  },
  {
    name: 'PlanProjectDetail',
    path: '/plan-detail',
    component: PlanProjectDetail,
    meta: {
      title: '计划处编制（项目明细）',
      index:1
    }
  },
  {
    name: 'CheckNewProject',
    path: '/check-new',
    component: CheckNewProject,
    meta: {
      title: '各处室申报（查看新开/续建项目）',
      index:1
    }
  },
  {
    name: 'CheckNewPlan',
    path: '/check-plan',
    component: CheckNewPlan,
    meta: {
      title: '计划处编制（查看新开/续建项目）',
      index:1
    }
  },
  {
    name: 'DepartmentLimits',
    path: '/limits',
    component: DepartmentLimits,
    meta: {
      title: '处室权限申请处理-代办',
      index:1
    }
  },
  {
    name: 'LimitsApply',
    path: '/limits-apply',
    component: LimitsApply,
    meta: {
      title: '权限申请处理',
      index:1
    }
  },
  {
    name: 'InvestmentPlan',
    path: '/investment-plan',
    component: InvestmentPlan,
    meta: {
      title: '投资计划',
      index:1
    }
  },

  {
    name: 'ResourceList',
    path: '/resource-list',
    component: ResourceList,
    meta: {
      title: '资源管理',
      index:1
    }
  },

  {
    name: 'ResourceDetail',
    path: '/resource-detail',
    component: ResourceDetail,
    meta: {
      title: '资源管理详情',
      index:1
    }
  },
  {
    name: 'ResourceAdd',
    path: '/resource-add',
    component: ResourceAdd,
    meta: {
      title: '资源管理新增',
      index:1
    }
  },
  {
    name: 'ShowEquipment',
    path: '/show-equipment',
    component: ShowEquipment,
    meta: {
      title: '管理设备',
      index:1
    }
  },
  {
    name: 'ProcurementList',
    path: '/procurement-list',
    component: ProcurementList,
    meta: {
      title: '采购管理',
      index:1
    }
  },
  {
    name: 'BusinessNegotiationAdd',
    path: '/business-add',
    component: BusinessNegotiationAdd,
    meta: {
      title: '商务谈判新增编辑',
      index:1
    }
  },
  {
    name: 'BusinessNegotiationDetail',
    path: '/business-detail',
    component: BusinessNegotiationDetail,
    meta: {
      title: '商务谈判详情',
      index:1
    }
  },
  {
    name: 'TenderingDetail',
    path: '/tendering-detail',
    component: TenderingDetail,
    meta: {
      title: '招投标详情',
      index:1
    }
  },
  {
    name: 'TenderingAdd',
    path: '/tendering-add',
    component: TenderingAdd,
    meta: {
      title: '招投标新增和编辑',
      index:1
    }
  },
  {
    name: 'ComparisoDetail',
    path: '/compariso-detail',
    component: ComparisoDetail,
    meta: {
      title: '询比价详情',
      index:1
    }
  },
  {
    name: 'ComparisoAdd',
    path: '/compariso-add',
    component: ComparisoAdd,
    meta: {
      title: '询比价新增编辑',
      index:1
    }
  },
  {
    name: 'OperationMenu',
    path: '/operation-menu',
    component: OperationMenu,
    meta: {
      title: '测试组件',
      index:1
    }
  },
  {
    name: 'Kyprocess',
    path: '/ky-process',
    component: Kyprocess,
    meta: {
      title: '可研流程图',
      index:1
    }
  },
  {
    name: 'DealtList',
    path: '/dealt-list',
    component: DealtList,
    meta: {
      title: '待办列表',
      index:1
    }
  },
  {
    name: 'ProcessList',
    path: '/process-list',
    component: ProcessList,
    meta: {
      title: '流程列表',
      index:1
    }
  },
  {
    name: 'design',
    path: '/design',
    component: ProcessDesign,
    meta: {
      title: '流程定义分类',
      index:1
    }
  },
  {
    name: 'ReportAddCopy',
    path: '/report-addCopy',
    component: ReportAddCopy,
    meta: {
      title: '添加费用预算',
      index:2
    }
  },




]

const router = new Router({
  routes,
  mode: 'hash'
});

export default router
