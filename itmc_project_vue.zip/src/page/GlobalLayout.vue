<template>
  <div>
    <div id="components-layout-demo-custom-trigger" >
      <span class="logo" style="height: 59px; display: flex;"><span style="display: inline-block; overflow: hidden; width: 160px;"><img src="@/assets/logonew3.png" alt=""></span>
      <span style="width: 1px;background: rgba(255, 255, 255, 0.5);height: 37px;margin-top: 12px;margin-left: 8px;"></span>
      <h1>IT协同管控与服务</h1>
      <span  class="headerRt" style="display: inline-block;float: right;padding: 0 20px;position: absolute;right: 0;color: #ffffff">
        <span id="search" style="height:25px;box-sizing: border-box">
          <a-input-search
            placeholder="请输入搜索内容"
            style="width: 200px"
            @search=""
          />
        </span>
        <!--<span class="header-notice action">
          <span class="ant-badge"><i class="anticon anticon-bell" style="font-size: 16px; padding: 4px;"><svg
              viewBox="64 64 896 896" data-icon="bell" width="1em" height="1em" fill="currentColor" aria-hidden="true"
              class=""><path d="M816 768h-24V428c0-141.1-104.3-257.7-240-277.1V112c0-22.1-17.9-40-40-40s-40 17.9-40 40v38.9c-135.7 19.4-240 136-240 277.1v340h-24c-17.7 0-32 14.3-32 32v32c0 4.4 3.6 8 8 8h216c0 61.8 50.2 112 112 112s112-50.2 112-112h216c4.4 0 8-3.6 8-8v-32c0-17.7-14.3-32-32-32zM512 888c-26.5 0-48-21.5-48-48h96c0 26.5-21.5 48-48 48zM304 768V428c0-55.6 21.6-107.8 60.9-147.1S456.4 220 512 220c55.6 0 107.8 21.6 147.1 60.9S720 372.4 720 428v340H304z"></path></svg></i><sup
              title="12" class="ant-scroll-number ant-badge-count ant-badge-multiple-words" data-show="true"><span
              class="ant-scroll-number-only" style="transition: none; transform: translateY(-1100%);"><p
              class="">0</p><p class="">1</p><p class="">2</p><p class="">3</p><p class="">4</p><p class="">5</p><p
              class="">6</p><p class="">7</p><p class="">8</p><p class="">9</p><p class="">0</p><p class="current">1</p><p
              class="">2</p><p class="">3</p><p class="">4</p><p class="">5</p><p class="">6</p><p class="">7</p><p
              class="">8</p><p class="">9</p><p class="">0</p><p class="">1</p><p class="">2</p><p class="">3</p><p
              class="">4</p><p class="">5</p><p class="">6</p><p class="">7</p><p class="">8</p><p class="">9</p></span><span
              class="ant-scroll-number-only" style="transition: none; transform: translateY(-1200%);"><p
              class="">0</p><p class="">1</p><p class="">2</p><p class="">3</p><p class="">4</p><p class="">5</p><p
              class="">6</p><p class="">7</p><p class="">8</p><p class="">9</p><p class="">0</p><p class="">1</p><p
              class="current">2</p><p class="">3</p><p class="">4</p><p class="">5</p><p class="">6</p><p class="">7</p><p
              class="">8</p><p class="">9</p><p class="">0</p><p class="">1</p><p class="">2</p><p class="">3</p><p
              class="">4</p><p class="">5</p><p class="">6</p><p class="">7</p><p class="">8</p><p class="">9</p></span></sup></span>
        </span>-->
            <span class="action action-full ant-dropdown-link user-dropdown-menu ant-dropdown-trigger"><span
              class="avatar ant-avatar ant-avatar-sm ant-avatar-circle ant-avatar-image"
              style="position: relative;margin-right: 10px;top:-3px;color: #000;background: #ffffff;height: 30px;width: 30px">
              <!--{{userJP}}-->
               <img src="../assets/people.png" alt="" style="margin-left: 0;top:0;height: 30px;">
            </span>
            <span>
              {{userInfo.userName}}
              <!--张婕-->
            </span>
            </span>
            <span class="action"><i class="anticon anticon-question-circle-o"><svg viewBox="64 64 896 896" data-icon="question-circle"  width="1em" height="1em" fill="currentColor" aria-hidden="true" class=""><path d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm0 820c-205.4 0-372-166.6-372-372s166.6-372 372-372 372 166.6 372 372-166.6 372-372 372z"></path><path
              d="M623.6 316.7C593.6 290.4 554 276 512 276s-81.6 14.5-111.6 40.7C369.2 344 352 380.7 352 420v7.6c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8V420c0-44.1 43.1-80 96-80s96 35.9 96 80c0 31.1-22 59.6-56.1 72.7-21.2 8.1-39.2 22.3-52.1 40.9-13.1 19-19.9 41.8-19.9 64.9V620c0 4.4 3.6 8 8 8h48c4.4 0 8-3.6 8-8v-22.7a48.3 48.3 0 0 1 30.9-44.8c59-22.7 97.1-74.7 97.1-132.5.1-39.3-17.1-76-48.3-103.3zM472 732a40 40 0 1 0 80 0 40 40 0 1 0-80 0z"></path></svg></i></span>
            <span class="action"><a href="/project/system/loginout.do" class="logout_title" style="color: #fff!important;"><i
              class="anticon anticon-logout"><svg viewBox="64 64 896 896" data-icon="logout" width="1em" height="1em" fill="currentColor" aria-hidden="true" class=""><path
              d="M868 732h-70.3c-4.8 0-9.3 2.1-12.3 5.8-7 8.5-14.5 16.7-22.4 24.5a353.84 353.84 0 0 1-112.7 75.9A352.8 352.8 0 0 1 512.4 866c-47.9 0-94.3-9.4-137.9-27.8a353.84 353.84 0 0 1-112.7-75.9 353.28 353.28 0 0 1-76-112.5C167.3 606.2 158 559.9 158 512s9.4-94.2 27.8-137.8c17.8-42.1 43.4-80 76-112.5s70.5-58.1 112.7-75.9c43.6-18.4 90-27.8 137.9-27.8 47.9 0 94.3 9.3 137.9 27.8 42.2 17.8 80.1 43.4 112.7 75.9 7.9 7.9 15.3 16.1 22.4 24.5 3 3.7 7.6 5.8 12.3 5.8H868c6.3 0 10.2-7 6.7-12.3C798 160.5 663.8 81.6 511.3 82 271.7 82.6 79.6 277.1 82 516.4 84.4 751.9 276.2 942 512.4 942c152.1 0 285.7-78.8 362.3-197.7 3.4-5.3-.4-12.3-6.7-12.3zm88.9-226.3L815 393.7c-5.3-4.2-13-.4-13 6.3v76H488c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h314v76c0 6.7 7.8 10.5 13 6.3l141.9-112a8 8 0 0 0 0-12.6z"></path></svg></i><span>&nbsp;退出</span></a>
            </span>
          </span>
      </span>
      <div>
          <span class="header light" style="display: none">
            <a-icon
              class="trigger"
              :type="collapsed ? 'menu-unfold' : 'menu-fold'"
              @click="()=> collapsed = !collapsed"
            />
          </span>
          <span></span>
      </div>
    </div>
    <div style="width: 100%;height: 59px"></div>
    <!--display: flex;-->
    <div>
      <a-layout id="homePage" ref="homePage" style="background: #ffffff;display: flex;">
        <a-layout-sider
          v-if="!isNoRight"
          :trigger="null"
          collapsible
          v-model="collapsed"
          style="float: left;box-shadow: 0 1px 6px rgba(0,0,0,.2);"
        >
          <div style="height: 100%;">
            <a-menu
              @click="handleClick"
              @openChange="onOpenChange"
              :defaultSelectedKeys="defaultSelectedKeys"
              :openKeys="openKeys"
              mode="inline"
              theme="light"
              style="height: 100%"
            >
              <template>
                <a-sub-menu key="sub2" v-for="(item,index) in mennuResources.data" :key="forId(index,'','')">
                  <template>
                  <span slot="title">
                    <a-icon :type="item.iconUrl" v-if="item.iconUrl"/>
                    <a-icon type="appstore" v-if="!item.iconUrl"/>
                    <span>{{item.resourceName}}</span></span>
                    <template v-for="(itemInner,indexInner) in item.children">
                      <a-menu-item v-if="itemInner.children.length<=0" :key="forId(index,indexInner,'')"
                                   @click="toPage(itemInner.resourceUrl,itemInner)">{{itemInner.resourceName}}
                    </a-menu-item>
                      <a-menu-item v-else :menu-info="itemInner"   :key="forId(index,indexInner,'')"
                                   @click="thirdMenu(index,indexInner)">{{itemInner.resourceName}}
                    </a-menu-item>
                    </template>
                  </template>
                </a-sub-menu>
                <!-- <a-sub-menu key="sub41">
                  <span slot="title"><a-icon type="appstore"/><span>采购管理</span></span>
                  <a-menu-item key="45" @click="toPagePath('/procurement-list')">采购管理</a-menu-item>
                </a-sub-menu> -->
                <a-sub-menu key="sub33">
                  <span slot="title"><a-icon type="appstore"/><span>组件</span></span>
                  <a-menu-item key="36" @click="toPagePath('/operation-menu')">组件</a-menu-item>
                  <a-menu-item key="37" @click="toPagePath('/ky-process')">流程</a-menu-item>
                  <a-menu-item key="39" @click="toPagePath('/dealt-list')">待办</a-menu-item>
                  <a-menu-item key="40" @click="toPagePath('/process-list')">流程列表</a-menu-item>
                  <!-- wjq -->
                   <a-menu-item key="41" @click="toPagePath('/design')">流程设计</a-menu-item>
                </a-sub-menu>
                <!-- wjq -->
                <!--<a-sub-menu key="sub32">-->
                   <!--<span slot="title"><a-icon type="appstore"/><span>供应商人员管理</span></span>-->
                   <!--<a-menu-item key="50" @click="toPagePath('/supplier')">供应商人员列表</a-menu-item>-->
                   <!--<a-menu-item key="51" @click="toPagePath('/business')">企业上报人员管理</a-menu-item>-->
                   <!--<a-menu-item key="52" @click="toPagePath('/sortManager')">项目分类管理</a-menu-item>-->
                 <!--</a-sub-menu>-->
                <!-- <a-sub-menu key="sub34">
                  <span slot="title"><a-icon type="appstore"/><span>资产管理</span></span>
                  <a-menu-item key="38" @click="toPagePath('/resource-list')">资产管理</a-menu-item>
                </a-sub-menu>


                <a-sub-menu key="sub27">
                   <span slot="title"><a-icon type="appstore"/><span>系统管理</span></span>
                   <a-menu-item key="15" @click="toPage('/dict-list')">数据字典</a-menu-item>
                   &lt;!&ndash;<a-menu-item key="17" @click="toPagePath('/report-list')">各处室上报列表</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="30" @click="toPagePath('/quotas')">年度费用预算编制</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="31" @click="toPagePath('/declare')">申报列表</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="32" @click="toPagePath('/edition-management')">编制版本管理</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="34" @click="toPagePath('/limits')">处室权限申请处理</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="16" @click="toPagePath('/company-select')">添加企业和明细信息</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="33" @click="toPagePath('/plan-detail')">年度计划项目明细</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="18" @click="toPagePath('/quotas-rp')">年度费用预算-汇总（各处室上报）</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="19" @click="toPagePath('/quotas-ve')">年度费用预算-汇总（各版本）</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="20" @click="toPagePath('/dp-report')">各处室上报</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="21" @click="toPagePath('/quotas-add')">年度费用预算编制添加</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="22" @click="toPagePath('/quotas-edit')">年度费用预算编制编辑</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="23" @click="toPagePath('/quotas')">年度费用预算编制</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="24" @click="toPagePath('/report-edit')">编辑费用预算</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="24" @click="toPagePath('/submission-plan')">报送建议计划</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="30" @click="toPagePath('/sum-suggestion')">汇总建议计划</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="25" @click="toPagePath('/sub-edit')">编辑建议计划</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="26" @click="toPagePath('/project-one')">项目一处建议计划（版本2.0）</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="27" @click="toPagePath('/gather-version')">汇总版本</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="29" @click="toPagePath('/history-version')">历史版本</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="28" @click="toPagePath('/manage-version')">综合管理处版本（版本1.0）</a-menu-item>&ndash;&gt;
                   &lt;!&ndash;<a-menu-item key="29" @click="toPagePath('/my-test')">测试页面</a-menu-item>&ndash;&gt;
                 </a-sub-menu>
                 <a-sub-menu key="sub28">
                   <span slot="title"><a-icon type="appstore"/><span>年度费用预算</span></span>
                   <a-menu-item key="17" @click="toPagePath('/report-list')">各处室上报列表</a-menu-item>
                   <a-menu-item key="30" @click="toPagePath('/quotas')">年度费用预算编制</a-menu-item>
                 </a-sub-menu>
                 <a-sub-menu key="sub29">
                   <span slot="title"><a-icon type="appstore"/><span>年度投资计划</span></span>
                   <a-menu-item key="31" @click="toPagePath('/declare')">申报列表</a-menu-item>
                   <a-menu-item key="32" @click="toPagePath('/edition-management')">编制版本管理</a-menu-item>
                 </a-sub-menu>
                 <a-sub-menu key="sub30">
                   <span slot="title"><a-icon type="appstore"/><span>权限申请</span></span>
                   <a-menu-item key="34" @click="toPagePath('/limits')">处室权限申请处理</a-menu-item>
                 </a-sub-menu>-->
                 <!--<a-sub-menu key="sub31">-->
                   <!--<span slot="title"><a-icon type="appstore"/><span>合同管理</span></span>-->
                   <!--<a-menu-item key="35" @click="toPagePath('/project-contract')">项目合同管理</a-menu-item>-->
                   <!--<a-menu-item key="34" @click="toPagePath('/cost-contract')">费用合同管理</a-menu-item>-->
                 <!--</a-sub-menu>-->
              </template>
            </a-menu>
          </div>
        </a-layout-sider>
        <a-layout style="overflow-x: inherit;">
          <div>
            <div class="tabBox" v-show="isHasTab">
              <span class="tabBoxItem" :class="{'thirdCurrIndex':thirdCurrIndex==index}"  v-for="(item,index) in thirdTabArr" @click="thirdTabSwitch(item,index)">{{item.resourceName}}</span>
            </div>
          </div>
          <router-view style="border-left: 1px solid #e8e8e8;"/>
          <div class="tel">
            <p>Copyright © 2018中国石油化工集团有限公司 版权所有</p>
            <p>技术与运维支持:18513724331 邮箱:ye.chen@pcitc.com，
             建议使用谷歌Chrome浏览器或360浏览器</p>
          </div>
        </a-layout>
      </a-layout>
    </div>
  </div>
</template>
<script>

  import {Pinyin} from '@/utils/Pinyin'
  import {apiService} from "@/services/apiservice";
  export default {
    name: 'GlobalLayout',
    data(){
      const panes = [
        {title: '首页', content: 'Content of Tab 1', key: '1',path:''},
      ]
      return {
        clientHeight:"",
        collapsed: false,
        title: 'IT协同管控与服务',
        openKeys: ['sub27'],
        rootSubmenuKeys: ['sub2', 'sub27', 'sub28', 'sub29', 'sub30'],
        selectedKey:[],
        sideMenu: [],
        defaultSelectedKeys:['forid_0-0-'],
        selectedKeys:['forid_0-0-'],
        panes,
        activeKey: panes[0].key,
        newTabIndex: 0,
        mennuResources: '',
        thirdTabArr:[{resourceName:"系统菜单"},{resourceName:"系统菜单"},{resourceName:"系统菜单"}],
        thirdCurrIndex:0,
        isHasTab:false,
        userJP:'',
        userInfo:{userName:''},
        isNoRight: false
      }
    },
    components: {
    },
    watch: {
//      openKeys (val) {
//      },
    /*  // 如果 `clientHeight` 发生改变，这个函数就会运行
      clientHeight: function () {
        this.changeFixed(this.clientHeight)
      },
      fullHeight (val) {
        if(!this.timer) {
          this.fullHeight = val
          this.timer = true
          let that = this
          setTimeout(function (){
            that.timer = false
          },400)
        }
      }*/
    },
    mounted(){
      let _self=this
      // 获取浏览器可视区域高度
      this.clientHeight = document.documentElement.clientHeight

      document.getElementById("homePage").style.minHeight= (_self.clientHeight-61) + 'px'
   /*   setTimeout(()=>{
        console.log(_self.$refs.homePage.style.height)
        _self.$refs.homePage.style['height'] = _self.clientHeight + 'px';//document.body.clientWidth;
      },800)*/

      //console.log(self.clientHeight);
//      window.onresize = function temp() {
//        this.clientHeight = `${document.documentElement.clientHeight}`;
//      };
    },
    methods: {
//      changeFixed(clientHeight){                        //动态修改样式
//        console.log(clientHeight);
////        this.$refs.homePage.style.height = this.clientHeight + 'px';
//      },
      getOrgByOrgTypeCodes1(){
        let _self=this
        let parmasData={}
        parmasData.json=true
        apiService.getCompanyTypeList(parmasData).then(data => {
          window.dataOrg=data
          window.ParentdataOrg=_self.initTreeData(data)
        }, r => {
        }).catch(
        )
      },
      initTreeData(dataOrg){
        var resultArr=dataOrg[0]
        var secArr=[];
        for(var i=0;i<dataOrg.length;i++){
          if(dataOrg[i].orgLevelName=='板块'){
            dataOrg[i].title=dataOrg[i].orgName
            dataOrg[i].key=dataOrg[i].orgId
            dataOrg[i].children=[];
            secArr.push(dataOrg[i])
          }
        }
        resultArr.title="中国石化"
        resultArr.key="109887"
        resultArr.children=secArr
        return resultArr
      },
//      changeMenu(openKey,selectKey){
//        this.openKeys= [openKey]
//        this.selectedKeys=[selectKey]
//      },
      forId(index, index2, index3){
        return "forid_" + index + "-" + index2 + "-" + index3
      },
      getCurrentUserInfo(){
        let userParm={}
        let _self=this
        apiService.getCurrentUserInfo(userParm).then(r => {
          _self.userInfo=r.data
          if(r.data.userName){
            _self.userJP=Pinyin.GetJP(r.data.userName).slice(0,1)
          }
        }, r => {
        }).catch(
        )
      },
      getResources(){
        let _self = this
        apiService.getResources().then(r => {
          console.log(r)
          _self.mennuResources = r
          _self.openKeys= ['forid_0--']
          _self.isHasTab=false
          if(r.data){
            if(r.data[0].children[0].children.length>0){
              this.thirdMenu(0, 0)
              // _self.toPage(r.data[0].children[0].children[0].resourceUrl)
              _self.panes=[{title:r.data[0].children[0].children[0].resourceName, content: r.data[0].children[0].children[0].resourceName, key: '1',path:r.data[0].children[0].children[0].resourceUrl}]
              const panes = _self.panes
            }else{
              _self.toPage(r.data[0].children[0].resourceUrl)
              _self.panes = [
                {title:r.data[0].children[0].resourceName, content: r.data[0].children[0].resourceName, key: '1',path:r.data[0].children[0].resourceUrl},
              ]
              const panes=_self.panes
            }
          }
        }, r => {
        }).catch(
        )
      },
      thirdTabSwitch(obj,index){
          this.thirdCurrIndex=index
          this.toPage(obj.resourceUrl)
         this.isHasTab=true
      },
      thirdMenu(index1,index2){
        this.thirdTabArr=this.mennuResources.data[index1].children[index2].children
        this.toPage(this.thirdTabArr[0].resourceUrl)
        this.isHasTab=true
      },
      toPagePath(url){
        this.$router.push({path: url})
      },
      toPage(url,item){
        this.isHasTab=false
      /*  if(url=='/report-list'){
          this.$router.push({path: url})
          return
        }
        if(url=='/dict-list'){
          this.$router.push({path: url})
       //   this.add({resourceName:'数据字典',resourceUrl:'/dict-list'})
          return
        }*/
        //非iframe页面
        if(url.indexOf("/#/")!=-1){
         var currUrl = url.slice(url.indexOf('/#/') + 3)
          this.$router.push({path: currUrl})
          return
        }
        var currUrl=""
        if(url.indexOf('project/')==-1){
          currUrl='/'+url
        }else{
          currUrl = url.slice(url.indexOf('project/') + 7)
        }

        var rtUrl = ""
        switch (currUrl) {
          case '/enterpries/edemandreport/eDemandReport.html':
            rtUrl = "/summary";
            break;
          case '/headquarters/mdemandcheck/mDemandCheck.html':
            rtUrl = "/retroaction";
            break;
          case '/enterpries/eplansearch/ePlanSearch.html':
            rtUrl = "/plan-check";
            break;
          case '/enterpries/eplanreprot/ePlanReport.html':
            rtUrl = "/plan-report";
            break;
          case '/headquarters/mplanstatistic/mBuildPlatStats.html':
            rtUrl = "/plan-plate";
            break;
          case '/headquarters/mplancheck/mPlanCheck.html':
            rtUrl = "/plan-review";
            break;
          case '/headquarters/mplanstatistic/mPlatClassStats.html':
            rtUrl = "/plan-classify";
            break;
          case '/userAuthApply/userApply.html':
            this.isNoRight = true;
            rtUrl = "/right-error";
            break;
          case '/headquarters/mplanstatistic/mPlatClassStatsSyb.html':
            rtUrl = "/plan-classify2";
            break;
          case '/headquarters/mplancollect/mPlanCollect.html':
            rtUrl = "/plan-summary";
            break;
          case '':
            rtUrl = "/plan-channel";
            break;
          case '/investmentBatchPlanManagement/allocationAndCompletion/tableList.html':
            rtUrl = "/invest-release";
            break;
          case '/investmentBatchPlanManagement/reportAndSure/indeTableList.html':
            rtUrl = "/invest-report";
            break;
          case '/investmentBatchPlanManagement/summaryAndRelease/tableList.html':
            rtUrl = "/invest-summary";
            break;
          case '/projectMileStone/apply.html':
            rtUrl = "/project-batch";
            break;
          case '/projectMileStone/compilationStage.html':
            rtUrl = "/project-quotas";
            break;
          case '/projectMileStone/projectMileStone.html':
            rtUrl = "/project-rate";
            break;
          case '/projectMileStone/projectCardPage.html':
            rtUrl = "/project-card";
            break;
          case '/projectMileStone/projectApproval.html':
            rtUrl = "/project-approve";
            break;
          case '/enterpries/proapprovalmanage/proLibrary.html':
            rtUrl = "/pro-library";
            break;
          case '/enterpries/proapprovalmanage/ReportUpAndReply.html':
            rtUrl = "/report-reply";
            break;
          case '/contractManagement/SPA/tableList.html':
            rtUrl = "/cost-if";
            break;
          case '/contractManagement/CPAF/tableList.html':
            rtUrl = "/contract-if";
            break;
          case '/headquarters/mdemandcollect/mDemandCollect.html':
            rtUrl = "/gather";
            break;

        }
        this.$router.push({path: rtUrl})
      },
     /* tabToPage(url){
        this.isHasTab=false
        if(url=='/dict-list'){
          this.$router.push({path: url})
          return
        }
        var currUrl=""
        if(url.indexOf('project/')==-1){
          currUrl=url
        }else{
          currUrl = url.slice(url.indexOf('project/') + 7)
        }

        var rtUrl = ""
        switch (currUrl) {
          case '/enterpries/edemandreport/eDemandReport.html':
            rtUrl = "/summary";
            break;
          case '/headquarters/mdemandcheck/mDemandCheck.html':
            rtUrl = "/retroaction";
            break;
          case '/enterpries/eplansearch/ePlanSearch.html':
            rtUrl = "/plan-check";
            break;
          case '/enterpries/eplanreprot/ePlanReport.html':
            rtUrl = "/plan-report";
            break;
          case '/headquarters/mplanstatistic/mBuildPlatStats.html':
            rtUrl = "/plan-plate";
            break;
          case '/headquarters/mplancheck/mPlanCheck.html':
            rtUrl = "/plan-review";
            break;
          case '/headquarters/mplanstatistic/mPlatClassStats.html':
            rtUrl = "/plan-classify";
            break;
          case '/headquarters/mplancollect/mPlanCollect.html':
            rtUrl = "/plan-summary";
            break;
          case '':
            rtUrl = "/plan-channel";
            break;
          case '/investmentBatchPlanManagement/allocationAndCompletion/tableList.html':
            rtUrl = "/invest-release";
            break;
          case '/investmentBatchPlanManagement/reportAndSure/indeTableList.html':
            rtUrl = "/invest-report";
            break;
          case '/investmentBatchPlanManagement/summaryAndRelease/tableList.html':
            rtUrl = "/invest-summary";
            break;
          case '/projectMileStone/apply.html':
            rtUrl = "/project-batch";
            break;
          case '/projectMileStone/compilationStage.html':
            rtUrl = "/project-quotas";
            break;
          case '/projectMileStone/projectMileStone.html':
            rtUrl = "/project-rate";
            break;
          case '/projectMileStone/projectCardPage.html':
            rtUrl = "/project-card";
            break;
          case '/projectMileStone/projectApproval.html':
            rtUrl = "/project-approve";
            break;
          case '/enterpries/proapprovalmanage/proLibrary.html':
            rtUrl = "/pro-library";
            break;
          case '/enterpries/proapprovalmanage/ReportUpAndReply.html':
            rtUrl = "/report-reply";
            break;
          case '/contractManagement/SPA/tableList.html':
            rtUrl = "/cost-if";
            break;
          case '/contractManagement/CPAF/tableList.html':
            rtUrl = "/contract-if";
            break;
          case '/headquarters/mdemandcollect/mDemandCollect.html':
            rtUrl = "/gather";
            break;

        }
        this.$router.push({path: rtUrl})
      },*/
      handleClick (e) {
      },
      titleClick (e) {
      },
      onOpenChange (openKeys) {
        this.openKeys =[openKeys[openKeys.length-1]]
//          const latestOpenKey = openKeys.find(key => this.openKeys.indexOf(key) === -1)
//          if (this.rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
//            this.openKeys = openKeys
//          } else {
//            this.openKeys = latestOpenKey ? [latestOpenKey] : []
//          }
      },
      callback (key) {
      },
      onEdit (targetKey, action) {
        this[action](targetKey)
      },
      clickTab(targetKey, action){
         this.tabToPage(this.panes[targetKey].path)
      },
      add (item) {
          const panes = this.panes
          const activeKey = this.newTabIndex++
          panes.push({title:item.resourceName, content:item.resourceName, key: activeKey,'path': item.resourceUrl})
          this.panes = panes
          this.activeKey = activeKey
      },
      remove (targetKey) {
        let activeKey = this.activeKey
        let lastIndex
        this.panes.forEach((pane, i) => {
          if (pane.key === targetKey) {
            lastIndex = i - 1
          }
        })
        if(lastIndex==-1){
          this.$message.info('最后一个不可以删除');
          return
        }
        const panes = this.panes.filter(pane => pane.key !== targetKey)
        if (lastIndex >= 0 && activeKey === targetKey) {
          activeKey = panes[lastIndex].key
        }
        this.panes = panes
        this.activeKey = activeKey
        this.tabToPage(this.panes[activeKey].path)
      },
    },
    created() {
      this.getResources()
      this.getCurrentUserInfo()
      // this.getOrgByOrgTypeCodes1()//模拟后台企业名称接口
    },

  }
</script>
<style>
  #components-layout-demo-custom-trigger .trigger {
    font-size: 18px;
    line-height: 50px;
    padding: 0 24px;
    cursor: pointer;
    transition: color .3s;
  }

  #components-layout-demo-custom-trigger {
    /*height: 100%;*/
    box-shadow: 0 1px 6px rgba(0,0,0,.8);
    margin-bottom: 5px;
    position: fixed;
    width: 100%;
    z-index: 100;
  }

  #components-layout-demo-custom-trigger .trigger:hover {
    color: #ffffff;
  }

  #components-layout-demo-custom-trigger .logo {
    line-height: 58px;
    height: 58px;
    /*background-color: rgb(16, 110, 190);*/
    background-image: linear-gradient(143deg, #4a5fc3 20%, rgb(24, 144, 255) 81%, rgb(24, 144, 255));
  }

  #components-layout-demo-custom-trigger .logo h1 {
    color: #ffffff;
    font-weight: 600;
    font-size: 16px;
    margin-left: 15px;
    letter-spacing: 2px;
  }

  .ant-layout-header {
    z-index: 2;
    color: white;
    height: 59px;
    -webkit-transition: background 300ms;
    transition: background 300ms;
  }

  .ant-layout-sider {
    /*background-color: #1890ff !important;*/
    background:#ffffff!important;
  }

  .logo img {
    height: 63px;
    margin-left: 13px;
    position: relative;
    top: -4px;
  }


  .ant-layout-header .trigger:hover {
    background: rgba(255, 255, 255, 0.3);
  }


  .ant-tabs.ant-tabs-card .ant-tabs-card-bar .ant-tabs-tab {
    border: none;
    background: #ffffff;
  }

  .ant-tabs-bar {
    margin: 0 20px;
    border: none;
  }

  .ant-layout.ant-layout-has-sider > .ant-layout, .ant-layout.ant-layout-has-sider > .ant-layout-content {
    overflow-x: initial;
  }

  .luser-wrapper .action {
    cursor: pointer;
    padding: 0 14px;
    display: inline-block;
    -webkit-transition: all .3s;
    transition: all .3s;
    height: 70%;
    line-height: 46px;
  }

  .headerRt > span {
    padding: 10px 10px;
    cursor: pointer;
  }

  .headerRt > span:hover {
    background: hsla(0, 0%, 100%, .3);
  }

  .ant-layout-sider-children {
    background: #ffffff;
  }

  .ant-tabs-extra-content{
    display: none;
  }

  .tabBox{
    background:#fff;
    padding:10px;
    border-bottom: 1px solid #ccc;
    /*border-left: 1px solid #ccc;*/
  }

  .tabBoxItem{
    cursor: pointer;
    color: rgba(0, 0, 0, 0.65);
    margin-left: 15px;
  }

  .tabBoxItem:hover{
    color: rgb(24, 144, 255);
  }

  .thirdCurrIndex{
    color: rgb(24, 144, 255);
  }
  .ant-menu-inline, .ant-menu-vertical, .ant-menu-vertical-left{
    border-right: none;
  }

  .ant-table-tbody>tr>td, .ant-table-thead>tr>th{
    padding: 3px 10px!important;
  }
  .ant-layout-sider-children{
    height: 100%;
    background: #ffffff!important;
  }
  .ant-layout-sider-children>div{
    height: 100%;
  }
  .ant-layout-sider-children>div ul{
    height: 100%;
  }
  .wrap{
    /*min-height: 550px;*/
    margin: 10px;
    margin-right:10px!important;
    padding:15px;
    background: #ffffff;
    border-left: 1px solid rgb(232, 232, 232);
    box-shadow: 0 1px 6px rgba(0,0,0,.2);
    height: 100%!important;
  }
  .wrapAppl {
    margin: 10px;
    border-left: 1px solid rgb(232, 232, 232);
    padding: 20px;
    background: #fff;
    box-shadow: 0 1px 6px rgba(0,0,0,.2);
    height: 100%;

  }
  .ant-input{
    height: 28px!important;
  }
  .ant-form-item-control,.ant-form-item-label{
    line-height: 28px!important;
  }
  .ant-btn-primary{
    font-weight: 700!important;
    /*color: #40a9ff!important;*/
    color: #ffffff!important;
    /*background-color: rgb(166, 209, 245)!important;*/
    background-color:rgb(0, 121, 254)!important;
    /*background: #fff!important;*/
    text-shadow:none!important;
    height: 28px!important;
  }
  .ant-menu:not(.ant-menu-horizontal) .ant-menu-item-selected{
    background: #F6F5F4 !important;
    color: rgb(0, 121, 254)!important;
  }
  .ant-menu-vertical .ant-menu-item:after, .ant-menu-vertical-left .ant-menu-item:after, .ant-menu-vertical-right .ant-menu-item:after, .ant-menu-inline .ant-menu-item:after{
    border-right: 3px solid rgb(16, 110, 190)!important;
  }
  .ant-input-suffix{
    margin-right: 10px!important;
  }
  #search .ant-input{
   height: 22px!important;
   /*background: rgb(16, 110, 190)!important;*/
    background: rgb(33, 144, 247)!important;
  }
  #search .ant-input-search-icon{
    color: #fff!important;
  }
  #search .ant-input-affix-wrapper{
    width: 255px !important;
  }
  #search .ant-input-affix-wrapper .ant-input{
    color: #ffffff !important;
  }
  #search .ant-input-affix-wrapper .ant-input::-webkit-input-placeholder { /* WebKit browsers */
    color:#F6F5F4;
  }
  :-moz-placeholder { /* Mozilla Firefox 4 to 18 */
    color:    #999;
  }
  ::-moz-placeholder { /* Mozilla Firefox 19+ */
    color:    #999;
  }
  :-ms-input-placeholder { /* Internet Explorer 10+ */
    color:    #999;
  }
  .ant-select-selection--single{
    line-height: 28px;
  }
  .ant-select-selection__rendered{
    line-height: 28px;
  }
  .ant-btn{
    border-color: rgb(0, 121, 254)!important;
    height: 28px!important;
  }
  .ant-table-thead > tr > th{
    background: #F6F5F4!important;
    font-weight: 700;
  }
  a {
    color: rgb(0, 121, 254)!important;
  }
  .ant-menu-vertical .ant-menu-item, .ant-menu-vertical-left .ant-menu-item, .ant-menu-vertical-right .ant-menu-item, .ant-menu-inline .ant-menu-item, .ant-menu-vertical .ant-menu-submenu-title, .ant-menu-vertical-left .ant-menu-submenu-title, .ant-menu-vertical-right .ant-menu-submenu-title, .ant-menu-inline .ant-menu-submenu-title{
    margin-top: 1px!important;
    margin-bottom: 1px!important;
  }
  .ant-menu-sub.ant-menu-inline > .ant-menu-item, .ant-menu-sub.ant-menu-inline > .ant-menu-submenu > .ant-menu-submenu-title{
    height: 28px !important;
    line-height: 28px !important;
  }
  .ant-menu-inline .ant-menu-submenu-title{
    font-weight: 700!important;
  }
  .ant-layout{
    min-height: 600px;
  }
  .ant-select-selection--single{
   height: 28px!important;
  }

  .ecllipsis{
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: inline-block;
  }
  .ant-modal-body{
    max-height: 400px;
    overflow-y: scroll;
  }
  .ant-modal-body::-webkit-scrollbar {/*滚动条整体样式*/
    width:5px;     /*高宽分别对应横竖滚动条的尺寸*/
    height: 1px;
  }

  .ant-modal-body::-webkit-scrollbar-thumb {/*滚动条里面小方块*/

    border-radius:3px;

    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);

    /*background: #535353;*/
    background: rgb(16, 110, 190);

  }

  .ant-modal-body::-webkit-scrollbar-track {/*滚动条里面轨道*/

    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);

    border-radius: 3px;

    background: #EDEDED;

  }
  .ant-menu-item{
    padding-left: 52px!important;
  }
  .ant-menu,.ant-form-item,.ant-input,.ant-table{
    font-family: "Microsoft YaHei", "宋体", "Arial Narrow", HELVETICA!important;
  }
  .tel {
    margin-bottom: 0.5em;
  }
  .tel p{
    text-align: center;
    line-height: 22px;
    font-size: 12px;
    margin-bottom: .2em;
  }
  .tel p a {
    cursor: default
  }
</style>
