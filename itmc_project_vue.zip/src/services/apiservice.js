import {HttpService} from './http';

export const apiService = {
  api: {
    getCurrentUserInfo:"/project/system/getCurrentUserInfo.do",
    getResources:"/project/system/getResources.do",
    getDictionary:"/project/system/getDictionary.do",
    getItmcDemandXxmmSum:"/project/mDemandCollect/getItmcDemandXxmmSum",
    getItmcDemandXxmms: "/project/mDemandCollect/getItmcDemandXxmms",
    getItmcDemandXxmmsDo:"/project/mDemandCollect/getItmcDemandXxmms.do",
    exportQyxq:"/project/mDemandCollect/exportQyxq.do",//项目需求导出
    loadOptionDepartment:"/project/mDemandCollect/exportQyxq.d", //项目需求获取部门信息
    getItmcDemandXmxxByPcode:"/hapi/project/eAnnualDemand/getItmcDemandXmxxByPcode.do",
    getChildOrgsByOrgId:"/hapi/project/org/getChildOrgsByOrgId",
    getItmcDemandXxmmCheck:"/hapi/project/mDemandCollect/getItmcDemandXxmmCheck",
    getBureaus:"/hapi/project/system/getBureaus.do",
    delProDetails:"/hapi/project/proDetails/delProDetails",
    getDictionaryFList:" /project/system/getDictionaryFList",
    updateFDictionary:" /project/system/updateFDictionary",
    deleteFDictionary:" /project/system/deleteFDictionary",
    insertFDictionary:" /project/system/insertFDictionary",
    getDictionaryList:" /project/system/getDictionaryList",
    updateDictionary:" /project/system/updateDictionary",
    deleteDictionary:" /project/system/deleteDictionary",
    insertDictionary:" /project/system/insertDictionary",
    // 业务处室年度费用预算申报页面查询
    judgeCostVersionLists:"/project/costBudget/judgeCostVersionLists",//查询年度费用预算版本信息
    getCostBudgetOfficeList:"/project/costBudget/getCostBudgetOfficeList",//各处室上报
    applyCostBudgetProject:"/project/costBudget/applyCostBudgetProject",//各处室上报申报
    getCostBudgetProjectDetails:"/project/costBudget/getCostBudgetProjectDetails",//费用预算编辑
    deleteCostBudgetProjectDetails:"/project/costBudget/deleteCostBudgetProjectDetails",//费用预算删除
    getItmcProjectTypeMenu:"/project/costBudget/getItmcProjectTypeMenu",//明细树形结构
    saveCostBudgetPlan:"/project/costBudget/saveCostBudgetPlan",//添加和编辑费用预算，保存功能
    updateCostBudgetPlan:"/project/costBudget/updateCostBudgetPlan",//修改编辑费用预算，保存功能
    getCostVersionList:"/project/costBudget/getCostVersionList",//年度费用预算编制，各版本
    getInformationCostBudgetList:"/project/costBudget/getInformationCostBudgetList",//汇总页面-初始化数据
    getItmcBeforeCostPlanList:"/project/costBudget/getItmcBeforeCostPlanList",//各处室上报查看页面初始化数据
    getCostBudgetProjectList:"/project/costBudget/getCostBudgetProjectList",//年度费用预算编制，明细
    saveCostVersion:"/project/costBudget/saveCostVersion",
    exportTemplate:"/project/costBudget/exportTemplate",
    getPlanAut:"/project/itmcAut/getPlanAut",//申报列表
    subtotal:"/project/itmcAut/subtotal",//分类汇总查询
    exportfileBudget:"/project/costBudget/exportfile",//申报列表导入
    exportfile:"/project/itmcAut/exportfile",//申报列表导入
    versionCtrolList: "/project/itmcAut/versionCtrolList",//编制版本管理
    exportVerDel:"/project/itmcAut/exportVerDel",//版本编制管理删除
    exportVersion:"/project/itmcAut/exportVersion",//版本编制管理导出
    authrReport:"/project/itmcAut/authrReport",//申报列表申报接口
    getVersionName:"/project/itmcAut/getVersionName",//select中获取版本名称
    reportFileExport:"/project/itmcAut/reportFileExport",//申报列表导出
    downloadFile:"/project/itmcAut/downloadFile",//申报列表导入下载模板
    exportWord:"/project/itmcAut/exportWord",//版本管理的导出word附件
    reportFileWord:"/project/itmcAut/reportFileWord",//申报列表点击导出
    getOrgByOrgTypeCodes:"/project/org/getOrgByOrgTypeCodes",//组织结构树信息
    saveProjectBudgetContent:"/project/costBudget/saveProjectBudgetContent",//汇总页编辑预算构成说明
    getItmcProjectTypeList:"/project/costBudget/getItmcProjectTypeList",//获取开支类型和项目名称
    updateCostProjectBudgetPlan:"/project/costBudget/updateCostProjectBudgetPlan",//修改项目类型顺序
    getItmcProjectDetailTypeList:"/project/costBudget/getItmcProjectDetailTypeList",//查看开支类型项目明细
    getItmcInfoBureaus:"/project/costBudget/getItmcInfoBureaus",//查询信息部处室
    getUserAuthApplyList:"/project/userAuthApply/getUserAuthApplyList.do",//人员信息列表
    getUserAuthApplyById:"/project/userAuthApply/getUserAuthApplyById.do",//权限申请单角色信息
    getUserAuthApplyHistoryList:"/project/userAuthApply/getUserAuthApplyHistoryList.do",//申请数据查下款
    updateApproveStatus:"/project/userAuthApply/updateApproveStatus.do",//审核接口
    getProjectDataInfo:"/project/userAuthApply/getProjectDataInfo",//获取指定项目
    saveItmcProjectDetailType:"/project/costBudget/saveItmcProjectDetailType",//添加项目明细
    //合同接口
    getItmcProjectContract:"/project/itmcProjectContract/getItmcProjectContractV2",//项目合同列表
    getProjectContract:"/project/itmcProjectContract/getProjectContract",//项目合同详情基本信息(项目合同详情)
    getContractAmountDetailList:"/project/itmcProjectContract/getContractAmountDetailList",//项目合同金额明细(项目合同详情)
    getProjectAmountDetailList: "/project/itmcProjectContract/getProjectAmountDetailList",//项目合同金额明细（项目合同详情V2）
    getContractPaymentDetailList:"/project/itmcProjectContract/getContractPaymentDetailList",//付款明细(项目合同详情)
    getItmcContractAssetsDetailList:"/project/itmcProjectContract/getItmcContractAssetsDetailList",//固定资产(项目合同详情)
    getContractBasisDetailInfo:"/project/itmcProjectContract/getContractBasisDetailInfo",//合同依据(项目合同详情)
    getContractEnclosureInfo:"/project/itmcProjectContract/getContractEnclosureInfo",//合同附件(项目合同详情)
    getPayerNameFormDic:"/project/itmcProjectContract/getPayerNameFormDic",//付款选择单位(项目合同详情)
    calculatePay:"/project/itmcProjectContract/calculatePay",//合同付款明细弹窗表格(项目合同详情)
    createBill:"/project/itmcProjectContract/createBill",//服务确认(项目合同详情)
    fuWuDianJi:"/project/itmcProjectContract/fuWuDianJi",//创建报销单(项目合同详情)
    getItmcExpenditureTypeList:"/project/itmcExpenditureType/getItmcExpenditureTypeList",//开支类型(新增费用合同)
    getItmcInvestmentSupplierList:"/project/itmcInvestmentSupplier/getItmcInvestmentSupplierList",//乙方和丙方单位名称
    getMainProjectByProjectName:"/project/itmcInvestmentSupplier/getMainProjectByProjectName",//获取项目列表
    getItmcInvestmentDevicetypeList:"/project/itmcInvestmentDevicetypeSupplier/getItmcInvestmentDevicetypeListV2",// 设备分类列表
    getInvestmentDevicedetailList:"/project/itmcProjectContract/getInvestmentDevicedetailList",// 根据设备id获取设备信息
    updateItmcProjectContract:"/project/itmcProjectContract/updateItmcProjectContract",// 根据设备id获取设备信息
    getItmcPlanFeeplanByFeeType:"/project/itmcProjectContract/getItmcPlanFeeplanByFeeType",//获取费用合同
    addItmcProjectContract:"/project/itmcProjectContract/addItmcProjectContractV2",//添加合同
    getContractCode:"/project/itmcProjectContract/getContractCode",
    updateItmcProjectContractV2:"/project/itmcProjectContract/updateItmcProjectContractV2",
    delItmcProjectContractV2:"/project/itmcProjectContract/delItmcProjectContractV2",
    getContractAmountByProjectId:"/project/itmcProjectContract/getContractAmountByProjectId",
    synchronizedContract:"/project/itmcProjectContract/synchronizedContract",
    //采购管理
    addBidding:"/project/itmcPurchase/addBidding",//添加询比价申请/招投标方案
    addNegotiation:"/project/itmcPurchase/addNegotiation",//添加商务管控
    delFileData:"/project/itmcPurchase/delFileData",//删除文件
    delItmcPurchaseList:"/project/itmcPurchase/delItmcPurchaseList",//列表的删除
    edit:"/project/itmcPurchase/edit",//招投标/询比价/商务管控编辑
    getItmcInvestmentDetail:"/project/itmcPurchase/getItmcInvestmentDetail",//查看询比价/招投标详情/商务管控详情
    getItmcInvestmentSupplier:"/project/itmcPurchase/getItmcInvestmentSupplier",//获取供应商
    getItmcPurchaseList:"/project/itmcPurchase/getItmcPurchaseList",//采购管理列表查询
    getPersonPriceByLevel:"/project/itmcPurchase/getPersonPriceByLevel",//人员级别价格"
    updateContractFile:"/project/itmcPurchase/updateContractFile",   //文件上传
    getNameS:"/project/bureaus/getNameS",   // 获取联系人列表
    getItmcInvestmentBiddingDetail:"/project/itmcPurchase/getItmcInvestmentBiddingDetail", //查看询比价/招投标详情
    getItmcInvestmentNegotiationDTODetail:"/project/itmcPurchase/getItmcInvestmentNegotiationDTODetail", //查看商务管控详情
    getSoftOrHardList:"/project/itmcPurchase/getSoftOrHardList", // 获取软硬件列表
    getBureaus1:"/project/system/getBureaus",// 谈判人员——获取处室
    getPersonLevelList:"/project/itmcPurchase/getPersonLevelList",// 通过项目类型获取人员级别列表
    editPurchaseInfo:"/project/itmcPurchase/edit",// 招投标/询比价/商务管控编辑
    geiBiddingDeviceList:"/project/itmcPurchase/geiBiddingDeviceList",// 招投标/询比价设备_中标商设备列表查询
    saveBiddingDevice:"/project/itmcPurchase/saveBiddingDevice",// 招投标/询比价设备_保存设备
    updateBiddingDevice:"/project/itmcPurchase/updateBiddingDevice",// 招投标/询比价设备_编辑修改设备
    delBiddingDevice:"/project/itmcPurchase/delBiddingDevice",// 招投标/询比价设备_根据Id删除设备
    // test企业名称
    getCompanyTypeList:"/project/org/getCompanyTypeList",//模拟获取企业名称接口
    // "common/orgTree.html",//获取企业名称

    //合同
   // getResources:"http://localhost:35516/project/system/getResources.do",
   // getItmcProjectContract:"/hapi/project/itmcProjectContract/getItmcProjectContract",//项目合同列表
    // getDictionary:"/hapi/project/system/getDictionary.do",//合同日期和合同类型
    getItmcServiceMasterDataList:"http://p3mu89.natappfree.cc/project/itmcServiceMasterDataSupplier/getItmcServiceMasterDataList",
    complete:"/project/processEngine/complete",
    rollbaskTask:"/project/processEngine/rollbaskTask",
    queryTaskList:"/project/processEngine/queryTaskList",
    nextNodeInformation:"/project/processEngine/nextNodeInformation",
    getNodeAuditorList:"/project/processEngine/getNodeAuditorList",
    getHistoricalTaskNodeList:"/project/processEngine/getHistoricalTaskNodeList",
    getTransactorList:"",//查询办理人
    deleteCostBudgetVersion:"/project/costBudget/deleteCostBudgetVersion",//删除费用预算版本
    getProcessList:"/project/processEngine/getProcessList",//查询流程列表
    getTaskDodeList:"/project/processEngine/getTaskDodeList",//查询流程所有任务节点信息
    getProcessNodeConfiguration:"/project/processEngine/getProcessNodeConfiguration",//查询流程节点配置信息
    saveProcessConfiguration:"/project/processEngine/saveProcessConfiguration",//修改流程节点配置信息

    // 文档附件相关
    getDocAndDocTypeJson:"/project/itmcDocument/getDocAndDocTypeJson",// （编辑）获取文档和文档类型
    getDocAndDocTypeUploadedJson:"/project/itmcDocument/getDocAndDocTypeUploadedJson",// （查看）获取文档和文档类型
    uploadFile:"/project/itmcDocument/uploadFile",// 获取文档和文档类型
    delDocumentById:"/project/itmcDocument/delDocumentById",// 根据文档ID删除文档
    docDownLoadFile:"/project/itmcDocument/downLoadFile",// 文档下载

    // wjq
    //供应商人员列表 接口
    getSupplierManagerList:"/project/PmDetail/getPmDetailList",
    //添加供应商人员 接口
    postSupplierSavePmDetail:"/project/PmDetail/savePmDetail",
    //企业人员列表 接口
    getEnterprisePMList:"/project/enterprisePM/getEnterprisePMList",
    //添加企业人员 接口
    postSaveEnterprisePMl:"/project/enterprisePM/saveEnterprisePM",
    //单位/所在单位id和名称 接口
    getUserInfo:"/project/enterprisePM/getUserInfo",
    //下载上传图片 接口
    getPmDetailByUuid:"/project/PmDetail/getPmDetailByUuid",
    //下载上传图片 接口
    getEnterprisePMByUuid:"/project/enterprisePM/getEnterprisePMByUuid",
    //经营管理-自主研发-一类 接口
    postBusinessConfigList:"/project/itmcBusinessConfig/getBusinessConfigList",
    //保存分类默认配置 接口
    saveBusinessConfig:"/project/itmcBusinessConfig/saveBusinessConfig",
    //步骤-任务 接口
    postBusinessStageInfo:"/project/itmcBusinessConfig/getBusinessStageInfo",
    //活动-获取流程 接口
    postFlowInfo:"/project/itmcBusinessConfig/getFlowInfo",
    //表单-URL 接口
    postBusinessFormInfo:"/project/itmcBusinessConfig/getBusinessFormInfo",
    //平台分类-性质分类-投资分类 接口
    postDictionary:"/project/system/getDictionary.do",
    //禁用-启用 接口
    updateBusinessConfigStatus:"/project/itmcBusinessConfig/updateBusinessConfigStatus",
    //树 接口
    postBusinessTypeTree:"/project/itmcBusinessConfig/getBusinessTypeTree",
  },
  // wjq

  //供应商人员列表 接口
  getSupplierManagerList(body){
    return HttpService.get(this.api.getSupplierManagerList, body, false, true)
  },
  //添加供应商人员 接口
  postSupplierSavePmDetail(body){
    return HttpService.posts(this.api.postSupplierSavePmDetail, body, false, true)
  },
  //企业人员列表 接口
  getEnterprisePMList(body){
    return HttpService.get(this.api.getEnterprisePMList, body, false, true)
  },
  //添加企业人员员 接口
  postSaveEnterprisePMl(body){
    return HttpService.posts(this.api.postSaveEnterprisePMl, body, false, true)
  },
  //单位/所在单位id和名称 接口
  getUserInfo(body){
    return HttpService.get(this.api.getUserInfo, body, false, true)
  },
  //下载上传图片 接口
  getPmDetailByUuid(body){
    let unid = body.uuid
    return HttpService.get(this.api.getPmDetailByUuid+'/'+unid, body, false, true)
  },
  //下载上传图片 接口
  getEnterprisePMByUuid(body){
    let unid = body.uuid
    return HttpService.get(this.api.getEnterprisePMByUuid+'/'+unid, body, false, true)
  },
  //经营管理-自主研发-一类 接口
  postBusinessConfigList(body){
    return HttpService.post(this.api.postBusinessConfigList, body, false, true)
  },
  //保存分类默认配置 接口
  saveBusinessConfig(body){
    return HttpService.post(this.api.saveBusinessConfig, body, false, true)
  },
  //步骤-任务 接口
  postBusinessStageInfo(body){
    return HttpService.posts(this.api.postBusinessStageInfo, body, false, true)
  },
  //活动-获取流程 接口
  postFlowInfo(body){
    return HttpService.post(this.api.postFlowInfo, body, false, true)
  },
  //表单-URL 接口
  postBusinessFormInfo(body){
    return HttpService.posts(this.api.postBusinessFormInfo, body, false, true)
  },
  //平台分类-性质分类-投资分类 接口
  postDictionary(body){
    return HttpService.posts(this.api.postDictionary, body, false, true)
  },
  //禁用-启用 接口
  updateBusinessConfigStatus(body){
    return HttpService.posts(this.api.updateBusinessConfigStatus, body, false, true)
  },
  //树 接口
  postBusinessTypeTree(body){
    return HttpService.posts(this.api.postBusinessTypeTree, body, false, true)
  },
  getCurrentUserInfo(body){
    return HttpService.postUrl(this.api.getCurrentUserInfo, body, false, true);
  },
  getResources(body){
    return HttpService.get(this.api.getResources, body, false, true);
  },
  getDictionary(body){
    return HttpService.get(this.api.getDictionary, body, false, true);
  },
  //formData
  getDictionary1(body){
    return HttpService.postUrl(this.api.getDictionary, body, false, true);
  },
  getItmcDemandXxmms(body){
    return HttpService.postUrl(this.api.getItmcDemandXxmms, body, false, true);
  },
  getItmcDemandXxmmsDo(body){
    return HttpService.postUrl(this.api.getItmcDemandXxmmsDo, body, false, true);
  },
  getItmcDemandXxmmSum(body){
    return HttpService.postUrl(this.api.getItmcDemandXxmmSum, body, false, true);
  },
  exportQyxq(body){
    return HttpService.postUrl(this.api. exportQyxq, body, false, true);
  },
  loadOptionDepartment(body){
    return HttpService.postUrl(this.api. loadOptionDepartment, body, false, true);
  },

  getItmcDemandXmxxByPcode(body){
    return HttpService.post(this.api.getItmcDemandXmxxByPcode, body, false, true);
  },
  getChildOrgsByOrgId(body){
    return HttpService.post(this.api.getChildOrgsByOrgId, body, false, true);
  },
  getItmcDemandXxmmCheck(body){
    return HttpService.post(this.api.getItmcDemandXxmmCheck, body, false, true);
  },
  getBureaus(body){
    return HttpService.post(this.api.getBureaus, body, false, true);
  },
  getBureaus1(body){ // 采购管理获取处室列表
    return HttpService.post(this.api.getBureaus1, body, false, true);
  },
  delProDetails(body){
    return HttpService.post(this.api.delProDetails, body, false, true);
  },
  getDictionaryList(body){
    return HttpService.post(this.api.getDictionaryList, body, false, true);
  },
  updateDictionary(body){
    return HttpService.post(this.api.updateDictionary, body, false, true);
  },
  // deleteDictionary(body){
  //   return HttpService.post(this.api.deleteDictionary, body, false, true);
  // },
  deleteDictionary(body){
    return HttpService.postUrl(this.api.deleteDictionary, body, false, true);
  },
  insertDictionary(body){
    return HttpService.post(this.api.insertDictionary, body, false, true);
  },
  getDictionaryFList(body){
    return HttpService.post(this.api.getDictionaryFList, body, false, true);
  },
  updateFDictionary(body){
    return HttpService.post(this.api.updateFDictionary, body, false, true);
  },
  deleteFDictionary(body){
    return HttpService.post(this.api.deleteFDictionary, body, false, true);
  },
  insertFDictionary(body){
    return HttpService.post(this.api.insertFDictionary, body, false, true);
  },

  //采购管理
  addBidding(body){
    return HttpService.post(this.api.addBidding, body, false, true);
  },
  addNegotiation(body){
    return HttpService.post(this.api.addNegotiation, body, false, true);
  },
  delFileData(body){
    return HttpService.post(this.api.delFileData, body, false, true);
  },
  delItmcPurchaseList(body){
    return HttpService.post(this.api.delItmcPurchaseList, body, false, true);
  },
  edit(body){
    return HttpService.post(this.api.edit, body, false, true);
  },
  getItmcInvestmentDetail(body){
    return HttpService.post(this.api.getItmcInvestmentDetail, body, false, true);
  },
  getItmcInvestmentBiddingDetail(body){ // 查看询比价/招投标详情
    return HttpService.post(this.api.getItmcInvestmentBiddingDetail, body, false, true);
  },
  getItmcInvestmentNegotiationDTODetail(body){ // 查看商务管控详情
    return HttpService.post(this.api.getItmcInvestmentNegotiationDTODetail, body, false, true);
  },
  getPersonLevelList(body){ // 根据项目类型获取人员级别列表
    return HttpService.posts(this.api.getPersonLevelList, body, false, true);
  },
  editPurchaseInfo(body){ // 招投标/询比价/商务管控编辑
    return HttpService.post(this.api.editPurchaseInfo, body, false, true);
  },
  geiBiddingDeviceList(body){ // 招投标/询比价设备_中标商设备列表查询
    return HttpService.post(this.api.geiBiddingDeviceList, body, false, true);
  },
  saveBiddingDevice(body){ // 招投标/询比价设备_保存设备
    return HttpService.post(this.api.saveBiddingDevice, body, false, true);
  },
  updateBiddingDevice(body){ // 招投标/询比价设备_编辑修改设备
    return HttpService.post(this.api.updateBiddingDevice, body, false, true);
  },
  delBiddingDevice(body){ // 招投标/询比价设备_根据Id删除设备
    return HttpService.postUrl(this.api.delBiddingDevice, body, false, true);
  },
  getSoftOrHardList(body){ // 获取软硬件列表
    return HttpService.post(this.api.getSoftOrHardList, body, false, true);
  },
  getItmcInvestmentSupplier(body){
    return HttpService.post(this.api.getItmcInvestmentSupplier, body, false, true);
  },
  getNameS(body){
    return HttpService.post(this.api.getNameS, body, false, true);
  },
  getItmcPurchaseList(body){
    return HttpService.post(this.api.getItmcPurchaseList, body, false, true);
  },
  getPersonPriceByLevel(body){
    return HttpService.post(this.api.getPersonPriceByLevel, body, false, true);
  },
  updateContractFile(body){
    return HttpService.post(this.api.updateContractFile, body, false, true);
  },

  // //合同
  // getResources(body){
  //    return HttpService.get(this.api.getResources, body, false, false);
  // },

  getItmcServiceMasterDataList(body){
    return HttpService.get(this.api.getItmcServiceMasterDataList, body, false, false);
  },
  // 业务处室年度费用预算申报页面查询
  getCostBudgetOfficeList(body){
    return HttpService.post(this.api.getCostBudgetOfficeList, body, false, true);
  },
  getCostBudgetProjectDetails(body){
    return HttpService.post(this.api.getCostBudgetProjectDetails, body, false, true);
  },
  deleteCostBudgetProjectDetails(body){
    return HttpService.post(this.api.deleteCostBudgetProjectDetails, body, false, true);
  },
  getItmcProjectTypeMenu(body){
    return HttpService.post(this.api.getItmcProjectTypeMenu, body, false, true);
  },
  saveCostBudgetPlan(body){
    return HttpService.post(this.api.saveCostBudgetPlan, body, false, true);
  },
  updateCostBudgetPlan(body){
    return HttpService.post(this.api.updateCostBudgetPlan, body, false, true);
  },
  getCostVersionList(body){
    return HttpService.post(this.api.getCostVersionList, body, false, true);
  },
  getInformationCostBudgetList(body){
    return HttpService.post(this.api.getInformationCostBudgetList, body, false, true);
  },
  getItmcBeforeCostPlanList(body){
    return HttpService.post(this.api.getItmcBeforeCostPlanList, body, false, true);
  },
  getCostBudgetProjectList(body){
    return HttpService.post(this.api.getCostBudgetProjectList, body, false, true);
  },
  applyCostBudgetProject(body){
    return HttpService.post(this.api.applyCostBudgetProject, body, false, true);
  },
  saveCostVersion(body){
    return HttpService.post(this.api.saveCostVersion, body, false, true);
  },
  exportTemplate(body){
    return HttpService.post(this.api.saveCostVersion, body, false, true);
  },
  subtotal(body){
    return HttpService.post(this.api.subtotal, body, false, true);
  },
  exportfile(body){
    return HttpService.post(this.api.exportfile, body, false, true);
  },
  exportfileBudget(body){
    return HttpService.post(this.api.exportfileBudget, body, false, true);
  },
  versionCtrolList(body){
    return HttpService.post(this.api.versionCtrolList, body, false, true);
  },
  getPlanAut(body){
    return HttpService.post(this.api.getPlanAut, body, false, true);
  },
  getOrgByOrgTypeCodes(body){ //form提交
    return HttpService.postForm(this.api.getOrgByOrgTypeCodes, body, false, true);
  },
  saveProjectBudgetContent(body){
    return HttpService.post(this.api.saveProjectBudgetContent, body, false, true);
  },
  exportVerDel(body){
    return HttpService.post(this.api.exportVerDel, body, false, true);
  },
  exportVersion(body){
    return HttpService.post(this.api.exportVersion, body, false, true);
  },
  authrReport(body){
    return HttpService.post(this.api.authrReport, body, false, true);
  },
  getVersionName(body){
    return HttpService.post(this.api.getVersionName, body, false, true);
  },
  reportFileExport(body){
    return HttpService.post(this.api.reportFileExport, body, false, true);
  },
  downloadFile(body){
    return HttpService.post(this.api.downloadFile, body, false, true);
  },
  exportWord(body){
    return HttpService.post(this.api.exportWord, body, false, true);
  },
  reportFileWord(body){
    return HttpService.post(this.api.reportFileWord, body, false, true);
  },
  getItmcProjectTypeList(body){
    return HttpService.post(this.api.getItmcProjectTypeList, body, false, true);
  },
  updateCostProjectBudgetPlan(body){
    return HttpService.post(this.api.updateCostProjectBudgetPlan, body, false, true);
  },
  getItmcProjectDetailTypeList(body){
    return HttpService.post(this.api.getItmcProjectDetailTypeList, body, false, true);
  },
  getItmcInfoBureaus(body){
    return HttpService.post(this.api.getItmcInfoBureaus, body, false, true);
  },
  getUserAuthApplyList(body){
    return HttpService.post(this.api.getUserAuthApplyList, body, false, true);
  },
  getUserAuthApplyById(body){
    return HttpService.post(this.api.getUserAuthApplyById, body, false, true);
  },
  getUserAuthApplyHistoryList(body){
    return HttpService.post(this.api.getUserAuthApplyHistoryList, body, false, true);
  },
  updateApproveStatus(body){
    return HttpService.post(this.api.updateApproveStatus, body, false, true);
  },
  getProjectDataInfo(body){
    return HttpService.post(this.api.getProjectDataInfo, body, false, true);
  },
  saveItmcProjectDetailType(body){
    return HttpService.post(this.api.saveItmcProjectDetailType, body, false, true);
  },
  getItmcProjectContract(body){
    return HttpService.postForm(this.api.getItmcProjectContract, body, false, true);
  },
  getProjectContract(body){
    return HttpService.get(this.api.getProjectContract, body, false, true);
  },
  getContractAmountDetailList(body){
    return HttpService.get(this.api.getContractAmountDetailList, body, false, true);
  },
  getContractPaymentDetailList(body){
    return HttpService.get(this.api.getContractPaymentDetailList, body, false, true);
  },
  getItmcContractAssetsDetailList(body){
    return HttpService.get(this.api.getItmcContractAssetsDetailList, body, false, true);
  },
  getContractBasisDetailInfo(body){
    return HttpService.get(this.api.getContractBasisDetailInfo, body, false, true);
  },
  getContractEnclosureInfo(body){
    return HttpService.get(this.api.getContractEnclosureInfo, body, false, true);
  },
  getPayerNameFormDic(body){
    return HttpService.get(this.api.getPayerNameFormDic, body, false, true);
  },
  calculatePay(body){
    return HttpService.posts(this.api.calculatePay, body, false, true);
  },
  createBill(body){
    return HttpService.get(this.api.createBill, body, false, true);
  },
  fuWuDianJi(body){
    return HttpService.post(this.api.fuWuDianJi, body, false, true);
  },
  getItmcExpenditureTypeList(body){
    return HttpService.get(this.api.getItmcExpenditureTypeList, body, false, true);
  },
  getItmcInvestmentSupplierList(body){
    return HttpService.get(this.api.getItmcInvestmentSupplierList, body, false, true);
  },
  getMainProjectByProjectName(body){
    return HttpService.get(this.api.getMainProjectByProjectName, body, false, true);
  },
  getItmcInvestmentDevicetypeList(body){
    return HttpService.get(this.api.getItmcInvestmentDevicetypeList, body, false, true);
  },
  getInvestmentDevicedetailList(body){
    return HttpService.get(this.api.getInvestmentDevicedetailList, body, false, true);
  },
  updateItmcProjectContract(body, params){
    return HttpService.dynaPost(this.api.updateItmcProjectContract, body, false, true, params);
  },
  getItmcPlanFeeplanByFeeType(body){
    return HttpService.get(this.api.getItmcPlanFeeplanByFeeType, body, false, true);
  },
  delItmcProjectContractV2(body){
    return HttpService.posts(this.api.delItmcProjectContractV2,body,false,true);
  },
  getContractAmountByProjectId(body){
    return HttpService.get(this.api.getContractAmountByProjectId,body,false,true);
  },
  synchronizedContract(body){
    return HttpService.get(this.api.synchronizedContract,body,false,true);
  },
  // test企业名称
  getCompanyTypeList(body){
    return HttpService.post(this.api.getCompanyTypeList, body, false, true);
  },
  complete(body){
    return HttpService.post(this.api.complete, body, false, true);
  },
  rollbaskTask(body){
    return HttpService.posts(this.api.rollbaskTask, body, false, true);
  },
  queryTaskList(body){
    return HttpService.post(this.api.queryTaskList, body, false, true);
  },
  getHistoricalTaskNodeList(body){
    return HttpService.posts(this.api.getHistoricalTaskNodeList, body, false, true);
  },
  getNodeAuditorList(body){
    return HttpService.post(this.api.getNodeAuditorList, body, false, true);
  },
  nextNodeInformation(body){
    return HttpService.posts(this.api.nextNodeInformation, body, false, true);
  },
  getTransactorList(body){
    return HttpService.postUrl(this.api.getTransactorList, body, false, true);
  },
  deleteCostBudgetVersion(body){
    return HttpService.post(this.api.deleteCostBudgetVersion, body, false, true);
  },
  getProcessList(body){
    return HttpService.posts(this.api.getProcessList, body, false, true);
  },
  getTaskDodeList(body){
    return HttpService.posts(this.api.getTaskDodeList, body, false, true);
  },
  getProcessNodeConfiguration(body){
    return HttpService.post(this.api.getProcessNodeConfiguration, body, false, true);
  },
  saveProcessConfiguration(body){
    return HttpService.post(this.api.saveProcessConfiguration, body, false, true);
  },
  addItmcProjectContract(body,params){
    return HttpService.dynaPost(this.api.addItmcProjectContract, body, false, true,params);
  },
  getContractCode(body){
    return HttpService.get(this.api.getContractCode,body,false,true);
  },
  updateItmcProjectContractV2(body,params){
    return HttpService.dynaPost(this.api.updateItmcProjectContractV2,body,false,true,params);
  },

  // 文档附件
  getDocAndDocTypeJson(body){ // (编辑状态)获取文档和文档类型JSON
    return HttpService.postUrl(this.api.getDocAndDocTypeJson, body, false, true);
  },
  getDocAndDocTypeUploadedJson(body){ // (查看状态)获取文档和文档类型JSON
    return HttpService.postUrl(this.api.getDocAndDocTypeUploadedJson, body, false, true);
  },
  uploadFile(body){ // 保存上传文档信息
    return HttpService.post(this.api.uploadFile, body, false, true);
  },
  delDocumentById(body){ // 根据文档ID删除文档
    return HttpService.postUrl(this.api.delDocumentById, body, false, true);
  },
  docDownLoadFile(body){ // 根据文档ID下载文档
    return HttpService.postUrl(this.api.docDownLoadFile, body, false, true);
  },
  getProjectAmountDetailList(body){
    return HttpService.get(this.api.getProjectAmountDetailList, body, false, true);
  },
  judgeCostVersionLists(body){ // 保存上传文档信息
    return HttpService.post(this.api.judgeCostVersionLists, body, false, true);
  },
};



