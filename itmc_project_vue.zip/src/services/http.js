/**
 * http service1
 */
import $ from 'jquery';
// import { Indicator } from 'mint-ui';

const hookAjax = $ => {
  if ($.hooked) {
    return;
  }
  let doc = $(document);
  $.ajaxSetup({
    global: true,
    cache: false
  });
  doc.ajaxSend(function (evt, jqXHR, opts) {
    if (opts.hasOwnProperty('async') && !opts.async) {
    }
    if (opts.showLoading) {

      $('#globalLoading').show();
      // Indicator.open({
      //   text: '加载中...',
      //   spinnerType: 'fading-circle'
      // });
    }
  });
  doc.ajaxStop(function () {
    $('#globalLoading').hide();
    // Indicator.close();
  });
  $.hooked = true;
};

const instaceHolder = {};

const getInstance = () => {
  if (!instaceHolder.instance) {
    instaceHolder.instance = new HttpService();
  }
  return instaceHolder.instance;
};

const errorHandler = r => {
  if (r.errorCode == 403) {
    console.log(r.message);
    return location.replace('#/home');
  } else if(r.errorCode == 603) {
    console.log(r.message);
  }
};

export class HttpService {
  constructor() {

  }

  _get(url, params, noCache, showLoading) {
    hookAjax($); // 之所以放在这里是因为在construct阶段，loading组件还没有渲染出来
    return new Promise((resolve, reject) => {
      $.ajax({
        url: url,
        method: 'GET',
        data: params,
        showLoading: showLoading,
        dataType: 'json',
        //cache: !noCache, // 不需要缓存了
    /*    beforeSend: function(xhr){xhr.setRequestHeader('xtoken', 'c0dabe81-dc08-444e-b3ce-c86c6d8ee18f');},*/
        success: r => {
          if (!r) {
            return reject('服务器没有返回数据');
          }
          if ('errorCode' in r && r.errorCode != 0) {
            errorHandler(r);
            return reject(r);
          }

          if ('errorCode' in r && r.errorCode == 0) {
            return resolve(r.data);
          }

          resolve(r);
        },
        error: (xhr, textStatus, error) => {
          reject(error);
        }
      })
    });
  }
 _getAddToken(url, params, noCache, showLoading,token) {
    hookAjax($); // 之所以放在这里是因为在construct阶段，loading组件还没有渲染出来
    return new Promise((resolve, reject) => {
      $.ajax({
        url: url,
        method: 'GET',
        data: params,
        showLoading: showLoading,
        dataType: 'json',
        headers:token?token:'',
        //cache: !noCache, // 不需要缓存了
        /*    beforeSend: function(xhr){xhr.setRequestHeader('xtoken', 'c0dabe81-dc08-444e-b3ce-c86c6d8ee18f');},*/
        success: r => {
          if (!r) {
            return reject('服务器没有返回数据');
          }
          if ('errorCode' in r && r.errorCode != 0) {
            errorHandler(r);
            return reject(r);
          }

          if ('errorCode' in r && r.errorCode == 0) {
            return resolve(r.data);
          }

          resolve(r);
        },
        error: (xhr, textStatus, error) => {
          reject(error);
        }
      })
    });
  }
  _post(url, body, cache, showLoading) {
    hookAjax($); // 之所以放在这里是因为在construct阶段，loading组件还没有渲染出来
    return new Promise((resolve, reject) => {
      let options = {
        url: url,
        method: 'POST',
        contentType: 'application/json; charset=UTF-8',
        data: JSON.stringify(body),
        dataType: 'json',
        showLoading: showLoading,

        //cache: cache, // 不需要缓存了
        success: r => {
          if (!r) {
            return reject('服务器没有返回数据');
          }
          if ('errorCode' in r && r.errorCode != 0) {
            errorHandler(r);
            return reject(r);
          }
          if ('errorCode' in r && r.errorCode == 0) {
            return resolve(r.data);
          }
          resolve(r);
        },
        error: (xhr, textStatus, error) => {
          reject(error);
        }
      };
      if (body._json) {
        options.contentType = 'application/json';
        delete body._json;
        options.data = JSON.stringify(body);
      }
      // if (body._html) {
      //   console.log(body)
      //   options.contentType = 'text/html;charset=utf-8';
      //   delete body._html;
      //   console.log(body)
      // }
      $.ajax(options)
    });
  }
  _posts(url, body, cache, showLoading) {
    hookAjax($); // 之所以放在这里是因为在construct阶段，loading组件还没有渲染出来
    return new Promise((resolve, reject) => {
      let options = {
        url: url,
        method: 'POST',
        data: body,
        dataType: 'json',
        showLoading: showLoading,

        //cache: cache, // 不需要缓存了
        success: r => {
          if (!r) {
            return reject('服务器没有返回数据');
          }
          if ('errorCode' in r && r.errorCode != 0) {
            errorHandler(r);
            return reject(r);
          }
          if ('errorCode' in r && r.errorCode == 0) {
            return resolve(r.data);
          }
          resolve(r);
        },
        error: (xhr, textStatus, error) => {
          reject(error);
        }
      };
      if (body._json) {
        options.contentType = 'application/json';
        delete body._json;
        options.data = JSON.stringify(body);
      }
      // if (body._html) {
      //   console.log(body)
      //   options.contentType = 'text/html;charset=utf-8';
      //   delete body._html;
      //   console.log(body)
      // }
      $.ajax(options)
    });
  }  
  _postUrl(url, body, cache, showLoading) {
    hookAjax($); // 之所以放在这里是因为在construct阶段，loading组件还没有渲染出来
    return new Promise((resolve, reject) => {
      let options = {
        url: url+'?'+body,
        method: 'POST',
        //data: JSON.stringify(body),
        dataType: 'json',
        showLoading: showLoading,

        //cache: cache, // 不需要缓存了
        success: r => {
          if (!r) {
            return reject('服务器没有返回数据');
          }
          if ('errorCode' in r && r.errorCode != 0) {
            errorHandler(r);
            return reject(r);
          }
          if ('errorCode' in r && r.errorCode == 0) {
            return resolve(r.data);
          }
          resolve(r);
        },
        error: (xhr, textStatus, error) => {
          reject(error);
        }
      };
      if (body._json) {
        options.contentType = 'application/json';
        delete body._json;
        options.data = JSON.stringify(body);
      }
      // if (body._html) {
      //   console.log(body)
      //   options.contentType = 'text/html;charset=utf-8';
      //   delete body._html;
      //   console.log(body)
      // }
      $.ajax(options)
    });
  }
  _postAddToken(url, body, cache, showLoading,token,contentType) {
    hookAjax($); // 之所以放在这里是因为在construct阶段，loading组件还没有渲染出来
    return new Promise((resolve, reject) => {
      let options = {
        url: url,
        method: 'POST',
        data: body,
        dataType: 'json',
        showLoading: showLoading,
        headers:token?token:'',
        contentType:contentType||'application/x-www-form-urlencoded',
        //cache: cache, // 不需要缓存了
        success: r => {
          if (!r) {
            return reject('服务器没有返回数据');
          }
          if ('errorCode' in r && r.errorCode != 0) {
            errorHandler(r);
            return reject(r);
          }
          if ('errorCode' in r && r.errorCode == 0) {
            return resolve(r.data);
          }
          resolve(r);
          return
        },
        error: (xhr, textStatus, error) => {
          reject(error);
          return
        }
      };
      if (body._json) {
        options.contentType = 'application/json';
        delete body._json;
        options.data = JSON.stringify(body);
      }
      // if (body._html) {
      //   console.log(body)
      //   options.contentType = 'text/html;charset=utf-8';
      //   delete body._html;
      //   console.log(body)
      // }
      $.ajax(options)
    });
  }
  //  只发送 数组或字符串
  _postText(url, body, cache, showLoading) {
    hookAjax($); // 之所以放在这里是因为在construct阶段，loading组件还没有渲染出来
    return new Promise((resolve, reject) => {
      let options = {
        url: url,
        method: 'POST',
        data: body,
        showLoading: showLoading,
        contentType: 'application/json',
        //cache: cache, // 不需要缓存了
        success: r => {
          if (!r) {
            return reject('服务器没有返回数据');
          }
          if ('errorCode' in r && r.errorCode != 0) {
            errorHandler(r);
            return reject(r);
          }
          if ('errorCode' in r && r.errorCode == 0) {
            return resolve(r.data);
          }
          resolve(r);
        },
        error: (xhr, textStatus, error) => {
          reject(error);
        }
      };
      if (body._json) {
        options.contentType = 'application/json';
        delete body._json;
        options.data = JSON.stringify(body);
      }
      $.ajax(options)
    });
  }


  _postForm(url, formData, showLoading) {
    hookAjax($); // 之所以放在这里是因为在construct阶段，loading组件还没有渲染出来
    return new Promise((resolve, reject) => {
      $.ajax({
        url: url,
        method: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        dataType: 'json',
        showLoading: showLoading,
        success: r => {
          if (!r) {
            return reject('服务器没有返回数据');
          }
          if ('errorCode' in r && r.errorCode != 0) {
            errorHandler(r);
            return reject(r);
          }
          if ('errorCode' in r && r.errorCode == 0) {
            return resolve(r.data);
          }
          resolve(r);
        },
        error: (xhr, textStatus, error) => {
          reject(error);
        }
      })
    });
  }

  _dynaPost(url, body, cache, showLoading, parmas) {
    console.log(JSON.stringify(body))
    hookAjax($); // 之所以放在这里是因为在construct阶段，loading组件还没有渲染出来
    return new Promise((resolve, reject) => {
      let options = {
        url: url+'?'+parmas,
        method: 'POST',
        data: JSON.stringify(body),
        dataType: 'json',
        showLoading: showLoading,
        contentType: 'application/json; charset=UTF-8',
        cache: cache, // 不需要缓存了
        success: r => {
          if (!r) {
            return reject('服务器没有返回数据');
          }
          if ('errorCode' in r && r.errorCode != 0) {
            errorHandler(r);
            return reject(r);
          }
          if ('errorCode' in r && r.errorCode == 0) {
            return resolve(r.data);
          }
          resolve(r);
        },
        error: (xhr, textStatus, error) => {
          reject(error);
        }
      };
      if (body._json) {
        options.contentType = 'application/json';
        delete body._json;
        options.data = JSON.stringify(body);
      }
      // if (body._html) {
      //   console.log(body)
      //   options.contentType = 'text/html;charset=utf-8';
      //   delete body._html;
      //   console.log(body)
      // }
      $.ajax(options)
    });
  }

  static get(url, params, noCache, showLoading) {
    return getInstance()._get(url, params, noCache, showLoading);
  }

  static post(url, body, cache, showLoading) {
    // 默认的contentType是application/x-www-form-urlencoded
    // 如果想发送application/json，需要在body中增加_json:true，如 {id:1, _json:true}
    return getInstance()._post(url, body, cache, showLoading);
  }
  static posts(url, body, cache, showLoading) {
	    // 默认的contentType是application/x-www-form-urlencoded
	    // 如果想发送application/json，需要在body中增加_json:true，如 {id:1, _json:true}
	    return getInstance()._posts(url, body, cache, showLoading);
	  }
  static postUrl(url, body, cache, showLoading) {
    // 默认的contentType是application/x-www-form-urlencoded
    // 如果想发送application/json，需要在body中增加_json:true，如 {id:1, _json:true}
    return getInstance()._postUrl(url, body, cache, showLoading);
  }
  static dynaPost(url, body, cache, showLoading, parmas) {
    // 默认的contentType是application/x-www-form-urlencoded
    // 如果想发送application/json，需要在body中增加_json:true，如 {id:1, _json:true}
    return getInstance()._dynaPost(url, body, cache, showLoading, parmas);
  }


  static postAddToken(url, body, cache, showLoading,token,contentType) {
    // 默认的contentType是application/x-www-form-urlencoded
    // 如果想发送application/json，需要在body中增加_json:true，如 {id:1, _json:true}
    return getInstance()._postAddToken(url, body, cache, showLoading,token,contentType);
  }
  static getAddToken(url, body, cache, showLoading,token){
    return getInstance()._getAddToken(url, body, cache, showLoading,token);
  }

  static postText(url, body, cache, showLoading) {
    // 直接发送 数组或字符串
    return getInstance()._postText(url, body, cache, showLoading);
  }


  static postForm(url, formData, showLoading) {
    // 直接提交包含文件的formData
    return getInstance()._postForm(url, formData, showLoading);
  }
}

// HttpService.post('/',{a:1,b:{c:2},_json:true});

//HttpService.post('/',{a:1,b:{c:2},_json:true});

