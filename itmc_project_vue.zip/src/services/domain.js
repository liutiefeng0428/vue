 export const urlDomain=""
// export const urlDomain="http://local.itmc.sinopec.com:35516"
