<template>
  <div style="margin: 24px">
    <a-card :bordered="false">
      <div class="table-page-search-wrapper">
        <a-form layout="inline">
          <div>
            <a-form-item label="年度">
              <a-select
                mode="multiple"
                :size="size"
                placeholder="请选择年份"
                :defaultValue="[optionDate[0].optionName]"
                style="width: 400px"
                @change="handleChangeDate"
                @popupScroll="popupScroll">
                <a-select-option v-for="item in optionDate" :key="item.optionCode">
                  {{item.optionName}}
                </a-select-option>
              </a-select>
            </a-form-item>
            <a-form-item label="关键字搜索">
              <a-input placeholder="请输入关键字"/>
            </a-form-item>
            <a-form-item label="合同类型">
              <a-select
                :size="size"
                :defaultValue=contractType[0].optionName
                style="width: 200px"
                @change="handleChange"
              >
                <a-select-option v-for="item in contractType" :key="item.optionCode" :value="item.optionCode">
                  {{item.optionName}}
                </a-select-option>
              </a-select>
            </a-form-item>
          </div>
          <div style="margin:16px 0;">
            <span class="table-page-search-submitButtons">
              <a-button type="primary">查询</a-button>
              <a-button @click="triggerImport()">导入</a-button>
            </span>
            <button @click="toAdd" data-v-227ef8f8="" type="button" class="ant-btn ant-btn-primary">
              <i class="anticon anticon-plus">
                <svg viewBox="64 64 896 896" data-icon="plus" width="1em" height="1em" fill="currentColor"
                     aria-hidden="true" class="">
                  <path d="M482 152h60q8 0 8 8v704q0 8-8 8h-60q-8 0-8-8V160q0-8 8-8z"></path>
                  <path d="M176 474h672q8 0 8 8v60q0 8-8 8H176q-8 0-8-8v-60q0-8 8-8z"></path>
                </svg>
              </i>
              <span>新增</span>
            </button>
            <button @click="exportToExcel()" data-v-227ef8f8="" type="button" class="ant-btn ant-btn-primary">
              <i class="anticon anticon-import">
                <svg viewBox="64 64 896 896" data-icon="plus" width="1em" height="1em" fill="currentColor"
                     aria-hidden="true" class="">
                  <path d="M482 152h60q8 0 8 8v704q0 8-8 8h-60q-8 0-8-8V160q0-8 8-8z"></path>
                  <path d="M176 474h672q8 0 8 8v60q0 8-8 8H176q-8 0-8-8v-60q0-8 8-8z"></path>
                </svg>
              </i>
              <span>导出</span>
            </button>
          </div>
        </a-form>
      </div>
      <a id="importRef" href="javascript:;" class="file" style="display: none">导入表格
          <input id="upload" type="file" @change="importfxx(this)"
                 accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"/>
      </a>
      <div class="ant-alert ant-alert-info">
        <i class="anticon anticon-info-circle ant-alert-icon"></i> 已选择&nbsp;
        <a style="font-weight: 600;">0</a>项&nbsp;&nbsp;
        <a style="margin-left: 24px;">清空</a>
      </div>
      <!--<s-table></s-table>-->
    </a-card>
    <!--表格-->
     <div id="contractWrap">
        <div style="background: #fff; padding: 0px 32px;">
          <a-table bordered :columns="columns" :dataSource="data" :pagination="{ pageSize: pageSize }">
            <a slot="action" slot-scope="text, record, index" href="javascript:;">
              <a @click="doDelete(record.key,text,index)">编辑</a>
              <a-divider type="vertical"/>
              <a-dropdown>
                <a class="ant-dropdown-link">
                  更多 <a-icon type="down"/>
                </a>
                <a-menu slot="overlay">
                  <a-menu-item>
                    <a href="javascript:;" @click="handleDelete(record)">详情</a>
                  </a-menu-item>
                  <a-menu-item>
                    <a href="javascript:;" @click="handleDelete(record.username)">密码</a>
                  </a-menu-item>
                  <a-menu-item>
                    <a-popconfirm title="确定删除吗?" @confirm="() => handleDelete(record)">
                      <a>删除</a>
                    </a-popconfirm>
                  </a-menu-item>
                  <a-menu-item v-if="record.status==1">
                    <a-popconfirm title="确定冻结吗?" @confirm="() => handleFrozen(record.id,2)">
                      <a>冻结</a>
                    </a-popconfirm>
                  </a-menu-item>
                  <a-menu-item v-if="record.status==2">
                    <a-popconfirm title="确定解冻吗?" @confirm="() => handleFrozen(record.id,1)">
                      <a>解冻</a>
                    </a-popconfirm>
                  </a-menu-item>
                </a-menu>
              </a-dropdown>
            </a>
          </a-table>
        </div>
        <div>
          <a-drawer
            title="操作"
            :width="620"
            @close="onClose"
            :visible="visible"
            :wrapStyle="{height: 'calc(100% - 108px)',overflow: 'auto',paddingBottom: '108px'}"
          >

            <div
              :style="{
          position: 'absolute',
          left: 0,
          bottom: 0,
          width: '100%',
          borderTop: '1px solid #e9e9e9',
          padding: '10px 16px',
          background: '#fff',
          textAlign: 'right',
        }"
            >
              <a-button
                :style="{marginRight: '8px'}"
                @click="onClose"
              >
                取消
              </a-button>
              <a-button @click="onClose" type="primary">确认</a-button>
            </div>
          </a-drawer>
        </div>
      </div>


  </div>
</template>

<script>
  const columns= [{
    title: '合同名称',
    dataIndex: 'name',
    width: 250,
  }, {
    title: '合同金额',
    dataIndex: 'amount',
    width: 150,
  }, {
    title: '合同编号',
    dataIndex: 'contractCode',
    width: 150,
  }, {
    title: '甲方',
    dataIndex: 'partyA',
  }, {
    title: '删除',
    dataIndex: '',
    key: 'x',
    scopedSlots: { customRender: 'action' },
  },]
  const  dataSource=[
    {
      "uuid": "0ac4150587464b89aa8abf5443cd33fd",
      "contractId": "2f08c943-90ec-4792-b3c4-b1338fa40ef5",
      "projectId": "588e7a0b59764efca2f0ee396a876fac",
      "contractState": null,
      "purchaseId": "",
      "projectName": "测试项目0426-01_股份总部",
      "contractName": "采购合同-测试项目0426-01_股份总部",
      "contractType": "0101",
      "contractCode": "G11-MM-2019-357",
      "partyA": "中国石油化工股份有限公司信息化管理部",
      "partyB": "石化盈科信息技术有限责任公司",
      "partyC": null,
      "contractYeartype": "2019",
      "contractTaxAmount": 7,
      "contractNotTaxAmount": 6.03,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-26 11:32:12",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    },
    {
      "uuid": "044f9dd2913f4216b199df997cbb87ee",
      "contractId": "72ba569d-cfe3-43b5-aa58-909fdace9571",
      "projectId": "588e7a0b59764efca2f0ee396a876fac",
      "contractState": null,
      "purchaseId": "",
      "projectName": "测试项目0426-01_股份总部",
      "contractName": "采购合同-测试项目0426-01_股份总部",
      "contractType": "0101",
      "contractCode": "G11-MM-2019-356",
      "partyA": "中国石油化工股份有限公司信息化管理部",
      "partyB": "石化盈科信息技术有限责任公司",
      "partyC": null,
      "contractYeartype": "2019",
      "contractTaxAmount": 3,
      "contractNotTaxAmount": 2.59,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-26 10:55:17",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    },
    {
      "uuid": "fb263134b6514adeb574819827b6f3e1",
      "contractId": "074b3c0e-4ae7-4db2-9c76-5ffe2043c757",
      "projectId": "5dfb351a0bcc4cd6a9ae21b87c67f761",
      "contractState": null,
      "purchaseId": "",
      "projectName": "形象进度测试004_集团总部",
      "contractName": "采购合同-形象进度测试004_集团总部",
      "contractType": "0101",
      "contractCode": "GG-11-MM-2019-354",
      "partyA": "中国石油化工集团公司信息化管理部",
      "partyB": "上海众达信息产业有限公司",
      "partyC": "",
      "contractYeartype": "2019",
      "contractTaxAmount": 0,
      "contractNotTaxAmount": 0,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-24 15:32:24",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    },
    {
      "uuid": "17d76fdd75ae48138940e8b00b7fb646",
      "contractId": "f9289d35-8bc1-4855-9b14-ec4bdf0716b2",
      "projectId": "2f0902c8576947099340d1efb77fea75",
      "contractState": null,
      "purchaseId": "",
      "projectName": "形象进度测试004_股份总部",
      "contractName": "采购合同-形象进度测试004_股份总部",
      "contractType": "0101",
      "contractCode": "GG-11-MM-2019-353",
      "partyA": "中国石油化工股份有限公司信息化管理部",
      "partyB": "上海众达信息产业有限公司",
      "partyC": "",
      "contractYeartype": "2019",
      "contractTaxAmount": 0,
      "contractNotTaxAmount": 0,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-24 15:32:05",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    },
    {
      "uuid": "3339876e95e04ea0914e019758da4c63",
      "contractId": "6cefcb5a-c2e6-4793-9b39-7efef3cece74",
      "projectId": "76c8d60cdfd9432abcd8adf3e558f349",
      "contractState": null,
      "purchaseId": "",
      "projectName": "形象进度测试003_集团总部",
      "contractName": "采购合同-形象进度测试003_集团总部",
      "contractType": "0101",
      "contractCode": "GG-11-MM-2019-352",
      "partyA": "中国石油化工集团公司信息化管理部",
      "partyB": "石化盈科信息技术有限责任公司",
      "partyC": null,
      "contractYeartype": "2019",
      "contractTaxAmount": 1800,
      "contractNotTaxAmount": 1551.72,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-23 17:50:23",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    }
  ];
  const data = [];
  for (let i = 0; i < dataSource.length; i++) {
    data.push({
      key: i,
      name: dataSource[i].contractName,
      amount:dataSource[i].contractNotTaxAmount,
      contractCode:dataSource[i].contractCode,
      partyA:dataSource[i].partyA,
//      contractCode: `London Park no. ${i}`,
    });
  }

  import STable from '@/components/table/StandardTable'
  export default {
    name: "ProjectContract",
    components: {
      STable,
    },
    data () {
      return {
        size: 'default',
        contractType: [
          {
            "optionName": "采购合同",
            "status": 0,
            "note": "项目合同类型",
            "sort": null,
            "typeCode": "HTLXXM",
            "optionCode": "0101"
          },
          {
            "optionName": "服务合同",
            "status": 0,
            "note": "项目合同类型",
            "sort": null,
            "typeCode": "HTLXXM",
            "optionCode": "0102"
          }
        ],
        optionDate: [
          {
            "optionName": "2025",
            "status": 0,
            "note": "下拉框年份",
            "sort": 1,
            "typeCode": "JHND",
            "optionCode": "2025"
          },
          {
            "optionName": "2024",
            "status": 0,
            "note": "下拉框年份",
            "sort": 2,
            "typeCode": "JHND",
            "optionCode": "2024"
          },
          {
            "optionName": "2023",
            "status": 0,
            "note": "下拉框年份",
            "sort": 3,
            "typeCode": "JHND",
            "optionCode": "2023"
          },
          {
            "optionName": "2022",
            "status": 0,
            "note": "下拉框年份",
            "sort": 4,
            "typeCode": "JHND",
            "optionCode": "2022"
          },
          {
            "optionName": "2021",
            "status": 0,
            "note": "下拉框年份",
            "sort": 5,
            "typeCode": "JHND",
            "optionCode": "2021"
          },
          {
            "optionName": "2020",
            "status": 0,
            "note": "下拉框年份",
            "sort": 6,
            "typeCode": "JHND",
            "optionCode": "2020"
          },
          {
            "optionName": "2019",
            "status": 0,
            "note": "下拉框年份",
            "sort": 7,
            "typeCode": "JHND",
            "optionCode": "2019"
          },
          {
            "optionName": "2018",
            "status": 0,
            "note": "下拉框年份",
            "sort": 8,
            "typeCode": "JHND",
            "optionCode": "2018"
          },
          {
            "optionName": "2017",
            "status": 0,
            "note": "下拉框年份",
            "sort": 9,
            "typeCode": "JHND",
            "optionCode": "2017"
          },
          {
            "optionName": "2016",
            "status": 0,
            "note": "下拉框年份",
            "sort": 10,
            "typeCode": "JHND",
            "optionCode": "2016"
          },
          {
            "optionName": "2015",
            "status": 0,
            "note": "下拉框年份",
            "sort": 11,
            "typeCode": "JHND",
            "optionCode": "2015"
          },
          {
            "optionName": "2014",
            "status": 0,
            "note": "下拉框年份",
            "sort": 12,
            "typeCode": "JHND",
            "optionCode": "2014"
          },
          {
            "optionName": "2013",
            "status": 0,
            "note": "下拉框年份",
            "sort": 13,
            "typeCode": "JHND",
            "optionCode": "2013"
          },
          {
            "optionName": "2012",
            "status": 0,
            "note": "下拉框年份",
            "sort": 14,
            "typeCode": "JHND",
            "optionCode": "2012"
          },
          {
            "optionName": "2011",
            "status": 0,
            "note": "下拉框年份",
            "sort": 15,
            "typeCode": "JHND",
            "optionCode": "2011"
          },
          {
            "optionName": "2010",
            "status": 0,
            "note": "下拉框年份",
            "sort": 16,
            "typeCode": "JHND",
            "optionCode": "2010"
          }
        ],
        tHeader: ['合同名称', '合同金额', '合同编号', '甲方'],
        filterVal: ['name', 'amount', 'contractCode', 'partyA'],
        dataSource: [
          {
            "uuid": "0ac4150587464b89aa8abf5443cd33fd",
            "contractId": "2f08c943-90ec-4792-b3c4-b1338fa40ef5",
            "projectId": "588e7a0b59764efca2f0ee396a876fac",
            "contractState": null,
            "purchaseId": "",
            "projectName": "测试项目0426-01_股份总部",
            "contractName": "采购合同-测试项目0426-01_股份总部",
            "contractType": "0101",
            "contractCode": "G11-MM-2019-357",
            "partyA": "中国石油化工股份有限公司信息化管理部",
            "partyB": "石化盈科信息技术有限责任公司",
            "partyC": null,
            "contractYeartype": "2019",
            "contractTaxAmount": 7,
            "contractNotTaxAmount": 6.03,
            "comprehensiveRate": 0,
            "projectWbsCode": "",
            "createUserId": null,
            "createUserName": null,
            "createTime": "2019-04-26 11:32:12",
            "lastupdateUserId": null,
            "lastupdateUserName": null,
            "lastupdateTime": null,
            "partyACode": null,
            "partyBId": null,
            "partyCId": null,
            "fundType": null,
            "expenditureTypeCode": null,
            "expenditureTypeName": null,
            "assetsAmountSubtotal": 0,
            "expenseItem": null,
            "expenseValue": null,
            "expenseAmount": 0,
            "contractFinalPrice": 0,
            "contractNumber": null,
            "contractPaymentState": null,
            "contractSystemId": null
          },
          {
            "uuid": "044f9dd2913f4216b199df997cbb87ee",
            "contractId": "72ba569d-cfe3-43b5-aa58-909fdace9571",
            "projectId": "588e7a0b59764efca2f0ee396a876fac",
            "contractState": null,
            "purchaseId": "",
            "projectName": "测试项目0426-01_股份总部",
            "contractName": "采购合同-测试项目0426-01_股份总部",
            "contractType": "0101",
            "contractCode": "G11-MM-2019-356",
            "partyA": "中国石油化工股份有限公司信息化管理部",
            "partyB": "石化盈科信息技术有限责任公司",
            "partyC": null,
            "contractYeartype": "2019",
            "contractTaxAmount": 3,
            "contractNotTaxAmount": 2.59,
            "comprehensiveRate": 0,
            "projectWbsCode": "",
            "createUserId": null,
            "createUserName": null,
            "createTime": "2019-04-26 10:55:17",
            "lastupdateUserId": null,
            "lastupdateUserName": null,
            "lastupdateTime": null,
            "partyACode": null,
            "partyBId": null,
            "partyCId": null,
            "fundType": null,
            "expenditureTypeCode": null,
            "expenditureTypeName": null,
            "assetsAmountSubtotal": 0,
            "expenseItem": null,
            "expenseValue": null,
            "expenseAmount": 0,
            "contractFinalPrice": 0,
            "contractNumber": null,
            "contractPaymentState": null,
            "contractSystemId": null
          },
          {
            "uuid": "fb263134b6514adeb574819827b6f3e1",
            "contractId": "074b3c0e-4ae7-4db2-9c76-5ffe2043c757",
            "projectId": "5dfb351a0bcc4cd6a9ae21b87c67f761",
            "contractState": null,
            "purchaseId": "",
            "projectName": "形象进度测试004_集团总部",
            "contractName": "采购合同-形象进度测试004_集团总部",
            "contractType": "0101",
            "contractCode": "GG-11-MM-2019-354",
            "partyA": "中国石油化工集团公司信息化管理部",
            "partyB": "上海众达信息产业有限公司",
            "partyC": "",
            "contractYeartype": "2019",
            "contractTaxAmount": 0,
            "contractNotTaxAmount": 0,
            "comprehensiveRate": 0,
            "projectWbsCode": "",
            "createUserId": null,
            "createUserName": null,
            "createTime": "2019-04-24 15:32:24",
            "lastupdateUserId": null,
            "lastupdateUserName": null,
            "lastupdateTime": null,
            "partyACode": null,
            "partyBId": null,
            "partyCId": null,
            "fundType": null,
            "expenditureTypeCode": null,
            "expenditureTypeName": null,
            "assetsAmountSubtotal": 0,
            "expenseItem": null,
            "expenseValue": null,
            "expenseAmount": 0,
            "contractFinalPrice": 0,
            "contractNumber": null,
            "contractPaymentState": null,
            "contractSystemId": null
          },
          {
            "uuid": "17d76fdd75ae48138940e8b00b7fb646",
            "contractId": "f9289d35-8bc1-4855-9b14-ec4bdf0716b2",
            "projectId": "2f0902c8576947099340d1efb77fea75",
            "contractState": null,
            "purchaseId": "",
            "projectName": "形象进度测试004_股份总部",
            "contractName": "采购合同-形象进度测试004_股份总部",
            "contractType": "0101",
            "contractCode": "GG-11-MM-2019-353",
            "partyA": "中国石油化工股份有限公司信息化管理部",
            "partyB": "上海众达信息产业有限公司",
            "partyC": "",
            "contractYeartype": "2019",
            "contractTaxAmount": 0,
            "contractNotTaxAmount": 0,
            "comprehensiveRate": 0,
            "projectWbsCode": "",
            "createUserId": null,
            "createUserName": null,
            "createTime": "2019-04-24 15:32:05",
            "lastupdateUserId": null,
            "lastupdateUserName": null,
            "lastupdateTime": null,
            "partyACode": null,
            "partyBId": null,
            "partyCId": null,
            "fundType": null,
            "expenditureTypeCode": null,
            "expenditureTypeName": null,
            "assetsAmountSubtotal": 0,
            "expenseItem": null,
            "expenseValue": null,
            "expenseAmount": 0,
            "contractFinalPrice": 0,
            "contractNumber": null,
            "contractPaymentState": null,
            "contractSystemId": null
          },
          {
            "uuid": "3339876e95e04ea0914e019758da4c63",
            "contractId": "6cefcb5a-c2e6-4793-9b39-7efef3cece74",
            "projectId": "76c8d60cdfd9432abcd8adf3e558f349",
            "contractState": null,
            "purchaseId": "",
            "projectName": "形象进度测试003_集团总部",
            "contractName": "采购合同-形象进度测试003_集团总部",
            "contractType": "0101",
            "contractCode": "GG-11-MM-2019-352",
            "partyA": "中国石油化工集团公司信息化管理部",
            "partyB": "石化盈科信息技术有限责任公司",
            "partyC": null,
            "contractYeartype": "2019",
            "contractTaxAmount": 1800,
            "contractNotTaxAmount": 1551.72,
            "comprehensiveRate": 0,
            "projectWbsCode": "",
            "createUserId": null,
            "createUserName": null,
            "createTime": "2019-04-23 17:50:23",
            "lastupdateUserId": null,
            "lastupdateUserName": null,
            "lastupdateTime": null,
            "partyACode": null,
            "partyBId": null,
            "partyCId": null,
            "fundType": null,
            "expenditureTypeCode": null,
            "expenditureTypeName": null,
            "assetsAmountSubtotal": 0,
            "expenseItem": null,
            "expenseValue": null,
            "expenseAmount": 0,
            "contractFinalPrice": 0,
            "contractNumber": null,
            "contractPaymentState": null,
            "contractSystemId": null
          }
        ],
        data,
        columns,
        pageSize:4,
        visible: false,
        childrenDrawer: false
      }
    },
    methods: {
      handleDelete(record){
        this.$message.error("测试错误消息")
        this.$message.success("测试警告")
        this.$message.warn("测试警告")
        console.log(record)
      },
      doDelete(key,text,index){
        this.showDrawer()
      },
      showDrawer() {
        this.visible = true
      },
      onClose() {
        this.visible = false
      },
      showChildrenDrawer() {
        this.childrenDrawer = true
      },
      onChildrenDrawerClose() {
        this.childrenDrawer = false
      },
      toAdd(){
        this.$router.push({path: '/add-contract'})
      },
      exportToExcel(){
        this.$gloableF.exportToExcel(this.tHeader, this.filterVal, this.dataSource)
      },
      handleChange(value) {
        console.log(`Selected: ${value}`);
      },
      handleChangeDate(value){
        console.log(value);
      },
      popupScroll(){
        console.log('popupScroll')
      },
      triggerImport(){
//         触发importRef的click事件
      },
      importfxx(obj) {
        let _this = this;
        let inputDOM = this.$refs.inputer;
        // 通过DOM取文件数据
        this.file = event.currentTarget.files[0];
        var rABS = false; //是否将文件读取为二进制字符串
        var f = this.file;
        var reader = new FileReader();
        //if (!FileReader.prototype.readAsBinaryString) {
        FileReader.prototype.readAsBinaryString = function (f) {
          var binary = "";
          var rABS = false; //是否将文件读取为二进制字符串
          var pt = this;
          var wb; //读取完成的数据
          var outdata;
          var reader = new FileReader();
          reader.onload = function (e) {
            var bytes = new Uint8Array(reader.result);
            var length = bytes.byteLength;
            for (var i = 0; i < length; i++) {
              binary += String.fromCharCode(bytes[i]);
            }
            var XLSX = require('xlsx');
            if (rABS) {
              wb = XLSX.read(btoa(fixdata(binary)), { //手动转化
                type: 'base64'
              });
            } else {
              wb = XLSX.read(binary, {
                type: 'binary'
              });
            }
            outdata = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);//outdata就是你想要的东西
            this.da = [...outdata]
            let arr = []
            this.da.map(v => {
              let obj = {}
              arr.push(v)
            })
            console.log(arr)
            let para = {
              //withList: JSON.stringify(this.da)
              withList: arr
            }
//            _this.$message({
//              message: '请耐心等待导入成功',
//              type: 'success'
//            });
            withImport(para).then(res => {
              window.location.reload()
            })

          }
          reader.readAsArrayBuffer(f);
        }
        if (rABS) {
          reader.readAsArrayBuffer(f);
        } else {
          reader.readAsBinaryString(f);
        }
      },

    },
    watch: {
      /*
       'selectedRows': function (selectedRows) {
       this.needTotalList = this.needTotalList.map(item => {
       return {
       ...item,
       total: selectedRows.reduce( (sum, val) => {
       return sum + val[item.dataIndex]
       }, 0)
       }
       })
       }
       */
    }
  }
</script>
<style>
  #contractWrap .ant-table-bordered .ant-table-thead > tr > th{
    padding: 9px 16px!important;
  }
  #contractWrap .ant-table-bordered .ant-table-tbody > tr > td{
    padding: 2px 16px!important;
  }
</style>
