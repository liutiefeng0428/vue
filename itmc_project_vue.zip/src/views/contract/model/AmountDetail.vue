<template>
  <div>
    <div v-if="contractType == '01'">
      <div v-if="isEdit">
        <a-table :pagination="false" bordered :columns="columns_01" :dataSource="amountDetail" rowKey="uuid">
        <span slot="action" slot-scope="text, record, index">
          <a @click="doAdd(record,text,index)">添加</a>
          <a @click="doDelete(record,text,index)">删除</a>
        </span>
          <span slot="taxCode" slot-scope="text, record, index">
          <a-select
            style="width: 100%"
            v-model="record.taxCode">
            <a-select-option v-for="item in taxCodeList" :key="item.optionCode" :title="item.optionName" :value="item.optionCode">
              {{item.optionName}}
            </a-select-option>
          </a-select>
        </span>
          <span slot="amount" slot-scope="text, record, index">
          <a-input  v-model="record.amount" placeholder="请输入整数或小数"/>
        </span>
        </a-table>
      </div>
      <div v-else>
         <a-table :pagination="false" bordered :columns="columns_04" :dataSource="amountDetail" rowKey="uuid">
           <span slot="taxCode" :title="taxRateNameObject[record.taxCode]" slot-scope="text, record, index">
             <select class="taxCodeListCss" name=""  v-model="record.taxCode" disabled>
               <option v-for="item in taxCodeList" :key="item.optionCode" :title="item.optionName" :value="item.optionCode">{{item.optionName}}</option>
             </select>
           </span>
        </a-table>
      </div>
    </div>
    <div v-if="contractType == '02'">
      <div v-if="isEdit">
        <a-table :pagination="false" bordered :columns="columns_03" :dataSource="amountDetail" rowKey="uuid">
        <span slot="amount" slot-scope="text, record, index">
          <a-input  v-model="record.amount"  placeholder="请输入整数或小数"/>
        </span>
        </a-table>
      </div>
      <div v-else>
        <a-table :pagination="false" bordered :columns="columns_02" :dataSource="amountDetail" rowKey="uuid">
            <span slot="taxCode" :title="taxRateNameObject[record.taxCode]" slot-scope="text, record, index">
             <select class="taxCodeListCss" name=""  v-model="record.taxCode" disabled>
               <option v-for="item in taxCodeList" :key="item.optionCode" :title="item.optionName" :value="item.optionCode">{{item.optionName}}</option>
             </select>
           </span>
        </a-table>
      </div>
    </div>
  </div>
</template>
<script>
  const columns_01 = [
    {
      title: '服务编码',
      dataIndex: 'serviceCode',
    }, {
      title: '批复类型',
      dataIndex: 'replyName',
    }, {
      title: '批复总额',
      dataIndex: 'totalAmount',
    }, {
      title: '已用金额',
      dataIndex: 'alreadyUsedAmount',
    }, {
      title: '可用金额',
      dataIndex: 'availableAmount',
    }, {
      title: '服务名称',
      dataIndex: 'serviceName',
    }, {
      title: '税率/税值',
      dataIndex: 'taxCode',
      scopedSlots: {customRender: 'taxCode'},
      width: 220,
    }, {
      title: '本次金额',
      dataIndex: 'amount',
      scopedSlots: {customRender: 'amount'},
    }, {
      title: '操作',
      dataIndex: '',
      key: 'x',
      scopedSlots: {customRender: 'action'},
    }
  ];

  const columns_04 = [
    {
      title: '服务编码',
      dataIndex: 'serviceCode',
    }, {
      title: '批复类型',
      dataIndex: 'replyName',
    }, {
      title: '批复总额',
      dataIndex: 'totalAmount',
    }, {
      title: '已用金额',
      dataIndex: 'alreadyUsedAmount',
    }, {
      title: '可用金额',
      dataIndex: 'availableAmount',
    }, {
      title: '服务名称',
      dataIndex: 'serviceName',
    }, {
      title: '税率/税值',
      dataIndex: 'taxCode',
      scopedSlots: {customRender: 'taxCode'},
      width: 220,
    }, {
      title: '本次金额',
      dataIndex: 'amount'

    }, {
      title: '操作',
      dataIndex: '',
      key: 'x'

    }
  ];
  const columns_03 = [
    {
      title: '费用类型',
      dataIndex: 'replyName',
    }, {
      title: '开支项目名称',
      dataIndex: 'expenditureItemName',
    }, {
      title: '本次金额',
      dataIndex: 'amount',
      scopedSlots: {customRender: 'amount'},
    }, {
      title: '总金额',
      dataIndex: 'totalAmount',
    }, {
      title: '已用金额',
      dataIndex: 'alreadyUsedAmount',
    }, {
      title: '可用金额',
      dataIndex: 'availableAmount',
    }
  ];

  const columns_02 = [
    {
      title: '费用类型',
      dataIndex: 'replyName',
    }, {
      title: '开支项目名称',
      dataIndex: 'expenditureItemName',
    }, {
      title: '本次金额',
      dataIndex: 'amount'
     // scopedSlots: {customRender: 'amount'},
    }, {
      title: '总金额',
      dataIndex: 'totalAmount',
    }, {
      title: '已用金额',
      dataIndex: 'alreadyUsedAmount',
    }, {
      title: '可用金额',
      dataIndex: 'availableAmount',
    }
  ];

  import {apiService} from "@/services/apiservice";

  export default {
    name: "AmountDetail",
    data() {
      return {
        columns_01,
        columns_02,
        columns_03,
        columns_04,
        contractTypeList: [
          {
            "optionName": "采购合同",
            "status": 0,
            "note": "项目合同类型",
            "sort": null,
            "typeCode": "HTLXXM",
            "optionCode": "01"
          },
          {
            "optionName": "服务合同",
            "status": 0,
            "note": "项目合同类型",
            "sort": null,
            "typeCode": "HTLXXM",
            "optionCode": "02"
          }
        ],
        IntegerFloat:/^[\d]{1,12}((\.)?|(\.{0,1}[\d]{1,2}))?$/,
        NonNumeric:/[^\d\.]+/
      }
    },
    props: ['isEdit', 'contractId', 'contractType', 'amountDetail', 'outuuid','taxRateObject','taxRateNameObject','taxCodeList','baseInfo'],
    computed: {},
    watch:{
      amountDetail:{
        handler(n,o){
          let _self = this;
          let sumPrice = 0;
          let sumNotRate = 0;
          let nLength = n.length;
          for (let i = 0; i < nLength; i++) {
             let amount = n[i].amount;
             //校验
             if(this.NonNumeric.test(amount)){
               n[i].amount = "";
             }
             if(!this.IntegerFloat.test(amount)){
                if(amount.length > 0){
                  n[i].amount = n[i].amount.substring(0,amount.length -1);
               }
             }
             if(parseFloat(n[i].amount) > parseFloat(n[i].availableAmount)){
               this.$message.error(n[i].replyName + '本次金额不能大于可用金额');
               // this.$message.warning('请调整' + n[i].replyName + '相关设备' + (i+1));
               n[i].amount ="";
               if (n[i].replyType == "03") { //硬件
                 let contractAssetsDetail = this.$parent.getContractAssetsDetail();
                 setTimeout(function () {
                   for(let k = 0;k<contractAssetsDetail.length; k++){
                     if (contractAssetsDetail[k].assetsModle == "1") {
                       contractAssetsDetail[k].unitPrice = "";
                       contractAssetsDetail[k].number = "";
                     }
                   };
                   setTimeout(function () {
                     _self.$message.error('请重新输入硬件单价和数量');
                   },1);
                 },0);
               } else if (n[i].replyType == "02") {
                 setTimeout(function () {
                   for(let k = 0;k<contractAssetsDetail.length; k++){
                     if (contractAssetsDetail[k].assetsModle == "2") {
                       contractAssetsDetail[k].unitPrice = "";
                       contractAssetsDetail[k].number = "";
                     }
                   };
                   setTimeout(function () {
                     _self.$message.error('请重新输入软件单价和数量');
                   },1);
                 },0);
               }
             }

            //  //计算总价
            // sumPrice += parseFloat(amount == '' ? '0' : amount);
            // if(this.taxRateObject[n[i].taxCode] != "0"){//计算不含税总价
            //   sumNotRate += parseFloat(amount == "" ? "0" : (parseFloat(amount)*(1-(parseFloat(this.taxRateObject[n[i].taxCode])/100))));
            // }
          }

          if(this.contractType == "02"){
           // let total = parseFloat(this.baseInfo.contractTaxAmount == "" ? "0" : this.baseInfo.contractTaxAmount);
            let tempTotal = 0;
            for (let k = 0;k < nLength; k++) {
              tempTotal +=  parseFloat(n[k].amount == "" ? "0" : n[k].amount);
            }
            //
            this.baseInfo.tempJinEMingXi = tempTotal.toFixed(2);
            this.baseInfo.contractTaxAmount = parseFloat(this.baseInfo.contractTaxAmountTemp == "" || this.baseInfo.contractTaxAmountTemp == undefined ? "0" : this.baseInfo.contractTaxAmountTemp) + tempTotal;
            //this.baseInfo.contractTaxAmount = (tempTotal).toFixed(2);
          }
          // this.baseInfo.contractTaxAmount = sumPrice.toFixed(2);
          // let contractPaymentDetail = this.$parent.getContractPaymentDetail();
          // for(let k = 0; k < contractPaymentDetail.length; k++){
          //    contractPaymentDetail[k].paymentAmount = this.baseInfo.contractTaxAmount;
          // }
          // this.$parent.setContractPaymentDetail(JSON.parse(JSON.stringify(contractPaymentDetail)));
        },
        immediate: true,
        deep: true
      }
    },
    mounted() {

      // if (!this.isEdit) {
      //   alert(this.isEdit);
      //   columns_01.splice((columns_01.length - 1), 1);
      //   for (var i = 0; i < columns_01.length; i++) {
      //     if (columns_01[i].scopedSlots) {
      //       columns_01[i].scopedSlots = ''
      //     }
      //   }
      // }
    },
    created() {
      this.taxRateNameObject = this.taxRateNameObject;
    },
    methods: {
      reset() {
      },
      doDelete(record, text, index) {
        this.amountDetail.splice(index, 1);
      },
      doAdd(record, text, index) {
        var source = Object.assign({}, record);
        source.uuid = this.outuuid();
        this.amountDetail.splice(index + 1, 0, source);
      },
      taxCodeName(str){
        return this.taxRateNameObject[str];
      },
      sleep(s){
        let start  = new Date().getTime();
        while((new Date()).getTime() - start < s){
          continue;
        }
      },
      // 获取合同税率/税值列表
      getDictionary() {
        var _self = this
        var parmasData = {_json: true, typeCode: 'SMD'};
        apiService.getDictionary(parmasData).then(r => {
          _self.taxCodeList = r
          setTimeout(function () {
            for (let i = 0; i < _self.taxCodeList.length; i++){
                _self.taxRateObject[_self.taxCodeList[i].optionCode]=_self.taxCodeList[i].taxRate;
            }
            //this.$parent.setTaxRateObject(_self.taxRateObject);
          },0)

        }, r => {
        }).catch(
        )
      },
    }
  }
</script>

<style>

.taxCodeListCss{
  -webkit-appearance:none;
  -moz-appearance:none;
  appearance:none; /*去掉下拉箭头*/
  border: none;
  background-color: white;
}
.taxCodeListCss::-ms-expand { display: none; }
</style>
