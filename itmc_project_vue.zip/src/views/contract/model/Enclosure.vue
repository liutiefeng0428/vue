<template>
  <div>
    <div>
      <a-table v-if="!isEdit" bordered :columns="columns" :dataSource="enclosure" rowKey="uuid">
      </a-table>
      <a-table :pagination="false" v-if="isEdit" bordered :columns="columns" :dataSource="enclosureAll" class="basisTableEdit">
        <span slot="action" slot-scope="text, record, index">
          <a-upload
          @change="saveFile"
          >
            <a-button>
              选择文件
           </a-button>
          </a-upload>
          <a-button>删除文件</a-button>
          <div class="ant-divider ant-divider-vertical"></div>
          <a-button @click="doAdd(record,text,index)">添加</a-button>
        </span>
        <span slot="fileName" slot-scope="text, record, index">
          <a-input disabled v-model="record.fileName"/>
        </span>
      </a-table>
      </div>
    </div>
</template>
<script>
const columns_enclosure = [
  {
    title: '附件类型',
    dataIndex: 'fileType',
    customRender: (text, row, index) => {
        const obj = {
          children: text,
          attrs: {},
        };
        obj.attrs.rowSpan = row.row;
        return obj;
    },
  }, {
    title: '附件名称',
    dataIndex: 'fileName',
    scopedSlots: { customRender: 'fileName' }
  }, {
    title: '操作',
    dataIndex: 'action',
    key: 'action',
    colSpan: 2,
    width: '30%',
    scopedSlots: { customRender: 'action' },
  }
];
var defaultEnclosure = [
  {
    key: '1',
    fileName: "",
    fileType: "技术附件",
    ossFileId: "",
    projectId: "",
    uuid: ""
  },
  {
    key: '2',
    fileName: "",
    fileType: "签约依据",
    ossFileId: "",
    projectId: "",
    uuid: ""
  },
];
import {apiService} from "@/services/apiservice";

import Vue from 'vue';
export default {
    name: "Enclosure",
    data () {
        return {
            columns: columns_enclosure,
            // data: data,
            // isEdit: true,
            selectedRowKeys: [],
            optionDepart:[],
            optionDepartSelect:"",
            defaultEnclosure: defaultEnclosure,
            enclosureAll: [],
            rowspan1: 0,
            rowspan2: 0,
            defaultKey: 100,

        }
    },
    components: {
    },
    props: ['isEdit','contractId','contractType','enclosure'],
    created(){
      alert(this.contractId);
    },
    computed: {
    },
    mounted(){
      if(!this.isEdit) columns_enclosure.splice((columns_enclosure.length-1), 1);

      if(this.enclosure.length == 0) this.enclosureAll = this.enclosure.concat(this.defaultEnclosure);
      else this.enclosureAll = this.enclosure;
      for(var i=0; i<this.enclosureAll.length; i++){
        this.enclosureAll[i].row = 0;
        if(this.enclosureAll[i].fileType == '技术附件'){
          this.rowspan1++;
        }
        if(this.enclosureAll[i].fileType == '签约依据'){
          this.rowspan2++;
        }
      }
      for(var i=0; i<this.enclosureAll.length; i++){
        if(this.enclosureAll[i].fileType == '技术附件'){
          this.enclosureAll[i].row = this.rowspan1;
          break;
        }
      }
      for(var i=0; i<this.enclosureAll.length; i++){
        if(this.enclosureAll[i].fileType == '签约依据'){
          this.enclosureAll[i].row = this.rowspan2;
          break;
        }
      }
    },
    methods: {
        reset() {
        },
        doAdd(record,text,index){
          this.enclosureAll.splice(index+1, 0, {
            key: this.defaultKey,
            fileName: "",
            fileType: record.fileType,
            ossFileId: "",
            projectId: "",
            uuid: "",
            row: 0,
          });
          for(var i=0; i<this.enclosureAll.length; i++){
            if(this.enclosureAll[i].fileType == record.fileType && this.enclosureAll[i].row){
              this.enclosureAll[i].row = parseInt(this.enclosureAll[i].row) + 1;
            }
          }
          this.defaultKey = this.defaultKey + 1;
          // console.log(this.enclosureAll);
        },
        onSelectChange (selectedRowKeys) {
          console.log('selectedRowKeys changed: ', selectedRowKeys);
          this.selectedRowKeys = selectedRowKeys
        },
        handleChangeDepart(val){
          this.optionDepartSelect=val
        },
        showPayModal(){
          this.payModal=true
          console.log(this.selectedRowKeys);
          let parmas={contractId:"b788df05-6ae2-4f1b-9945-d77b03839085",amountIds:"3363c9b46d374861ac31ee967a41c397"}
        },
        saveFile(file){
          alert(this.contractId);
          console.log(file);
          console.log(this);
          // let _self=this
          // const { fileList } = this;
          // const formData = new FormData();
          // formData.append('file', this.files);

          // reqwest({
          //   url: '/project/itmcAut/exportfile',
          //   method: 'post',
          //   processData: false,
          //   data: formData,
          //   success: () => {
          //     _self.fileList = []
          //     _self.$message.success('上传成功');
          //     _self.expVisible=false
          //     var params = {planYear: _self.optionDateSelect,investmentChannel:"B01"}
          //     params._json = true
          //     _self.loadTable(params)
          //     var params2 = {planYear:_self.optionDateSelect,investmentChannel:"B02"}
          //     params2._json = true
          //     _self.loadTable2(params2)
          //   },
          //   error: () => {
          //     _self.$message.error('上传失败');
          //     _self.expVisible=false
          //   },
          // });
        },
        goBack(){
          this.$router.go(-1)
        },
    }
}
</script>
<style>
.basisTableEdit span span{
  display: inline-block;
}
</style>
