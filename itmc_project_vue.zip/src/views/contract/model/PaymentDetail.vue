<template>
  <div>
    <div style="margin-bottom: 10px">
      <a-button v-if="!isEdit" @click="showPayModal" class="ant-btn ant-btn-primary">付款</a-button>
    </div>
    <div v-if="!isEdit">
      <div>
        <a-table ref="deleteMore" :pagination="false" bordered :columns="columns_paymentDetail" :dataSource="paymentDetail" :rowSelection="rowSelection" rowKey="uuid">
        </a-table>
      </div>
      <span class="">合计：{{totalSum}}</span>
    </div>
    <div v-if="isEdit">
      <div>
        <a-table ref="deleteMore" :pagination="false" bordered  :columns="columns_paymentDetail_edit" :dataSource="paymentDetail" :rowSelection="rowSelection" rowKey="uuid">
          <span slot="action" slot-scope="text, record, index">
            <a @click="doAdd(record,text,index)">添加</a>
            <a v-if="index" @click="doDelete(record,text,index)">删除</a>
          </span>
          <span v-if="isEdit" slot="paymentAmount" slot-scope="text, record, index">
            <a-input v-model="record.paymentAmount" placeholder="请输入整数或小数"/>
          </span>
          <span v-if="isEdit" slot="paymentRatio" slot-scope="text, record, index">
            <a-input v-model="record.paymentRatio" />
          </span>
          <span v-if="isEdit" slot="paymentCondition" slot-scope="text, record, index">
            <a-input v-model="record.paymentCondition" />
          </span>
          <span v-if="isEdit" slot="remarks" slot-scope="text, record, index">
            <a-input v-model="record.remarks"/>
          </span>
        </a-table>
      </div>
      <span class="">合计：{{totalSum}}</span>
    </div>
    <!-- 付款确认模态框 -->
    <a-modal
      title="付款确认"
      :width="900"
      centered
      :footer="null"
      v-model="payModal">
      <div>
        <div style="flex: 1">
          <div>
            <span>单位:</span>
            <a-select :value="optionDepartSelect"  class="querySelect" @change="handleChangeDepart" style="width:300px">
              <a-select-option v-for="item in optionDepart" :key="item.optionCode">{{item.optionName}}</a-select-option>
            </a-select>
          </div>
          <div style="margin-top: 10px">
            <div class="ant-table-content">
              <div class="ant-table-body">
                <table style="width: 100%">
                  <thead class="ant-table-thead">
                  <tr>
                    <th class="">序号</th>
                    <th class=""><div>付款条件</div></th>
                    <th class=""><div>合同总金额</div></th>
                    <th class=""><div>合同剩余金额</div></th>
                    <th class=""><div>条款金额</div></th>
                    <th class=""><div>投资构成</div></th>
                    <th class=""><div>金额</div></th>
                    <th class=""><div>付款金额</div></th>
                    <th class=""><div>付款内容</div></th>
                  </tr>
                  </thead>
                  <tbody class="ant-table-tbody">
                  <tr v-for="(item, index) in calculatePays">
                    <td>{{ index + 1}}</td>
                    <td>{{item.fuKuanTiaoJian}}</td>
                    <td>{{toFixed(item.zongJinE)}}</td>
                    <td>{{toFixed(item.heTongShengYuJinE)}}</td>
                    <td >{{toFixed(item.tiaoKuanJinE)}}</td>
                    <td  style="text-align: left;" v-html="item.touZiGouCheng"></td>
                    <td><!--{{item.taxCode}}--></td>
                    <td>{{toFixed(item.fuKuanJinE)}}</td>
                    <td> <!--{{item.amount}}-->
                      <a-input size="small" placeholder="" v-model="item.paymentContents"/>
                    </td>
                  </tr>
                  <!--<tr>-->
                    <!--<td>{{item.replyName}}1</td>-->
                    <!--<td>{{item.totalAmount}}2</td>-->
                    <!--<td>{{item.serviceName}}3</td>-->
                    <!--<td>{{item.taxCode}}4</td>-->
                    <!--<td>{{item.amount}}5</td>-->
                    <!--<td>{{item.serviceName}}3</td>-->
                    <!--<td>{{item.taxCode}}4</td>-->
                    <!--<td>{{item.amount}}5</td>-->
                  <!--</tr>-->
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div style="margin-top: 20px">
            <a-button @click="createBill()" class="ant-btn ant-btn-primary">服务确认 </a-button>
            <a-button @click="fuWuDianJi()" class="ant-btn ant-btn-primary">创建报销单</a-button>
            <a-button @click="goBack()" class="ant-btn ant-btn-primary">返回</a-button>
          </div>
        </div>
      </div>
    </a-modal>
  </div>
</template>
<script>
const columns_paymentDetail_edit = [
  {
    title: '状态',
    dataIndex: 'stateName',
  }, {
    title: '金额',
    dataIndex: 'paymentAmount',
    scopedSlots: { customRender: 'paymentAmount' }
  }, {
    title: '比例（%）',
    dataIndex: 'paymentRatio',
    scopedSlots: { customRender: 'paymentRatio' }
  }, {
    title: '付款条件',
    dataIndex: 'paymentCondition',
    scopedSlots: { customRender: 'paymentCondition' }
  }, {
    title: '备注',
    dataIndex: 'remarks',
    scopedSlots: { customRender: 'remarks' }
  }, {
    title: '操作',
    dataIndex: 'action',
    key: 'action',
    scopedSlots: { customRender: 'action' },
  }
];
const columns_paymentDetail = [
  {
    title: '状态',
    dataIndex: 'stateName',
  }, {
    title: '金额',
    dataIndex: 'paymentAmount',
  }, {
    title: '比例（%）',
    dataIndex: 'paymentRatio',
  }, {
    title: '付款条件',
    dataIndex: 'paymentCondition',
  }, {
    title: '备注',
    dataIndex: 'remarks',
  }
];

import {apiService} from "@/services/apiservice";

import Vue from 'vue';
export default {
    name: "PaymentDetail",
    data () {
        return {
            columns_paymentDetail,
            columns_paymentDetail_edit,
            selectedRowKeys: [],
            payModal:false, // 付款确认模态框
            selectedRows: [], // 模态框中选中的行数据
            optionDepart:[],
            optionDepartSelect:"",
            calculatePays:[],//付款列表
            calculatePaysCopy:[],
            contractIdTemp:"",
            listuuId:""

        }
    },
    props: ['isEdit','contractId','contractType','paymentDetail','outuuid','isAdd'],
    created(){
      if(this.isAdd == true){
        let source = {
          uuid: this.$parent.uuid(32,32),
          contractId:this.contractId,
          paymentAmount:0,
          paymentRatio:"90",
          paymentCondition:"",
          remarks:""
        };

        this.$parent.setContractPaymentDetail([source, {
          uuid: this.$parent.uuid(32,32),
          contractId:this.contractId,
          paymentAmount:0,
          paymentRatio:"10",
          paymentCondition:"",
          remarks:""
        }]);
      }
    },
  watch:{
    paymentDetail:{
      handler(val, old) {
        //合同明细付款校验
        let  IntegerFloat = /^[\d]{1,12}((\.)?|(\.{0,1}[\d]{1,2}))?$/;
        let   NonNumeric = /[^\d\.]+/;
        let rate = /^(([\d]{0,2})|([1][0][0])?)$/;
        let NotRate = /[^\d]+/;
        let paymentRatioSum =0;
        for(let i = 0;i < val.length; i++){
          if(NonNumeric.test(val[i].paymentAmount)){
            val[i].paymentAmount = "0"

          }
          if(NotRate.test(val[i].paymentRatio)){
            val[i].paymentRatio = "0";
          }
          if(!IntegerFloat.test(val[i].paymentAmount)){
            if(val[i].paymentAmount.length > 0){
              val[i].paymentAmount = val[i].paymentAmount.substring(0,val[i].paymentAmount.length -1);
            }
          }
          if(!rate.test(val[i].paymentRatio)){
            if(val[i].paymentRatio.length > 0){
              val[i].paymentRatio = val[i].paymentRatio.substring(0,val[i].paymentRatio.length -1);
            }
          }
          paymentRatioSum += parseInt(val[i].paymentRatio);
        }

        if(parseInt(paymentRatioSum) < 0 || parseInt(paymentRatioSum) > 100){
          for (let k = 0;k < val.length;k++) {
            val[k].paymentRatio = "0";
          }
        }
      },
      deep: true,
      immediate: true

    }
  },
    computed: {
      rowSelection() {
        const { selectedRowKeys } = this;
        return {
          onChange: (selectedRowKeys, selectedRows) => {
            this.selectedRows = selectedRows;
          }
        }
      },
      totalSum: function(){
        var money = 0;
        for(var i=0; i<this.paymentDetail.length; i++){
          money += parseFloat((this.paymentDetail[i].paymentAmount == undefined || this.paymentDetail[i].paymentAmount == ""  || this.paymentDetail[i].paymentAmount == "0") ? '0' : this.paymentDetail[i].paymentAmount.replace(/[,]?/g,""));
        }
        return money;
      }
    },
    // watch: {
    //   // 如果 `question` 发生改变，这个函数就会运行
    //   question: function (newQuestion, oldQuestion) {
    //     this.answer = 'Waiting for you to stop typing...'
    //     this.debouncedGetAnswer()
    //   }
    // },
    mounted(){
      // if(!this.isEdit) columns_paymentDetail.splice((columns_paymentDetail.length-1), 1);
      // if(!this.isEdit){
      //   columns_paymentDetail.splice((columns_paymentDetail.length-1), 1);
      //   for(var i=0; i<columns_paymentDetail.length; i++){
      //     if(columns_paymentDetail[i].scopedSlots){
      //       columns_paymentDetail[i].scopedSlots = ''
      //     }
      //   }
      // }
    },
    methods: {
        reset() {
        },
        toFixed(str){
          return  parseFloat(str == "" ? '0' : str).toFixed(2);
        },
        doDelete(record,text,index){
          this.paymentDetail.splice(index, 1);
        },
        doAdd(record,text,index){
          var source = Object.assign({},record);
          source.uuid = this.outuuid();
          source.paymentAmount = 0;
          source.paymentRatio = '';
          source.paymentCondition = '';
          source.remarks = '';
          this.paymentDetail.splice(index+1, 0, source);
        },
        onSelectChange (selectedRowKeys) {
          this.selectedRowKeys = selectedRowKeys;
        },
        handleChangeDepart(val){
          this.optionDepartSelect=val;
        },
        showPayModal(){
          this.payModal=true;
          let parmas={typeCode:"PayerName",dictionaryCode:""};
          this.getPayerNameFormDic(parmas);
          // ContractId: 9ce35c43-1a08-42c7-ba69-4215652f35a7
          // amountIds: 5b651b85b0d54fa28a0711b0f0738d4f,dcefc91d735645d3ada0cc0ff0e58512,
          //   rows: 0
          // page: 1
          let _self = this;
          let amountIds = [];
          if(this.selectedRows.length > 0){
            //查询付款列表
            let listUuidTemp = [];
            let contractIdTempC = "";
            apiService.calculatePay({
                    ContractId:this.selectedRows[0].contractId,
                    amountIds:this.selectedRows.map(function (item) {
                      return item.uuid;
                    }).join(",")
            }).then((r) => {
              _self.calculatePaysCopy = JSON.parse(JSON.stringify(r.list));
              let result = r.list.map(function (item) {

                contractIdTempC = item.contractId;
                   item['touZiGouCheng'] = item['touZiGouCheng'].map(function (tzc) {
                     listUuidTemp.push(tzc.uuid);
                    switch (tzc.replyType) {
                      case "03":
                         return "硬件配置费:"+ tzc.amount + "<br/>";
                        break;
                      case "02":
                        return "软件配置费:" + tzc.amount + "<br/>";
                        break;
                      case "04" :
                        return "技术服务费:" + tzc.amount + "<br/>";
                        break;
                      case "20" :
                        return "其他:" + tzc.amount + "<br/>";
                        break;
                      default:
                        return "";
                    }
                  }).join(",").replace(/,/g,"");
                  return item;
                 });
              this.calculatePays = result;
              this.listuuId = listUuidTemp.join(",");
              this.contractIdTemp = contractIdTempC;
            }).catch((r) => {
            });
          }
        },
        getPayerNameFormDic(parmasData){
          let _self=this;
          apiService.getPayerNameFormDic(parmasData).then(r => {
              if(r.status=='200'){
                _self.optionDepart=r.data;
                // _self.optionDepartSelect=r.data[0].optionCode
              }
          }, r => {
          }).catch(
          )
        },
        createBill(){
          let _self=this;
          // let parmasData={contractId:contractId};
          // parmasData._json=true;
          if(this.calculatePays.length > 0){
            if(this.optionDepartSelect == ""){
              let error = this.$message.error('单位名称不能为空。');
              return false;
            }
            apiService.createBill({code:this.optionDepartSelect,contractId:this.contractIdTemp,listuuId:this.paymentDetail.map(function (item) {
                return item.uuid;
              }).join(",")}).then((r) => {
              if(r.returnMSG.code =='200'){
                _self.$message.success(r.returnMSG.msg);
              }
            }, (r) => {
            }).catch((r) => {}
            );
          }
        },
        fuWuDianJi(){
          let _self=this;
          let parmasData={};
          parmasData._json=true;
          let pays = this.calculatePays;
          for (let i = 0; i < pays.length; i++) {
            this.calculatePaysCopy[i].paymentContents = pays[i].paymentContents;
          }
          apiService.fuWuDianJi(this.calculatePaysCopy).then(r => {
            if(r.result='0000'){
              _self.$message.success(r.msg);
            }
          }, r => {
          }).catch(
          )
        },
        goBack(){
          this.$router.go(-1);
        },
    }
}
</script>
