<template>
  <div>
    <div>
      <a-table v-if="!isEdit" bordered :columns="columns" :dataSource="contractBasis" rowKey="uuid">
      </a-table>
      <a-table :pagination="false" v-if="isEdit" bordered :columns="columns" :dataSource="contractBasisAll" class="basisTableEdit">
        <span slot="action" slot-scope="text, record, index">
          <a-upload
            name="file"
            accept=".xls,.xlsx"
            
            @change="(v)=>saveFile(v,record,index)"
          
          >
            <a-button>
              选择文件
           </a-button>
          </a-upload>
          <a-button>删除文件</a-button>
          <div class="ant-divider ant-divider-vertical"></div>
          <a-button @click="doAdd(record,text,index)">添加</a-button>
        </span>
        <span slot="basisDate" slot-scope="text, record, index">
          <a-date-picker :value="moment(record.basisDate, 'YYYY-MM-DD')"/>
        </span>
        <span slot="amount" slot-scope="text, record, index">
          <a-input v-model="record.amount" />
        </span>
        <span slot="fileName" slot-scope="text, record, index">
          <a-input disabled v-model="record.fileName" />
        </span>
      </a-table>
      </div>
    </div>
  </div>
</template>
<script>
const columns_contractBasis = [
  {
    title: '依据名称',
    dataIndex: 'basisName',
    customRender: (text, row, index) => {
        const obj = {
          children: text,
          attrs: {},
        };
        obj.attrs.rowSpan = row.row;
        return obj;
    },
  }, {
    title: '日期',
    dataIndex: 'basisDate',
    scopedSlots: { customRender: 'basisDate' }
  }, {
    title: '金额',
    dataIndex: 'amount',
    scopedSlots: { customRender: 'amount' }
  }, {
    title: '附件名称',
    dataIndex: 'fileName',
    scopedSlots: { customRender: 'fileName' }
  }, {
    title: '操作',
    dataIndex: 'action',
    key: 'action',
    width: '30%',
    colSpan: 2,
    scopedSlots: { customRender: 'action' },
  }
];
var defaultBasis = [
  {
    key: '1',
    amount: "",
    basisDate: "2019-01-01",
    basisName: "商务谈判单",
    basisType: "",
    fileName: "",
    fileType: "",
    ossFileId: "",
    projectId: "",
    statue: "",
    uuid: ""
  },
  {
    key: '2',
    amount: "",
    basisDate: "",
    basisName: "汇报单",
    basisType: "",
    fileName: "",
    fileType: "",
    ossFileId: "",
    projectId: "",
    statue: "",
    uuid: ""
  },
  {
    key: '3',
    amount: "",
    basisDate: "2019-01-03",
    basisName: "签报单",
    basisType: "",
    fileName: "",
    fileType: "",
    ossFileId: "",
    projectId: "",
    statue: "",
    uuid: ""
  }
];
import {apiService} from "@/services/apiservice";
 
import Vue from 'vue';
import moment from 'moment';
export default {
    name: "contractBasis",
    data () {
        return {
            columns: columns_contractBasis,
            // data: data,
            // isEdit: true,
            selectedRowKeys: [], 
            optionDepart:[],
            optionDepartSelect:"",
            defaultBasis: defaultBasis,
            contractBasisAll: [],
            rowspan1:"0",
            rowspan2:"0",
            rowspan3:"0",
            defaultKey: 100,
            currentdate: '',

        }
    },
    components: {
    },
    props: ['isEdit','contractId','contractType','contractBasis'],
    computed: {
    },
    mounted(){
      if(!this.isEdit) columns_contractBasis.splice((columns_contractBasis.length-1), 1);

      if(this.contractBasis.length == 0) this.contractBasisAll = this.contractBasis.concat(this.defaultBasis);
      else this.contractBasisAll = this.contractBasis.concat();
      for(var i=0; i<this.contractBasisAll.length; i++){
        this.contractBasisAll[i].row = 0;
        if(this.contractBasisAll[i].basisName == '商务谈判单'){
          this.rowspan1++;
        }else if(this.contractBasisAll[i].basisName == '汇报单'){
          this.rowspan2++;
        }else if(this.contractBasisAll[i].basisName == '签报单'){
          this.rowspan3++;
        }
        if(!this.contractBasisAll[i].basisDate) this.contractBasisAll[i].basisDate = this.currentdate;
      }
      for(var i=0; i<this.contractBasisAll.length; i++){
        if(this.contractBasisAll[i].basisName == '商务谈判单'){
          this.contractBasisAll[i].row = this.rowspan1;
          break;
        }
      }
      for(var i=0; i<this.contractBasisAll.length; i++){
        if(this.contractBasisAll[i].basisName == '汇报单'){
          this.contractBasisAll[i].row = this.rowspan2;
          break;
        }
      }
      for(var i=0; i<this.contractBasisAll.length; i++){
        if(this.contractBasisAll[i].basisName == '签报单'){
          this.contractBasisAll[i].row = this.rowspan3;
          break;
        }
      }
    },
    created(){
      this.currentdate = this.getNowFormatDate()
    },
    watch: {
      contractBasisAll(val,info) {
        this.sendMsg()
      },
    },
    methods: {
        reset() {
        },
        sendMsg(){
           this.$emit('contractBasisAll',this.contractBasisAll)
        },
        doAdd(record,text,index){
          this.contractBasisAll.splice(index+1, 0, {
            key: this.defaultKey,
            amount: "",
            basisDate: "",
            basisName: record.basisName,
            basisType: "",
            fileName: "",
            fileType: "",
            ossFileId: "",
            projectId: "",
            statue: "",
            uuid: "",
            row: 0
          });
          for(var i=0; i<this.contractBasisAll.length; i++){
            console.log(this.contractBasisAll[i].basisName);
            console.log(record.basisName);
            console.log(this.contractBasisAll[i].row)
            if(this.contractBasisAll[i].basisName == record.basisName && this.contractBasisAll[i].row){
              console.log(2222);
              console.log(this.contractBasisAll[i].row);
              this.contractBasisAll[i].row = parseInt(this.contractBasisAll[i].row) + 1;
            }
          }
          this.defaultKey = this.defaultKey + 1;
          console.log(this.contractBasisAll);
        },
        onSelectChange (selectedRowKeys) {
          console.log('selectedRowKeys changed: ', selectedRowKeys);
          this.selectedRowKeys = selectedRowKeys
        },
        handleChangeDepart(val){
          this.optionDepartSelect=val
        },
        showPayModal(){
          this.payModal=true
          console.log(this.selectedRowKeys);
          let parmas={contractId:"b788df05-6ae2-4f1b-9945-d77b03839085",amountIds:"3363c9b46d374861ac31ee967a41c397"}
        },
        saveFile(info, record, index){
         let { file } = info
         let value = {
          name: file.name,
          type: file.type,
          size: file.size,
          status: file.status,
          percent: file.percent
        }
          console.log('2222');
          console.log(file);
          console.log(record);
          console.log(index);
          // let _self=this
          // const { fileList } = this;
          // const formData = new FormData();
          // formData.append('file', this.files);

          // reqwest({
          //   url: '/project/itmcAut/exportfile',
          //   method: 'post',
          //   processData: false,
          //   data: formData,
          //   success: () => {
          //     _self.fileList = []
          //     _self.$message.success('上传成功');
          //     _self.expVisible=false
          //     var params = {planYear: _self.optionDateSelect,investmentChannel:"B01"}
          //     params._json = true
          //     _self.loadTable(params)
          //     var params2 = {planYear:_self.optionDateSelect,investmentChannel:"B02"}
          //     params2._json = true
          //     _self.loadTable2(params2)
          //   },
          //   error: () => {
          //     _self.$message.error('上传失败');
          //     _self.expVisible=false
          //   },
          // });
        },
        getNowFormatDate(){
          var date = new Date();
          var seperator1 = "-";
          var year = date.getFullYear();
          var month = date.getMonth() + 1;
          var strDate = date.getDate();
          if (month >= 1 && month <= 9) {
              month = "0" + month;
          }
          if (strDate >= 0 && strDate <= 9) {
              strDate = "0" + strDate;
          }
          var currentdate = year + seperator1 + month + seperator1 + strDate;
          return currentdate;
        },
        goBack(){
          this.$router.go(-1)
        },
        moment,
    }
}
</script>
<style>
.basisTableEdit span span{
  display: inline-block;
}
</style>