<template>
  <div>
    <div style="margin-bottom: 10px">
      <a-button v-if="isEdit" @click="showSelectModal" class="ant-btn ant-btn-primary">选择</a-button>
      <a-button v-if="isEdit" @click="showAddModal" class="ant-btn ant-btn-primary">添加</a-button>
    </div>
    <div v-if="!isEdit">
      <div>
        <div class="ant-table-content">
          <div class="ant-table-body">
            <table style="width: 100%">
              <thead class="ant-table-thead">
              <tr>
                <th style="width: 50px;" class="">
                  <div>序号</div>
                </th>
                <th style="width: 50px;">
                  <div>种类</div>
                </th>
                <th class="">
                  <div>类型名称</div>
                </th>
                <th class="">
                  <div>配置名称</div>
                </th>
                <th class="">
                  <div>产品名称/型号</div>
                </th>
                <th class="">
                  <div>单价</div>
                </th>
                <th class="">
                  <div>数量（台、套）</div>
                </th>
                <th class="w-100">
                  <div>总价</div>
                </th>
                <th style="width: 50px;" v-if="isEdit" class="">
                  <div>操作</div>
                </th>
              </tr>
              </thead>
              <tbody class="ant-table-tbody">
              <tr v-if="contractAssetsDetail.length>0" v-for="(item,index) in contractAssetsDetail">
                <td>{{index+1}}</td>
                <td>{{(item.assetsModle == 1) ? '硬件' : '软件'}}</td>
                <td>{{item.assetsTypeName}}</td>
                <td>{{item.configureName}}</td>
                <td>{{item.productName}}</td>
                <td>{{item.unitPrice}}</td>
                <td>{{item.number}}</td>
                <td>{{item.totalPrice}}</td>
              </tr>
              <tr>
                <td colspan="7" style="text-align: right;">资金金额小计：</td>
                <td>{{baseInfo.assetsAmountSubtotal}}</td>
              </tr>
              <tr>
                <td colspan="5" style="text-align: right;">最终集成费费率（设备价的%）：</td>
                <td>{{baseInfo.expenseValue}}</td>
                <!-- <td><a-input v-model="item.assetsTypeName" /></td> -->
                <td style="text-align: right;">集成费金额</td>
                <td>{{baseInfo.expenseAmount}}</td>
              </tr>
              <tr>
                <td colspan="7" style="text-align: right;">合同最终优惠价：</td>
                <td>{{baseInfo.contractFinalPrice}}</td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
<!--    服务合同-->
    <div v-if="isEdit">
      <div>
        <div class="ant-table-content">
          <div class="ant-table-body">
            <table style="width: 100%">
              <thead class="ant-table-thead">
              <tr>
                <th style="width: 50px;" class="">
                  <div>序号</div>
                </th>
                <th style="width: 50px;">
                  <div>种类</div>
                </th>
                <th class="">
                  <div>类型名称</div>
                </th>
                <th class="">
                  <div>配置名称</div>
                </th>
                <th class="">
                  <div>产品名称/型号</div>
                </th>
                <th class="">
                  <div>单价</div>
                </th>
                <th class="">
                  <div>数量（台、套）</div>
                </th>
                <th class="w-100">
                  <div>总价</div>
                </th>
                <th style="width: 50px;" v-if="isEdit" class="">
                  <div>操作</div>
                </th>
              </tr>
              </thead>
              <tbody class="ant-table-tbody">
              <tr v-if="contractAssetsDetail.length>0" v-for="(item,index) in contractAssetsDetail">
                <td>{{index+1}}</td>
                <td>{{(item.assetsModle == 1) ? '硬件' : '软件'}}</td>
                <td>
                  <a-input v-model="item.assetsTypeName"/>
                </td>
                <td>
                  <a-input v-model="item.configureName"/>
                </td>
                <td>
                  <a-input v-model="item.productName"/>
                </td>
                <td>
                  <a-input  v-model="item.unitPrice" placeholder="请输入整数或小数"/>
                </td>
                <td>
                  <a-input  v-model="item.number" placeholder="请输入整数"/>
                </td>
                <td>
                  {{item.totalPrice}}
                  <!-- <a-input v-model="item.totalPrice" /> -->
                </td>
                <td>
                  <a @click="doDelete(index)">删除</a>
                </td>
              </tr>
              <tr>
                <td colspan="7" style="text-align: right;">资金金额小计：</td>
                <td colspan="2">{{baseInfo.assetsAmountSubtotal}}</td>
              </tr>
              <tr>
                <td colspan="5" style="text-align: right;">最终集成费费率（设备价的%）：</td>
                <td>
                  <a-input-number class="inputExpenseValue"
                    size="small" v-model="baseInfo.expenseValue"  @change="expenseValueChange"/>
                  <span style="margin-left: 5px;">%</span></td>
                <td style="text-align: right;">金额</td>
                <td colspan="2">{{baseInfo.expenseAmount}}</td>
              </tr>
              <tr>
                <td colspan="7" style="text-align: right;">合同最终优惠价：</td>
                <td colspan="2">{{baseInfo.contractFinalPrice}}</td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- 选择模态框 -->
    <a-modal
      title="选择设备"
      :width="900"
      centered
      okText='添加'
      cancelText='取消'
      @ok="() => addConfigs()"
      v-model="selectModal">
      <div style="height: 352px">
        <div id="affixTableBox">
          <div id="affixTableTree">
            <div>
              <span class="demandline"></span>
              <span class="demandtitle">设备分类</span>
            </div>
            <div id="selectTreeList" class="ztree mt10" style="border: none;">
              <a-tree
                showLine
                :treeData="treeData"
                @select="onSelect"
              />
            </div>
          </div>
          <div id="affixTableData">
            <div class="table-page-search-wrapper">
              <a-form layout="inline">
                <div>
                  <a-form-item label="配置名称">
                    <a-input v-model="deviceConfig"/>
                  </a-form-item>
                  <a-form-item label="产品名称">
                    <a-input v-model="deviceName"/>
                  </a-form-item>
                  <a-form-item>
                  <span class="table-page-search-submitButtons">
                    <a-button @click="deviceListSearch" type="primary" icon="search">查询</a-button>
                  </span>
                  </a-form-item>
                </div>
              </a-form>
            </div>
            <div style="text-align: right;margin: 5px 0;">
              <span>单位：元</span>
            </div>
            <div id="affixTableList">
              <div>
                <a-table style="width: 100%;" ref="deleteMore" :pagination="false" bordered
                         :columns="columns_deviceList" :dataSource="deviceListData" :rowSelection="productRowSelection"
                         rowKey="id">
                  <span slot="deviceConfig" slot-scope="text, record, index">
                    <span :title="record.deviceConfig">{{record.deviceConfig}}</span>
                  </span>
                  <span slot="deviceName" slot-scope="text, record, index">
                    <span :title="record.deviceName">{{record.deviceName}}</span>
                  </span>
                  <span slot="deviceModel" slot-scope="text, record, index">
                    <span :title="record.deviceModel">{{record.deviceModel}}</span>
                  </span>
                  <span slot="unitPrice" slot-scope="text, record, index">
                    <span :title="record.unitPrice">{{record.unitPrice}}</span>
                  </span>
                </a-table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </a-modal>
    <!-- 添加模态框 -->
    <a-modal
      title="添加设备"
      :width="450"
      centered
      okText='添加'
      cancelText='取消'
      @ok="() => addConfigs1()"
      v-model="addModal">
      <div style="height: 352px">
        <div id="affixTableBox">
          <div id="addTableTree">
            <div>
              <span class="demandline"></span>
              <span class="demandtitle">设备分类</span>
            </div>
            <div id="addTreeList" class="ztree mt10 affixTreeList" style="border: none;">
              <a-tree
                checkStrictly
                showLine
                :treeData="treeData"
                @check="onAddSelect"
                checkable
              />
            </div>
          </div>
        </div>
      </div>
    </a-modal>
  </div>
</template>
<script>
  const columns_assetsDetail = [
    {
      title: '种类',
      dataIndex: 'assetsType',
    }, {
      title: '类型名称',
      dataIndex: 'assetsTypeName',
    }, {
      title: '配置名称',
      dataIndex: 'configureName',
    }, {
      title: '产品名称/型号',
      dataIndex: 'productName',
    }, {
      title: '单价',
      dataIndex: 'unitPrice',
    }, {
      title: '数量（台、套）',
      dataIndex: 'number',
    }, {
      title: '总价',
      dataIndex: 'totalPrice',
    }
  ];
  const columns_deviceList = [
    {
      title: '配置名称',
      dataIndex: 'deviceConfig',
      width: 160,
      scopedSlots: {customRender: 'deviceConfig'}
    }, {
      title: '产品名称',
      dataIndex: 'deviceName',
      width: 160,
      className: 'column-deviceName',
      scopedSlots: {customRender: 'deviceName'}
    }, {
      title: '品牌',
      dataIndex: 'pinPai',
      width: 60,
    }, {
      title: '型号',
      dataIndex: 'deviceModel',
      width: 100,
      scopedSlots: {customRender: 'deviceModel'}
    }, {
      title: '价格',
      dataIndex: 'unitPrice',
      width: 100,
      scopedSlots: {customRender: 'unitPrice'}
    }
  ];
  import {apiService} from "@/services/apiservice";

  import Vue from 'vue';

  import dom from 'jquery';

  export default {
    name: "AmountDetail",
    data() {
      return {
        columns: columns_assetsDetail,
        columns_deviceList: columns_deviceList,
        deviceListData: [],
        selectedDeviceKeys: [],
        selectedProductKeys: [],
        // selectedProductKeys: [],
        contractAssetsDetailCopy: [],
        selectedProductRow: [],
        addProductRow: [],
        selectedRows: [],
        optionDepart: [],
        optionDepartSelect: "",
        deviceConfig: '',
        deviceName: '',
        selectModal: false,
        addModal: false,
        treeData: [
          {title: '硬件分类', key: '0'},
          {title: '软件分类', key: '1'},
        ],
      }
    },
    props: ['isEdit', 'contractId', 'contractType', 'contractAssetsDetail', 'baseInfo'],
    computed: {
      productRowSelection() {
        const {selectedRowKeys} = this;
        return {
          onChange: (selectedRowKeys, selectedRows) => {
            this.selectedProductRow = selectedRows;
            this.selectedProductKeys = selectedRowKeys;
          }
        }
      },
      // 资金金额小计
      // assetsAmountSubtotal() {
      //   let assetsAmountSubtotal = 0;
      //   this.contractAssetsDetail.map((item) => {
      //     if (isNaN(item.totalPrice) || item.totalPrice.length == 0) item.totalPrice = 0
      //     assetsAmountSubtotal += parseFloat(item.totalPrice)
      //   })
      //   return parseFloat(assetsAmountSubtotal).toFixed(2)
      // },
    },
    mounted() {
    },
    watch: {
      contractAssetsDetail:{
        handler(val,old){

          // const  IntegerFloat = /^[\d]{1,9}((\.)?|(\.{0,1}[\d]{1,2}))?$/;
          // const   NonNumeric = /[^\d\.]+/;
          // const rate = /^(([\d]{0,5})|([1][0][0])?)$/;
          // const NotRate = /[^\d]+/;
          // const thousandsIntReg = /[\d]{3}$/;
          // let assetsAmountSubTotal = 0;
          // if(this.contractType == "01"){
          //   for(let i = 0; i < val.length; i++){
          //     if(NonNumeric.test(val[i].unitPrice)){
          //       val[i].unitPrice = "0";
          //     }
          //     if(NotRate.test(val[i].number)){
          //       val[i].number = "0";
          //     }
          //     if(!IntegerFloat.test(val[i].unitPrice)){
          //       if(val[i].unitPrice.length > 0){
          //         val[i].unitPrice = val[i].unitPrice.substring(0,val[i].unitPrice.length -1);
          //       }
          //     }
          //     if(!rate.test(val[i].number)){
          //       if(val[i].number.length > 0){
          //         val[i].number = val[i].number.substring(0,val[i].number.length - 1);
          //       }
          //     }
          //     //计算每行总价
          //     val[i].totalPrice = (((val[i].unitPrice == undefined ||val[i].unitPrice == "" || val[i].unitPrice == "0") ?  0 : parseFloat(val[i].unitPrice)) * ((val[i].number == undefined || val[i].number == "" || val[i].number == "0") ? 0 : parseFloat(val[i].number))).toFixed(2) + "";
          //     assetsAmountSubTotal += parseFloat(val[i].totalPrice);
          //   }
          // } else if (this.contractType == "02") {
          //   for(let i = 0; i < val.length;i++){
          //     //计算每行总价
          //     val[i].totalPrice = (((val[i].unitPrice == undefined ||val[i].unitPrice == "" || val[i].unitPrice == "0") ?  0 : parseFloat(val[i].unitPrice)) * ((val[i].number == undefined || val[i].number == "" || val[i].number == "0") ? 0 : parseFloat(val[i].number))).toFixed(2) + "";
          //     assetsAmountSubTotal += parseFloat(val[i].totalPrice);
          //   }
          // }
          // // hardWareAndSoftWareCost:{hardWarea:"",softWare:""}//硬件、软件费用
          // // let wareCost = {};
          // this.baseInfo.assetsAmountSubtotal = assetsAmountSubTotal.toFixed(0);
          // /** 合同最终优惠价=硬件小计*(1+约定集成费费率)，要求千位取整
          //     最终集成费费率=（合同最终优惠价千位取整-硬件小计）/硬件小计
          //      集成费金额=合同最终优惠价-硬件小计
          //  */
          // /**
          //    1)在附件：固定资产无形资产使用情况模块中，添加或者选择软件和硬件产品会将其计算出总价  为“小计”
          //    2)集成费按照合同金额计算，大于等于500万元为2%，小于500万为3%，系统根据合同金额给出默认约定集成费费率，用户可以根据自身需求进行修改
          //    3)合同最终优惠价=软硬件小计+软硬件小计*约定集成费费率
          //   */
          // //合同最终优惠价
          //
          // let   expenseValueTemp = parseInt(this.baseInfo.expenseValue == "" ? "0" : this.baseInfo.expenseValue);
          // let endContractFinal = 0;//合同最终优惠价
          // let expenseValueY = "";//最终集成费率
          // // if(expenseValueTemp > 0 && expenseValueTemp != 2 && expenseValueTemp != 3){//客户自定义集成费计算
          // //
          // // } else { //合同规定集成费计算
          //    //集成费率按3%或2%计算
          //   if(parseFloat(this.baseInfo.assetsAmountSubtotal) < parseFloat(5000000)){
          //     this.baseInfo.expenseValue = "3";
          //     endContractFinal = (parseInt(this.baseInfo.assetsAmountSubtotal)*(1+ 0.03)).toFixed(0).replace(thousandsIntReg,"000");
          //
          //   } else {
          //     this.baseInfo.expenseValue = "2";
          //     endContractFinal = (parseInt(this.baseInfo.assetsAmountSubtotal)*(1+ 0.02)).toFixed(0).replace(thousandsIntReg,"000");
          //   }
          // // }
          //
          // //计算集成费
          // let expenseValue = this.baseInfo.expenseValue;
          // this.baseInfo.expenseAmount = parseFloat((parseFloat(IntegerFloat.test(this.baseInfo.assetsAmountSubtotal) ?  this.baseInfo.assetsAmountSubtotal : "0")) * ((this.baseInfo.expenseValue == "" ? 0 : this.baseInfo.expenseValue / 100))).toFixed(2);
          // //最终合同价
          // this.baseInfo.contractFinalPrice = (parseFloat(this.baseInfo.assetsAmountSubtotal) + parseFloat(this.baseInfo.expenseAmount));
          // this.baseInfo.contractTaxAmount = this.baseInfo.contractFinalPrice;
        this.contractAssetsDetailReg(val);
        this.contractAssetsDetailComputer(val);


        },
        deep:true
      },
      'baseInfo.expenseValue':function(val,old){
        this.baseInfoExpenseValueReg(val);
       // this.expenseValueChange(this.baseInfo.expenseValue);
        //this.baseInfoExpenseValueComputer();
       // this.contractAssetsDetailComputer(this.contractAssetsDetail);
      },
      contractAssetsDetailCopy(val, info) {
        this.sendMsg()
      },
      // 资金金额小计
      // assetsAmountSubtotal(val, info) {
      //   this.baseInfo.assetsAmountSubtotal = val
      //   this.baseInfo.expenseAmount = parseFloat(val * this.baseInfo.expenseValue / 100).toFixed(2)
      //   this.baseInfo.contractFinalPrice = parseFloat(val * (1 + this.baseInfo.expenseValue / 100)).toFixed(2)
      // }
    },
    methods: {
      expenseValueChange(str){
        if(str < 0){
          str = 0;
        }

        let val = str + "";
        const thousandsIntReg = /[\d]{3}\.[\d]{2}$/;
        let  endDiscountsPrice = "0";//合同最终优惠价
        let  endIntegrationRate = 0;//最终集成费费率
        let  integrationPrice = "0";//集成费金额
        const notNumber = /[^\d]/;
        // if (!notNumber.test(val)) {
          endDiscountsPrice = (parseFloat(this.baseInfo.assetsAmountSubtotal) * (1 + (parseInt(val)/100))).toFixed(2).replace(thousandsIntReg,"000.00");
          endIntegrationRate = ((parseFloat(endDiscountsPrice) - parseFloat(this.baseInfo.assetsAmountSubtotal)) / parseFloat(this.baseInfo.assetsAmountSubtotal)).toFixed(2);
          endIntegrationRate = (parseFloat(endIntegrationRate) * 100).toFixed(0);
          integrationPrice = (parseFloat(endDiscountsPrice) - parseFloat(this.baseInfo.assetsAmountSubtotal)).toFixed(2);
          //集成费率
          this.baseInfo.expenseValue = endIntegrationRate;
          this.baseInfo.expenseAmount = integrationPrice;
          //最终合同优惠价
          this.baseInfo.contractFinalPrice = endDiscountsPrice;

        this.baseInfo.contractTaxAmount = endDiscountsPrice;

        if(this.contractType == "02"){
          this.baseInfo.contractTaxAmount = (parseFloat(endDiscountsPrice) + (parseFloat((this.baseInfo.tempJinEMingXi == undefined || this.baseInfo.tempJinEMingXi == "") ? "0" : this.baseInfo.tempJinEMingXi)));
        }

        //合同付款明细
        let contractPaymentDetail = this.$parent.getContractPaymentDetail();
        for(let i = 0;i < contractPaymentDetail.length;i++){
          contractPaymentDetail[i].paymentRatio
          if(contractPaymentDetail[i].paymentRatio == "90"){
            contractPaymentDetail[i].paymentAmount = ((parseFloat(endDiscountsPrice) * 90)/100).toFixed(2);
          } else if(contractPaymentDetail[i].paymentRatio == "10") {
            contractPaymentDetail[i].paymentAmount = ((parseFloat(endDiscountsPrice) * 10)/100).toFixed(2);
          }
        }
        // }
      },

      baseInfoExpenseValueReg(expenseValue){//集成费率校验
        let expenseValueStr = expenseValue + "";

        const rate = /^(([\d]{0,2})|([1][0][0])?)$/;
        const  IntegerFloat = /^[\d]{1,9}((\.)?|(\.{0,1}[\d]{1,2}))?$/;
        const NotRate = /[^\d]+/;
        let json = {};
        if(NotRate.test(expenseValueStr)){
          expenseValueStr = '0';
          this.baseInfo.expenseValue = parseInt("0");
          Object.assign(json,this.baseInfo);
          this.$parent.baseInfo = json;
          dom(".inputExpenseValue").find("input").blur();
        }
        if(!rate.test(expenseValueStr)){
          if(expenseValueStr.length > 0){
            expenseValueStr =  parseInt(expenseValueStr.substring(0,expenseValueStr.length - 1));
            this.baseInfo.expenseValue = parseInt(expenseValueStr);
            Object.assign(json,this.baseInfo);
            this.$parent.baseInfo= json;
            dom(".inputExpenseValue").find("input").blur();
          }
        }
      },
      baseInfoExpenseValueComputer(){
        const thousandsIntReg = /[\d]{3}\.[\d]{2}$/;
        let  endDiscountsPrice = "0";//合同最终优惠价
        let  endIntegrationRate = 0;//最终集成费费率
        let  integrationPrice = "0";//集成费金额

        endIntegrationRate = ((parseFloat(this.baseInfo.contractFinalPrice) - parseFloat(this.baseInfo.assetsAmountSubtotal)) / parseFloat(this.baseInfo.assetsAmountSubtotal)).toFixed(2);
        endIntegrationRate = parseFloat(endIntegrationRate) * 100;

        integrationPrice = (parseFloat(this.baseInfo.contractFinalPrice) - parseFloat(this.baseInfo.assetsAmountSubtotal)).toFixed(2);

        //硬件小计
       // this.baseInfo.assetsAmountSubtotal = assetsAmountSubTotal.toFixed(2);

        //集成费率
       this.baseInfo.expenseValue = endIntegrationRate;
       this.baseInfo.expenseAmount = integrationPrice;
        //最终合同优惠价
        this.baseInfo.contractFinalPrice = this.baseInfo.contractFinalPrice;


      },
      contractAssetsDetailReg(contractAssetsDetails){//校验和计算
        const  IntegerFloat = /^[\d]{1,9}((\.)?|(\.{0,1}[\d]{1,2}))?$/;
        const   NonNumeric = /[^\d\.]+/;
        const rate = /^(([\d]{0,5})|([1][0][0])?)$/;
        const NotRate = /[^\d]+/;

          for(let i = 0; i < contractAssetsDetails.length; i++){
            if(NonNumeric.test(contractAssetsDetails[i].unitPrice)){
              contractAssetsDetails[i].unitPrice = "";
            }
            if(NotRate.test(contractAssetsDetails[i].number)){
              contractAssetsDetails[i].number = "";
            }
            if(!IntegerFloat.test(contractAssetsDetails[i].unitPrice)){
              if(contractAssetsDetails[i].unitPrice.length > 0){
                contractAssetsDetails[i].unitPrice = contractAssetsDetails[i].unitPrice.substring(0,contractAssetsDetails[i].unitPrice.length -1);
              }
            }
            if(!rate.test(contractAssetsDetails[i].number)){
              if(contractAssetsDetails[i].number.length > 0){
                contractAssetsDetails[i].number = contractAssetsDetails[i].number.substring(0,contractAssetsDetails[i].number.length - 1);
              }
            }
          }
      },
      contractAssetsDetailComputer(contractAssetsDetail){
        const thousandsIntReg = /[\d]{3}\.[\d]{2}$/;
        let assetsAmountSubTotal = 0;//硬件小计
        let handWareCostSum = 0;//硬件费用
        let softWareCostSum = 0;//软件费用
        for (let i =0; i < contractAssetsDetail.length;i++) {
          //计算每行总价
          contractAssetsDetail[i].totalPrice = (((contractAssetsDetail[i].unitPrice == undefined ||contractAssetsDetail[i].unitPrice == "" || contractAssetsDetail[i].unitPrice == "0") ?  0 : parseFloat(contractAssetsDetail[i].unitPrice)) * ((contractAssetsDetail[i].number == undefined || contractAssetsDetail[i].number == "" || contractAssetsDetail[i].number == "0") ? 0 : parseFloat(contractAssetsDetail[i].number))).toFixed(2) + "";
          assetsAmountSubTotal += parseFloat(contractAssetsDetail[i].totalPrice);

          if (contractAssetsDetail[i].assetsModle == "硬件") {
            handWareCostSum += parseFloat((contractAssetsDetail[i].totalPrice == undefined || contractAssetsDetail[i].totalPrice == "") ? "0" : contractAssetsDetail[i].totalPrice);
          } else if (contractAssetsDetail[i].assetsModle == "软件") {
            softWareCostSum += parseFloat((contractAssetsDetail[i].totalPrice == undefined || contractAssetsDetail[i].totalPrice == "") ? "0" : contractAssetsDetail[i].totalPrice);
          } else if (contractAssetsDetail[i].assetsModle == "1") {//硬件
            handWareCostSum += parseFloat((contractAssetsDetail[i].totalPrice == undefined || contractAssetsDetail[i].totalPrice == "" ) ? "0" : contractAssetsDetail[i].totalPrice);
          } else if (contractAssetsDetail[i].assetsModle == "2") {//软件
            softWareCostSum += parseFloat((contractAssetsDetail[i].totalPrice == undefined || contractAssetsDetail[i].totalPrice == "") ? "0" : contractAssetsDetail[i].totalPrice);
          }
        }
        let contractAmountDetail = this.$parent.getContractAmountDetail();
        for (let i = 0; i < contractAmountDetail.length; i++) {
          if (contractAmountDetail[i].replyType == "03") { //硬件
            contractAmountDetail[i].amount = handWareCostSum;
          } else if (contractAmountDetail[i].replyType == "02") {
            contractAmountDetail[i].amount = softWareCostSum;
          }
        }
        //硬件小计
        this.baseInfo.assetsAmountSubtotal = assetsAmountSubTotal.toFixed(2);
       /** 硬件小计	约定集成费费率	最终集成费费率	集成费金额	合同最终优惠价
        >=500万元	2%	2%及以下	根据计算方法计算。	保持千位整数，百、十、个位及小数位为零。
        <500万元	3%	3%及以下
        计算公式：	合同最终优惠价=硬件小计*(1+约定集成费费率)，要求千位取整
                  最终集成费费率=（合同最终优惠价千位取整-硬件小计）/硬件小计
                  集成费金额=合同最终优惠价-硬件小计
        */
         let  endDiscountsPrice = "0";//合同最终优惠价
         let  endIntegrationRate = 0;//最终集成费费率
         let  integrationPrice = "0";//集成费金额
        if(parseFloat(this.baseInfo.assetsAmountSubtotal) >= parseFloat(5000000)){//大于等于500 万
          const appointRate = "2";
          endDiscountsPrice = (parseFloat(this.baseInfo.assetsAmountSubtotal) * (1 + 0.02)).toFixed(2).replace(thousandsIntReg,"000.00");
          if(this.baseInfo.assetsAmountSubtotal != "" && this.baseInfo.assetsAmountSubtotal != "0.00"){
            endIntegrationRate = ((parseFloat(endDiscountsPrice) - parseFloat(this.baseInfo.assetsAmountSubtotal)) / parseFloat(this.baseInfo.assetsAmountSubtotal)).toFixed(2);
            endIntegrationRate = parseFloat(endIntegrationRate) * 100;
            integrationPrice = (parseFloat(endDiscountsPrice) - parseFloat(this.baseInfo.assetsAmountSubtotal)).toFixed(2);
          }
        } else if (parseFloat(this.baseInfo.assetsAmountSubtotal) < parseFloat(5000000)) {//小于500万
          const appointRate = "3";
          if(this.baseInfo.assetsAmountSubtotal != "" && this.baseInfo.assetsAmountSubtotal != "0.00"){
            endDiscountsPrice = (parseFloat(this.baseInfo.assetsAmountSubtotal) * (1 + 0.03)).toFixed(2).replace(thousandsIntReg,"000.00");
            endIntegrationRate = ((parseFloat(endDiscountsPrice) - parseFloat(this.baseInfo.assetsAmountSubtotal)) / parseFloat(this.baseInfo.assetsAmountSubtotal)).toFixed(2);
            endIntegrationRate = parseFloat(endIntegrationRate) * 100;
            integrationPrice = (parseFloat(endDiscountsPrice) - parseFloat(this.baseInfo.assetsAmountSubtotal)).toFixed(2);
          }
        }

        //集成费率
        this.baseInfo.expenseValue = endIntegrationRate;
        this.baseInfo.expenseAmount = integrationPrice;
        //最终合同优惠价
        this.baseInfo.contractFinalPrice = endDiscountsPrice;

        this.baseInfo.contractTaxAmount = endDiscountsPrice;
        this.baseInfo.contractTaxAmountTemp = endDiscountsPrice;

        if(this.contractType == "02"){
          this.baseInfo.contractTaxAmount = (parseFloat(endDiscountsPrice) + (parseFloat((this.baseInfo.tempJinEMingXi == undefined || this.baseInfo.tempJinEMingXi == "") ? "0" : this.baseInfo.tempJinEMingXi)));
        }

        //合同付款明细
        let contractPaymentDetail = this.$parent.getContractPaymentDetail();
        for(let i = 0;i < contractPaymentDetail.length;i++){
          contractPaymentDetail[i].paymentRatio
          if(contractPaymentDetail[i].paymentRatio == "90"){
            contractPaymentDetail[i].paymentAmount = ((parseFloat(endDiscountsPrice) * 90)/100).toFixed(2);
          } else if(contractPaymentDetail[i].paymentRatio == "10") {
            contractPaymentDetail[i].paymentAmount = ((parseFloat(endDiscountsPrice) * 10)/100).toFixed(2);
          }
        }
      },
      // 表格列表页删除按钮
      doDelete(index) {
        this.contractAssetsDetail.splice(index, 1);
      },
      // 表格列表总价计算
      calcTotalPrice(unitPrice, number, index) {
        this.contractAssetsDetail[index].totalPrice = (parseFloat(unitPrice) * parseFloat(number)).toFixed(2);
      },
      sendMsg() {
        this.$emit('contractAssetsDetailCopy', this.contractAssetsDetailCopy)
      },
      // 选择按钮点击事件
      showSelectModal() {
        this.selectModal = true
        this.getItmcInvestmentDevicetypeList()
      },
      // 添加按钮点击事件
      showAddModal() {
        this.addModal = true
        this.getItmcInvestmentDevicetypeList()
      },
      // 获取软件/硬件数据，并渲染tree
      getItmcInvestmentDevicetypeList() {
        let _self = this
        let parmasData = {deviceType: 0, deviceTypeId: ''}
        apiService.getItmcInvestmentDevicetypeList(parmasData).then(r => {
          this.createAssetTree(r)
        }, r => {
        }).catch(
        )
      },
      // 根据设备信息渲染表格函数
      getInvestmentDevicedetailList(parmasData) {
        let _self = this
        apiService.getInvestmentDevicedetailList(parmasData).then(r => {
          _self.deviceListData = r;
        }, r => {
        }).catch(
        )
      },
      // 渲染树函数
      createAssetTree(r) {
        // 硬件
        var equipment = r.investmentEquipmenttypeList[0]
        var equinode = this.createNodes(equipment.deviceTypeName,
          equipment.deviceTypeId,
          equipment.deviceTypeList, equipment.deviceMainTypeId);
        Vue.set(this.treeData, 0, equinode);
        // 软件
        var softwareData = r.investmentSoftwaretypeList[0]
        var softnode = this.createNodes(softwareData.deviceTypeName,
          softwareData.deviceTypeId,
          softwareData.deviceTypeList, equipment.deviceMainTypeId);
        Vue.set(this.treeData, 1, softnode);
      },
      // 递归函数创建树节点
      createNodes(text, id, list, type, folder, leafNode) {
        let that = this;
        var node = {};
        node.title = text;
        node.key = id;
        node.type = type;
        node.folder = folder;
        node.leafNode = leafNode;
        node.children = [];
        if (list)
          list.forEach(function (c, index, data) {
            node.children.push(
              that.createNodes(c.deviceTypeName, c.deviceTypeId, c.deviceTypeList, c.deviceMainTypeId, c.folder, c.leafNode))
          });
        return node;
      },
      // 添加设备复选框选择select事件
      onSelect(selectedKeys, info) {
        var _self = this;
        var deviceInfo = {
          SoftOrHard: 0,
          DeviceType: selectedKeys[0],
          DeviceConfig: _self.deviceConfig,
          DeviceName: _self.deviceName
        }
        this.getInvestmentDevicedetailList(deviceInfo);
        this.selectedDeviceKeys = selectedKeys
      },
      // 添加设备复选框选择check事件
      onAddSelect(selectedKeys, info) {
        var _self = this;
        _self.addProductRow = info.checkedNodes;
      },
      // 选择设备模态框表格查询
      deviceListSearch() {
        var _self = this;
        var deviceInfo = {
          SoftOrHard: 0,
          DeviceType: _self.selectedDeviceKeys[0],
          DeviceConfig: _self.deviceConfig,
          DeviceName: _self.deviceName
        }
        this.getInvestmentDevicedetailList(deviceInfo);
      },
      goBack() {
        this.$router.go(-1)
      },
      // 选择设备确认按钮回调函数
      addConfigs() {
        var _self = this;
        var index = _self.contractAssetsDetail.length;
        for (var i = 0; i < _self.selectedProductRow.length; i++) {
          Vue.set(this.contractAssetsDetail, index, {
            assetsModle: _self.selectedProductRow[i].softOrHard,
            assetsType: _self.selectedProductRow[i].deviceType,
            assetsTypeName: _self.selectedProductRow[i].deviceTypeName,
            configureName: _self.selectedProductRow[i].deviceConfig,
            productName: _self.selectedProductRow[i].deviceName,
            unitPrice: _self.selectedProductRow[i].unitPrice,
            number: 1,
            totalPrice: _self.selectedProductRow[i].unitPrice
          })
          index++;
        }
        _self.selectModal = false;
      },
      // 添加设备确认按钮回调函数
      addConfigs1() {
        let _self = this
        var contractAssetsDetailCopy = this.contractAssetsDetail.concat()
        var index = _self.contractAssetsDetail.length
        //选择叶子节点
        _self.addProductRow = _self.addProductRow.filter(function (item) {
          return item.data.props.dataRef.leafNode == true;
        });
        for (var i = 0; i < _self.addProductRow.length; i++) {
          Vue.set(contractAssetsDetailCopy, index, {
            assetsModle: _self.addProductRow[i].data.props.dataRef.type,
            assetsType: _self.addProductRow[i].data.props.dataRef.key,
            assetsTypeName: _self.addProductRow[i].data.props.dataRef.title,
            configureName: '',
            productName: '',
            unitPrice: '',
            number: 1,
            totalPrice: ''
          })
          index++;
        }
        this.contractAssetsDetailCopy = this.unique(contractAssetsDetailCopy, 'assetsType');
        _self.addModal = false;
      },
      // 根据唯一标识过滤数组
      unique(arr, name) {
        var hash = {};
        return arr.reduce(function (item, next) {
          hash[next[name]] ? '' : hash[next[name]] = true && item.push(next);
          return item;
        }, []);
      },
    }
  }
</script>
<style>
  #affixTableBox {
    display: flex;
    height: 100%;
  }

  #affixTableTree {
    padding-right: 10px;
    width: 23%;
    overflow-x: hidden;
    border-right: 1px solid #EDEDED;
  }

  #addTableTree {
    padding-right: 10px;
    width: 100%;
    overflow-x: hidden;
  }

  .affixTreeList {
    height: 331px;
    overflow-y: auto;
    overflow-x: hidden;
  }

  #affixTableData {
    width: 77%;
    padding: 10px;
    flex: 1;
  }

  .demandline {
    border-right: 6px solid #409EFF;
    height: 20px;
  }

  .demandtitle {
    font-size: 14px;
    font-weight: bold;
    margin-left: 10px;
  }

  #affixTableList {
    overflow: scroll;
    overflow-x: hidden;
    height: 282px;
    border: 1px solid #ddd;
    border-left: none;
  }

  #affixTableList table {
    width: 100%;
    table-layout: fixed;
  }

  #affixTableList table tbody tr td {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  #affixTableList .ant-table-selection-column {
    width: 40px;
  }

  .w-100 {
    width: 100px;
  }
</style>
