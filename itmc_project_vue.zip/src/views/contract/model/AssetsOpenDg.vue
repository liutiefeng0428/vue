<template>
  <div>
    <a-tree
      showLine
      :treeData="treeData"
      @select="onSelect"
    />
  </div>
</template>
<script>
 
import {apiService} from "@/services/apiservice";
 
import Vue from 'vue';
export default {
    name: "AssetsOpenDg",
    data () {
        return {
            columns: columns_assetsDetail,
            columns_deviceList: columns_deviceList,
            deviceListData: [],
            // data: data,
            // isEdit: true,
            selectedRowKeys: [], 
            selectedRows:[],
            optionDepart:[],
            optionDepartSelect:"",
            selectModal:false,
            addModal:false,
            treeList:{},
            treeData: [
              { title: '硬件分类', key: '0'},
              { title: '软件分类', key: '1'},
            ],
            equipmentData:[],
            softwareData:[],
        }
    },
    props: ['isEdit','contractId','contractType','contractAssetsDetail'],
    computed: {
      rowSelection() {
        const { selectedRowKeys } = this;
        return {
          onChange: (selectedRowKeys, selectedRows) => {
            this.selectedRows = selectedRows;
          }
        }
      },
    },
    mounted(){
    },
    methods: { 
        onSelectChange (selectedRowKeys) {
          console.log('selectedRowKeys changed: ', selectedRowKeys);
          this.selectedRowKeys = selectedRowKeys
        },
        handleChangeDepart(val){
          this.optionDepartSelect=val
        },
        
        getItmcInvestmentDevicetypeList(){
          let _self=this
          let parmasData={deviceType:0, deviceTypeId:''}
          apiService.getItmcInvestmentDevicetypeList(parmasData).then(r => {
              this.createAssetTree(r)
          }, r => {
          }).catch(
          )
        },
       createAssetTree(r)
        {
            var equipment= r.investmentEquipmenttypeList[0] 
            var equinode= this.createNodes(equipment.deviceTypeName,
            equipment.deviceTypeId,
            equipment.deviceTypeList) ;
           Vue.set(this.treeData, 0, equinode); 
           var softwareData= r.investmentSoftwaretypeList[0] 
            var softnode= this.createNodes(softwareData.deviceTypeName,
            softwareData.deviceTypeId,
            softwareData.deviceTypeList) ;
           Vue.set(this.treeData, 1, softnode);

            console.log("树节点")
            console.log(this.treeData)

        },
        createNodes(text,id,list)
        {
          let that =this;
          var node ={} ;
          node.title=text;
          node.key=id;
          node.children=[];
          if(list)
            list.forEach(function(c,index,data){
              node.children.push(
                  that.createNodes(c.deviceTypeName,c.deviceTypeId,c.deviceTypeList))
            });
         return node;
        },
        goBack(){
          this.$router.go(-1)
        }
    }
}
</script>
<style>
    #affixTableBox {
      display: flex;
      height: 100%;
    }
    #affixTableTree {
      padding-right: 10px;
      width: 23%;
      overflow-x: hidden;
      border-right: 1px solid #EDEDED;
    }
    #affixTableData {
      width: 77%;
      padding: 10px;
      flex: 1;
    }
    .demandline {
      border-right: 6px solid #409EFF;
      height: 20px;
    }
    .demandtitle {
      font-size: 14px;
      font-weight: bold;
      margin-left: 10px;
    }
    #affixTableList{
      overflow:  scroll;
      overflow-x:hidden;
      height:200px;
      border:1px solid #ddd;
      border-left:none;
    }
    #affixTableList .table tbody tr td{
      overflow: hidden;
      text-overflow:ellipsis;
      white-space: nowrap;
    }
</style>