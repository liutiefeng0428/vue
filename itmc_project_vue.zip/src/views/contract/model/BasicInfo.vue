<template>
  <div>
    <div>
      <div class="ant-table-content">
        <div class="ant-table-body">
          <table style="width: 100%" id="baseInfoTable">
            <tbody class="ant-table-tbody">
            <tr>
              <td class="describeTd">合同类型:</td>
              <td v-if="isEdit">
                <a-select
                  :size="size"
                  :value="baseInfo.contractType ? baseInfo.contractType : ''"
                  v-model="baseInfo.contractType"
                  style="width: 100%"
                  @change="handleChangeContractType">
                  <a-select-option
                    v-for="item in (contractType == '01' ? contractTypeList : (contractType == '02' ? contractCostTypeList : []))"
                    :key="item.optionCode" :value="item.optionCode">
                    {{item.optionName}}
                  </a-select-option>
                </a-select>
              </td>
              <td v-else>
                <div v-if="contractType == '01'">
                  <span v-if="baseInfo.contractType=='0101'">采购合同</span>
                  <span v-if="baseInfo.contractType=='0102'">服务合同</span>
                </div>
                <div v-else-if="contractType == '02'">
                  <span v-if="baseInfo.contractType=='0201'">采购合同</span>
                  <span v-if="baseInfo.contractType=='0202'">服务合同</span>
                  <span v-if="baseInfo.contractType=='0203'">合同</span>
                </div>
              </td>
              <td class="describeTd" v-if="contractType == '01'">项目名称:</td>
              <td v-if="true == isAdd && contractType == '01'">
                <a-input read-only style="width: calc(100% - 90px)" v-model="baseInfo.projectName"/>
                <a-button @click="showSelectModal()" class="ant-btn ant-btn-primary">选择</a-button>
              </td>
              <td v-if="isAdd != true && contractType == '01'">{{baseInfo.projectName}}</td>

              <td class="describeTd" v-if="contractType == '02'">开支类型:</td>
              <td v-if="contractType == '02' && isAdd == true">
                <a-select
                  mode="multiple"
                  :size="size"
                  v-model="expenditureTypeCodeSs"
                  style="width: 100%"
                  @change="handleChangeExpenditureTypeCode"
                >
                  <a-select-option v-for="item in expenditureTypeList" :key="item.expenditureTypeCode"
                                   :value="item.expenditureTypeCode">
                    {{item.expenditureTypeName}}
                  </a-select-option>
                </a-select>
              </td>
              <td v-if="contractType == '02' && isAdd != true">
                <a-select
                  disabled
                  mode="multiple"
                  :size="size"
                  v-model="expenditureTypeCodeS"
                  style="width: 100%"
                  @change="handleChangeExpenditureTypeCode"
                >
                  <a-select-option v-for="item in expenditureTypeList" :key="item.expenditureTypeCode"
                                   :value="item.expenditureTypeCode">
                    {{item.expenditureTypeName}}
                  </a-select-option>
                </a-select>
              </td>
            </tr>
            <tr>
              <td class="describeTd">合同名称:</td>
              <td v-if="isEdit">
                <a-input v-model="baseInfo.contractName"/>
              </td>
              <td v-else>{{baseInfo.contractName}}</td>
              <td class="describeTd">合同编号:</td>
              <td style="text-align: left;padding-left: 20px !important;">{{baseInfo.contractCode}}</td>
            </tr>

            <tr>
              <td class="describeTd">甲方:</td>
              <td v-if="isEdit">
                <a-select
                  :size="size"
                  style="width: 100%"
                  @change="handleChangePartyACode"
                  v-model="baseInfo.partyACode"
                  placeholder="请选择"
                >
                  <a-select-option v-for="item in partyListA" :key="item.id" :value="item.id">
                    {{item.supplierName}}
                  </a-select-option>
                </a-select>
              </td>
              <td v-else>{{baseInfo.partyA}}</td>
              <td class="describeTd">乙方:</td>
              <td v-if="isEdit">
                <a-select
                  :size="size"
                  style="width: 100%"
                  @change="handleChangePartyB"
                  v-model="baseInfo.partyBId"
                  placeholder="请选择"
                >
                  <a-select-option v-for="item in partyList" :key="item.id" :value="item.id">
                    {{item.supplierName}}
                  </a-select-option>
                </a-select>
              </td>
              <td v-else>{{baseInfo.partyB}}</td>
            </tr>


            <tr>
              <td class="describeTd">丙方:</td>
              <td v-if="isEdit">
                <a-select
                  :size="size"
                  style="width: 100%"
                  @change="handleChangePartyC"
                  :showSearch="true"
                  placeholder="请选择"
                  v-model="baseInfo.partyCId"
                >
                  <a-select-option v-for="item in partyList" :key="item.id" :value="item.id">
                    {{item.supplierName}}
                  </a-select-option>
                </a-select>
              </td>
              <td v-else>{{baseInfo.partyC}}</td>

              <td class="describeTd" rowspan="2">合同金额（含税）:</td>
              <td rowspan="2">{{baseInfo.contractTaxAmount}}</td>
            </tr>
            <tr>
              <td class="describeTd">合同年度:</td>
              <td v-if="isEdit">
                <a-select
                  :size="size"
                  style="width: 100%"
                  @change="handleChangeDate"
                  v-model="baseInfo.contractYeartype"
                >
                  <a-select-option v-for="item in optionDate" :key="item.optionCode" :value="item.optionCode">
                    {{item.optionName}}
                  </a-select-option>
                </a-select>
              </td>
              <td v-else>{{baseInfo.contractYeartype}}</td>
              <td style="display: none"></td>

              <td style="display: none">
<!--                {{baseInfo.contractNotTaxAmount}}-->
              </td>
            </tr>
            <tr v-if="contractType=='01'">
              <td class="describeTd">WBS编号:</td>
              <td>{{baseInfo.projectWbsCode}}</td>
              <td class="describeTd">采购单号:</td>
              <td>{{baseInfo.purchaseId}}</td>
            </tr>
            <tr v-if="!isEdit">
              <td class="describeTd">合同状态:</td>
              <td>
                   <span v-if="baseInfo.contractState == '0'">起草</span>
                   <span v-if="baseInfo.contractState == '2'">审批中</span>
                   <span v-if="baseInfo.contractState == '3'">实施中</span>
                   <span v-if="baseInfo.contractState == '4'">已完成</span>
                   <span v-if="baseInfo.contractState == '6'">拒绝</span>
              </td>
              <td class="describeTd" style="display: none"></td>
              <td style="display: none"></td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <!-- 选择项目模态框 -->
    <a-modal
      title="选择项目"
      :width="900"
      centered
      cancelText="取消"
      okText="确认"
      @ok="() => saveProjectName()"
      v-model="selectModal">
      <div>
        <div style="flex: 1">
          <div>
            <span>单位:</span>
            <a-input v-model="projectNameSearch" style="width: 250px"/>
            <a-button @click="showSelectModal()" type="primary" icon="search">查询</a-button>
          </div>
          <div style="margin-top: 10px">
            <div class="contentBos">
              <a-table style="width: 100%" bordered
                       :columns="columns"
                       :dataSource="mainPrjData"
                       :pagination="pagination"
                       @change="handleTableChange"
                       :rowSelection="rowSelection" rowKey="uuid">
              </a-table>
            </div>
          </div>
        </div>
      </div>
    </a-modal>
  </div>
</template>
<script>
  const columns = [
    {
      title: '项目名称',
      dataIndex: 'projectName',
    }, {
      title: '批复金额',
      dataIndex: 'replyTotal',
    }
  ];

  let costTypeList = [{
    id: 224,
    optionName: "采购合同",
    status: 0,
    note: "费用合同类型",
    sort: null,
    typeCode: "HTLXFY",
    optionCode: "0201",
    creUserId: null,
    creUserName: null,
    creTime: null
  },
    {
      id: 225,
      optionName: "服务合同",
      status: 0,
      note: "费用合同类型",
      sort: null,
      typeCode: "HTLXFY",
      optionCode: "0202",
      creUserId: null,
      creUserName: null,
      creTime: null
    },
    {
      id: 226,
      optionName: "运维合同",
      status: 0,
      note: "费用合同类型",
      sort: null,
      typeCode: "HTLXFY",
      optionCode: "0203",
      creUserId: null,
      creUserName: null,
      creTime: null
    }
  ];
  import {apiService} from "@/services/apiservice";

  import Vue from 'vue';

  export default {
    name: "BaSicInfo",
    data() {
      return {
        columns,
        mainPrjData: [], // 模态框中使用的项目列表
        selectModal: false, // 选择项目模态框
        projectNameSearch: '', // 模态框搜索项——项目名称
        selectedRow: [], // 模态框中选中的行数据
        size: 'default',
        pagination: {current: 1, pageSize: 10, total: 0},
        expenditureTypeList: [],
        partyList: [], // 乙方和丙方数据列表
        partyListA: [ // 甲方数据列表
          {
            "id": "B01",
            "supplierName": "中国石油化工股份有限公司",
          },
          {
            "id": "B02",
            "supplierName": "中国石油化工集团有限公司"
          },
          {
            "id": "B03",
            "supplierName": "中国石油化工集团资产经营管理有限公司"
          },
        ],
        //合同管理合同类型
        contractTypeList: [
          {
            "optionName": "采购合同",
            "status": 0,
            "note": "项目合同类型",
            "sort": null,
            "typeCode": "HTLXXM",
            "optionCode": "0101"
          },
          {
            "optionName": "服务合同",
            "status": 0,
            "note": "项目合同类型",
            "sort": null,
            "typeCode": "HTLXXM",
            "optionCode": "0102"
          }
        ],
        //费用合同 合同类型
        contractCostTypeList: costTypeList,
        optionDate: [], //合同年度,
        expenditureTypeCodeSs:[]//开支类型
      }
    },
    props: {
      isEdit: {
        type: Boolean
      },
      contractId: {
        type: String
      },
      contractType: {
        type: String
      },
      baseInfo: {
        type: Object
      },
      isAdd: {
        type: Boolean
      },
      expenditureTypeCodeS:{
        type:Array,
        default: []
      }
    },
    computed: {

      rowSelection() {
        const {selectedRowKeys} = this;
        return {
          type: 'radio',
          onChange: (selectedRowKeys, selectedRows) => {
            this.selectedRows = selectedRows;
          },
          getCheckboxProps: record => ({
            props: {
              name: record.name,
            }
          }),
        }
      }
    },
    mounted() {
      //this.expenditureTypeCodeSs=this.expenditureTypeCodeS//开支类型
      // this.reset();
      // this.optionDateSelect=this.optionDate[0].optionName
    },
    watch:{
      'baseInfo.partyACode':function (val,old) {
         this.baseInfo.partyA = this.partyListA.filter(function (item) {
           return item.id == val;
         })[0].supplierName;
      },
      'baseInfo.partyBId':function (val,old) {
        this.baseInfo.partyB = this.partyList.filter(function (item) {
          return item.id == val;
        })[0].supplierName;
      },
      'baseInfo.partyCId':function (val,old) {
        this.baseInfo.partyC = this.partyList.filter(function (item) {
          return item.id == val;
        })[0].supplierName;
      }
    },
    created() {
      var parentCode = {ExpenditureTypeParentCode: 0};
      this.getItmcExpenditureTypeList(parentCode);
      this.getItmcInvestmentSupplierList();
      this.getDictionary();
      let _self = this;
      if (this.isEdit == true && this.contractType == "01") {
        this.loadContractTypeHTLXXM();
        // alert("01");
      }
      ;

      if (this.isEdit == true && this.contractType == "02") {
        this.loadContractTypeHTLXFY();
      };

      if(this.isAdd){
        this.baseInfo.contractId = this.contractId;
        setTimeout(function () {
          apiService.getContractCode({}).then((r) => {
            _self.baseInfo.contractCode = r.ContractCode;
          },(err) => {
          })
        },0);
      }
    },
    methods: {
      handleTableChange(pagination, filters, sorter){
        let _self = this;
        var projectInfo = {projectName: this.projectNameSearch, rows: pagination.pageSize, page: pagination.current}
        this.getMainProjectByProjectName(projectInfo);
        _self.pagination.current = pagination.current;
      },
      handleChangeContractType(val) {
        if (val == "0102" || val == "0202") {//服务合同
          this.$parent.setContractPaymentDetail([{
            uuid: this.$parent.uuid(32,32),
            contractId:this.contractId,
            paymentAmount: 0,
            paymentRatio: "",
            paymentCondition: "",
            remarks: ""
          }, {
            uuid: this.$parent.uuid(32,32),
            contractId:this.contractId,
            paymentAmount: 0,
            paymentRatio: "",
            paymentCondition: "",
            remarks: ""
          }, {
            uuid: this.$parent.uuid(32,32),
            contractId:this.contractId,
            paymentAmount: 0,
            paymentRatio: "",
            paymentCondition: "",
            remarks: ""
          }, {
            uuid: this.$parent.uuid(32,32),
            contractId:this.contractId,
            paymentAmount: 0,
            paymentRatio: "",
            paymentCondition: "",
            remarks: ""
          }]);
        } else {
          let source = {
            uuid: this.$parent.uuid(32,32),
            contractId:this.contractId,
            paymentAmount: 0,
            paymentRatio: "90",
            paymentCondition: "",
            remarks: ""
          };

          this.$parent.setContractPaymentDetail([source, {
            uuid: this.$parent.uuid(32,32),
            contractId:this.contractId,
            paymentAmount: 0,
            paymentRatio: "10",
            paymentCondition: "",
            remarks: ""
          }]);
        }
      },
      handleChange(value) {
      },
      handleChangeDate(value) {
      },
      handleChangePartyACode(val){

      },
      handleChangePartyB(val){

      },
      handleChangePartyC(val){

      },
      // 模态框显示的方法
      showSelectModal() {
        this.selectModal = true
        var projectInfo = {projectName: this.projectNameSearch, rows: this.pagination.pageSize, page: this.pagination.current}
        this.getMainProjectByProjectName(projectInfo)
      },
      // 新增费用合同——开支类型
      getItmcExpenditureTypeList(parmasData) {
        var _self = this
        apiService.getItmcExpenditureTypeList(parmasData).then(r => {
          _self.expenditureTypeList = r
        }, r => {
        }).catch(
        )
      },
      // 获取乙方和丙方的单位名称
      getItmcInvestmentSupplierList() {
        var _self = this
        apiService.getItmcInvestmentSupplierList().then(r => {
          // <a-select-option v-for="item in partyList" :key="item.id" :value="item.id">
          //     {{item.supplierName}}
          // </a-select-option>
          r.unshift({id:"",supplierName:"请选择"});
          _self.partyList = r
        }, r => {
        }).catch(
        )
      },
      // 获取合同年度列表
      getDictionary() {
        var _self = this
        var parmasData = {_json: true, typeCode: 'JHND'};
        apiService.getDictionary(parmasData).then(r => {
          _self.optionDate = r
          this.baseInfo.contractYeartype = new Date().getFullYear();
        }, r => {
        }).catch(
        )
      },
      // 获取项目列表
      getMainProjectByProjectName(parmasData) {
        var _self = this
        apiService.getMainProjectByProjectName(parmasData).then(r => {
          console.log(1)
          _self.mainPrjData = r.list;
          _self.pagination.total = r.total;
        }, r => {
        }).catch(
        )
      },
      saveProjectName() {
        let _self = this;
        if (this.selectedRows) {
          const uuid = this.selectedRows[0].uuid;
          let params = {
            ProjectId: uuid,
            bankrollType:'01'
          };
          apiService.getContractAmountByProjectId(params).then(r => {
            this.baseInfo.projectName = this.selectedRows[0].projectName;
            this.$parent.setContractAmountDetail({result:r.map(function (item) {
              if(item.approvalType == "02"){
                item['replyName'] = "软件配置费";
                item['replyType'] = "02";
              } else if (item.approvalType == "03") {
                item['replyName'] = "硬件配置费";
                item['replyType'] = "03";
              } else if (item.approvalType == "04"){
                item['replyName'] = "技术服务费";
                item['replyType'] = "";
              } else if (item.approvalType == "20") {
                item['replyName'] = "其他";
                item['replyType'] = "";
              }
              item['totalAmount'] = item.approvalSum.replace(/,/g,"");
              item['alreadyUsedAmount'] = item.usedAmount.replace(/,/g,"");
              item['availableAmount'] = item.availableAmount.replace(/,/g,"");
              item['taxCode'] = "B0";
              item['amount'] = "";
              item['serviceCode'] = "PS000001";
              item['uuid'] = Math.random()*1000 + "";
              return item;
            })});
            _self.selectModal = false;
            _self.baseInfo.projectId = _self.selectedRows[0].uuid;
          }, r => {
          }).catch(reason => {
          })
        }
        //this.selectModal = false;
      },
      loadContractTypeHTLXXM() {// 获取合同类型
        var _self = this
        var parmasData = "typeCode=HTLXXM"
        apiService.getDictionary1(parmasData).then(r => {
          _self.contractTypeList = r;
        }, r => {
        }).catch(
        )
      },
      loadContractTypeHTLXFY() {//获取费用合同类型
        var _self = this
        var parmasData = "typeCode=HTLXFY"
        apiService.getDictionary1(parmasData).then(r => {
          _self.contractCostTypeList = r;
        }, r => {
        }).catch(
        )
      },
      handleChangeExpenditureTypeCode(val) {
        let _self = this;
        this.baseInfo.expenditureTypeCode = val.join(",");
        let newJson = {};
        Object.assign(newJson, this.baseInfo);
        this.baseInfo = newJson;
        let params = {FeeType: val.join(",")};
        apiService.getItmcPlanFeeplanByFeeType(params).then(r => {
          let tempArr = [];
          for (let i = 0; i < r.length; i++) {
            tempArr.push({
              uuid: r[i].feePlanId,
              contractId: this.contractId,
              amountType: "",
              replyName: (r[i].feeType == "1" || r[i].feeType == "2" || r[i].feeType == "3") ? "信息化管理部维护费" : (r[i].feeType == "4") ? "信息化管理部桌面更新及耗材费" : "",//费用类型
              replyType: r[i].feeType,
              expenditureItemName: r[i].feeName,//开支项目名称
              amount: 0,//本次金额
              totalAmount: r[i].feeMoney,//总金额
              alreadyUsedAmount: r[i].alreadyUsedAmount,//已用金额
              availableAmount: r[i].availableMoney,//可用金额
            });
          }
          let json = {result: tempArr};
          _self.$parent.setContractAmountDetail(json);
        }, r => {
        }).catch(
        )
      }
    }
  }
</script>
<style>
  #baseInfoTable tr td:nth-of-type(odd) {
    width: 15%;
  }

  #baseInfoTable tr td:nth-of-type(even) {
    width: 35%;
  }
</style>
