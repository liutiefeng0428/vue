<template>
  <div>
    <iframe width="100%" frameborder="0" style="width: 100%" :src=url id="iframe"></iframe>
    </div>
</template>

<script>

  import $ from 'jquery'
  import {urlDomain} from '@/services/domain'
  export default {
    name: "CostIf",
    components: {
    },
    data () {
     return {
        url:urlDomain+"/project/contractManagement/SPA/tableList.html",
     }
    },
    methods: {
    },
    created(){
    },
    mounted(){
      let clientHeight = document.documentElement.clientHeight
      document.getElementById("iframe").style.height= (clientHeight-70) + 'px'
    },
    watch: {

    }
  }

</script>
<style>
  @import '../../assets/css/common.css';
</style>
