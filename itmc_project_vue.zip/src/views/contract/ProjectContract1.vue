<template>
  <div class="wrap">
    <div style="margin-bottom:16px;">
      <div class="table-page-search-wrapper">
        <a-form layout="inline">
          <div>
            <a-form-item label="年度">
              <a-select
                :defaultValue="new Date().getFullYear()"
                mode="multiple"
                :size="size"
                v-model="optionDateSelect"
                placeholder="请选择年份"
                style="width: 400px"
                @change="handleChange"
              >
                <a-select-option v-for="item in optionDate" :key="item.optionCode">
                  {{item.optionName}}
                </a-select-option>
              </a-select>
            </a-form-item>
            <a-form-item label="关键字搜索">
              <a-input placeholder="请输入关键字" v-model="keyword"/>
            </a-form-item>
            <a-form-item label="合同类型">
              <a-select
                :size="size"
                defaultValue=""
                v-model="contractTypeSel"
                style="width: 200px"
                @change="handleChangeType"
              >
                <a-select-option v-for="item in contractTypeList" :key="item.optionCode">
                  {{item.optionName}}
                </a-select-option>
              </a-select>
            </a-form-item>
          </div>
          <div style="margin:16px 0;">
            <span @click="queryTable" class="table-page-search-submitButtons">
              <a-button type="primary" icon="search">查询</a-button>
            </span>
            <button @click="toAdd" data-v-227ef8f8="" type="button" class="ant-btn ant-btn-primary">
              <i class="anticon anticon-plus">
                <svg viewBox="64 64 896 896" data-icon="plus" width="1em" height="1em" fill="currentColor"
                     aria-hidden="true" class="">
                  <path d="M482 152h60q8 0 8 8v704q0 8-8 8h-60q-8 0-8-8V160q0-8 8-8z"></path>
                  <path d="M176 474h672q8 0 8 8v60q0 8-8 8H176q-8 0-8-8v-60q0-8 8-8z"></path>
                </svg>
              </i>
              <span>新增</span>
            </button>
            <button @click="exportToExcel()" data-v-227ef8f8="" type="button" class="ant-btn ant-btn-primary">
              <i class="anticon anticon-import">
                <svg viewBox="64 64 896 896" data-icon="plus" width="1em" height="1em" fill="currentColor"
                     aria-hidden="true" class="">
                  <path d="M482 152h60q8 0 8 8v704q0 8-8 8h-60q-8 0-8-8V160q0-8 8-8z"></path>
                  <path d="M176 474h672q8 0 8 8v60q0 8-8 8H176q-8 0-8-8v-60q0-8 8-8z"></path>
                </svg>
              </i>
              <span>导出</span>
            </button>
          </div>
        </a-form>
      </div>
    </div>
    <div class="con-title" style="margin-top: 20px">
      <span class="divdLine"></span>
      <span>项目合同信息</span>
      <span class="unitText">单位：元</span>
    </div>
    <div id="contractList">
      <div>
        <a-table style="width: 100%;" :pagination="pagination" @change="handleTableChange" bordered :columns="columns" :dataSource="dataInfo" rowKey="uuid" :scroll="{ y: 340 }">
          <span slot="number" slot-scope="text, record, index">
            <span>{{index+1}}</span>
          </span>
          <span slot="contractName" slot-scope="text, record, index">
            <a :title="record.contractName" @click="toDetail(record)">{{record.contractName}}</a>
          </span>
          <span slot="contractCode" slot-scope="text, record, index">
            <span :title="record.contractCode">{{record.contractCode}}</span>
          </span>
          <span slot="partyA" slot-scope="text, record, index">
<!--           // <span :title="record.partyA">{{record.partyA}}</span>-->
            <select disabled class="taxCodeListCss" name=""  v-model="record.partyACode">
              <option value="" v-for="item in partyListA" :value="item.id">{{item.supplierName}}</option>
            </select>
          </span>
          <span slot="partyB" slot-scope="text, record, index">
<!--            <span :title="record.partyB">{{record.partyB}}</span>-->
             <select disabled class="taxCodeListCss" name=""  v-model="record.partyBId">
              <option value="" v-for="item in partyList" :value="item.id" :title="item.supplierName">{{item.supplierName}}</option>

            </select>
          </span>
          <span slot="partyC" slot-scope="text, record, index">
<!--            <span :title="record.partyC">{{record.partyC}}</span>-->
              <select disabled class="taxCodeListCss" name=""  v-model="record.partyCId">
              <option value="" v-for="item in partyList" :value="item.id">{{item.supplierName}}</option>
            </select>
          </span>
          <span slot="action" slot-scope="text, record, index">
            <a @click="toEdit(record)">编辑</a>
            <a-popconfirm title="确定删除吗?" @confirm="() => handleDelete(record.uuid,record)">
              <a>删除</a>
            </a-popconfirm>
          </span>
        </a-table>
        <!-- <table style="width: 100%">
          <thead class="ant-table-thead">
            <tr>
              <th rowspan="1" class=""><div>合同名称</div></th>
              <th rowspan="1" class=""><div>合同金额</div></th>
              <th rowspan="1" class=""><div>合同编号</div></th>
              <th rowspan="1" class=""><div>甲方</div></th>
              <th rowspan="1" class=""><div>乙方</div></th>
              <th rowspan="1" class=""><div>丙方</div></th>
              <th colspan="1" class=""><div>年度</div></th>
              <th rowspan="1" class=""><div>操作</div></th>
            </tr>
          </thead>
          <tbody class="ant-table-tbody">
            <tr  v-for="(item,index) in dataInfo">
               <td><a @click="toDetail(item)">{{item.contractName}}</a></td>
               <td>{{item.contractTaxAmount}}</td>
               <td>{{item.contractCode}}</td>
               <td>{{item.partyA}}</td>
               <td>{{item.partyB}}</td>
               <td>{{item.partyC}}</td>
               <td>{{item.contractYeartype}}</td>
               <td>
                  <a-popconfirm title="确定删除吗?" @confirm="() => handleDelete(record.id)">
                    <a>删除</a>
                  </a-popconfirm>
               </td>
            </tr>
          </tbody>
        </table> -->
      </div>
<!--       <div class="tableFooter">-->
<!--        <a-pagination showSizeChanger :pageSize.sync="pageSize" @showSizeChange="onShowSizeChange" :total="totalPage" v-model="currentPage"/>-->
<!--      </div>-->
    </div>
    <a-modal
      title="导入年度信息化项目投资计划"
      :width="600"
      centered
      v-model="expVisible"
      @ok="() => saveFile()"
      @cancel="() => setVersionVisible(false)"
      okText="保存"
      cancelText="取消"
    >
      <div>
        <div class="clearfix">
          <a-upload
            :fileList="fileList"
            :remove="handleRemove"
            :beforeUpload="beforeUpload"
          >
            <a-button>
              <a-icon type="upload"/>
              上传
           </a-button>
          </a-upload>
        </div>
        <div style="margin-top: 10px;">
          <a @click="downloadFile">本处室年度投资计划申报模板下载</a>
        </div>

      </div>
    </a-modal>
  </div>
</template>

<script>
const columns = [
  {
    title: '序号',
    dataIndex: 'number',
    width: 50,
    scopedSlots: { customRender: 'number' }
  },
  {
    title: '合同名称',
    dataIndex: 'contractName',
    width: 210,
    align:'left',
    scopedSlots: { customRender: 'contractName' }
  }, {
    title: '合同金额',
    dataIndex: 'contractTaxAmount',
    width: 100,
    className: 'column-contractTaxAmount',
  }, {
    title: '合同编号',
    dataIndex: 'contractCode',
    width: 120,
    scopedSlots: { customRender: 'contractCode' }
  }, {
    title: '甲方',
    dataIndex: 'partyA',
    width: 120,
    scopedSlots: { customRender: 'partyA' }
  }, {
    title: '乙方',
    dataIndex: 'partyB',
    width: 120,
    scopedSlots: { customRender: 'partyB' }
  }, {
    title: '丙方',
    dataIndex: 'partyC',
    width: 120,
    scopedSlots: { customRender: 'partyC' }
  }, {
    title: '年度',
    dataIndex: 'contractYeartype',
    width: 80
  }, {
    title: '操作',
    dataIndex: 'action',
    width: 80,
    scopedSlots: { customRender: 'action' }
  }
];

  import {apiService} from "@/services/apiservice";
  import reqwest from 'reqwest'
  import $ from "jquery";
  export default {
    name: "ProjectContract1",
    data() {
      return {
        dataInfo:[],
        pageSize: 5,
        currentPage:0,
        totalPage:10,
        pagination: {current: 1, pageSize: 10, total: 0},
        optionDate:[],
        contractType: '01',
        contractTypeList:[],
        contractTypeSel:"",
        keyword:"",
        size:'default',


        optionDateSelect: [],
        investmentChannel:"B01",
        dataInfo2:[],
        expVisible:false,
        fileList: [],
        files:null,
        reportStatue:"0",
        reportStatueText:"未申报",

        columns:columns,
        partyList:[],
        partyListA: [ // 甲方数据列表
          {
            "id": "B01",
            "supplierName": "中国石油化工股份有限公司",
          },
          {
            "id": "B02",
            "supplierName": "中国石油化工集团有限公司"
          },
          {
            "id": "B03",
            "supplierName": "中国石油化工集团资产经营管理有限公司"
          },
        ],
      }
    },
    watch:{
      pageSize(val) {
        console.log('pageSize',val);
      },
      currentPage(val) {
        console.log('currentPage',val);
      }
    },
    computed:{
      totalSumAll(){
        let totalSumAll = 0;
        this.dataInfo.map((item) => {if(!isNaN(item.totalSum)) totalSumAll += item.totalSum})
        if(isNaN(totalSumAll)){
          return 0
        }
        return totalSumAll
      },
      lyTotalSumAll(){
        let lyTotalSumAll = 0;
        this.dataInfo.map((item) => {if(!isNaN(item.lyTotalSum)) lyTotalSumAll += item.lyTotalSum})
        if(isNaN(lyTotalSumAll)){
          return 0
        }
        return lyTotalSumAll
      },
      nowTotalSumAll(){
        let nowTotalSumAll = 0;
        this.dataInfo.map((item) => {if(!isNaN(item.nowTotalSum)) nowTotalSumAll += item.nowTotalSum})
        if(isNaN(nowTotalSumAll)){
          return 0
        }
        return nowTotalSumAll
      },
      nyTotalSumAll(){
        let nyTotalSumAll = 0;
        this.dataInfo.map((item) => {if(!isNaN(item.nyTotalSum)) nyTotalSumAll += item.nyTotalSum})
        if(isNaN(nyTotalSumAll)){
          return 0
        }
        return nyTotalSumAll
      },
      totalSumAll2(){
        let totalSumAll2 = 0;
        this.dataInfo2.map((item) => {if(!isNaN(item.totalSum)) totalSumAll2 += item.totalSum})
        if(isNaN(totalSumAll2)){
          return 0
        }
        return totalSumAll2
      },
      lyTotalSumAll2(){
        let lyTotalSumAll2 = 0;
        this.dataInfo2.map((item) => {if(!isNaN(item.lyTotalSum)) lyTotalSumAll2 += item.lyTotalSum})
        if(isNaN(lyTotalSumAll2)){
          return 0
        }
        return lyTotalSumAll2
      },
      nowTotalSumAll2(){
        let nowTotalSumAll2 = 0;
        this.dataInfo2.map((item) => {if(!isNaN(item.nowTotalSum)) nowTotalSumAll2 += item.nowTotalSum})
        if(isNaN(nowTotalSumAll2)){
          return 0
        }
        return nowTotalSumAll2
      },
      nyTotalSumAll2(){
        let nyTotalSumAll2 = 0;
        this.dataInfo2.map((item) => {if(!isNaN(item.nyTotalSum)) nyTotalSumAll2 += item.nyTotalSum})
        if(isNaN(nyTotalSumAll2)){
          return 0
        }
        return nyTotalSumAll2
      },
    },
    methods: {
      onShowSizeChange(currentPage, pageSize) {
        console.log(currentPage, pageSize);
      },
      toDetail(item){
        this.$router.push({name: "ContractDetail",params: {contractId:item.contractId, contractType:'01',isEdit:false}});
      },
      toEdit(item){
        if(item.contractState == 2){
          // this.$router.push({path: "/contract-detial",query: {contractId:item.contractId, contractType:'01',isEdit:true}});
          this.$router.push({name: "ContractDetail",params: {contractId:item.contractId, contractType:'01',isEdit:true}});
        } else {
          this.$message.error('合同在审批状态下，才能进行修改。');
        }
      },
      toAdd(){
       // this.$router.push({path: "/contract-detial",query: {contractId:'new', contractType:'01',isEdit:true}});
        this.$router.push({name: "ContractDetail",params: {contractId:this.uuid(40,16), contractType:'01',isEdit:true,isAdd:true}});
      },
      handleDelete(id,item){
        let _self = this;
        if(item.contractState == 0 || item.contractSystemId == null || item.contractState == 6){
          apiService.delItmcProjectContractV2({uuid:id}).then((r) => {
            if(r.flag == true){
              let _self = this;
              var parmasData = new FormData();
              parmasData.append('rows', _self.pagination.pageSize);
              parmasData.append('page', _self.pagination.current);
              parmasData.append('years', _self.optionDateSelect.join(','));
              parmasData.append('keyword', _self.keyword);
              parmasData.append('contractType', _self.contractTypeSel);
              parmasData.append("pm","01");
              _self.loadTable(parmasData);
            }
          },(r) => {

          }).catch((r) => {

          });
        } else if(item.contractState == 2){
          _self.$message.error('合同审批中，不能删除。');
        } else if(item.contractState == 3){
          _self.$message.error('合同实施中，不能删除。');
        } else if (item.contractState == 4){
          _self.$message.error('合同已完成，不能删除。');
        }

      },
      handleTableChange(pagination, filters, sorter){
        let _self = this;
        var parmasData = new FormData();
        parmasData.append('rows', pagination.pageSize);
        parmasData.append('page', pagination.current);
        parmasData.append('years', this.optionDateSelect.join(','));
        parmasData.append('keyword', this.keyword);
        parmasData.append('contractType', this.contractTypeSel);
        parmasData.append("pm","01");
        this.loadTable(parmasData)
        _self.pagination.current = pagination.current;
      },
      // 获取合同年度列表
      loadDate(){
        var _self = this
        var parmasData = "typeCode=JHND"
        apiService.getDictionary1(parmasData).then(r => {
          _self.optionDate = r
          _self.optionDateSelect = [new Date().getFullYear()];
        }, r => {
        }).catch(
        )
      },
      loadContractType(){
        var _self = this
        var parmasData = "typeCode=HTLXXM"
        apiService.getDictionary1(parmasData).then(r => {
          _self.contractTypeList = r
          _self.contractTypeList.unshift({id:111, optionName:"全部", status:0, note:"", sort:null, typeCode:"HTLXXM", optionCode:"", creUserId:null, creUserName:null, creTime:null});
          _self.contractTypeSel = _self.contractTypeList[0].optionCode
        }, r => {
        }).catch(
        )
      },
      handleChange(value){
        this.optionDateSelect = value
        console.log(this.optionDateSelect)
      },
      handleChangeType(value){
        this.contractTypeSel = value
        console.log(this.contractTypeSel)
      },
      queryTable(value){
        /*let parmasData={rows:this.pageSize,
          page:this.currentPage,
          years:this.optionDateSelect.join(','),
          keyword:this.keyword,
          contractType:this.contractTypeSel}
        parmasData._json=true*/
        // 渲染合同列表数据
        var parmasData = new FormData();
        parmasData.append('rows', this.pagination.pageSize);
        parmasData.append('page', this.pagination.current);
        parmasData.append('years', this.optionDateSelect.join(','));
        parmasData.append('keyword', this.keyword);
        parmasData.append('contractType', this.contractTypeSel);
        parmasData.append("pm","01");
        this.loadTable(parmasData)
      },
      loadTable(parmasData){
//        getPlanAut
        var _self = this
        apiService.getItmcProjectContract(parmasData).then(r => {
          _self.dataInfo=r.list
          _self.pagination.total=r.total
        }, r => {
        }).catch(
        )
      },
      exportToExcel(){
       let prams = "years=" + this.optionDateSelect.join(',') + "&keyword= " + this.keyword + "&contractType=" + this.contractTypeSel + "&flag=0&pm=01";
       window.location.href = "project/itmcProjectContract/exportContractDetailsV2.do?" + prams;
      },



      downloadFile(){
        let _self=this
       // let parmasData={planYear:_self.optionDateSelect}
        window.location.href='/project/itmcAut/downloadFile?planYear='+_self.optionDateSelect
//        parmasData._json=true
//        apiService.downloadFile(parmasData).then(r => {
//          if(r.result=='200'){
//            _self.$message.success("模板下载成功")
//          }else{
//            _self.$message.warning(r.msg)
//          }
//        }, r => {
//        }).catch(
//        )
      },
      reportFileExport(){
        if(this.dataInfo2.length<=0&&this.dataInfo.length<=0){
          this.$message.warning("暂无可导出数据......")
          return
        }
        window.location.href='/project/itmcAut/reportFileExport?planYear='+this.optionDateSelect
      },
      authrReport(){
        let _self=this
        if(_self.dataInfo2.length<=0&&_self.dataInfo.length<=0){
          this.$message.warning("暂无可申报数据......")
          return
        }
        let parmasData={planYear:this.optionDateSelect}
        parmasData._json=true
        apiService.authrReport(parmasData).then(r => {
            if(r.result=='200'){
              _self.$message.success("申报成功")
              var params = {planYear: _self.optionDateSelect,investmentChannel:"B01"}
              params._json = true
              _self.loadTable(params)
              var params2 = {planYear:_self.optionDateSelect,investmentChannel:"B02"}
              params2._json = true
              _self.loadTable2(params2)
            }else{
              _self.$message.warning(r.msg)
            }
        }, r => {
        }).catch(
        )
      },

      setVersionVisible(){
        this.expVisible=false
      },
      handleRemove(file) {
        const index = this.fileList.indexOf(file);
        const newFileList = this.fileList.slice();
        newFileList.splice(index, 1);
        this.fileList = newFileList
      },
      beforeUpload(file) {
        this.files=file
        this.fileList = [...this.fileList, file]
        return false;
      },
      saveFile(){
        let _self=this
        const { fileList } = this;
        var formData = new FormData();
        formData.append('file', this.files);
        formData.append('planYear',this.optionDateSelect)

        reqwest({
          url: '/project/itmcAut/exportfile',
          method: 'post',
          processData: false,
          data: formData,
          success: () => {
            _self.fileList = []
            _self.$message.success('上传成功');
            _self.expVisible=false
            var params = {planYear: _self.optionDateSelect,investmentChannel:"B01"}
            params._json = true
            _self.loadTable(params)
            var params2 = {planYear:_self.optionDateSelect,investmentChannel:"B02"}
            params2._json = true
            _self.loadTable2(params2)
          },
          error: () => {
            _self.$message.error('上传失败');
            _self.expVisible=false
          },
        });
      },
      triggerImport(){
        this.expVisible=true
      },
     /* loadTable(parmasData){
        var _self = this
        apiService.getPlanAut(parmasData).then(r => {
            _self.dataInfo=r.list
          if(r.list.length>0){
            _self.reportStatue=r.list[0].reportStatue
            if(_self.reportStatue=='0'){
              _self.reportStatueText='未申报'
            }else{
              _self.reportStatueText='已申报'
            }
          }else{
            _self.reportStatueText='未申报'
          }

        }, r => {
        }).catch(
        )
      },
      loadTable2(parmasData){
        var _self = this
        apiService.getPlanAut(parmasData).then(r => {
          _self.dataInfo2=r.list
          if(r.list.length>0){
            _self.reportStatue=r.list[0].reportStatue
            if(_self.reportStatue=='0'){
              _self.reportStatueText='未申报'
            }else{
              _self.reportStatueText='已申报'
            }
          }else{
            _self.reportStatueText='未申报'
          }
        }, r => {
        }).catch(
        )
      },*/
      handleChangeDate(value){
        this.optionDateSelect = value
        var params = {planYear: this.optionDateSelect,investmentChannel:this.investmentChannel}
        params._json = true
        this.loadTable(params)
        var params2 = {planYear:this.optionDateSelect,investmentChannel:"B02"}
        params2._json = true
        this.loadTable2(params2)
      },
      callback(value){
        this.investmentChannel=value
      },
      onDelete(outerIndex, innerIndex){
      },
      uuid(len, radix) {//设置UUID
        var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
        var uuid = [], i;
        radix = radix || chars.length;
        if (len) {
          // Compact form
          for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random()*radix];
        } else {
          // rfc4122, version 4 form
          var r;
          // rfc4122 requires these characters
          uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
          uuid[14] = '4';
          // Fill in random data. At i==19 set the high bits of clock sequence as
          // per rfc4122, sec. 4.1.5
          for (i = 0; i < 36; i++) {
            if (!uuid[i]) {
              r = 0 | Math.random()*16;
              uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
            }
          }
        }
        this.uuidAdd = uuid.join('')
        return uuid.join('');
      },
      // 获取乙方和丙方的单位名称
      getItmcInvestmentSupplierList() {
        var _self = this
        apiService.getItmcInvestmentSupplierList().then(r => {
          // <a-select-option v-for="item in partyList" :key="item.id" :value="item.id">
          //     {{item.supplierName}}
          // </a-select-option>
          //r.unshift({id:"",supplierName:"请选择"});
          _self.partyList = r
        }, r => {
        }).catch(
        )
      },
    },
    created(){
      // 获取合同年度列表
      this.loadDate()
      // 获取合同类型列表
      this.loadContractType()
      // 渲染合同列表数据
      var parmasData = new FormData();
      // parmasData.append('rows', this.pageSize);
      // parmasData.append('page', this.currentPage);
      parmasData.append('years', this.optionDateSelect.join(","));
      parmasData.append('keyword', this.keyword);
      parmasData.append('contractType', this.contractTypeSel);
      parmasData.append("pm","01");
      parmasData.append("page",this.pagination.current);
      parmasData.append("rows",this.pagination.pageSize);
      // formData.append('_json', true);
      // let parmasData={rows:this.pageSize,
      //   page:this.currentPage,
      //   years:"",
      //   keyword:this.keyword,
      //   contractType:this.contractTypeSel}
      // parmasData._json=true
      this.loadTable(parmasData)
      this.getItmcInvestmentSupplierList();
    }
  }
</script>
<style>
  .wrap {
    background: #ffffff;
    padding: 20px;
  }
  .ant-table-thead > tr > th {
    border-left: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
  }

  .ant-table-thead tr {
    border-top: 1px solid #e8e8e8;
  }
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #333333;
    display: flex;
    margin-bottom: 20px;
    position: relative;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    bottom:0;
    right: 25px;
  }
  .divdLine {
    display: inline-block;
    width: 5px;
    background: rgb(24, 144, 255);
    height: 20px;
    margin-right: 10px;
  }
  .ant-table-tbody>tr>td, .ant-table-thead>tr>th{
    font-size: 14px;
    text-align: center;
    padding: 6px 16px;
  }

  .ant-table-tbody > tr > td {
    border: 1px solid #e8e8e8;
  }
  .tableFooter{
    margin-top: 10px;
    text-align: right;
  }
  #contractList table {
    width: 100%;
    table-layout: fixed;
  }
  #contractList table tbody tr td{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
  }

  .taxCodeListCss{
    -webkit-appearance:none;
    -moz-appearance:none;
    appearance:none; /*去掉下拉箭头*/
    border: none;
    background-color: white;
  }
  .taxCodeListCss::-ms-expand { display: none; }
</style>
