<template>
  <div class="wrap">
    <div class="con-title">
      <span class="divdLine"></span>
      <span>基本信息</span>
      <span class="unitText">单位：元</span>
    </div>
    <BasicInfo :isEdit="isEdit" :contractId="contractId" :expenditureTypeCodeS="expenditureTypeCodeS"  :isAdd="isAdd" :contractType="contractType" :baseInfo="baseInfo"></BasicInfo>

    <div class="con-title">
      <span class="divdLine"></span>
      <span>合同金额明细</span>
      <span class="unitText">单位：元</span>
    </div>
    <AmountDetail :isEdit="isEdit" :contractId="contractId" :contractType="contractType" :amountDetail="amountDetail" :baseInfo="baseInfo" :taxRateObject="taxRateObject" :taxRateNameObject="taxRateNameObject" :taxCodeList="taxCodeList" :outuuid="outuuid"></AmountDetail>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>合同付款明细</span>
      <span class="unitText">单位：元</span>
    </div>
    <PaymentDetail :isEdit="isEdit" :contractId="contractId" :contractType="contractType" :paymentDetail="paymentDetail" :outuuid="outuuid" :isAdd="isAdd"></PaymentDetail>
    <div v-if="baseInfo.contractType == undefined || baseInfo.contractType == '0101' || baseInfo.contractType == '0201' || baseInfo.contractType == '0203'">
      <div class="con-title" >
        <span class="divdLine"></span>
        <span>附件：固定资产、无形资产使用情况</span>
        <span class="unitText">单位：元</span>
      </div>
      <AssetsDetail @contractAssetsDetailCopy="getAssetsDetailFormSon" :isEdit="isEdit" :contractId="contractId" :contractType="contractType" :contractAssetsDetail="contractAssetsDetail" :baseInfo="baseInfo"></AssetsDetail>
    </div>

    <div class="con-title">
      <span class="divdLine"></span>
      <span>合同依据</span>
      <span class="unitText">单位：元</span>
    </div>
    <!-- <contractBasis @contractBasisAll="getContractBasisFromSon" :isEdit="isEdit" :contractId="contractId" :contractType="contractType" :contractBasis="contractBasis"></contractBasis> -->
    <UploadFile :isEdit="isEdit" :relationId="contractId" :businessType="businessTypeHTYJ"></UploadFile>

    <div class="con-title">
      <span class="divdLine"></span>
      <span>合同附件</span>
      <span class="unitText">单位：元</span>
    </div>
    <!-- <enclosure :isEdit="isEdit" :contractId="contractId" :contractType="contractType" :enclosure="enclosure"></enclosure> -->
    <UploadFile :isEdit="isEdit" :relationId="contractId" :businessType="businessTypeHTFJ"></UploadFile>
    <div class="container" style="margin-top: 20px;text-align: center">
      <div>
        <!--<a-button v-if="!isEdit" @click="goBack()" class="ant-btn ant-btn-primary">合同编辑</a-button>-->
        <a-button v-if="isEdit" @click="saveContractInfo()" :loading="loading" class="ant-btn ant-btn-primary">保存</a-button>
        <a-button @click="goBack()" class="ant-btn ant-btn-primary">取消</a-button>
      </div>
    </div>
    <!--@ok="() => initTable()"-->
    <!--@cancel="() => setModal1Visible(false)"-->
    <!--okText="确认"-->
    <!--cancelText="关闭"-->
    <a-modal
      title="付款确认"
      :width="900"
      centered
      v-model="payModal">
      <div>
        <div style="flex: 1">
          <div>
            <span>单位:</span>
            <a-select :value=optionDepartSelect class="querySelect" @change="handleChangeDepart" style="width:300px">
              <a-select-option v-for="item in optionDepart" :key="item.optionCode"> {{item.optionName}}</a-select-option>
            </a-select>
          </div>
          <div style="margin-top: 10px">
            <div class="contentBos">
              <div class="conLeft">投资</div>
              <div style="flex: 14">
                <table style="width: 100%">
                  <thead class="ant-table-thead">
                  <tr>
                    <th class=""><div>付款条件</div></th>
                    <th class=""><div>合同总金额</div></th>
                    <th class=""><div>合同剩余金额</div></th>
                    <th class=""><div>条款金额</div></th>
                    <th class=""><div>投资构成</div></th>
                    <th class=""><div>金额</div></th>
                    <th class=""><div>付款金额</div></th>
                    <th class=""><div>付款内容</div></th>
                  </tr>
                  </thead>
                  <tbody class="ant-table-tbody">
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                  <!--<tr>-->
                    <!--<td>{{item.replyName}}1</td>-->
                    <!--<td>{{item.totalAmount}}2</td>-->
                    <!--<td>{{item.serviceName}}3</td>-->
                    <!--<td>{{item.taxCode}}4</td>-->
                    <!--<td>{{item.amount}}5</td>-->
                    <!--<td>{{item.serviceName}}3</td>-->
                    <!--<td>{{item.taxCode}}4</td>-->
                    <!--<td>{{item.amount}}5</td>-->
                  <!--</tr>-->
                  <!--<tr>-->
                    <!--<td>{{item.replyName}}1</td>-->
                    <!--<td>{{item.totalAmount}}2</td>-->
                    <!--<td>{{item.serviceName}}3</td>-->
                    <!--<td>{{item.taxCode}}4</td>-->
                    <!--<td>{{item.amount}}5</td>-->
                    <!--<td>{{item.serviceName}}3</td>-->
                    <!--<td>{{item.taxCode}}4</td>-->
                    <!--<td>{{item.amount}}5</td>-->
                  <!--</tr>-->
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div style="margin-top: 20px">
            <a-button @click="createBill()" class="ant-btn ant-btn-primary">服务确认 </a-button>
            <a-button @click="fuWuDianJi()" class="ant-btn ant-btn-primary">创建报销单</a-button>
            <a-button @click="goBack()" class="ant-btn ant-btn-primary">返回</a-button>
          </div>
        </div>
      </div>
    </a-modal>
  </div>
</template>

<script>

  import {apiService} from "@/services/apiservice";
  import BasicInfo from './model/BasicInfo'
  import AmountDetail from './model/AmountDetail'
  import PaymentDetail from './model/PaymentDetail'
  import AssetsDetail from './model/AssetsDetail'
  import contractBasis from './model/contractBasis'
  import enclosure from './model/enclosure'
  import UploadFile from '@/components/operation/UploadFile'
  export default {
    name: "ContractDetail1",
    components: {
      BasicInfo,
      AmountDetail,
      PaymentDetail,
      AssetsDetail,
      contractBasis,
      enclosure,
      UploadFile
    },
    data() {
      return {
        contractId:"27403d95-a6ac-40b3-83fb-2eecdd8ceaec",
        // contractId:"new",
        contractType:'02',
        isEdit:true,
        isAdd:false,
        expenditureTypeCodeS:[],
        baseInfo:{contractId:this.contractId,contractType:'',projectName:'',expenditureTypeCode:'',contractName:'',partyACode:"B01",partyBId:'AE4FEF8D-A987-4739-8E81-C56A26597883',partyCId:'',contractYeartype:'',contractTaxAmount:'',contractNotTaxAmount:'',expenseValue:0,expenditureTypeCode:"",contractTaxAmount:"",contractNotTaxAmount:"",contractCode:"",partyA: "中国石油化工股份有限公司" ,partyB:"石化盈科信息技术有限责任公司"},
        paymentDetail:[],
        contractAssetsDetail:[],
        contractBasis:[],
        enclosure:[],
        amountDetail:[],
        taxCodeList:[],
        taxRateObject:{},
        taxRateNameObject:{},
        payModal:false,
        optionDepart:[],
        optionDepartSelect:"",
        currentCheck:[],
        investmentChannel:"股份",
        constrNature:"新开",
        planYear:"",
        loading:false,
        businessTypeHTYJ:"HTYJ",// 合同依据
        businessTypeHTFJ:"HTFJ",// 合同附件
        hardWareAndSoftWareCost:{hardWarea:"",softWare:""}//硬件、软件费用
      }
    },
    watch:{
      // baseInfo:{handler(val,old){
      //     let str = val.expenseValue+ "";
      //     let rate = /^(([\d]{0,2})|([1][0][0])?)$/;
      //     let NotRate = /[^\d]+/;
      //
      //
      //     let newJson = {};
      //     if(NotRate.test(str)){
      //       this.baseInfo.expenseValue = 0;
      //       Object.assign(newJson,this.baseInfo);
      //       this.baseInfo = newJson;
      //     }
      //     if(!rate.test(str)){
      //       if(str.length > 0){
      //
      //         console.log("str >>> " + str)
      //         this.baseInfo.expenseValue = parseInt(str.substring(0,str.length -1));
      //         Object.assign(newJson,this.baseInfo);
      //         this.baseInfo = newJson;
      //         //this.$parent.setBaseInfo(newJson);
      //         console.log(newJson)
      //       }
      //     }
      //
      //     let contractAssetsDetail = this.contractAssetsDetail;
      //     if(contractAssetsDetail){
      //       for(let i = 0; i < contractAssetsDetail.length;i++){
      //         //contractAssetsDetail[i].unitPrice = "5555";
      //       }
      //     }
      //
      //
      //
      //   },deep:true},
    },
    methods: {
      handleChangeDepart(val){
        this.optionDepartSelect=val
      },
      getAssetsDetailFormSon(data){
          this.contractAssetsDetail = data
      },
      getContractBasisFromSon(data){
          this.contractBasis = data
      },
      showPayModal(){
          this.payModal=true
          let parmas={contractId:"b788df05-6ae2-4f1b-9945-d77b03839085",amountIds:"3363c9b46d374861ac31ee967a41c397"}
      },
      onChange (e) {
        console.log(`checked = ${e.target.checked}`)
      },
      // 基本信息
      getProjectContract(parmasData){
        var _self = this
        apiService.getProjectContract(parmasData).then(r => {
          _self.expenditureTypeCodeS = r.expenditureTypeCode.split(",");
          r.expenseValue = parseInt(r.expenseValue);
          _self.baseInfo=r
        }, r => {
        }).catch(
        )
      },
      // 合同金额明细
      getContractAmountDetailList(parmasData){
        var _self = this
        apiService.getContractAmountDetailList(parmasData).then(r => {
          _self.amountDetail=r.list
          for(var i=0; i<_self.amountDetail.length; i++){
            if(!_self.amountDetail[i].uuid){
              _self.amountDetail[i].uuid = this.outuuid();
            }
          }

        }, r => {
        }).catch(
        )
      },
      // 合同付款明细
      getContractPaymentDetailList(parmasData){
        var _self = this
        apiService.getContractPaymentDetailList(parmasData).then(r => {
          _self.paymentDetail=r.list
          for(var i=0; i<_self.paymentDetail.length; i++){
            if(!_self.paymentDetail[i].uuid){
              _self.paymentDetail[i].uuid = this.outuuid();
            }
          }

        }, r => {
        }).catch(
        )
      },
      // 附件：固定资产、无形资产使用情况
      getItmcContractAssetsDetailList(parmasData){
        var _self = this
        apiService.getItmcContractAssetsDetailList(parmasData).then(r => {
          _self.contractAssetsDetail=r.list
        }, r => {
        }).catch(
        )
      },
      // 保存合同信息
      updateItmcProjectContract(parmasData, parmas){
        var _self = this
        apiService.updateItmcProjectContract(parmasData, parmas).then(r => {
          this.$message.success('保存成功！')
        }, r => {
        }).catch(
        )
      },
      // 合同依据
      getContractBasisDetailInfo(parmasData){
        var _self = this
        apiService.getContractBasisDetailInfo(parmasData).then(r => {
          _self.contractBasis=r.list
        }, r => {
        }).catch(
        )
      },
      // 合同附件
      getContractEnclosureInfo(parmasData){
        var _self = this
        apiService.getContractEnclosureInfo(parmasData).then(r => {
          _self.enclosure=r.list
        }, r => {
        }).catch(
        )
      },
      getPayerNameFormDic(parmasData){
        let _self=this
        apiService.getPayerNameFormDic(parmasData).then(r => {
            if(r.status=='200'){
              _self.optionDepart=r.data
              _self.optionDepartSelect=r.data[0].optionCode
            }
        }, r => {
        }).catch((r)=>{})
      },
      createBill(){
        let _self=this
        let parmasData={contractId:contractId}
        parmasData._json=true
        apiService.createBill(parmasData).then(r => {
          if(r.status=='200'){
            _self.$message.success("确认成功")
          }
        }, r => {
        }).catch(
        )
      },
      fuWuDianJi(){
        let _self=this
        let parmasData={}
        parmasData._json=true
        apiService.fuWuDianJi(parmasData).then(r => {
          if(r.status=='200'){
            _self.$message.success("报销单创建成功")
          }
        }, r => {
        }).catch(
        )
      },
      goBack(){
        this.$router.go(-1)
      },
      outuuid(){
        let len = 7
        let chars = 'abcdefghijklmnopqrstuvwxyz2345678'
        let maxPos = chars.length
        let pwd = ''
        for (let i = 0; i < len; i++) {
          pwd += chars.charAt(Math.floor(Math.random() * maxPos))
        }
        return 'f_' + pwd
      },
      saveContractInfo(){
        this.loading = true;
        this.baseInfo['contractId'] = this.contractId;
        let _self =this;
        if(this.isAdd == true){
          let saveContractData={
            itmcProjectContract: this.baseInfo,
            itmcContractAmountDetailList: this.amountDetail.map(function (item) {
              item['contractId'] = _self.contractId;
              return item;
            }),
            itmcContractPaymentDetailList: this.paymentDetail.map(function (item) {
              item['contractId'] = _self.contractId;
              item['uuid'] = _self.uuid(40,16);
              return item;
            }),
            itmcContractAssetsDetailList: this.contractAssetsDetail.map(function (item) {
              item['contractId'] = _self.contractId;
              return item;
            })
            // itmcContractBasisDetailList: this.contractBasis,
            // itmcContractEnclosureList: this.enclosure,
          }
          //添加
          let saveContractParmas='ContractId='+this.contractId

          apiService.addItmcProjectContract(saveContractData, saveContractParmas).then((r) => {
            if(r.result == "0000"){
              if(_self.contractType == "01"){
                this.$message.success('保存成功。');
                this.$router.push({path: "/project-contract"})
              } else if (_self.contractType == "02"){
                this.$message.success('保存成功。');
                this.$router.push({path: "/cost-contract"});
              }
              apiService.synchronizedContract(saveContractParmas).then((r) => {
                if(r.success) {
                  if(_self.contractType == "01"){
                    this.$message.success('保存成功。');
                    this.$router.push({path: "/project-contract"})
                  } else if (_self.contractType == "02"){
                    this.$message.success('保存成功。');
                    this.$router.push({path: "/cost-contract"});
                  }
                } else {
                  this.$message.error('同步失败。');
                }
              },(r) => {
              }).catch((r) => {
              });
            } else {
              this.loading = false;
              this.$message.error('保存失败。');
            }
          },(r) => {

          }).catch((r) => {

          })

        } else {//修改
          let saveContractData={
            itmcProjectContract: this.baseInfo,
            itmcContractAmountDetailList: this.amountDetail,
            itmcContractPaymentDetailList: this.paymentDetail,
            itmcContractAssetsDetailList: this.contractAssetsDetail
            // itmcContractBasisDetailList: this.contractBasis,
            // itmcContractEnclosureList: this.enclosure,
          }
          //添加
          let saveContractParmas='ContractId='+this.contractId
          apiService.updateItmcProjectContractV2(saveContractData,saveContractParmas).then((r) => {
            if(r.result == "0000"){
              if(_self.contractType == "01"){
                this.$message.success('保存成功。');
                this.$router.push({path: "/project-contract"})
              } else if (_self.contractType == "02"){
                this.$message.success('保存成功。');
                this.$router.push({path: "/cost-contract"});
              }
              apiService.synchronizedContract(saveContractParmas).then((r) => {
                if(r.success) {
                  if(_self.contractType == "01"){
                    this.$message.success('保存成功。');
                    this.$router.push({path: "/project-contract"})
                  } else if (_self.contractType == "02"){
                    this.$message.success('保存成功。');
                    this.$router.push({path: "/cost-contract"});
                  }
                } else {
                  this.$message.error('同步失败。');
                }
              },(r) => {
              }).catch((r) => {
              });
            } else {
              this.loading = false;
              this.$message.error('保存失败。');
            }

          },(r) => {

          })
        }

       //this.updateItmcProjectContract(saveContractData, saveContractParmas)
      },
      setContractAmountDetail(params){
        this.amountDetail = params.result;
      },
      getContractAmountDetail(){
        return this.amountDetail;
      },
      setContractPaymentDetail(params){
        this.paymentDetail = params;
      },
      getContractPaymentDetail(){
        return this.paymentDetail;
      },
      getContractAssetsDetail(){
        return this.contractAssetsDetail;
      },
      setTaxRateObject(params){
        this.taxRateObject = params;
      },
      setBaseInfo(params){
        this.baseInfo = params;
      },
      setHardWareAndSoftWareCost(params){
        this.hardWareAndSoftWareCost = params;
      },
      formatNumFloat(num){
        return (num+ '').replace(/(\d{1,3})(?=(\d{3})+(?:$|\.))/g,'$1,');
      },
      formatCurrency(num){
        if(num){
          num = num.toString().replace(/\$|\,/g,'');
          if(''==num || isNaN(num)){return 'Not a Number ! ';}
          var sign = num.indexOf("-")> 0 ? '-' : '';
          var cents = num.indexOf(".")> 0 ? num.substr(num.indexOf(".")) : '';
          cents = cents.length>1 ? cents : '' ;
          num = num.indexOf(".")>0 ? num.substring(0,(num.indexOf("."))) : num ;
          if('' == cents){ if(num.length>1 && '0' == num.substr(0,1)){return 'Not a Number ! ';}}
          else{if(num.length>1 && '0' == num.substr(0,1)){return 'Not a Number ! ';}}

          for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++){
            num = num.substring(0,num.length-(4*i+3))+','+num.substring(num.length-(4*i+3));
          }
          return (sign + num + cents);
        }
      },
      uuid(len, radix) {//设置UUID
        var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
        var uuid = [], i;
        radix = radix || chars.length;
        if (len) {
          // Compact form
          for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random()*radix];
        } else {
          // rfc4122, version 4 form
          var r;
          // rfc4122 requires these characters
          uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
          uuid[14] = '4';
          // Fill in random data. At i==19 set the high bits of clock sequence as
          // per rfc4122, sec. 4.1.5
          for (i = 0; i < 36; i++) {
            if (!uuid[i]) {
              r = 0 | Math.random()*16;
              uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
            }
          }
        }
        this.uuidAdd = uuid.join('')
        return uuid.join('');
      },
      getDictionary() {
        var _self = this;
        var parmasData = {_json: true, typeCode: 'SMD'};
        apiService.getDictionary(parmasData).then(r => {
          _self.taxCodeList = r;
            for (let i = 0; i < _self.taxCodeList.length; i++){
              _self.taxRateObject[_self.taxCodeList[i].optionCode]=_self.taxCodeList[i].taxRate;
              _self.taxRateNameObject[_self.taxCodeList[i].optionCode] = _self.taxCodeList[i].optionName;
            }
        }, r => {
        }).catch(
        )
      }
    },
    beforeCreate(){

    },
    created(){
      let _self = this;
      this.contractId=this.$route.params.contractId;
      this.contractType=this.$route.params.contractType;
      this.isEdit=this.$route.params.isEdit;
      if(this.$route.params.isAdd == true){
        this.isAdd = this.$route.params.isAdd;
        if(this.contractType == '01'){
           this.baseInfo.contractType = "0101";
        } else if(this.contractType == '02'){
           this.baseInfo.contractType = "0201";
        }
      }
      this.getDictionary();
      if(this.$route.params.isAdd != true || this.$route.params.isAdd == undefined){
          let baseParmas={ContractId:this.contractId};
          baseParmas._json=true;
          this.getProjectContract(baseParmas);
          let baseAmountParmas={ContractId:this.contractId};
          baseAmountParmas._json=true;
          this.getContractAmountDetailList(baseAmountParmas);
          let basePaymentParmas={ContractId:this.contractId};
          basePaymentParmas._json=true;
          this.getContractPaymentDetailList(basePaymentParmas);
          let AssetsDetailList={ContractId:this.contractId};
          AssetsDetailList._json=true;
          this.getItmcContractAssetsDetailList(AssetsDetailList);
          let contractBasisPramas={ContractId:this.contractId};
          contractBasisPramas._json=true;
          this.getContractBasisDetailInfo(contractBasisPramas);
          let enclosurePramas={ContractId:this.contractId};
          enclosurePramas._json=true;
          this.getContractEnclosureInfo(enclosurePramas);
          let payerNamePramas={typeCode:"PayerName",dictionaryCode:""};
          payerNamePramas._json=true;
          this.getPayerNameFormDic(payerNamePramas);
        };
        // setTimeout(function () {
        //   _self.getDictionary();
        // },0);
    }
  }
</script>
<style>
  .wrap {
    background: #ffffff;
    padding: 20px;
  }

  #headSearch > span {
    margin-left: 10px;
  }

  #headSearch {
    align-items: center;
  }

  .ant-table-tbody > tr > td {
    border: 1px solid #e8e8e8;
  }

  .ant-table-thead > tr > th {
    border-left: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
  }

  .ant-table-thead tr {
    border-top: 1px solid #e8e8e8;
  }

  .ant-table-thead > tr > th, .ant-table-tbody > tr > td {
    padding: 6px 16px;
  }
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #333333;
    display: flex;
    margin-bottom: 20px;
    position: relative;
    margin-top: 20px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: rgb(24, 144, 255);
    height: 20px;
    margin-right: 10px;
  }
  .flexBox{
    display: flex;
  }
  .flexTitle{
    flex: 2;
    text-align: right;
    padding: 10px;
  }
  .flexCon{
    flex: 8;
    text-align: left;
    padding: 10px;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    bottom: 0;
    right: 25px;
  }
  .contentBos{
    display: flex;
  }
  .contentBos .conLeft{
    justify-content: center;
    align-items: center;
    flex: 1;
    display: flex;
    border-left: 1px solid #e8e8e8;
    border-top: 1px solid #e8e8e8;
    border-bottom: 1px solid #e8e8e8;
  }
</style>
