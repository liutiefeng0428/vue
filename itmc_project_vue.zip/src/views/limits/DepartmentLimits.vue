<template>
  <div class="wrap">
    <div class="con-title">
      <span class="divdLine"></span>
      <span>处室权限申请处理-待办</span>
    </div>
    <div class="container" style="padding: 0">
      <div>
        <div class="ant-table-content">
          <div class="ant-table-tbody">
            <table style="width: 100%">
              <thead class="ant-table-thead"><tr>
                <th class="ant-table-align-left" style="text-align: left;"><div>待办类型</div></th>
                <th class="ant-table-align-left" style="text-align: left;"><div>待办内容</div></th>
                <th class="ant-table-align-left" style="text-align: left;"><div>发起人</div></th>
                <th class="ant-table-align-left" style="text-align: left;"><div>当前处理人</div></th>
                <th class="ant-table-align-left" style="text-align: left;"><div>提交时间</div></th></tr></thead>
              <tbody class="ant-table-tbody">
               <tr v-for="(item,index) in infoData">
                 <td>权限申请</td>
                 <td><span><a @click="toLimitsApply(item.uuid)">{{item.applyRoleName}}权限申请</a></span></td>
                 <td>{{item.createUserName}}</td>
                 <td>{{item.lastApproveUser}}</td>
                 <td>{{item.createTime|formatDateTime}}</td>
               </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import reqwest from 'reqwest'
  import {apiService} from "@/services/apiservice";
  export default {
    name: "DepartmentLimits",
    components: {
    },
    data() {
      return {
        infoData:[],
      }
    },
    methods: {
      toLimitsApply(uuid){
          this.$router.push({path:'/limits-apply',query:{uuid:uuid}})
      },
      getUserAuthApplyList(){
        let _self=this
        var parmasData={}
        parmasData._json=true
        apiService.getUserAuthApplyList(parmasData).then(r => {
          _self.infoData=r
        }, r => {
        }).catch(
        )
      },
    },
    computed: {

    },
    filters:{
      formatDateTime (inputTime) {
        var cur=  inputTime*1000 //毫秒数转日期
        var date = new Date(cur);
        var y = date.getFullYear();
        var m = date.getMonth() + 1;
        m = m < 10 ? ('0' + m) : m;
        var d = date.getDate();
        d = d < 10 ? ('0' + d) : d;
        var h = date.getHours();
        h = h < 10 ? ('0' + h) : h;
        var minute = date.getMinutes();
        var second = date.getSeconds();
        minute = minute < 10 ? ('0' + minute) : minute;
        second = second < 10 ? ('0' + second) : second;
        return y + '-' + m + '-' + d + ' ' + '　' + h + ':' + minute + ':' + second;
      }
    },
    created(){
      this.getUserAuthApplyList()
    }
  }
</script>
<style>
  .wrap {
    padding: 15px;
    background: #ffffff;
    margin: 10px;
  }
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 15px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .con-head{
    margin-bottom: 20px;
  }
  .ant-table-tbody table{
    border-top: 1px solid #e8e8e8;
    border-left: 1px solid #e8e8e8;
  }
  .ant-table-tbody > tr > td{
    border-bottom: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
    -webkit-transition: all 0.3s, border 0s;
    transition: all 0.3s, border 0s;
  }
  .ant-table-thead > tr > th{
    border-right: 1px solid #e8e8e8;
  }
  /*.ant-table-thead > tr > th, .ant-table-tbody > tr > td{*/
    /*padding: 8px 16px;*/
  /*}*/
</style>
