<template>
  <div class="wrapAppl" style="margin-right:330px">
    <div class="wrap-content">
      <div class="con-title">
        <span class="divdLine"></span>
        <span>项目上报权限申请单</span>
      </div>
      <div class="container" style="margin-bottom: 20px;display: flex;padding: 0">
        <div style="flex: 1">
          <div class="flexBox1">
            <div class="flexItems1">
              <div class="flexT">登录角色</div>
              <div class="flexC">{{roleInfo.applyRoleName}}</div>
            </div>
            <div class="flexItems1">
              <div class="flexT">账号</div>
              <div class="flexC">{{roleInfo.account}}</div>
            </div>
            <div class="flexItems1">
              <div class="flexT">姓名</div>
              <div class="flexC">{{roleInfo.userName}}</div>
            </div>
            <div class="flexItems1">
              <div class="flexT">所属单位</div>
              <div class="flexC">{{roleInfo.userOrgName}}</div>
            </div>
            <div class="flexItems1">
              <div class="flexT">所在部门</div>
              <div class="flexC">{{roleInfo.userDeptName}}</div>
            </div>
            <div class="flexItems1"  v-if="roleInfo.applyRoleName!='项目经理'">
              <div class="flexT">联系电话</div>
              <div class="flexC">{{roleInfo.mobile}}</div>
            </div>
            <div class="flexItems1">
              <div class="flexT">手机</div>
              <div class="flexC">{{roleInfo.mobile}}</div>
            </div>
            <div class="flexItems1" v-if="roleInfo.applyRoleName=='项目经理'">
              <div class="flexT">所属项目</div>
              <div class="flexC">{{roleInfo.projectName}}</div>
            </div>
            <div class="flexItems1" v-if="roleInfo.applyRoleName=='项目经理'">
              <div class="flexT">项目主管处室</div>
              <div class="flexC">{{roleInfo.projectDeptName}}</div>
            </div>
            <div class="flexItems1" v-if="roleInfo.applyRoleName=='项目经理'">
              <div class="flexT">申请事由</div>
              <div class="flexC">{{roleInfo.applyOpinion}}</div>
            </div>
          </div>
        </div>
        <!--<div style="flex: 1">-->
        <!--<div style="display: flex;margin-bottom: 10px">-->
        <!--<span style="flex:2;text-align: right;margin-right: 10px">审批意见:</span>-->
        <!--<span style="flex: 8"><a-button type="primary" @click="saveApproveStatus()">提交</a-button>-->
        <!--<a-button @click="goBack()">取消</a-button></span>-->
        <!--</div>-->
        <!--<div style="display: flex;margin-bottom: 10px">-->
        <!--<span style="flex:2;text-align: right;margin-right: 10px">当前审批人:</span>-->
        <!--<span style="flex: 8">{{roleInfo.userName}}</span>-->
        <!--</div>-->
        <!--<div style="display: flex;margin-bottom: 10px">-->
        <!--<span style="flex:2;text-align: right;margin-right: 10px">审批结果:</span>-->
        <!--<span style="flex: 8">-->
        <!--<a-radio-group @change="onChangeApply" v-model="applyRes">-->
        <!--<a-radio :value="1">审批通过</a-radio>-->
        <!--<a-radio :value="0">审批驳回</a-radio>-->
        <!--</a-radio-group>-->
        <!--</span>-->
        <!--</div>-->
        <!--<div style="display: flex;margin-bottom:10px" v-if="roleInfo.applyRoleName=='项目经理'">-->
        <!--<span style="flex:2;text-align: right;margin-right: 10px">指定项目:</span>-->
        <!--<span style="flex: 8">-->
        <!--<a-select  :value=optionProjectNameSelect class="querySelect" @change="handleChangeProject" style="width: 200px">-->
        <!--<a-select-option v-for="item in projectName" :key="item.projectCode"> {{item.projectName}}</a-select-option>-->
        <!--</a-select>-->
        <!--</span>-->
        <!--</div>-->
        <!--<div style="display: flex;margin-bottom:10px">-->
        <!--<span style="flex: 2;text-align: right;margin-right: 10px">审批意见:</span>-->
        <!--<a-textarea style="flex: 8" v-model="approveOpinion" :rows="4"/>-->
        <!--</div>-->
        <!--<div style="display: flex;margin-bottom: 10px">-->
        <!--<span style="flex:2;text-align: right;margin-right: 10px">下一步处理人:</span>-->
        <!--<span style="flex: 8">系统管理员</span>-->
        <!--</div>-->
        <!--</div>-->
      </div>
      <div class="con-title">
        <span class="divdLine"></span>
        <span>流程信息</span>
      </div>
      <div class="container" style="padding: 0">
        <div>
          <div class="ant-table-content">
            <div class="ant-table-tbody">
              <table style="width: 100%">
                <thead class="ant-table-thead"><tr>
                  <th class="ant-table-align-left" style="text-align: left;"><div>审批人</div></th>
                  <th class="ant-table-align-left" style="text-align: left;"><div>审批动作</div></th>
                  <th class="ant-table-align-left" style="text-align: left;"><div>审批时间</div></th>
                  <th class="ant-table-align-left" style="text-align: left;"><div>审批意见</div></th>
                </tr></thead>
                <tbody class="ant-table-tbody">
                <tr v-for="(item,index) in infoList">
                  <td>{{item.approveUserName}}</td>
                  <td><span v-if="item.approveResult=='1'">审批同意</span><span v-if="item.approveResult=='0'">审批拒绝</span></td>
                  <td>{{item.approveTime|formatDateTime}}</td>
                  <td>{{item.approveOpinion}}</td>
                </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div>
      <tools :labelCol="labelCol" :wrapperCol="wrapperCol" @submitObj="submitObj" ></tools>
    </div>
  </div>
</template>

<script>

  import reqwest from 'reqwest'
  import {apiService} from "@/services/apiservice";
  import Tools from '@/components/operation/Tools'
  export default {
    name: "LimitsApply",
    components: {
      Tools
    },
    data() {
      return {
        applyRes:1,
        uuid:"",
        approveOpinion:"",
        projectName:[],
        optionProjectNameSelect:"",
        ProjectNameSelect:"",
        roleInfo:{},
        infoList:[],
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 12 },
        },
      }
    },
    methods: {
      submitObj(operationObj){
        console.log(operationObj)
      },
      onChangeApply(e){
        console.log('radio checked', e.target.value)
      },
      goBack(){
          this.$router.go(-1)
      },
      getProjectDataInfo(parmasData){
        let _self=this
        apiService.getProjectDataInfo(parmasData).then(r => {
          _self.projectName=r
          _self.optionProjectNameSelect=r[0].projectCode
          _self.ProjectNameSelect=r[0].projectName
        }, r => {
        }).catch(
        )
      },
      getUserAuthApplyById(parmasData){
        let _self=this
        apiService.getUserAuthApplyById(parmasData).then(r => {
          _self.roleInfo=r
          let parmas={projectDeptCode:r.projectDeptCode}
          parmas._json=true
          _self.getProjectDataInfo(parmas)
        }, r => {
        }).catch(
        )
      },
      getUserAuthApplyHistoryList(parmasData){
        let _self=this
        apiService.getUserAuthApplyHistoryList(parmasData).then(r => {
          _self.infoList=r
        }, r => {
        }).catch(
        )
      },
      saveApproveStatus(){
        let parmasData={uuid:this.uuid,result:this.applyRes,approveOpinion:this.approveOpinion,projectId:this.optionProjectNameSelect,projectName:this.ProjectNameSelect}
        parmasData._json=true
        apiService.updateApproveStatus(parmasData).then(r => {
          this.$message.success("提交成功")
        }, r => {
        }).catch(
        )
      },
      handleChangeProject(value){
        this.optionProjectNameSelect = value
        this.projectName.findIndex(item=> item=== '');
      },
    },
    computed: {

    },
    filters:{
      formatDateTime (inputTime) {
        var cur=  inputTime*1000 //毫秒数转日期
        var date = new Date(cur);
        var y = date.getFullYear();
        var m = date.getMonth() + 1;
        m = m < 10 ? ('0' + m) : m;
        var d = date.getDate();
        d = d < 10 ? ('0' + d) : d;
        var h = date.getHours();
        h = h < 10 ? ('0' + h) : h;
        var minute = date.getMinutes();
        var second = date.getSeconds();
        minute = minute < 10 ? ('0' + minute) : minute;
        second = second < 10 ? ('0' + second) : second;
        return y + '-' + m + '-' + d + ' ' + '　' + h + ':' + minute + ':' + second;
      }
    },
    filters:{
      formatDateTime (inputTime) {
        var date = new Date(inputTime);
        var y = date.getFullYear();
        var m = date.getMonth() + 1;
        m = m < 10 ? ('0' + m) : m;
        var d = date.getDate();
        d = d < 10 ? ('0' + d) : d;
        var h = date.getHours();
        h = h < 10 ? ('0' + h) : h;
        var minute = date.getMinutes();
        var second = date.getSeconds();
        minute = minute < 10 ? ('0' + minute) : minute;
        second = second < 10 ? ('0' + second) : second;
        return y + '-' + m + '-' + d + ' ' + '　' + h + ':' + minute + ':' + second;
      }
    },
    created(){
      this.uuid=this.$route.query.uuid
      var parmasData={uuid:this.uuid}
      parmasData._json=true
      this.getUserAuthApplyById(parmasData)
      var parmasData1={uuid:this.uuid}
      parmasData1._json=true
      this.getUserAuthApplyHistoryList(parmasData1)
    }
  }
</script>
<style>
/*  .wrapAppl {
    padding: 20px;
    background: #ffffff;
    margin: 10px;
    height: 100%;
  }*/
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 15px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .con-head{
    margin-bottom: 20px;
  }
  .ant-table-tbody table{
    border-top: 1px solid #e8e8e8;
    border-left: 1px solid #e8e8e8;
  }
  .ant-table-tbody > tr > td{
    border-bottom: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
    -webkit-transition: all 0.3s, border 0s;
    transition: all 0.3s, border 0s;
  }
  .ant-table-thead > tr > th{
    border-right: 1px solid #e8e8e8;
  }
  /*.ant-table-thead > tr > th, .ant-table-tbody > tr > td{*/
    /*padding: 8px 16px;*/
  /*}*/
  .flexBox1{
    border-top: 1px solid #e8e8e8;
    border-left: 1px solid #e8e8e8;
  }
  .flexItems1{
    display: flex;
    box-sizing: border-box;
  }
  .flexT{
    flex: 2;
    text-align: right;
    padding:5px 10px;
    background: #fafafa;
    border-right: 1px solid #e8e8e8;
    border-bottom: 1px solid #e8e8e8;
  }
  .flexC{
    flex: 8;
    text-align: left;
    padding:5px 10px;
    border-right: 1px solid #e8e8e8;
    border-bottom: 1px solid #e8e8e8;
  }
</style>
