<template>
  <div>
    <iframe style="width: 100%"  id="iframe" :src=url frameborder="0"></iframe>
  </div>
</template>

<script>

  import {urlDomain} from '@/services/domain'
  export default {
    name: "ProjectCard",
    components: {
    },
    data () {
     return {
       url:urlDomain+"/project/projectMileStone/projectCardPage.html"
     }
    },
    methods: {
    },
    mounted(){
      let clientHeight = document.documentElement.clientHeight
      document.getElementById("iframe").style.height= (clientHeight-70) + 'px'
    },
    created(){
    },
    watch: {
    }
  }
</script>
<style>
  @import '../../assets/css/common.css';
</style>
