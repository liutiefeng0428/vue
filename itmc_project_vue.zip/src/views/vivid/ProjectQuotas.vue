<template>
  <div>
    <iframe style="width: 100%;" :src=url frameborder="0" id="iframe"></iframe>
  </div>
</template>

<script>

  import {urlDomain} from '@/services/domain'
  export default {
    name: "ProjectQuotas",
    components: {
    },
    data () {
     return {
       url:urlDomain+"/project/projectMileStone/compilationStage.html"
     }
    },
    methods: {
    },
    mounted(){
      let clientHeight = document.documentElement.clientHeight
      document.getElementById("iframe").style.height= (clientHeight-70) + 'px'
    },
    watch: {

    }
  }
</script>
<style>
  @import '../../assets/css/common.css';
</style>
