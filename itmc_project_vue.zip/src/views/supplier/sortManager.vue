<template>
  <div class="wrap wrap-flex">
    <div class="fenlei">项目分类管理</div>
    <div class="tree-box">
      <!-- <tree @changeZzyfShow="changeZzyfShow" @getKeyCode="getKeyCode"></tree> -->
      <a-tree @select="onSelect" :treeData="treeData" :defaultExpandedKeys='["SCYY", "FL01", "SCYY,FL01,GM02"]' />
    </div>
    <div class="table-box">
      <!-- <zzyf v-if="zzyf" :keyCodeArr="keyCodeArr"></zzyf> -->
      <div v-if="zzyf">
    <a-button type="primary" @click="add">新建</a-button>
    <div style="margin-top:15px;" class="btn-style">
      <a-table :columns="columns" :dataSource="data3" :pagination="false" bordered>
        <a
          style="text-decoratio: none;"
          slot="operation"
          slot-scope="text, record, index"
          href="javascript:;"
          @click="forbiddens(text, record, index)"
        >{{record.status=='启用'?'禁用':(record.status=='禁用'?'启用':'禁用')}}</a>
      </a-table>
    </div>
  </div>
    </div>
  </div>
</template>
<script>
import { apiService } from "@/services/apiservice";
// import zzyf from "./sortComponents/ZZYF.vue";
// import tree from "./sortComponents/TREE.vue";
export default {
  components: {
    // zzyf,
    // tree
  },
  data() {
    return {
      zzyf: false,
      expandedKeys: ["SCYY", "FL01", "SCYY,FL01,GM02"],
      keyCodeArr: ["SCYY", "FL01", "GM02"],
      data3: [],
      columns: [
        {
          title: "步骤",
          dataIndex: "parentStageName",
          key: "parentStageName"
        },
        {
          title: "任务顺序",
          dataIndex: "stageSort",
          key: "stageSort"
        },
        {
          title: "任务",
          dataIndex: "stageName",
          key: "stageName"
        },
        {
          title: "活动",
          key: "flowName",
          dataIndex: "flowName"
        },
        {
          title: "表单名称",
          key: "formName",
          dataIndex: "formName"
        },
        {
          title: "状态",
          key: "status",
          dataIndex: "status"
        },
        {
          title: "备注",
          key: "remark",
          dataIndex: "remark"
        },
        {
          title: "操作",
          key: "operation",
          dataIndex: "operation",
          scopedSlots: { customRender: "operation" }
        }
      ],
      visible: false,
      fileList: [],
      value: "",
      treeData: [],
    };
  },
  mounted(){
      
  },
  created(){
    this.getTreeList();
    this.getData()
    this.zzyf = true
  },
  methods: {
    getData() {
      let params = {
        platformCode: this.keyCodeArr.join(',').split(',')[0],
        propertyCode: this.keyCodeArr.join(',').split(',')[1],
        investmentCode: this.keyCodeArr.join(',').split(',')[2],
      };
      apiService
        .postBusinessConfigList(params)
        .then(
          r => {
            // console.log(r)
            if (r.success == true) {
              this.data3 = r.result;
              this.data3.forEach(item => {
                if (item.status == "1") {
                  item.status = "启用";
                } else if (item.status == "0") {
                  item.status = "禁用";
                }
              });
            }
          },
          r => {}
        )
        .catch();
    },
    forbiddens(text, record, index) {
      console.log(record);
      if (record.status == "启用") {
        record.status = "0";
      } else if (record.status == "禁用") {
        record.status = "1";
      }
      let params = {
        configId: record.configId,
        status: record.status
      };
      apiService
        .updateBusinessConfigStatus(params)
        .then(
          r => {
            console.log(r);
            if (r.success == true) {
              this.$message.success("操作成功！");
              this.getData();
            }
          },
          r => {}
        )
        .catch();
    },
    add() {
      this.$router.push({ name: "add" });
    },
    onSelect(selectedKeys, info) {
      console.log(selectedKeys)
      console.log(selectedKeys.join(',').split(','))
      let threeCode = selectedKeys.join(',').split(',')
      this.keyCodeArr = selectedKeys
    //   this.zzyf = true
    //   this.getData()
      if(threeCode.length==1){
          this.zzyf = true
      }else if(threeCode.length==2){
          this.zzyf = true
      }else if(threeCode.length==3){
          this.zzyf = true
          this.getData()
      }
    },
    getTreeList() {
      let params = {};
      apiService
        .postBusinessTypeTree(params)
        .then(r => {
          console.log(r.result);
          let data = r.result
          var list = [];
          var li = [];
          for (var i = 0; i < data.length; i++) {
            if (li.indexOf(data[i]["platformCode"]) == -1) {
              list.push({
                title: data[i]["platformName"],
                key: data[i]["platformCode"],
                // disabled: true,
                children: []
              });
              li.push(data[i]["platformCode"]);
            }
          }

          for (var i = 0; i < list.length; i++) {
            for (var j = 0; j < data.length; j++) {
              if (list[i]["key"] == data[j]["platformCode"]) {
                list[i]["children"].push({
                  title: data[j]["propertyName"],
                  key: data[j]["propertyCode"],
                //   disabled: true,
                  children: []
                });
              }
            }
          }

          for (var i = 0; i < list.length; i++) {
            for (var j = 0; j < data.length; j++) {
              if (list[i]["key"] == data[j]["platformCode"]) {
                for (var k = 0; k < list[i]["children"].length; k++) {
                  if (
                    list[i]["children"][k]["key"] == data[j]["propertyCode"]
                  ) {
                    let newArr = []
                    newArr.push(data[j]["platformCode"])
                    newArr.push(data[j]["propertyCode"])
                    newArr.push(data[j]["investmentCode"])
                    list[i]["children"][k]["children"].push({
                      title: data[j]["investmentName"],
                      key: newArr.join(','),
                    });
                  }
                }
              }
            }
          }
          console.log(list);
          this.treeData = list
        })
        .catch();
    }
  }
};
</script>
<style>
.wrap {
  padding: 20px;
  background: #ffffff;
  margin: 10px;
  position: relative;
}
.wrap-flex {
  display: flex;
}
.fenlei {
  position: absolute;
  top: 0;
  font-size: 16px;
  padding: 10px 0 10px 0;
}
.tree-box {
  width: 200px;
  padding-top: 20px;
}
.table-box {
  flex: 1;
  /* margin-left: 30px; */
  margin-top: 20px;
}
</style>