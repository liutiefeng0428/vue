<template>
  <div>
    <a-button type="primary" @click="add">新建</a-button>
    <a-button type="primary" @click="visible = true">上传BPMN文件</a-button>
    <div style="margin-top:15px;" class="btn-style">
      <a-table :columns="columns" :dataSource="data3" :pagination="false" bordered>
        <a
          style="text-decoratio: none;"
          slot="operation"
          slot-scope="text, record, index"
          href="javascript:;"
          @click="forbiddens(text, record, index)"
        >{{record.status=='启用'?'禁用':(record.status=='禁用'?'启用':'禁用')}}</a>
      </a-table>
    </div>
    <a-modal title="上传BPMN文件" :visible="visible" :closable="false" width="620px">
      <template slot="footer">
        <a-button key="back" @click="visible = false">取消</a-button>
        <a-button key="submit" type="primary" html-type="submit" @click="visible = false">上传</a-button>
      </template>
      <div class="row_col_style">
        <a-row>
          <a-col :span="8">分 类</a-col>
          <a-col :span="16">
            <a-tree-select
              style="width: 300px"
              :dropdownStyle="{ maxHeight: '400px', overflow: 'auto' }"
              :treeData="treeData"
              placeholder="请选择分类"
              treeDefaultExpandAll
              v-model="value"
              :allowClear="true"
              @change="onChange"
            >
              <!-- <span
                style="color: #08c"
                slot="title"
                slot-scope="{key, value}"
                v-if="key='0-0-1'"
              >Child Node1 {{value}}</span> -->
            </a-tree-select>
          </a-col>
          <a-col :span="8" style="border-top: 0;">流程标题</a-col>
          <a-col :span="16" style="height:42px;border-top: 0;">
            <a-input placeholder="请输入流程标题" style="width: 300px;" />
          </a-col>
          <a-col :span="8" style="border-top: 0;">流程Key</a-col>
          <a-col :span="16" style="height:42px;border-top: 0;">
            <a-input placeholder="请输入流程Key" style="width: 300px;" />
          </a-col>
          <a-col :span="8" style="border-top: 0;">流程描述</a-col>
          <a-col :span="16" style="height:42px;border-top: 0;">
            <a-input placeholder="请输入流程描述" style="width: 300px;" />
          </a-col>
          <a-col :span="8" style="border-top: 0;">上传BPMN文件</a-col>
          <a-col :span="16" style="height:42px;border-top: 0;" class="uploadSpan">
            <a-upload
              :fileList="fileList"
              :remove="handleRemove"
              :beforeUpload="beforeUpload"
              @change="handleUpload"
            >
              <a-button>
                <a-icon type="upload"/>选择文件
              </a-button>
            </a-upload>
          </a-col>
        </a-row>
      </div>
    </a-modal>
  </div>
</template>
<script>
import { apiService } from "@/services/apiservice";
export default {
  data() {
    return {
      data3: [],
      columns: [
        {
          title: "步骤",
          dataIndex: "parentStageName",
          key: "parentStageName"
        },
        {
          title: "任务顺序",
          dataIndex: "stageSort",
          key: "stageSort"
        },
        {
          title: "任务",
          dataIndex: "stageName",
          key: "stageName"
        },
        {
          title: "活动",
          key: "flowName",
          dataIndex: "flowName"
        },
        {
          title: "表单名称",
          key: "formName",
          dataIndex: "formName"
        },
        {
          title: "状态",
          key: "status",
          dataIndex: "status"
        },
        {
          title: "备注",
          key: "remark",
          dataIndex: "remark"
        },
        {
          title: "操作",
          key: "operation",
          dataIndex: "operation",
          scopedSlots: { customRender: "operation" }
        }
      ],
      visible: false,
      fileList: [],
      value: "",
      treeData: [
        {
          title: "通用审批",
          value: "0-0",
          key: "0-0",
          children: [
            {
              title: "库存管理",
              value: "0-0-1",
              key: "0-0-1",
            },
            {
              title: "应聘面试审批",
              value: "0-0-2",
              key: "0-0-2"
            }
          ]
        },
        {
          title: "申请入职",
          value: "0-1",
          key: "0-1"
        },
        {
          title: "转正审批",
          value: "0-2",
          key: "0-2"
        },
        {
          title: "调岗申请",
          value: "0-3",
          key: "0-3"
        }
      ]
    };
  },
  props: ['keyCodeArr'],
  mounted() {
    this.getData();
  },
  methods: {
    getData() {
      let params = {
        platformCode: this.keyCodeArr.join(',').split(',')[0],
        propertyCode: this.keyCodeArr.join(',').split(',')[1],
        investmentCode: this.keyCodeArr.join(',').split(',')[2],
      };
      apiService
        .postBusinessConfigList(params)
        .then(
          r => {
            // console.log(r)
            if (r.success == true) {
              this.data3 = r.result;
              this.data3.forEach(item => {
                if (item.status == "1") {
                  item.status = "启用";
                } else if (item.status == "0") {
                  item.status = "禁用";
                }
              });
            }
          },
          r => {}
        )
        .catch();
    },
    forbiddens(text, record, index) {
      console.log(record);
      if (record.status == "启用") {
        record.status = "0";
      } else if (record.status == "禁用") {
        record.status = "1";
      }
      let params = {
        configId: record.configId,
        status: record.status
      };
      apiService
        .updateBusinessConfigStatus(params)
        .then(
          r => {
            console.log(r);
            if (r.success == true) {
              this.$message.success("操作成功！");
              this.getData();
            }
          },
          r => {}
        )
        .catch();
    },
    add() {
      this.$router.push({ name: "add" });
    },
    onChange (value) {
      console.log(value)
      this.value = value
    },
    handleUpload() {
        console.log(123)
    //   const { fileList } = this;
    //   const formData = new FormData();
    //       fileList.forEach((file) => {
    //         formData.append('files',file);
    //       })
    //   formData.append("file", this.files);
    //   formData.append("serviceName", "企业人员");

    //   this.uploading = true;
    //   reqwest({
    //     url: "/project/upload/uploadPmPhoto",
    //     method: "post",
    //     processData: false,
    //     data: formData,
    //     success: r => {
    //       // console.log(r.OssFileId);
    //       this.OssFileId = r.result.OssFileId;
    //       // this.$message.success("导入成功");
    //     },
    //     error: () => {
    //       this.uploading = false;
    //       this.$message.error("导入失败");
    //     }
    //   });
    },
    handleRemove(file) {
      const index = this.fileList.indexOf(file);
      const newFileList = this.fileList.slice();
      newFileList.splice(index, 1);
      this.fileList = newFileList;
    },
    beforeUpload(file) {
      this.handleRemove(this.files); //保证只能上传一个文件
      this.files = file;
      this.fileList = [...this.fileList, file];
      return false;
    }
  }
};
</script>
<style>
.ant-form-item-label {
  width: 69px !important;
}
.textArea textarea.ant-input {
  min-height: 69px !important;
  min-width: 443px !important;
}
.btn-style .ant-btn {
  color: rgb(0, 121, 254) !important;
  border: 0;
  padding: 0 8px !important;
}
.btn-style .ant-btn-primary {
  background-color: white !important;
  box-shadow: 0px 0px !important;
}
.row_col_style .ant-col-8 {
  padding: 10px 10px;
  border: 1px solid #eee;
  text-align: center;
}
.row_col_style .ant-col-16 {
  padding: 5px 10px 5px 10px;
  border-top: 1px solid #eee;
  border-right: 1px solid #eee;
  border-bottom: 1px solid #eee;
}
.row_col_style .ant-select-selection--single {
  height: 31px !important;
  line-height: 20px !important;
}
.row_col_style .ant-select-selection__rendered {
  line-height: 27px !important;
}
.row_col_style .uploadSpan.ant-col-16 span:first-child{
  display: flex;
  align-items: center;
}
.row_col_style .uploadSpan.ant-col-16 .ant-upload-list-item .anticon-close{
  position: absolute;
  top: 6px;
  right: 0px !important;
}
</style>