<template>
  <div class="wrap">
    <div style="padding: 20px;">
      <a-form :form="form">
        <a-form-item :label-col="labelCol" :wrapper-col="wrapperCol" label="配置名称：">
          <a-input placeholder="请填入分类配置" style="width: 443px;" v-model="form.configName" />
        </a-form-item>
        <a-form-item :label-col="labelCol" :wrapper-col="wrapperCol" label="平台分类：">
          <a-select
            style="width: 160px"
            labelInValue
            @change="handleChangePlatform"
            v-model="form.platformName"
          >
            <a-select-option
              :value="item.optionCode"
              v-for="item in pingTaiList"
            >{{item.optionName}}</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item :label-col="labelCol" :wrapper-col="wrapperCol" label="性质分类：">
          <a-select
            style="width: 160px"
            labelInValue
            @change="handleChangeNature"
            v-model="form.propertyName"
          >
            <a-select-option
              :value="item.optionCode"
              v-for="item in xingZhiList"
            >{{item.optionName}}</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item :label-col="labelCol" :wrapper-col="wrapperCol" label="投资分类：">
          <a-select
            style="width: 160px"
            labelInValue
            @change="handleChangeInvest"
            v-model="form.investmentName"
          >
            <a-select-option
              :value="`${item.id},${item.optionCode}`"
              v-for="item in touZiList"
            >{{item.optionName}}</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item :label-col="labelCol" :wrapper-col="wrapperCol" label="可选/必选：">
          <a-radio-group @change="onChange" v-model="form.optionType">
            <a-radio :value="0">可选</a-radio>
            <a-radio :value="1">必选</a-radio>
          </a-radio-group>
        </a-form-item>
        <a-form-item :label-col="labelCol" :wrapper-col="wrapperCol" label="步骤：">
          <a-select
            style="width: 443px"
            labelInValue
            @change="handleChangeStep"
            v-model="form.parentStageName"
          >
            <a-select-option
              :value="`${item.stageId},${item.sort}`"
              v-for="item in parentStageNameList"
            >{{item.stageName}}</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item :label-col="labelCol" :wrapper-col="wrapperCol" label="任务：">
          <a-select
            style="width: 443px"
            labelInValue
            @change="handleChangeTask"
            v-model="form.stageName"
          >
            <a-select-option
              :value="`${item.stageId},${item.sort}`"
              v-for="item in stageNameList"
            >{{item.stageName}}</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item :label-col="labelCol" :wrapper-col="wrapperCol" label="活动：">
          <a-select
            style="width: 443px"
            labelInValue
            @change="handleChangeVisibily"
            v-model="form.flowName"
          >
            <a-select-option :value="item.KEY_" v-for="item in flowNameList">{{item.NAME_}}</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item :label-col="labelCol" :wrapper-col="wrapperCol" label="表单名称：">
          <a-select
            style="width: 443px"
            labelInValue
            @change="handleChangeFromName"
            v-model="form.formName"
          >
            <a-select-option :value="item.formId" v-for="item in formNameList">{{item.formName}}</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item :label-col="labelCol" :wrapper-col="wrapperCol" label="表单Url：">
          <a-input :placeholder="formURL" style="width: 443px;" disabled />
        </a-form-item>
        <a-form-item :label-col="labelCol" :wrapper-col="wrapperCol" label="后置任务：">
          <a-select
            mode="multiple"
            placeholder="请填入后置任务"
            style="width: 443px"
            labelInValue
            @change="handleChangeHost"
          >
            <a-select-option v-for="item in optionHost" :value="item.id" :key="item.id">{{item.val}}</a-select-option>
          </a-select>
        </a-form-item>
        <a-form-item :label-col="labelCol" :wrapper-col="wrapperCol" label="备注：" class="textArea">
          <a-textarea placeholder="请输入备注内容" v-model="form.remark" autosize />
        </a-form-item>
      </a-form>
      <div style="text-align: center;">
        <a-button key="back" @click="handleCancel">取消</a-button>
        <a-button key="submit" type="primary" html-type="submit" @click="handleOk">保存</a-button>
      </div>
    </div>
  </div>
</template>
<script>
import { apiService } from "@/services/apiservice";
export default {
  data() {
    return {
      form: {
        configName: "",
        platformName: "经营管理平台",
        propertyName: "自主开发类项目",
        investmentName: "一类项目",
        optionType: 0,
        parentStageName: "",
        stageName: "",
        flowName: "",
        formName: "",
        backCondition: "",
        remark: ""
      },
      parentStageNameList: [],
      stageNameList: [],
      flowNameList: [],
      formNameList: [],
      formURL: "",
      optionHostList: [],
      parentStageSort: "",
      stageSort: "",
      parentStageId: "",
      stageId: "",
      pingTaiList: [],
      xingZhiList: [],
      touZiList: [],
      investmentCode: "",
      visible: false,
      labelCol: {
        xs: { span: 30 },
        sm: { span: 3 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 }
      },
      radioValue: 1,
      optionHost: [
        { id: 1, val: "可研初评" },
        { id: 2, val: "可研决策" },
        { id: 3, val: "正式评审" }
      ]
    };
  },
  mounted() {
    this.getStepList();
    this.getFlowList();
    this.getPingTaiList();
    this.getXingZhiList();
    this.getTouZiList();
  },
  methods: {
    add() {
      this.$router.push({ name: "add" });
    },
    handleCancel() {
      this.visible = false;
    },
    handleOk() {
        if(!this.form.configName){
            return this.$message.error('配置名称不能为空！')
        }else if(!this.form.platformName["label"]){
            return this.$message.error('平台分类不能为空！')
        }else if(!this.form.propertyName["label"]){
            return this.$message.error('性质分类不能为空！')
        }else if(!this.form.investmentName["label"]){
            return this.$message.error('投资分类不能为空！')
        }else if(!this.form.parentStageName){
            return this.$message.error('步骤不能为空！')
        }else if(!this.form.stageName){
            return this.$message.error('任务不能为空！')
        }else if(!this.form.flowName){
            return this.$message.error('活动不能为空！')
        }else if(!this.form.formName){
            return this.$message.error('表单名称不能为空！')
        }
      let params = {
        configName: this.form.configName,
        platformName: this.form.platformName["label"],
        propertyName: this.form.propertyName["label"],
        investmentName: this.form.investmentName["label"],
        investmentCode: this.investmentCode,
        propertyCode: this.form.propertyName["key"],
        platformCode: this.form.platformName["key"],
        optionType: this.form.optionType,
        parentStageName: this.form.parentStageName["label"],
        parentStageId: this.parentStageId,
        parentStageSort: this.parentStageSort,
        stageName: this.form.stageName["label"],
        stageId: this.stageId,
        stageSort: this.stageSort,
        flowName: this.form.flowName["label"],
        flowId: this.form.flowName["key"],
        formName: this.form.formName["label"],
        formId: this.form.formName["key"],
        formUrl: this.formURL,
        backCondition: "",
        remark: this.form.remark,
        status: "1"
      };
      apiService
        .saveBusinessConfig(params)
        .then(
          r => {
            console.log(r);
            if (r.success == true) {
              this.$message.success(r.message);
              this.$router.push({ name: "sortManager" });
            }
          },
          r => {}
        )
        .catch();
    },
    handleChangePlatform(val) {
      //平台分类
      console.log(val);
    },
    handleChangeNature(val) {
      //性质分类
      console.log(val);
    },
    handleChangeInvest(val) {
      //投资分类
      console.log(val);
      this.investmentCode = "";
      this.investmentCode = val.key.split(",")[1];
    },
    handleChangeStep(val) {
      //步骤
      //   console.log(val.key.split(',')[0]);
      //   console.log(val.key.split(',')[1]);
      this.parentStageId = "";
      this.parentStageId = val.key.split(",")[0];
      this.parentStageSort = "";
      this.parentStageSort = val.key.split(",")[1];
      this.form.stageName = "";
      let params = {
        parentStageId: this.parentStageId,
        stageType: "2",
        status: "1"
      };
      apiService
        .postBusinessStageInfo(params)
        .then(
          r => {
            //   console.log(r)
            if (r.success == true) {
              this.stageNameList = r.result;
            }
          },
          r => {}
        )
        .catch();
    },
    handleChangeTask(val) {
      this.form.formName = "";
      console.log(val.key.split(",")[0]);
      console.log(val.key.split(",")[1]);
      this.stageId = "";
      this.stageId = val.key.split(",")[0];
      this.stageSort = "";
      this.stageSort = val.key.split(",")[1];
      let params = {
        stageId: this.stageId,
        status: "1"
      };
      apiService
        .postBusinessFormInfo(params)
        .then(
          r => {
            console.log(r);
            if (r.success == true) {
              if (r.result.length > 0) {
                this.formNameList = r.result;
                this.formNameList.forEach(item => {
                  this.formURL = item.formUrl;
                });
              }else {
                  this.formNameList = []
                  this.$message.error('该任务下没有表单信息，请重新选择任务！')
              }
            }
          },
          r => {}
        )
        .catch();
    },
    handleChangeVisibily(val) {
      console.log(val);
      this.form.flowName = val;
    },
    handleChangeFromName(val) {
      console.log(val);
    },
    handleChangeHost(value) {
      console.log(value);
      this.optionHostList = [];
      value.forEach(item => {
        this.optionHostList.push(item.label);
      });
    },
    onChange(e) {
      console.log(e.target.value);
    },
    getStepList() {
      let params = {
        stageType: "1",
        status: "1"
      };
      apiService
        .postBusinessStageInfo(params)
        .then(
          r => {
            // console.log(r)
            if (r.success == true) {
              this.parentStageNameList = r.result;
            }
          },
          r => {}
        )
        .catch();
    },
    getFlowList() {
      let params = {};
      apiService
        .postFlowInfo(params)
        .then(
          r => {
            // console.log(r)
            if (r.success == true) {
              this.flowNameList = r.result;
            }
          },
          r => {}
        )
        .catch();
    },
    getPingTaiList() {
      let params = {
        typeCode: "SSPT"
      };
      apiService
        .postDictionary(params)
        .then(
          r => {
            // console.log(r)
            this.pingTaiList = r;
          },
          r => {}
        )
        .catch();
    },
    getXingZhiList() {
      let params = {
        typeCode: "XMFL"
      };
      apiService
        .postDictionary(params)
        .then(
          r => {
            // console.log(r)
            this.xingZhiList = r;
          },
          r => {}
        )
        .catch();
    },
    getTouZiList() {
      let params = {
        typeCode: "ZTGM"
      };
      apiService
        .postDictionary(params)
        .then(
          r => {
            // console.log(r)
            this.touZiList = r;
          },
          r => {}
        )
        .catch();
    }
  }
};
</script>
<style>
.ant-form-item-label {
  width: 69px !important;
}
.textArea textarea.ant-input {
  min-height: 69px !important;
  min-width: 443px !important;
}
.textArea .ant-input{
    width: 0px !important;
}
</style>