<template>
  <div>
    <a-tree @select="onSelect" :treeData="treeData" />
  </div>
</template>
<script>
import { apiService } from "@/services/apiservice";
import Vue from "vue";
export default {
  data() {
    return {
      dataList: [
        {
          title: "经营管理",
          key: "0-0",
          children: [
            {
              title: "自主研发",
              key: "0-0-0",
              children: [
                {
                  title: "一类",
                  key: "0-0-0-0"
                },
                {
                  title: "二（A）类",
                  key: "0-0-0-1"
                },
                {
                  title: "二（B）类",
                  key: "0-0-0-2"
                },
                {
                  title: "信息三类",
                  key: "0-0-0-3"
                },
                {
                  title: "板块三类",
                  key: "0-0-0-4"
                }
              ]
            },
            {
              title: "提升完善推广",
              key: "0-0-1"
            },
            {
              title: "引进实施",
              key: "0-0-2"
            },
            {
              title: "基础设施",
              key: "0-0-3"
            },
            {
              title: "新技术应用",
              key: "0-0-4"
            }
          ]
        }
      ],
      treeData: [],
    };
  },
  mounted() {
    this.getTreeList();
  },
  methods: {
    onSelect(selectedKeys, info) {
      console.log(selectedKeys[0])
      console.log(selectedKeys)
      this.$emit("getKeyCode", selectedKeys)
      if (selectedKeys) {
        this.$emit("changeZzyfShow", true);
      } else {
        this.$emit("changeZzyfShow", false);
      }
    },
    getTreeList() {
      let params = {};
      apiService
        .postBusinessTypeTree(params)
        .then(r => {
          console.log(r.result);
          let data = r.result
          var list = [];
          var li = [];
          for (var i = 0; i < data.length; i++) {
            if (li.indexOf(data[i]["platformCode"]) == -1) {
              list.push({
                title: data[i]["platformName"],
                key: data[i]["platformCode"],
                children: []
              });
              li.push(data[i]["platformCode"]);
            }
          }

          for (var i = 0; i < list.length; i++) {
            for (var j = 0; j < data.length; j++) {
              if (list[i]["key"] == data[j]["platformCode"]) {
                list[i]["children"].push({
                  title: data[j]["propertyName"],
                  key: data[j]["propertyCode"],
                  children: []
                });
              }
            }
          }

          for (var i = 0; i < list.length; i++) {
            for (var j = 0; j < data.length; j++) {
              if (list[i]["key"] == data[j]["platformCode"]) {
                for (var k = 0; k < list[i]["children"].length; k++) {
                  if (
                    list[i]["children"][k]["key"] == data[j]["propertyCode"]
                  ) {
                    let newArr = []
                    newArr.push(data[j]["platformCode"])
                    newArr.push(data[j]["propertyCode"])
                    newArr.push(data[j]["investmentCode"])
                    list[i]["children"][k]["children"].push({
                      title: data[j]["investmentName"],
                      key: newArr.join(','),
                    });
                  }
                }
              }
            }
          }
          console.log(list);
          this.treeData = list
        })
        .catch();
    }
  }
};
</script>
<style>
</style>