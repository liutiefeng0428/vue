<template>
  <div class="wrap wrap-flex">
    <div class="fenlei">流程定义分类</div>
    <div class="tree-box">
      <a-tree-select
        style="width: 160px"
        :treeData="treeData"
        placeholder="请选择流程分类"
        allowClear
        :value="value"
        @change="onChange"
      ></a-tree-select>
    </div>
    <div class="list-box">
      <!-- <table-list></table-list> -->
      <div style="margin-bottom:20px;">
        <span>流程名称:</span>
        <a-input placeholder="请输入流程名称" style="width: 160px;margin-left: 5px;"></a-input>
        <!-- <span style="margin-left:10px;">标识键:</span>
        <a-input placeholder="请输入姓名" style="width: 160px;margin-left: 5px;"></a-input>
        <span style="margin-left:10px;">状态:</span>
        <a-input placeholder="请输入姓名" style="width: 160px;margin-left: 5px;"></a-input>-->
        <span style="margin-left: 15px;" class="table-page-search-submitButtons">
          <a-button type="primary" icon="search">搜索</a-button>
        </span>
      </div>
      <!-- <a-button type="primary" @click="addInfo">新增</a-button> -->
      <a-button type="primary" @click="upLoadLile">上传BPMN文件</a-button>
      <div class="table-box">
        <a-table :columns="columns" :dataSource="listData" :pagination="false" bordered>
          <a
            style="text-decoratio: none;"
            slot="operation"
            slot-scope="text, record, index"
            href="javascript:;"
            @click="editInfo(text, record, index)"
          >编辑</a>
        </a-table>
      </div>

      <div>
        <!--上传BPMN文件/新增/编辑-->
        <a-modal :title="title" :visible="visible" :closable="false" width="620px">
          <template slot="footer">
            <a-button key="back" @click="visible = false">取消</a-button>
            <a-button
              key="submit"
              type="primary"
              html-type="submit"
              v-if="biaoshi == 1"
              @click="visible = false"
            >保存</a-button>
            <a-button
              key="submit"
              type="primary"
              html-type="submit"
              v-if="biaoshi == 2"
              @click="handleUpload()"
            >上传</a-button>
            <a-button
              key="submit"
              type="primary"
              html-type="submit"
              v-if="biaoshi == 3"
              @click="visible = false"
            >保存3</a-button>
          </template>
          <div class="row_col_style">
            <a-row>
              <a-col :span="8">分 类</a-col>
              <a-col :span="16">
                <a-tree-select
                  style="width: 300px"
                  :treeData="treeData"
                  placeholder="请选择流程分类"
                  :value="value"
                  @change="onChange"
                ></a-tree-select>
              </a-col>
              <div v-if="biaoshi == 2">
                <a-col :span="8" style="border-top: 0;">流程标题</a-col>
                <a-col :span="16" style="height:42px;border-top: 0;">
                  <a-input placeholder="请输入流程标题" v-model="processTitle" style="width: 300px;" />
                </a-col>
              </div>
              <div v-if="biaoshi == 2">
                <a-col :span="8" style="border-top: 0;">上传BPMN文件</a-col>
                <a-col :span="16" style="height:42px;border-top: 0;" class="uploadSpan">
                  <a-upload
                    :fileList="fileList"
                    :remove="handleRemove"
                    :beforeUpload="beforeUpload"
                  >
                    <a-button>
                      <a-icon type="upload" />选择文件
                    </a-button>
                  </a-upload>
                </a-col>
              </div>
              <!-- 新增 strat -->
              <!-- <div v-if="biaoshi == 1">
                <a-col :span="8" style="border-top: 0;">标 题</a-col>
                <a-col :span="16" style="height:42px;border-top: 0;">
                  <a-input placeholder="请输入标题" style="width: 300px;" />
                </a-col>
              </div>-->
              <!-- 新增 end -->
              <!-- 编辑 strat -->
              <div v-if="biaoshi == 3">
                <a-col :span="8" style="border-top: 0;">标 题</a-col>
                <a-col :span="16" style="height:42px;border-top: 0;">
                  <a-input placeholder="请输入标题" v-model="editTitle" style="width: 300px;" />
                </a-col>
              </div>
              <!-- 编辑 end -->
              <!-- <div v-if="biaoshi == 2">
                <a-col :span="8" style="border-top: 0;">流程Key</a-col>
                <a-col :span="16" style="height:42px;border-top: 0;">
                  <a-input placeholder="请输入流程Key" v-model="form.processKey" style="width: 300px;" />
                </a-col>
              </div>-->
              <!-- 新增 strat -->
              <!-- <div v-if="biaoshi == 1">
                <a-col :span="8" style="border-top: 0;">标识Key</a-col>
                <a-col :span="16" style="height:42px;border-top: 0;">
                  <a-input placeholder="请输入标识Key" style="width: 300px;" />
                </a-col>
              </div>-->
              <!-- 新增 end -->
              <!-- 编辑 strat -->
              <div v-if="biaoshi == 3">
                <a-col :span="8" style="border-top: 0;">标识Key</a-col>
                <a-col :span="16" style="height:42px;border-top: 0;">
                  <a-input placeholder="请输入标识Key" v-model="editKey" style="width: 300px;" />
                </a-col>
              </div>
              <!-- 编辑 end -->
              <!-- <div v-if="biaoshi == 2">
                <a-col :span="8" style="border-top: 0;">流程描述</a-col>
                <a-col :span="16" style="height:42px;border-top: 0;">
                  <a-input placeholder="请输入流程描述" v-model="form.processText" style="width: 300px;" />
                </a-col>
              </div>-->
              <!-- 新增 strat -->
              <!-- <div v-if="biaoshi == 1">
                <a-col :span="8" style="border-top: 0;">描 述</a-col>
                <a-col :span="16" style="height:42px;border-top: 0;">
                  <a-input placeholder="请输入描述" style="width: 300px;" />
                </a-col>
              </div>-->
              <!-- 新增 end -->
              <!-- 编辑 strat -->
              <!-- <div v-if="biaoshi == 3">
                <a-col :span="8" style="border-top: 0;">描 述</a-col>
                <a-col :span="16" style="height:42px;border-top: 0;">
                  <a-input placeholder="请输入描述" style="width: 300px;" />
                </a-col>
              </div>-->
              <!-- 编辑 end -->
            </a-row>
          </div>
        </a-modal>
      </div>
    </div>
  </div>
</template>
<script>
// import tableList from './designComponents/tableList.vue' LCFL
import { apiService } from "@/services/apiservice";
import reqwest from "reqwest";
export default {
  components: {
    // tableList
  },
  data() {
    return {
      biaoshi: 1,
      title: "新增流程定义管理",
      visible: false,
      expVisible: false,
      fileList: [],
      files: null,
      value: "",
      columns: [
        {
          title: "流程名称",
          dataIndex: "processDefName",
          key: "processDefName"
        },
        {
          title: "标识Key",
          dataIndex: "defKey",
          key: "defKey"
        },
        {
          title: "版本号",
          dataIndex: "processVersion",
          key: "processVersion"
        },
        {
          title: "操作",
          key: "operation",
          dataIndex: "operation",
          scopedSlots: { customRender: "operation" }
        }
      ],
      optionDate: [],
      listData: [],
      processSort: "",
      processTitle: "",
      editTitle: "",
      editKey: ",",
      // processKey: '',
      // processText: '',
      treeData: [
        {
          title: "经营管理",
          // key: "0-0",
          value: "0-0",
          children: [
            {
              title: "自主研发",
              // key: "0-0-0",
              value: "0-0-0",
              children: [
                {
                  title: "一类",
                  // key: "0-0-0-0",
                  value: "0-0-0-0"
                },
                {
                  title: "二（A）类",
                  // key: "0-0-0-1",
                  value: "0-0-0-1"
                }
              ]
            },
            {
              title: "提升完善推广",
              // key: "0-0-1",
              value: "0-0-1"
            }
          ]
        }
      ]
    };
  },
  watch: {
    visible: {
      handler(val, old) {
        if (val == false) {
          this.processSort = "";
          this.processTitle = "";
          this.fileList = [];
        }
      },
      deep: true,
      immediate: true
    }
  },
  mounted() {
    // this.getTreeList();
    // this.getDataList();
  },
  methods: {
    // getTreeList() {
    //   let parmasData = "typeCode=LCFL";
    //   apiService
    //     .getDictionary1(parmasData)
    //     .then(
    //       r => {
    //         console.log(r);
    //         this.optionDate = r;
    //       },
    //       r => {}
    //     )
    //     .catch();
    // },
    // getDataList(typy){
    //   let params = {
    //     optionCode: typy
    //   }
    //   apiService.getProcessList(params).then(r => {
    //     console.log(r)
    //     this.listData = r
    //   }).catch()
    // },
    handleChangeDate(val) {
      console.log(val);
      this.getDataList(val);
    },
    handleChange(val) {
      console.log(val);
    },
    setVersionVisible() {
      this.expVisible = false;
    },
    addInfo() {
      this.biaoshi = 1;
      this.title = "新增流程定义管理";
      this.visible = true;
    },
    upLoadLile() {
      this.title = "上传BPMN文件";
      this.biaoshi = 2;
      this.visible = true;
      // this.expVisible = true;
    },
    editInfo(text, record, index) {
      this.biaoshi = 3;
      this.title = "编辑流程定义管理";
      console.log(record);
      this.editTitle = record.processDefName;
      this.editKey = record.defKey;
      this.visible = true;
    },
    onChange(value) {
      console.log(value);
      this.value = value;
    },
    handleUpload(file) {
      console.log(file);
      const { fileList } = this;
      const formData = new FormData();
      formData.append("file", this.files);
      formData.append("name", this.processTitle);
      formData.append("category", this.processSort);

      this.uploading = true;
      reqwest({
        url: "/project/processEngine/createUpload",
        method: "post",
        processData: false,
        data: formData,
        success: r => {
          console.log(r);
          if (r.result == "0000") {
            this.$message.success("上传成功");
            this.visible = false;
          }
        },
        error: () => {
          this.uploading = false;
          this.$message.error("上传失败");
        }
      });
    },
    handleRemove(file) {
      const index = this.fileList.indexOf(file);
      const newFileList = this.fileList.slice();
      newFileList.splice(index, 1);
      this.fileList = newFileList;
    },
    beforeUpload(file) {
      this.handleRemove(this.files); //保证只能上传一个文件
      this.files = file;
      console.log(this.files);
      this.fileList = [...this.fileList, file];
      return false;
    }
  }
};
</script>
<style>
.wrap {
  padding: 20px;
  background: #ffffff;
  margin: 10px;
  position: relative;
}
.wrap-flex {
  display: flex;
}
.fenlei {
  position: absolute;
  top: 0;
  font-size: 16px;
  padding: 8px 0 10px 0;
}
.tree-box {
  width: 200px;
  padding-top: 20px;
}
.list-box {
  flex: 1;
  margin-top: 20px;
}
.table-box {
  margin-top: 20px;
}
.row_col_style .ant-col-8 {
  padding: 10px 10px;
  border: 1px solid #eee;
  text-align: center;
}
.row_col_style .ant-col-16 {
  padding: 5px 10px 5px 10px;
  border-top: 1px solid #eee;
  border-right: 1px solid #eee;
  border-bottom: 1px solid #eee;
}
.row_col_style .ant-select-selection--single {
  height: 31px !important;
  line-height: 20px !important;
}
.row_col_style .ant-select-selection__rendered {
  line-height: 27px !important;
}
.row_col_style .uploadSpan.ant-col-16 span:first-child {
  display: flex;
  align-items: center;
}
.row_col_style .uploadSpan.ant-col-16 .ant-upload-list-item .anticon-close {
  position: absolute;
  top: 6px;
  right: 0px !important;
}
</style>