<template>
  <div class="wrap wrapSupplier">
    <span style="margin-left: 15px;">姓名:</span>
    <a-input placeholder="请输入姓名" v-model="pmName" style="width: 160px"></a-input>
    <span style="margin-left: 15px;">关键字:</span>
    <a-input placeholder="请输入关键字" v-model="identityCard" style="width: 160px"></a-input>
    <span style="margin-left: 15px;" class="table-page-search-submitButtons">
      <a-button type="primary" icon="search" @click="checkListInfos">查询</a-button>
    </span>
    <div style="margin-top:15px;">
      <a-button type="primary" @click="add">添加</a-button>
    </div>
    <div style="margin-top:15px;">
      <a-table :columns="columns" :dataSource="data" :pagination="false">
        <!-- <span slot="operation" slot-scope="text, record, index">
          <a-button type="primary" @click="checkDetails(text, record, index)">查看</a-button>
        </span> -->
        <a
          style="text-decoratio: none;"
          slot="operation"
          slot-scope="text, record, index"
          href="javascript:;"
          @click="checkDetails(text, record, index)"
        >查看</a>
      </a-table>
    </div>
    <div style="margin-top: 15px;display: flex;justify-content: center;">
      <a-pagination
        :pageSizeOptions="pageSizeOptions"
        :total="total"
        showSizeChanger
        :pageSize="pageSize"
        v-model="current"
        @change="currentChange"
        @showSizeChange="onShowSizeChange"
      >
        <template slot="buildOptionText" slot-scope="props">
          <span v-if="props.value!=='50'">{{props.value}}条/页</span>
        </template>
      </a-pagination>
    </div>
    <!-- 添加add/编辑edit 弹窗-->
    <a-modal :title="title" :visible="visible" :closable="false">
      <template slot="footer">
        <a-button v-if="biaoshi==1" key="back" @click="handleCancel">取消</a-button>
        <a-button v-if="biaoshi==1" key="submit" type="primary" html-type="submit" @click="handleOk">保存</a-button>
        <a-button v-if="biaoshi==2" key="back" @click="visible=false">确认</a-button>
      </template>
      <div>
        <a-form :form="form">
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="照片："
          >
            <a-upload
              :fileList="fileList"
              @change="handleUpload"
              :remove="handleRemove"
              :beforeUpload="beforeUpload"
              v-if="biaoshi == 1"
            >
              <a-button>
                <a-icon type="upload" />上传
              </a-button>
            </a-upload>
            <img v-if="biaoshi == 2" :src="imageUrl" alt style="width:50%;" />
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="姓名："
          >
            <a-input
              v-if="biaoshi == 1"
              id="pmName"
              placeholder="请输入姓名"
              v-model="form.pmName"
              style="width: 160px"
            />
            <span v-if="biaoshi == 2">{{checkData.pmName}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="直属领导邮箱："
          >
            <a-input
              v-if="biaoshi == 1"
              id="leaderEmail"
              placeholder="请输入直属领导邮箱"
              v-model="form.leaderEmail"
              style="width: 160px"
            />
            <span v-if="biaoshi == 2">{{checkData.leaderEmail}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="性别："
          >
            <a-select
              v-if="biaoshi == 1"
              id="sex"
              v-model="form.sex"
              defaultValue
              style="width: 160px"
            >
              <a-select-option value disabled>--请选择性别--</a-select-option>
              <a-select-option value="1">男</a-select-option>
              <a-select-option value="2">女</a-select-option>
            </a-select>
            <span v-if="biaoshi == 2">{{checkData.sex}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="手机："
          >
            <a-input
              v-if="biaoshi == 1"
              id="mobile"
              placeholder="请输入手机号"
              v-model="form.mobile"
              style="width: 160px"
            />
            <span v-if="biaoshi == 2">{{checkData.mobile}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="工作电话："
          >
            <a-input
              v-if="biaoshi == 1"
              id="tel"
              placeholder="请输入工作电话"
              v-model="form.tel"
              style="width: 160px"
            />
            <span v-if="biaoshi == 2">{{checkData.tel}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="邮箱："
          >
            <a-input
              v-if="biaoshi == 1"
              id="pmEmail"
              placeholder="请输入邮箱"
              v-model="form.pmEmail"
              style="width: 160px"
            />
            <span v-if="biaoshi == 2">{{checkData.pmEmail}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="统一身份账号："
          >
            <a-input
              v-if="biaoshi == 1"
              id="account"
              placeholder="请输入统一身份账号"
              v-model="form.account"
              style="width: 160px"
            />
            <span v-if="biaoshi == 2">{{checkData.account}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="项目权限申请说明："
          >
            <a-textarea
              v-if="biaoshi == 1"
              id="applyOpinion"
              placeholder="请输入项目权限申请说明"
              v-model="form.applyOpinion"
            />
            <span v-if="biaoshi == 2">{{checkData.applyOpinion}}</span>
          </a-form-item>
        </a-form>
      </div>
    </a-modal>
    <!-- <a-textarea placeholder="Autosize height based on content lines" autosize /> -->
  </div>
</template>
<script>
import { apiService } from "@/services/apiservice";
import reqwest from "reqwest";
function getBase64(img, callback) {
  const reader = new FileReader();
  reader.addEventListener("load", () => callback(reader.result));
  reader.readAsDataURL(img);
}
export default {
  data() {
    return {
      fileList: [],
      files: null,
      pageSizeOptions: ["10", "20", "30"],
      current: 1,
      pageSize: 10,
      total: 0,
      form: {
        pmName: "",
        leaderEmail: "",
        sex: "",
        mobile: "",
        tel: "",
        pmEmail: "",
        account: "",
        applyOpinion: ""
      },
      pmName: "",
      identityCard: "",
      loading: false,
      photoUrl: "",
      imageUrl: "",
      OssFileId: "",
      checkData: {},
      biaoshi: 1,
      title: "添加",
      visible: false,
      labelCol: {
        xs: { span: 30 },
        sm: { span: 7 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 }
      },
      columns: [
        {
          title: "姓名",
          dataIndex: "pmName",
          key: "pmName"
        },
        {
          title: "直属领导邮箱",
          dataIndex: "leaderEmail",
          key: "leaderEmail"
        },
        {
          title: "性别",
          dataIndex: "sex",
          key: "sex"
        },
        {
          title: "手机",
          key: "mobile",
          dataIndex: "mobile"
        },
        {
          title: "工作电话",
          key: "tel",
          dataIndex: "tel"
        },
        {
          title: "邮箱",
          key: "pmEmail",
          dataIndex: "pmEmail"
        },
        {
          title: "统一身份账号",
          key: "account",
          dataIndex: "account"
        },
        {
          title: "项目权限申请说明",
          key: "applyOpinion",
          dataIndex: "applyOpinion"
        },
        {
          title: "操作",
          key: "operation",
          dataIndex: "operation",
          scopedSlots: { customRender: "operation" }
        }
      ],
      data: []
    };
  },
  watch: {
    visible: {
      handler(val, old) {
        if (val == false) {
          this.form = {};
        }
      },
      deep: true
    }
  },
  mounted() {
    this.getData();
  },
  methods: {
    add() {
      this.title = "添加";
      this.biaoshi = 1;
      this.visible = !this.visible;
    },
    checkDetails(record, text, index) {
      this.title = "查看";
      this.biaoshi = 2;
      console.log(text);
      console.log(index);
      this.checkData = text;
      let params = {
        uuid : text.id
      }
      apiService.getPmDetailByUuid(params).then(r => {
        console.log(r)
        if(r.success == true){
          this.imageUrl = r.result.photoUrl
        }
      }, r => {

      }).catch()
      this.visible = true;
    },
    getData() {
      let params = {
        page: this.current,
        pmName: this.pmName,
        rows: this.pageSize
      };
      apiService
        .getSupplierManagerList(params)
        .then(
          r => {
            // console.log(r)
            if (r.success == true) {
              this.total = r.result.total;
              this.data = r.result.list;
              this.data.forEach(item => {
                if (item.sex == "2") {
                  item.sex = "男";
                } else if (item.sex == "1") {
                  item.sex = "女";
                }
              });
            }
          },
          r => {}
        )
        .catch();
    },
    checkListInfos() {
      this.current = 1;
      this.getData();
    },
    handleOk() {
      let _that = this;
      if (this.fileList.length == 0) {
        return this.$message.error("上传照片不能为空!");
      }
      let emailExg = /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,5}$/;
      let mobileExg = /^1[3456789]\d{9}$/;
      let telExg = /0\d{2,3}-\d{7,8}/;
      let idCardExg = /^(?=.*[a-zA-Z]+)(?=.*[0-9]+)[a-zA-Z0-9]+$/;
      // let idCardExg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/
      if (!this.form.pmName) {
        return this.$message.error("姓名不能为空!");
      } else if (!this.form.leaderEmail) {
        return this.$message.error("直属领导邮箱不能为空!");
      } else if (!emailExg.test(this.form.leaderEmail)) {
        return this.$message.error("直属领导邮箱格式不正确!");
      } else if (!this.form.sex) {
        return this.$message.error("性别不能为空!");
      } else if (!this.form.mobile) {
        return this.$message.error("手机号不能为空!");
      } else if (!mobileExg.test(this.form.mobile)) {
        return this.$message.error("手机号格式不正确!");
      } else if (!this.form.tel) {
        return this.$message.error("工作电话不能为空!");
      } else if (!telExg.test(this.form.tel)) {
        return this.$message.error("工作电话格式不正确!");
      } else if (!this.form.pmEmail) {
        return this.$message.error("邮箱不能为空!");
      } else if (!emailExg.test(this.form.pmEmail)) {
        return this.$message.error("邮箱格式不正确!");
      } else if (!this.form.account) {
        return this.$message.error("统一身份账号不能为空!");
      } else if (!idCardExg.test(this.form.account)) {
        return this.$message.error("统一身份账号必须包含数字和字母!");
      } else if (!this.form.applyOpinion) {
        return this.$message.error("项目权限申请说明不能为空!");
      } else {
        let param = {
          account: this.form.account,
          applyOpinion: this.form.applyOpinion,
          leaderEmail: this.form.leaderEmail,
          mobile: this.form.mobile,
          tel: this.form.tel,
          photoUrl: this.OssFileId,
          pmEmail: this.form.pmEmail,
          pmName: this.form.pmName,
          sex: this.form.sex
        };
        apiService
          .postSupplierSavePmDetail(param)
          .then(
            r => {
              if (r.code == 200) {
                this.$message.success(r.message);
                this.visible = false;
                _that.getData();
              }
            },
            r => {}
          )
          .catch();
      }
    },
    handleCancel() {
      this.visible = false;
    },
    onShowSizeChange(current, pageSize) {
      // console.log(current);
      // console.log(pageSize);
      this.pageSize = pageSize;
      this.getData();
    },
    currentChange(page, pageSize) {
      // console.log(page);
      // console.log(pageSize);
      this.current = page;
      this.getData();
    },
    handleRemove(file) {
      const index = this.fileList.indexOf(file);
      const newFileList = this.fileList.slice();
      newFileList.splice(index, 1);
      this.fileList = newFileList;
    },
    beforeUpload(file) {
      this.handleRemove(this.files); //保证只能上传一个文件
      this.files = file;
      this.fileList = [...this.fileList, file];
      return false;
    },
    handleUpload() {
      const { fileList } = this;
      const formData = new FormData();
      formData.append("file", this.files);
      formData.append("serviceName", "供应商人员");

      this.uploading = true;
      reqwest({
        url: "/project/upload/uploadPmPhoto",
        method: "post",
        processData: false,
        data: formData,
        success: r => {
          // console.log(r.OssFileId)
          // let str = r.OssFileId
          // let newstr = str.replace('*',' ')
          // this.OssFileId = newstr;
          this.OssFileId = r.result.OssFileId;
        },
        error: () => {
          this.uploading = false;
          this.$message.error("导入失败");
        }
      });
    }
    // beforeUpload(file) {
    //   const isJPG = file.type === "image/jpeg";
    //   if (!isJPG) {
    //     this.$message.error("You can only upload JPG file!");
    //   }
    //   const isLt2M = file.size / 1024 / 1024 < 2;
    //   if (!isLt2M) {
    //     this.$message.error("Image must smaller than 2MB!");
    //   }
    //   return isJPG && isLt2M;
    // }
  }
};
</script>
<style>
.wrap {
  padding: 20px;
  background: #ffffff;
  margin: 10px;
}
.ant-upload.ant-upload-select-picture-card {
  width: 80px !important;
  height: 60px !important;
  margin-bottom: 0px !important;
}
.itemForm2 {
  margin-bottom: 8px !important;
}
.itemForm1 {
  margin-bottom: 24px !important;
}
textarea.ant-input {
  min-height: 70px !important;
}
</style>