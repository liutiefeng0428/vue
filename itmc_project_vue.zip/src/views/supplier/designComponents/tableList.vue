<template>
  <div>
    <div style="margin-bottom:20px;">
      <span>流程名称:</span>
      <a-input placeholder="请输入姓名" style="width: 160px;margin-left: 5px;"></a-input>
      <span style="margin-left:10px;">标识键:</span>
      <a-input placeholder="请输入姓名" style="width: 160px;margin-left: 5px;"></a-input>
      <span style="margin-left:10px;">状态:</span>
      <a-input placeholder="请输入姓名" style="width: 160px;margin-left: 5px;"></a-input>
      <span style="margin-left: 15px;" class="table-page-search-submitButtons">
        <a-button type="primary" icon="search">搜索</a-button>
      </span>
    </div>
    <a-button type="primary" @click="addInfo">新增</a-button>
    <a-button type="primary" @click="upLoadLile">上传BPMN文件</a-button>
    <div class="table-box">
      <a-table :columns="columns" :dataSource="data" :pagination="false" bordered>
        <a
          style="text-decoratio: none;"
          slot="operation"
          slot-scope="text, record, index"
          href="javascript:;"
          @click="editInfo(text, record, index)"
        >编辑</a>
      </a-table>
    </div>
    <div style="margin-top: 15px;display: flex;justify-content: center;">
      <a-pagination
        :pageSizeOptions="pageSizeOptions"
        :total="total"
        showSizeChanger
        :pageSize="pageSize"
        v-model="current"
        @change="currentChange"
        @showSizeChange="onShowSizeChange"
      >
        <template slot="buildOptionText" slot-scope="props">
          <span v-if="props.value!=='50'">{{props.value}}条/页</span>
        </template>
      </a-pagination>
    </div>
    <div>
      <!-- 上传BPMN文件窗体 新增-->
      <a-modal :title="title" :visible="visible" :closable="false" width="620px">
        <template slot="footer">
          <a-button key="back" @click="visible = false">取消</a-button>
          <a-button key="submit" type="primary" html-type="submit" @click="visible = false">上传</a-button>
        </template>
        <div class="row_col_style">
          <a-row>
            <a-col :span="8">分 类</a-col>
            <a-col :span="16">
              <a-tree-select
                style="width: 300px"
                :dropdownStyle="{ maxHeight: '400px', overflow: 'auto' }"
                :treeData="treeData"
                placeholder="请选择分类"
                treeDefaultExpandAll
                v-model="value"
                :allowClear="true"
                @change="onChange"
              >
                <!-- <span
                style="color: #08c"
                slot="title"
                slot-scope="{key, value}"
                v-if="key='0-0-1'"
                >Child Node1 {{value}}</span>-->
              </a-tree-select>
            </a-col>
            <div v-if="biaoshi == 2">
              <a-col :span="8" style="border-top: 0;">流程标题</a-col>
              <a-col :span="16" style="height:42px;border-top: 0;">
                <a-input placeholder="请输入流程标题" style="width: 300px;" />
              </a-col>
            </div>
            <!-- 新增 strat -->
            <div v-if="biaoshi == 1">
              <a-col :span="8" style="border-top: 0;">标 题</a-col>
              <a-col :span="16" style="height:42px;border-top: 0;">
                <a-input placeholder="请输入标题" style="width: 300px;" />
              </a-col>
            </div>
            <!-- 新增 end -->
            <div v-if="biaoshi == 2">
              <a-col :span="8" style="border-top: 0;">流程Key</a-col>
              <a-col :span="16" style="height:42px;border-top: 0;">
                <a-input placeholder="请输入流程Key" style="width: 300px;" />
              </a-col>
            </div>
            <!-- 新增 strat -->
            <div v-if="biaoshi == 1">
              <a-col :span="8" style="border-top: 0;">标识Key</a-col>
              <a-col :span="16" style="height:42px;border-top: 0;">
                <a-input placeholder="请输入标识Key" style="width: 300px;" />
              </a-col>
            </div>
            <!-- 新增 end -->
            <div v-if="biaoshi == 2">
              <a-col :span="8" style="border-top: 0;">流程描述</a-col>
              <a-col :span="16" style="height:42px;border-top: 0;">
                <a-input placeholder="请输入流程描述" style="width: 300px;" />
              </a-col>
            </div>
            <!-- 新增 strat -->
            <div v-if="biaoshi == 1">
              <a-col :span="8" style="border-top: 0;">描 述</a-col>
              <a-col :span="16" style="height:42px;border-top: 0;">
                <a-input placeholder="请输入描述" style="width: 300px;" />
              </a-col>
            </div>
            <!-- 新增 end -->
            <div v-if="biaoshi == 2">
              <a-col :span="8" style="border-top: 0;">上传BPMN文件</a-col>
              <a-col :span="16" style="height:42px;border-top: 0;" class="uploadSpan">
                <a-upload
                  :fileList="fileList"
                  :remove="handleRemove"
                  :beforeUpload="beforeUpload"
                  @change="handleUpload"
                >
                  <a-button>
                    <a-icon type="upload" />选择文件
                  </a-button>
                </a-upload>
              </a-col>
            </div>
          </a-row>
        </div>
      </a-modal>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      biaoshi: 1,
      title: "新增流程定义管理",
      pageSizeOptions: ["10", "20", "30"],
      current: 1,
      pageSize: 10,
      total: 0,
      visible: false,
      fileList: [],
      value: "",
      treeData: [
        {
          title: "通用审批",
          value: "0-0",
          key: "0-0",
          children: [
            {
              title: "库存管理",
              value: "0-0-1",
              key: "0-0-1"
            },
            {
              title: "应聘面试审批",
              value: "0-0-2",
              key: "0-0-2"
            }
          ]
        },
        {
          title: "申请入职",
          value: "0-1",
          key: "0-1"
        },
        {
          title: "转正审批",
          value: "0-2",
          key: "0-2"
        },
        {
          title: "调岗申请",
          value: "0-3",
          key: "0-3"
        }
      ],
      columns: [
        {
          title: "流程名称",
          dataIndex: "name",
          key: "name"
        },
        {
          title: "标识Key",
          dataIndex: "lckey",
          key: "lckey"
        },
        {
          title: "状态",
          dataIndex: "status",
          key: "status"
        },
        {
          title: "版本号",
          dataIndex: "hao",
          key: "hao"
        },
        {
          title: "创建时间",
          dataIndex: "time",
          key: "time"
        },
        {
          title: "操作",
          key: "operation",
          dataIndex: "operation",
          scopedSlots: { customRender: "operation" }
        }
      ],
      data: [
        {
          key: "1",
          name: "流程名称123",
          lckey: "key123",
          status: "1",
          hao: "1234567890",
          time: "2019-09-20"
        }
      ]
    };
  },
  methods: {
    addInfo() {
      this.biaoshi = 1;
      this.title = "新增流程定义管理";
      this.visible = true;
    },
    upLoadLile() {
      this.biaoshi = 2;
      this.title = "上传BPMN文件";
      this.visible = true;
    },
    editInfo(text, record, index) {
      this.title = "编辑流程定义管理";
      console.log(record);
      this.visible = true;
    },
    onChange(value) {
      console.log(value);
      this.value = value;
    },
    handleUpload() {
      console.log(123);
      //   const { fileList } = this;
      //   const formData = new FormData();
      //       fileList.forEach((file) => {
      //         formData.append('files',file);
      //       })
      //   formData.append("file", this.files);
      //   formData.append("serviceName", "企业人员");

      //   this.uploading = true;
      //   reqwest({
      //     url: "/project/upload/uploadPmPhoto",
      //     method: "post",
      //     processData: false,
      //     data: formData,
      //     success: r => {
      //       // console.log(r.OssFileId);
      //       this.OssFileId = r.result.OssFileId;
      //       // this.$message.success("导入成功");
      //     },
      //     error: () => {
      //       this.uploading = false;
      //       this.$message.error("导入失败");
      //     }
      //   });
    },
    handleRemove(file) {
      const index = this.fileList.indexOf(file);
      const newFileList = this.fileList.slice();
      newFileList.splice(index, 1);
      this.fileList = newFileList;
    },
    beforeUpload(file) {
      this.handleRemove(this.files); //保证只能上传一个文件
      this.files = file;
      this.fileList = [...this.fileList, file];
      return false;
    },
    currentChange(val) {
      console.log(val);
    },
    onShowSizeChange(val, pageSize) {
      console.log(pageSize);
    }
  }
};
</script>
<style>
.table-box {
  margin-top: 20px;
}
.row_col_style .ant-col-8 {
  padding: 10px 10px;
  border: 1px solid #eee;
  text-align: center;
}
.row_col_style .ant-col-16 {
  padding: 5px 10px 5px 10px;
  border-top: 1px solid #eee;
  border-right: 1px solid #eee;
  border-bottom: 1px solid #eee;
}
.row_col_style .ant-select-selection--single {
  height: 31px !important;
  line-height: 20px !important;
}
.row_col_style .ant-select-selection__rendered {
  line-height: 27px !important;
}
.row_col_style .uploadSpan.ant-col-16 span:first-child {
  display: flex;
  align-items: center;
}
.row_col_style .uploadSpan.ant-col-16 .ant-upload-list-item .anticon-close {
  position: absolute;
  top: 6px;
  right: 0px !important;
}
</style>