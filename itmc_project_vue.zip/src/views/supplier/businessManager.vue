<template>
  <div class="wrap wrapSupplier">
    <span style="margin-left: 15px;">姓名:</span>
    <a-input placeholder="请输入姓名" v-model="pmName" style="width: 160px"></a-input>
    <span style="margin-left: 15px;">关键字:</span>
    <a-input placeholder="请输入关键字" v-model="identityCard" style="width: 160px"></a-input>
    <span style="margin-left: 15px;">板块:</span>
    <a-input placeholder="请输入姓名" v-model="plateName" style="width: 160px"></a-input>
    <span style="margin-left: 15px;">单位:</span>
    <a-input placeholder="请输入关键字" v-model="belongCompanyName" style="width: 160px"></a-input>
    <span style="margin-left: 15px;" class="table-page-search-submitButtons">
      <a-button type="primary" icon="search" @click="checkListInfos">查询</a-button>
    </span>
    <div style="margin-top:15px;">
      <a-button type="primary" @click="add">添加</a-button>
    </div>
    <div style="margin-top:15px;">
      <a-table :columns="columns" :dataSource="data" :pagination="false">
        <!-- <span slot="operation" slot-scope="text, record, index">
          <a-button type="primary" @click="checkDetails(text, record, index)">查看</a-button>
        </span> -->
        <a
          style="text-decoratio: none;"
          slot="operation"
          slot-scope="text, record, index"
          href="javascript:;"
          @click="checkDetails(text, record, index)"
        >查看</a>
      </a-table>
    </div>
    <div style="margin-top: 15px;display: flex;justify-content: center;">
      <a-pagination
        :pageSizeOptions="pageSizeOptions"
        :total="total"
        showSizeChanger
        :pageSize="pageSize"
        v-model="current"
        @change="currentChange"
        @showSizeChange="onShowSizeChange"
      >
        <template slot="buildOptionText" slot-scope="props">
          <span v-if="props.value!=='50'">{{props.value}}条/页</span>
        </template>
      </a-pagination>
    </div>
    <!-- 添加add -->
    <a-modal :title="title" :visible="visible" :closable="false">
      <template slot="footer">
        <a-button v-if="biaoshi==1" key="back" @click="handleCancel">取消</a-button>
        <a-button v-if="biaoshi==1" key="submit" type="primary" html-type="submit" @click="handleOk">保存</a-button>
        <a-button v-if="biaoshi==2" key="back" @click="visible = false">确认</a-button>
      </template>
      <div>
        <a-form :form="form">
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="照片："
          >
            <a-upload
              :fileList="fileList"
              :remove="handleRemove"
              :beforeUpload="beforeUpload"
              @change="handleUpload"
              v-if="biaoshi == 1"
            >
              <a-button>
                <a-icon type="upload" />上传
              </a-button>
            </a-upload>
            <img v-if="biaoshi == 2" :src="imageUrl" alt style="width:50%;" />
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="板块："
          >
            <a-input
              v-if="biaoshi == 1"
              id="plate"
              v-model="form.plateName"
              placeholder="请输入板块"
              style="width: 160px"
            />
            <span v-if="biaoshi == 2">{{checkData.plateName}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="单位："
          >
            <a-input
              v-if="biaoshi == 1"
              id="unit"
              v-model="form.belongCompanyName"
              placeholder="请输入单位"
              style="width: 160px"
              disabled
            />
            <span v-if="biaoshi == 2">{{checkData.belongCompanyName}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="所在部门："
          >
            <a-input
              v-if="biaoshi == 1"
              id="section"
              v-model="form.belongDeptName"
              placeholder="请输入所在部门"
              style="width: 160px"
              disabled
            />
            <span v-if="biaoshi == 2">{{checkData.belongDeptName}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="姓名："
          >
            <a-input
              v-if="biaoshi == 1"
              id="name"
              v-model="form.pmName"
              placeholder="请输入姓名"
              style="width: 160px"
            />
            <span v-if="biaoshi == 2">{{checkData.pmName}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="性别："
          >
            <a-select
              v-if="biaoshi == 1"
              id="sex"
              v-model="form.sex"
              defaultValue
              style="width: 160px"
            >
              <a-select-option value>--请选择性别--</a-select-option>
              <a-select-option value="男">男</a-select-option>
              <a-select-option value="女">女</a-select-option>
            </a-select>
            <span v-if="biaoshi == 2">{{checkData.sex}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="手机："
          >
            <a-input
              v-if="biaoshi == 1"
              id="mobile"
              v-model="form.mobile"
              placeholder="请输入手机号"
              style="width: 160px"
            />
            <span v-if="biaoshi == 2">{{checkData.mobile}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="工作电话："
          >
            <a-input
              v-if="biaoshi == 1"
              id="phone"
              v-model="form.tel"
              placeholder="请输入工作电话"
              style="width: 160px"
            />
            <span v-if="biaoshi == 2">{{checkData.tel}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="邮箱："
          >
            <a-input
              v-if="biaoshi == 1"
              id="email"
              v-model="form.pmEmail"
              placeholder="请输入邮箱"
              style="width: 160px"
            />
            <span v-if="biaoshi == 2">{{checkData.pmEmail}}</span>
          </a-form-item>
          <a-form-item
            :class="[biaoshi==1?'itemForm1':(biaoshi==2?'itemForm2':'itemForm1')]"
            :label-col="labelCol"
            :wrapper-col="wrapperCol"
            label="统一身份账号："
          >
            <a-input
              v-if="biaoshi == 1"
              id="idCard"
              v-model="form.account"
              placeholder="请输入统一身份账号"
              style="width: 160px"
            />
            <span v-if="biaoshi == 2">{{checkData.account}}</span>
          </a-form-item>
        </a-form>
      </div>
    </a-modal>
  </div>
</template>
<script>
import { apiService } from "@/services/apiservice";
import reqwest from "reqwest";
function getBase64(img, callback) {
  const reader = new FileReader();
  reader.addEventListener("load", () => callback(reader.result));
  reader.readAsDataURL(img);
}
export default {
  data() {
    return {
      fileList: [],
      files: null,
      pageSizeOptions: ["10", "20", "30"],
      current: 1,
      pageSize: 10,
      total: 0,
      form: {
        pmName: "",
        leaderEmail: "",
        sex: "",
        mobile: "",
        tel: "",
        pmEmail: "",
        account: "",
        plateName: "",
        belongCompanyName: "",
        belongDeptName: ""
      },
      pmName: "",
      identityCard: "",
      plateName: "",
      belongCompanyName: "",
      loading: false,
      photoUrl: "",
      imageUrl: '',
      OssFileId: "",
      checkData: {},
      biaoshi: 1,
      title: "添加",
      resultDan: {},
      orgId: '',
      referOrgCode: '',
      visible: false,
      labelCol: {
        xs: { span: 30 },
        sm: { span: 7 }
      },
      wrapperCol: {
        xs: { span: 24 },
        sm: { span: 12 }
      },
      columns: [
        {
          title: "板块",
          dataIndex: "plateName",
          key: "plateName"
        },
        {
          title: "单位",
          dataIndex: "belongCompanyName",
          key: "belongCompanyName"
        },
        {
          title: "所在部门",
          dataIndex: "belongDeptName",
          key: "belongDeptName"
        },
        {
          title: "姓名",
          key: "pmName",
          dataIndex: "pmName"
        },
        {
          title: "性别",
          key: "sex",
          dataIndex: "sex"
        },
        {
          title: "手机",
          key: "mobile",
          dataIndex: "mobile"
        },
        {
          title: "工作电话",
          key: "tel",
          dataIndex: "tel"
        },
        {
          title: "邮箱",
          key: "pmEmail",
          dataIndex: "pmEmail"
        },
        {
          title: "统一身份账号",
          key: "account",
          dataIndex: "account"
        },
        {
          title: "操作",
          key: "operation",
          dataIndex: "operation",
          scopedSlots: { customRender: "operation" }
        }
      ],
      data: []
    };
  },
  watch: {
    visible: {
      handler(val, old) {
        if (val == false) {
          this.form = {};
        }
      },
      deep: true
    }
  },
  mounted() {
    this.getData();
  },
  methods: {
    getData() {
      let params = {
        keyWords: this.identityCard,
        page: this.current,
        pmName: this.pmName,
        rows: this.pageSize,
        plateName: this.plateName
      };
      apiService
        .getEnterprisePMList(params)
        .then(
          r => {
            // console.log(r)
            if (r.success == true) {
              this.total = r.result.total;
              this.data = r.result.list;
            }
          },
          r => {}
        )
        .catch();
    },
    add() {
      this.title = "添加";
      this.biaoshi = 1;
      apiService.getUserInfo().then(r => {
        // console.log(r)
        if(r.success == true){
          this.form.belongCompanyName = r.result.orgName
          this.form.belongDeptName = r.result.referOrgName
          this.orgId = r.result.orgId
          this.referOrgCode = r.result.referOrgCode
        }
      }, r=> {

      }).catch()
      this.visible = !this.visible;
    },
    checkListInfos() {
      this.current = 1;
      this.getData();
    },
    checkDetails(record, text, index) {
      this.title = "查看";
      this.biaoshi = 2;
      // console.log(text);
      // console.log(index);
      this.checkData = text;
      let params = {
        uuid : text.id
      }
      apiService.getEnterprisePMByUuid(params).then(r => {
        console.log(r)
        if(r.success == true){
          this.imageUrl = r.result.photoUrl
        }
      }, r => {

      }).catch()
      this.visible = true;
    },
    handleOk() {
      if (this.fileList.length == 0) {
        return this.$message.error("上传照片不能为空!");
      }
      let emailExg = /^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,5}$/;
      let mobileExg = /^1[3456789]\d{9}$/;
      let telExg = /0\d{2,3}-\d{7,8}/;
      let idCardExg = /^(?=.*[a-zA-Z]+)(?=.*[0-9]+)[a-zA-Z0-9]+$/;
      // let idCardExg = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/
      if (!this.form.plateName) {
        return this.$message.error("板块不能为空!");
      } else if (!this.form.belongCompanyName) {
        return this.$message.error("单位不能为空!");
      } else if (!this.form.belongDeptName) {
        return this.$message.error("所在部门不能为空!");
      } else if (!this.form.pmName) {
        return this.$message.error("姓名不能为空!");
      } else if (!this.form.sex) {
        return this.$message.error("性别不能为空!");
      } else if (!this.form.mobile) {
        return this.$message.error("手机号不能为空!");
      } else if (!mobileExg.test(this.form.mobile)) {
        return this.$message.error("手机号格式不正确!");
      } else if (!this.form.tel) {
        return this.$message.error("工作电话不能为空!");
      } else if (!telExg.test(this.form.tel)) {
        return this.$message.error("工作电话格式不正确!");
      } else if (!this.form.pmEmail) {
        return this.$message.error("邮箱不能为空!");
      } else if (!emailExg.test(this.form.pmEmail)) {
        return this.$message.error("邮箱格式不正确!");
      } else if (!this.form.account) {
        return this.$message.error("统一身份账号不能为空!");
      } else if (!idCardExg.test(this.form.account)) {
        return this.$message.error("统一身份账号必须包含数字和字母!");
      } else {
          let param = {
            account: this.form.account,
            plateName: this.form.plateName,
            mobile: this.form.mobile,
            tel: this.form.tel,
            photoUrl: this.OssFileId,
            pmEmail: this.form.pmEmail,
            pmName: this.form.pmName,
            sex: this.form.sex,
            belongCompanyName: this.form.belongCompanyName,
            belongDeptName: this.form.belongDeptName,
            belongCompanyCode: this.referOrgCode,
            belongDeptCode: this.orgId
          };
          // console.log(param);
          apiService
            .postSaveEnterprisePMl(param)
            .then(
              r => {
                // console.log(r);
                // console.log(r.code);
                if (r.code == 200) {
                  this.$message.success("保存成功！");
                  this.visible = false;
                  this.getData();
                }
              },
              r => {}
            )
            .catch();
      }
    },
    handleUpload() {
      const { fileList } = this;
      const formData = new FormData();
          fileList.forEach((file) => {
            formData.append('files',file);
          })
      formData.append("file", this.files);
      formData.append("serviceName", "企业人员");

      this.uploading = true;
      reqwest({
        url: "/project/upload/uploadPmPhoto",
        method: "post",
        processData: false,
        data: formData,
        success: r => {
          // console.log(r.OssFileId);
          this.OssFileId = r.result.OssFileId;
          // this.$message.success("导入成功");
        },
        error: () => {
          this.uploading = false;
          this.$message.error("导入失败");
        }
      });
    },
    handleCancel() {
      this.visible = !this.visible;
    },
    onShowSizeChange(current, pageSize) {
      // console.log(current)
      // console.log(pageSize)
      this.pageSize = pageSize;
      this.getData();
    },
    currentChange(page, pageSize) {
      // console.log(page)
      // console.log(pageSize)
      this.current = page;
      this.getData();
    },
    handleRemove(file) {
      const index = this.fileList.indexOf(file);
      const newFileList = this.fileList.slice();
      newFileList.splice(index, 1);
      this.fileList = newFileList;
    },
    beforeUpload(file) {
      this.handleRemove(this.files); //保证只能上传一个文件
      this.files = file;
      this.fileList = [...this.fileList, file];
      return false;
    }
  }
};
</script>
<style>
.wrap {
  padding: 20px;
  background: #ffffff;
  margin: 10px;
}
.ant-upload.ant-upload-select-picture-card {
  width: 80px !important;
  height: 60px !important;
  margin-bottom: 0px !important;
}
.itemForm2 {
  margin-bottom: 8px !important;
}
.itemForm1 {
  margin-bottom: 24px !important;
}
</style>