<template>
  <div class="wrap">
     <div class="processBar">
       <span>平台：</span>
       <a-select :value="optionDateSelect" class="querySelect" @change="handleChangeDate" style="width: 120px">
         <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
       </a-select>
       <span style="margin-left: 20px">投资规模：</span>
       <a-select :value="optionDateSelect" class="querySelect" @change="handleChangeDate" style="width: 120px">
         <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
       </a-select>
     </div>
     <div>
       <a-timeline>
         <a-timeline-item color="green">
           项目启动
         </a-timeline-item>
         <a-timeline-item color="green">
           <div class="stageBox" style="height: 80px">
             <span>可研阶段</span>
             <div class="processBox">
               <div class="processBoxCon">
                 <div class="lineOrientation"></div>
                 <div class="arrow">
                   <div class="arrow-right">
                   </div>
                   <!--<div class="ant-timeline-item-head ant-timeline-item-head-blue"></div>-->
                 </div>
                 <a-timeline class="childNodeBox" style="top:-12px">
                   <a-timeline-item class="childNodeBox-content">
                     <span>可研提交</span>
                     <div class="processBox">
                       <div class="processBoxCon">
                         <div class="lineOrientation"></div>
                         <div class="arrow">
                           <div class="arrow-right">
                           </div>
                            <!--<div class="ant-timeline-item-head ant-timeline-item-head-blue"></div>-->
                         </div>
                         <div class="proSel">
                           <a-select :value="optionDateSelect" class="querySelect" @change="handleChangeDate" style="width: 120px">
                             <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
                           </a-select>
                         </div>
                       </div>
                     </div>
                     <div class="processBox" style="left:290px;">
                       <div class="processBoxCon">
                         <div class="lineOrientation"></div>
                         <div class="arrow">
                           <div class="arrow-right">
                           </div>
                           <!--<div class="ant-timeline-item-head ant-timeline-item-head-blue"></div>-->
                         </div>
                         <div class="proSel">
                           <a-select :value="optionDateSelect" class="querySelect" @change="handleChangeDate" style="width: 120px">
                             <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
                           </a-select>
                         </div>
                       </div>
                     </div>
                     <!--每个加left220px-->
                     <div class="processBox" style="left:510px;">
                       <div class="processBoxCon">
                         <div class="lineOrientation"></div>
                         <div class="arrow">
                           <div class="arrow-right">
                           </div>
                           <!--<div class="ant-timeline-item-head ant-timeline-item-head-blue"></div>-->
                         </div>
                         <div class="proSel">
                           <a-select :value="optionDateSelect" class="querySelect" @change="handleChangeDate" style="width: 120px">
                             <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
                           </a-select>
                         </div>
                       </div>
                     </div>
                   </a-timeline-item>
                   <a-timeline-item class="childNodeBox-content">
                     <span> 可研预审</span>
                     <div class="processBox">
                       <div class="processBoxCon">
                         <div class="lineOrientation"></div>
                         <div class="arrow">
                           <div class="arrow-right">
                           </div>
                            <!--<div class="ant-timeline-item-head ant-timeline-item-head-blue"></div>-->
                         </div>
                         <div class="proSel">
                           <a-select :value="optionDateSelect" class="querySelect" @change="handleChangeDate" style="width: 120px">
                             <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
                           </a-select>
                         </div>
                       </div>
                     </div>
                     <!-- 计算公式第2个 220*1+70-->
                     <div class="processBox" style="left:290px">
                       <div class="processBoxCon">
                         <div class="lineOrientation"></div>
                         <div class="arrow">
                           <div class="arrow-right">
                           </div>
                            <!--<div class="ant-timeline-item-head ant-timeline-item-head-blue"></div>-->
                         </div>
                         <div class="proSel">
                           <a-select :value="optionDateSelect" class="querySelect" @change="handleChangeDate" style="width: 120px">
                             <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
                           </a-select>
                         </div>
                       </div>
                     </div>
                   </a-timeline-item>
                 </a-timeline>
               </div>
             </div>

           </div>
         </a-timeline-item>
         <a-timeline-item color="red">
           项目实施
         </a-timeline-item>
         <a-timeline-item>
           项目商务
         </a-timeline-item>
         <a-timeline-item class="stageBox">
           <span>项目验收</span>
           <div class="processBox">
             <div class="processBoxCon">
               <div class="lineOrientation"></div>
               <div class="arrow">
                 <div class="arrow-right">
                 </div>
               </div>
               <!--子流程top:-12px取决子流程个数-->
               <a-timeline class="childNodeBox" style="right: -20px;top: 7px;">
               <a-timeline-item class="childNodeBox-content">
                 <span>可研验收</span>
                 <div class="processBox">
                   <div class="processBoxCon">
                     <div class="lineOrientation"></div>
                     <div class="arrow">
                       <div class="arrow-right">
                       </div>
                        <!--<div class="ant-timeline-item-head ant-timeline-item-head-blue"></div>-->
                     </div>
                     <div class="proSel">
                       <a-select :value="optionDateSelect" class="querySelect" @change="handleChangeDate" style="width: 120px">
                         <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
                       </a-select>
                     </div>
                   </div>
                 </div>
                 <!-- 计算公式第2个 220*1+70-->
                 <div class="processBox" style="left:290px">
                   <div class="processBoxCon">
                     <div class="lineOrientation"></div>
                     <div class="arrow">
                       <div class="arrow-right">
                       </div>
                        <!--<div class="ant-timeline-item-head ant-timeline-item-head-blue"></div>-->
                     </div>
                     <div class="proSel">
                       <a-select :value="optionDateSelect" class="querySelect" @change="handleChangeDate" style="width: 120px">
                         <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
                       </a-select>
                     </div>
                   </div>
                 </div>
               </a-timeline-item>
             </a-timeline>
           </div>
         </div>
         </a-timeline-item>
       </a-timeline>
     </div>
  </div>
</template>
<script>

  export default {
    name: "Kyprocess",
    components: {
    },
    data () {
      return {
        optionDate: [{optionName:"11",optionCode:"1"},{optionName:"234",optionCode:"2"}],
        optionDateSelect: '流程',
      }
    },
    created () {

    },
    methods: {
      handleChangeDate(value){

      },
    },
    watch: {

    },
    mounted(){

    }
  }


</script>
<style>
.stageBox{
  position:relative;
  width: 170px;
}
.childNodeBox{
  position: absolute;
  top:0;
  right: 0;
}
.lineOrientation{
  position: absolute;
  left: 10px;
  top: 0.75em;
  width: 70px;
  border-top: 1px solid #e8e8e8;
}
.arrow-right{
  width:7px;
  height:7px;
  border-bottom:2px solid #e8e8e8;
  border-right:2px solid #e8e8e8;
  border-top:2px solid transparent;
  border-left:2px solid transparent;
  transform:rotate(-45deg);
}
.childNodeBox-content{
  position: relative;
}
.processBox{
  position: absolute;
  left: 70px;
  top: 0;
  width: 100%;
}
.processBoxCon{
  position: relative;
}

.arrow{
  left: 74px;
  position: absolute;
  top: 8px;
}
.arrow-right{

}
.proSel{
  position: absolute;
  left: 100px;
}
.processBar{
  margin-bottom: 40px;
}
</style>
