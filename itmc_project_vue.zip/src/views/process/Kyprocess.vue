<template>
  <div class="wrap">
    <!--<div class="con-title">-->
      <!--<span>{{projectName}}</span>-->
    <!--</div>-->
    <div class="con-head">
      <span>流程节点:</span>
      <a-select v-model="taskNodeName" class="querySelect" @change="onTaskNode" style="width: 120px">
        <a-select-option v-for="item in taskDodeList" :key="item.id"> {{item.name}}</a-select-option>
      </a-select>
      
    </div>

    <div class="container" style="padding: 0">
      <div class="define-table">
        <div class="table-head" style=" border-left: 1px solid #ccc;">
          <div class="table-item"  style="display: flex;align-items: center">自定义审批按钮</div>
          <div class="table-item" style="display: flex;align-items: center">限时确认时间</div>
          <div class="table-item" style="display: flex;align-items: center">审核人</div>
          <!--<div class="table-item">通知人</div>-->

        </div>
        <div class="tbl-rt" style="border-right: 1px solid #ccc;border-right: 1px solid #ccc;">
          <div class="table-rt">
            <div class="table-body">
              <div class="table-item">
                <!--<a-select :value=bureausSel class="querySelect"  style="width:100%">-->
                <a-checkbox :checked = "btnApprove == 0" @change="onBtnApprove"  >审核</a-checkbox>
                <a-checkbox :checked = "btnTransfer == 0" @change="onBtnTransfer" >转办</a-checkbox>
                <a-checkbox :checked = "btnReject == 0" @change="onBtnReject">驳回</a-checkbox>
              </div>
              <div class="table-item">
                <input type="number" v-model="time" class="qymoneyAmout ant-input" placeholder="天数" style="margin: -5px 0px;">
              </div>
              <div class="table-item" style="display: flex;align-items: center">
                <a-select
                  mode="tags"
                  style="width: 100%"
                  v-model="reviwer"
                  @change="handleChange"
                  placeholder="请选择可提交办理人"
                >
                  <a-select-option v-for="item in reviewerList" :key="item.reviewerId">{{item.reviewerName}}</a-select-option>
                </a-select>
              </div>
<!--              <div class="table-item">
                <a-select :value=projectTypeSel  class="querySelect" @change="handleChangeType" style="width:100%">
                  <a-select-option v-for="item in projectType" :key="item.code"> {{item.name}}</a-select-option>
                </a-select>
              </div>-->
            </div>
            <div class="table-head">
              <div class="table-item"  style="display: flex;align-items: center">是否通知</div>
              <div class="table-item" style="display: flex;align-items: center">驳回配置</div>
              <div class="table-item" style="display: flex;align-items: center"></div>
              <!--<div class="table-item" style="display: flex;align-items: center"></div>-->
            </div>
            <div class="table-body">
              <div class="table-item" >
                <a-checkbox :checked = "mailNotice == 0" @change="onMailNotice">邮件通知</a-checkbox>
              </div>
              <div class="table-item" style="display: flex;align-items: center">
                <a-checkbox :checked = "originateNode == 0" @change="onOriginateNode">驳回(发起人)</a-checkbox>
                <a-checkbox :checked = "directionNode == 0" @change="onDirectionNode">驳回(指定节点)</a-checkbox>
                <a-checkbox :checked = "lastNode == 0" @change="onLastNode">驳回(上一节点)</a-checkbox>
              </div>
              <div class="table-item"></div>
              <!--<div class="table-item"></div>-->
            </div>

          </div>
        </div>
      </div>

      <!--<div>-->
        <!--<div>-->
          <!--<div class="ant-table">-->
            <!--<table >-->
              <!--<tbody class="ant-table-tbody">-->
              <!--<tr>-->
                <!--<th class="k50">自定义审批按钮</th>-->
                <!--<th class="k250">111</th>-->
                <!--<th class="k50">超时时间</th>-->
                <!--<th class="k250">111</th>-->
                <!--&lt;!&ndash;<th class="k250">各处预算</th>　　　　&ndash;&gt;-->
                <!--&lt;!&ndash;<th class="k250">优化预算</th>　　　　&ndash;&gt;-->
              <!--</tr>-->
              <!--<tr>-->
                <!--<th class="k50">审批人</th>-->
                <!--<th class="k250">111</th>-->
                <!--<th class="k50">是否通知</th>-->
                <!--<th class="k250">111</th>-->
                <!--&lt;!&ndash;<th class="k250">各处预算</th>　　　　&ndash;&gt;-->
                <!--&lt;!&ndash;<th class="k250">优化预算</th>　　　　&ndash;&gt;-->
              <!--</tr>-->
              <!--</tbody>-->
            <!--</table>-->
          <!--</div>-->
        <!--</div>-->
      <!--</div>-->
    </div>
    <div class="container" style="text-align: right;margin-top: 5px;">

    </div>
    <div class="container" style="text-align: center;margin-top: 20px">
      <div>
        <!--<a-button v-if="flag==0" type="primary" @click="saveEdit()">保存</a-button>-->
        <a-button type="primary" @click="saveAdd()">保存</a-button>
        <a-button @click="goBack()">返回</a-button>
      </div>
    </div>
  </div>
</template>
<script>
  import {apiService} from "@/services/apiservice";
  export default {
    name: "Kyprocess",
    components: {
    },
    data () {
      return {
        processDefId: '',//流程ID
        taskNodeName: '',
        reviwer: '',//人员
        btnApprove: '1',//审核
        btnReject: '1',//驳回
        btnTransfer: '1',//转办
        lastNode: '1',//上一节点
        directionNode: '1',//指定节点
        originateNode: '1',//发起节点
        mailNotice: '1',//邮件通知
        time: '',//天数
        taskDodeList: [],//流程任務列表
        reviewerList: [],//审核人列表
        optionDate: [{optionName:"11",optionCode:"1"},{optionName:"234",optionCode:"2"}],
        optionDateSelect: '流程',
        processArray:[{tabName:"可研阶段",children:[{title:"可研提交",children:[{name:"表单1"},{name:"表单2"},{name:"表单3"},{name:"表单2"},{name:"表单3"}]},{title:"可研预审",children:[{name:"表单11"},{name:"表单12"}]}]}],
        modalVisible:false,
      }
    },
    created () {
      this.loadMsg();
      this.getTaskDodeList();
    },
    methods: {
      //按钮选择
      onChange (e) {
        console.log(`checked = ${e.target.checked}`)
      },
      //审核按钮选择
      onBtnApprove (e) {
        if(e.target.checked){
          this.btnApprove="0";
        }else{
          this.btnApprove="1";
        }
      },
      //驳回按钮选择
      onBtnReject (e) {
        if(e.target.checked){
          this.btnReject="0";
        }else{
          this.btnReject="1";
        }
      },
      //转办按钮选择
      onBtnTransfer (e) {
        if(e.target.checked){
          this.btnTransfer="0";
        }else{
          this.btnTransfer="1";
        }
      },
      //驳回（发起节点）
      onOriginateNode (e) {
        if(e.target.checked){
          this.originateNode="0";
        }else{
          this.originateNode="1";
        }
      },
      //驳回（指定节点）
      onDirectionNode (e) {
        if(e.target.checked){
          this.directionNode="0";
        }else{
          this.directionNode="1";
        }
      },
      //驳回（上一节点）
      onLastNode (e) {
        if(e.target.checked){
          this.lastNode="0";
        }else{
          this.lastNode="1";
        }
      },
      //是否邮件通知
      onMailNotice (e) {
        if(e.target.checked){
          this.mailNotice="0";
        }else{
          this.mailNotice="1";
        }
      },
      //选择办理人
      handleChange(value) {
        console.log("value:"+value);
      },
      loadMsg(){
        this.processDefId=this.$route.query.processDefId;
      },
      getTaskDodeList(){
        const _self=this;
        let parmasData={processDefId:_self.processDefId}
        apiService.getTaskDodeList(parmasData).then(r => {

          _self.taskDodeList=r.userTaskList;
          this.taskNodeName = _self.taskDodeList[0].id;
        }, r => {
        }).catch(
        )
      },
      getProcessNodeConfiguration(parmasData){
        apiService.getProcessNodeConfiguration(parmasData).then(r => {

          if(r.hasOwnProperty("btnApprove")){
            this.btnApprove=r.btnApprove;
          }else{
            this.btnApprove="1";
          }
          if(r.hasOwnProperty("btnTransfer")){
            this.btnTransfer=r.btnTransfer;
          }else{
            this.btnTransfer="1";
          }
          if(r.hasOwnProperty("btnReject")){
            this.btnReject=r.btnReject;
          }else{
            this.btnReject="1";
          }
          if(r.hasOwnProperty("lastNode")){
            this.lastNode=r.lastNode;
          }else{
            this.lastNode="1";
          }
          if(r.hasOwnProperty("directionNode")){
            this.directionNode=r.directionNode;
          }else{
            this.directionNode="1";
          }
          if(r.hasOwnProperty("originateNode")){
            this.originateNode=r.originateNode;
          }else{
            this.originateNode="1";
          }
          if(r.hasOwnProperty("mailNotice")){
            this.mailNotice=r.mailNotice;
          }else{
            this.mailNotice="1";
          }
          if(r.hasOwnProperty("time")){
            this.time=r.time;
          }else{
            this.time="0";
          }
          this.reviewerList=r.actNodeAuditorList;
          // this.reviwer="1";

          // console.log(">>>"+r);
          // _self.projectDetailsList=r
          // _self.taskDodeList=r.userTaskList;

        }, r => {
        }).catch(
        )
      },
      onTaskNode(value){
        var _self = this;
        this.taskNodeName=value;

        let parmasData={procDefKey:_self.processDefId,"nodeId":this.taskNodeName}
        _self.getProcessNodeConfiguration(parmasData);

      },
      handleChangeDate(value){

      },
      addProcess(){
          this.modalVisible=true
      },
      setModal1Visible(){
        this.modalVisible=false
      },
      saveAdd(){
        const _self=this;
        var key = this.processDefId.split(":")[0];
        let parmasData={list:[{nodeId:this.taskNodeName,procDefKey:key,parameterName:"time",ifComplaint:this.time},
          {nodeId:this.taskNodeName,procDefKey:key,parameterName:"mailNotice",ifComplaint:this.mailNotice},
          {nodeId:this.taskNodeName,procDefKey:key,parameterName:"originateNode",ifComplaint:this.originateNode},
          {nodeId:this.taskNodeName,procDefKey:key,parameterName:"directionNode",ifComplaint:this.directionNode},
          {nodeId:this.taskNodeName,procDefKey:key,parameterName:"lastNode",ifComplaint:this.lastNode},
          {nodeId:this.taskNodeName,procDefKey:key,parameterName:"btnReject",ifComplaint:this.btnReject},
          {nodeId:this.taskNodeName,procDefKey:key,parameterName:"btnTransfer",ifComplaint:this.btnTransfer},
          {nodeId:this.taskNodeName,procDefKey:key,parameterName:"btnApprove",ifComplaint:this.btnApprove}],
          reviwer:this.reviwer
        };
        apiService.saveProcessConfiguration(parmasData).then(r => {
          if(r.result=='0000'){
            this.$message.success("保存成功！")
          }else{
            this.$message.error("保存失败！")
          }

        }, r => {
        }).catch(
        )
      },
      goBack(){
        this.$router.go(-1);
      }
    },
    watch: {

    },
    mounted(){

    }
  }


</script>
<style>
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    bottom: 0;
    right: 25px;
  }

  .define-table, .table-rt {
    display: flex;
  }

  .define-table {
    border-top: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
  }

  .tbl-rt {
    flex: 7;
  }

  .table-head {
    flex: 1;
  }

  .table-body {
    flex: 2;
  }

  .table-item {
    border-right: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
    padding: 10px;
    color: rgba(0, 0, 0, 0.65);
    height: 45px;
    box-sizing: border-box;
    justify-content: center;
    align-items: center;
    text-align: center;
    display: flex;
  }

  .table-head {
    background: #fafafa;
  }

  .table-item input {
    width: 100%;
    height: 100%;
    outline: none;
  }

  .table-head textarea {
    width: 100%;
    height: 70px;
    padding: 10px;
    border: none;
    outline: none;
  }
  .container{
    padding: 0 15px;
  }
  .qymoneyAmout{
    text-align: center;
  }


  #detailTable {
    width: 100%;
    background: #fff;
    text-align: center;
    border-top: 1px solid #e8e8e8;
    border-left: 1px solid #e8e8e8;
    table-layout: fixed;
  }
  #detailTable tr th,#detailTable tr td{
    font-size: 12px;
    text-align: center;
    padding: 0 0 0 3px !important;

  }
  #detailTable td .ant-input{
    font-size: 12px;
    padding: 4px 2px;
  }
</style>
