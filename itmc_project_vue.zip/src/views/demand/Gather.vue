<template>
  <div>
    <a-card :bordered="false">
      <div class="table-page-search-wrapper">
        <a-form layout="inline">
          <div>
            <a-form-item label="年份">
              <a-select
                :size="size"
                :defaultValue=optionDate[0].optionName
                style="width: 200px"
                @change="handleChangeDate"
                v-model="optionDateSelect"
              >
                <a-select-option v-for="item in optionDate" :key="item.optionCode" :value="item.optionCode">
                  {{item.optionName}}
                </a-select-option>
              </a-select>
            </a-form-item>
            <a-form-item label="上报单位">
              <a-select
                treeCheckable
                mode="multiple"
                :size="size"
                placeholder="请选择上报单位"
                :defaultValue="[]"
                style="width: 200px"
                @change="handleChange"
                @popupScroll="popupScroll"
              >
                <a-select-option v-for="item in optionDepartment" :key="item.orgCode">
                  {{item.orgName}}
                </a-select-option>
              </a-select>
            </a-form-item>
            <a-form-item label="关键字搜索">
              <a-input placeholder="请输入关键字" v-model="keyWords"/>
            </a-form-item>
          </div>
          <div style="margin:16px 0;">
            <span class="table-page-search-submitButtons">
              <a-button type="primary" @click="doCheck">查询</a-button>
            </span>
            <button @click="exportQyxq()" data-v-227ef8f8="" type="button" class="ant-btn ant-btn-primary">
              <i class="anticon anticon-import">
                <svg viewBox="64 64 896 896" data-icon="plus" width="1em" height="1em" fill="currentColor"
                     aria-hidden="true" class="">
                  <path d="M482 152h60q8 0 8 8v704q0 8-8 8h-60q-8 0-8-8V160q0-8 8-8z"></path>
                  <path d="M176 474h672q8 0 8 8v60q0 8-8 8H176q-8 0-8-8v-60q0-8 8-8z"></path>
                </svg>
              </i>
              <span>导出</span>
            </button>
          </div>
        </a-form>
      </div>
    </a-card>
    <!--表格-->
    <div style="padding: 0px 32px;background: #fff">
      <div class="ant-alert ant-alert-info" style="display: flex">
        <span style="flex: 1">信息化应用需求</span>
        <span style="text-align: right;flex: 1;">总投资额度合计：<span> {{xxmmSum}} </span>万元</span>
      </div>
    </div>
    <div id="contractWrap">
      <div style="background: #fff; padding: 0px 32px;">
        <a-table bordered :columns="columns" :dataSource="infoData.list" :pagination="{ pageSize: pageSize }">
          <a slot="action" slot-scope="text, record, index" href="javascript:;">
            <a @click="doDetail(record,text,index)">查看详情</a>
          </a>
        </a-table>
      </div>
    </div>
    <!--表格-->
    <div style="padding: 0px 32px;background: #fff">
      <div class="ant-alert ant-alert-info" style="display: flex">
        <span style="flex: 1">基础设施和信息安全需求</span>
        <span style="text-align: right;flex: 1;">总投资额度合计：<span> {{xxmmSumBase}} </span>万元</span>
      </div>
    </div>
    <div>
      <div style="background: #fff; padding: 0px 32px;">
        <a-table bordered :columns="columnsBase" :dataSource="infoDataBase.list" :pagination="{ pageSize: pageSizeBase }">
          <a slot="actionBase" slot-scope="text, record, index" href="javascript:;">
            <a @click="doDetailBase(record,text,index)">查看详情</a>
          </a>
        </a-table>
      </div>
    </div>
    <a-modal
      title="查看信息化建设与应用需求"
      :width="700"
      centered
      v-model="modalVisible"
      @ok="() => setModal1Visible(false)"
      @cancel="() => setModal1Visible(false)"
      okText="确认"
      cancelText="关闭"
    >
      <div>
        <a-form-item
          label="项目名称"
          style="margin-bottom: 0"
        >
          <a-radio :defaultChecked="true" :disabled="true">信息化应用需求</a-radio>
          <a-radio :defaultChecked="false" :disabled="true">基础设施和信息安全需求</a-radio>
        </a-form-item>
        <a-form-item
          label="项目名称"
          style="margin-bottom: 0"
        >
          <a-input v-model="modalRecodes.projectName"
            :disabled="true"
            placeholder="Please input your name"
          />
        </a-form-item>
        <a-form-item
          label="项目年限"
          style="margin-bottom: 0"
        >
          <a-input v-model="modalRecodes.projectStarYear"
                   :disabled="true"
                   style="width: 80px"
          />
          -
           <a-input v-model="modalRecodes.projectEndYear"
                    :disabled="true"
                    style="width: 80px"
         />
        </a-form-item>
        <a-form-item
          label="现状及需求"
          style="margin-bottom: 0"
        >
          <a-textarea v-model="modalRecodes.projectDemand"
                   :disabled="true"
          />
        </a-form-item>
        <a-form-item
          label="建设目标和主要内容"
          style="margin-bottom: 0"
        >
          <a-textarea v-model="modalRecodes.projectTarget"
                      :disabled="true"
          />
        </a-form-item>
        <a-form-item
          label="投资总估算"
          style="margin-bottom: 0"
        >
          <a-input v-model="modalRecodes.projectInvestSum"
                   :disabled="true"
          />
        </a-form-item>
        <a-form-item
          label="备注"
          style="margin-bottom: 0"
        >
          <a-textarea v-model="modalRecodes.note"
                      :disabled="true"
          />
        </a-form-item>
       </div>
    </a-modal>

  </div>
</template>

<script>

  const  dataSource=[
    {
      "uuid": "0ac4150587464b89aa8abf5443cd33fd",
      "contractId": "2f08c943-90ec-4792-b3c4-b1338fa40ef5",
      "projectId": "588e7a0b59764efca2f0ee396a876fac",
      "contractState": null,
      "purchaseId": "",
      "projectName": "测试项目0426-01_股份总部",
      "contractName": "采购合同-测试项目0426-01_股份总部",
      "contractType": "0101",
      "contractCode": "G11-MM-2019-357",
      "partyA": "中国石油化工股份有限公司信息化管理部",
      "partyB": "石化盈科信息技术有限责任公司",
      "partyC": null,
      "contractYeartype": "2019",
      "contractTaxAmount": 7,
      "contractNotTaxAmount": 6.03,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-26 11:32:12",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    },
    {
      "uuid": "044f9dd2913f4216b199df997cbb87ee",
      "contractId": "72ba569d-cfe3-43b5-aa58-909fdace9571",
      "projectId": "588e7a0b59764efca2f0ee396a876fac",
      "contractState": null,
      "purchaseId": "",
      "projectName": "测试项目0426-01_股份总部",
      "contractName": "采购合同-测试项目0426-01_股份总部",
      "contractType": "0101",
      "contractCode": "G11-MM-2019-356",
      "partyA": "中国石油化工股份有限公司信息化管理部",
      "partyB": "石化盈科信息技术有限责任公司",
      "partyC": null,
      "contractYeartype": "2019",
      "contractTaxAmount": 3,
      "contractNotTaxAmount": 2.59,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-26 10:55:17",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    },
    {
      "uuid": "fb263134b6514adeb574819827b6f3e1",
      "contractId": "074b3c0e-4ae7-4db2-9c76-5ffe2043c757",
      "projectId": "5dfb351a0bcc4cd6a9ae21b87c67f761",
      "contractState": null,
      "purchaseId": "",
      "projectName": "形象进度测试004_集团总部",
      "contractName": "采购合同-形象进度测试004_集团总部",
      "contractType": "0101",
      "contractCode": "GG-11-MM-2019-354",
      "partyA": "中国石油化工集团公司信息化管理部",
      "partyB": "上海众达信息产业有限公司",
      "partyC": "",
      "contractYeartype": "2019",
      "contractTaxAmount": 0,
      "contractNotTaxAmount": 0,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-24 15:32:24",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    },
    {
      "uuid": "17d76fdd75ae48138940e8b00b7fb646",
      "contractId": "f9289d35-8bc1-4855-9b14-ec4bdf0716b2",
      "projectId": "2f0902c8576947099340d1efb77fea75",
      "contractState": null,
      "purchaseId": "",
      "projectName": "形象进度测试004_股份总部",
      "contractName": "采购合同-形象进度测试004_股份总部",
      "contractType": "0101",
      "contractCode": "GG-11-MM-2019-353",
      "partyA": "中国石油化工股份有限公司信息化管理部",
      "partyB": "上海众达信息产业有限公司",
      "partyC": "",
      "contractYeartype": "2019",
      "contractTaxAmount": 0,
      "contractNotTaxAmount": 0,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-24 15:32:05",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    },
    {
      "uuid": "3339876e95e04ea0914e019758da4c63",
      "contractId": "6cefcb5a-c2e6-4793-9b39-7efef3cece74",
      "projectId": "76c8d60cdfd9432abcd8adf3e558f349",
      "contractState": null,
      "purchaseId": "",
      "projectName": "形象进度测试003_集团总部",
      "contractName": "采购合同-形象进度测试003_集团总部",
      "contractType": "0101",
      "contractCode": "GG-11-MM-2019-352",
      "partyA": "中国石油化工集团公司信息化管理部",
      "partyB": "石化盈科信息技术有限责任公司",
      "partyC": null,
      "contractYeartype": "2019",
      "contractTaxAmount": 1800,
      "contractNotTaxAmount": 1551.72,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-23 17:50:23",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    }
  ];
  const data = [];
  for (let i = 0; i < dataSource.length; i++) {
    data.push({
      key: i,
      name: dataSource[i].contractName,
      amount:dataSource[i].contractNotTaxAmount,
      contractCode:dataSource[i].contractCode,
      partyA:dataSource[i].partyA,
//      contractCode: `London Park no. ${i}`,
    });
  }


  import { TreeSelect } from 'ant-design-vue'
  const SHOW_PARENT = TreeSelect.SHOW_PARENT
  import {apiService} from "@/services/apiservice";
  import ATextarea from "ant-design-vue/es/input/TextArea";
  export default {
    name: "Gather",
    components: {
      ATextarea
      //  STable,
    },
    data () {
      return {
        optionDate:[ ],
        optionDateSelect:'',
        keyWords:'',
        orgCodes:'',
        infoData:[],
        pageSize:10,
        columns:[],
        infoDataBase:[],
        pageSizeBase:10,
        columnsBase:[],
        xxmmSum:'0.00',
        xxmmSumBase:'0.00',
        modalVisible: false,
        modalRecodes:{
            projectName:'',
            projectDemand:'',
            projectInvestSum:'',
            projectTarget:'',
            projectStarYear:'',
            projectEndYear:'',
            note:''
        },
        optionDepartment:[
          {
            "orgId": "f608f2239d9c682807221cc6151cf8c5",
            "parentId": "81d4f4858ee77de60d875771e8fd4204",
            "oldParentId": "",
            "parentOrgName": "",
            "parentIdAndCode": "",
            "parentCode": "",
            "orgTypeId": "85afbf6b189e489fbe9b666fe19fb1ff",
            "orgLevelId": "5f45d373458a48d6988ecd94669e12ac",
            "orgLevelName": "",
            "positionId": "",
            "positionCode": "",
            "positionDesc": "",
            "positionIdAndCode": "",
            "appId": "116",
            "orgCode": "ORG000002",
            "orgIdAndOrgCode": "",
            "orgName": "油田企业",
            "shortName": "",
            "fullName": "信息化业务组织中国石油化工集团公司油田企业",
            "orgLevelCode": "",
            "orgTypeCode": "",
            "orgTypeName": "",
            "address": "",
            "email": "",
            "phone": "",
            "zipCode": "",
            "fax": "",
            "contact": "",
            "hasChild": 1,
            "isUsed": 0,
            "arrayParentId": "[f608f2239d9c682807221cc6151cf8c5][81d4f4858ee77de60d875771e8fd4204]",
            "arrayParentCode": "[ORG000002][ORG000001]",
            "remark": "",
            "orderNum": 10,
            "delFlag": 0,
            "createTime": 1506009600000,
            "createUserId": 1001818,
            "createUserAccount": "",
            "createUserName": "超级管理员",
            "updateTime": 1520784000000,
            "updateUserId": 1001818,
            "updateUserAccount": "admin",
            "updateUserName": "超级管理员",
            "reserve1": "",
            "reserve2": "",
            "enterCode": "",
            "enterName": "",
            "start": 0,
            "limit": 0
          },
          {
            "orgId": "a05d55b449cc44b50b3ecbf9a41e1169",
            "parentId": "81d4f4858ee77de60d875771e8fd4204",
            "oldParentId": "",
            "parentOrgName": "",
            "parentIdAndCode": "",
            "parentCode": "",
            "orgTypeId": "85afbf6b189e489fbe9b666fe19fb1ff",
            "orgLevelId": "5f45d373458a48d6988ecd94669e12ac",
            "orgLevelName": "",
            "positionId": "",
            "positionCode": "",
            "positionDesc": "",
            "positionIdAndCode": "",
            "appId": "116",
            "orgCode": "ORG000003",
            "orgIdAndOrgCode": "",
            "orgName": "炼化企业",
            "shortName": "",
            "fullName": "信息化业务组织中国石油化工集团公司炼化企业",
            "orgLevelCode": "",
            "orgTypeCode": "",
            "orgTypeName": "",
            "address": "",
            "email": "",
            "phone": "",
            "zipCode": "",
            "fax": "",
            "contact": "",
            "hasChild": 1,
            "isUsed": 0,
            "arrayParentId": "[a05d55b449cc44b50b3ecbf9a41e1169][81d4f4858ee77de60d875771e8fd4204]",
            "arrayParentCode": "[ORG000003][ORG000001]",
            "remark": "",
            "orderNum": 20,
            "delFlag": 0,
            "createTime": 1506009600000,
            "createUserId": 1001818,
            "createUserAccount": "",
            "createUserName": "超级管理员",
            "updateTime": 1520784000000,
            "updateUserId": 1001818,
            "updateUserAccount": "admin",
            "updateUserName": "超级管理员",
            "reserve1": "",
            "reserve2": "",
            "enterCode": "",
            "enterName": "",
            "start": 0,
            "limit": 0
          },
          {
            "orgId": "ff35b8a6bb2bb073bd0c9c6ec5126a7b",
            "parentId": "81d4f4858ee77de60d875771e8fd4204",
            "oldParentId": "",
            "parentOrgName": "",
            "parentIdAndCode": "",
            "parentCode": "",
            "orgTypeId": "85afbf6b189e489fbe9b666fe19fb1ff",
            "orgLevelId": "5f45d373458a48d6988ecd94669e12ac",
            "orgLevelName": "",
            "positionId": "",
            "positionCode": "",
            "positionDesc": "",
            "positionIdAndCode": "",
            "appId": "116",
            "orgCode": "ORG000006",
            "orgIdAndOrgCode": "",
            "orgName": "炼化工程企业",
            "shortName": "",
            "fullName": "信息化业务组织中国石油化工集团公司炼化工程企业",
            "orgLevelCode": "",
            "orgTypeCode": "",
            "orgTypeName": "",
            "address": "",
            "email": "",
            "phone": "",
            "zipCode": "",
            "fax": "",
            "contact": "",
            "hasChild": 1,
            "isUsed": 0,
            "arrayParentId": "[ff35b8a6bb2bb073bd0c9c6ec5126a7b][81d4f4858ee77de60d875771e8fd4204]",
            "arrayParentCode": "[ORG000006][ORG000001]",
            "remark": "",
            "orderNum": 50,
            "delFlag": 0,
            "createTime": 1506009600000,
            "createUserId": 1001818,
            "createUserAccount": "",
            "createUserName": "超级管理员",
            "updateTime": 1520784000000,
            "updateUserId": 1001818,
            "updateUserAccount": "admin",
            "updateUserName": "超级管理员",
            "reserve1": "",
            "reserve2": "",
            "enterCode": "",
            "enterName": "",
            "start": 0,
            "limit": 0
          },
          {
            "orgId": "c4fc0f9c582f2490a51d41bf2c2b5fd0",
            "parentId": "81d4f4858ee77de60d875771e8fd4204",
            "oldParentId": "",
            "parentOrgName": "",
            "parentIdAndCode": "",
            "parentCode": "",
            "orgTypeId": "85afbf6b189e489fbe9b666fe19fb1ff",
            "orgLevelId": "5f45d373458a48d6988ecd94669e12ac",
            "orgLevelName": "",
            "positionId": "",
            "positionCode": "",
            "positionDesc": "",
            "positionIdAndCode": "",
            "appId": "116",
            "orgCode": "ORG000009",
            "orgIdAndOrgCode": "",
            "orgName": "总部部门",
            "shortName": "",
            "fullName": "信息化业务组织中国石油化工集团公司总部部门",
            "orgLevelCode": "",
            "orgTypeCode": "",
            "orgTypeName": "",
            "address": "",
            "email": "",
            "phone": "",
            "zipCode": "",
            "fax": "",
            "contact": "",
            "hasChild": 1,
            "isUsed": 0,
            "arrayParentId": "[c4fc0f9c582f2490a51d41bf2c2b5fd0][81d4f4858ee77de60d875771e8fd4204]",
            "arrayParentCode": "[ORG000009][ORG000001]",
            "remark": "",
            "orderNum": 80,
            "delFlag": 0,
            "createTime": 1506009600000,
            "createUserId": 1001818,
            "createUserAccount": "",
            "createUserName": "超级管理员",
            "updateTime": 1520784000000,
            "updateUserId": 1001818,
            "updateUserAccount": "admin",
            "updateUserName": "超级管理员",
            "reserve1": "",
            "reserve2": "",
            "enterCode": "",
            "enterName": "",
            "start": 0,
            "limit": 0
          }
        ],
        size: 'default',
        value: [],
        SHOW_PARENT,
        contractType: [
          {
            "optionName": "采购合同",
            "status": 0,
            "note": "项目合同类型",
            "sort": null,
            "typeCode": "HTLXXM",
            "optionCode": "0101"
          },
          {
            "optionName": "服务合同",
            "status": 0,
            "note": "项目合同类型",
            "sort": null,
            "typeCode": "HTLXXM",
            "optionCode": "0102"
          }
        ],
        tHeader: ['合同名称', '合同金额', '合同编号', '甲方'],
        filterVal: ['name', 'amount', 'contractCode', 'partyA'],
        dataSource: [
          {
            "uuid": "0ac4150587464b89aa8abf5443cd33fd",
            "contractId": "2f08c943-90ec-4792-b3c4-b1338fa40ef5",
            "projectId": "588e7a0b59764efca2f0ee396a876fac",
            "contractState": null,
            "purchaseId": "",
            "projectName": "测试项目0426-01_股份总部",
            "contractName": "采购合同-测试项目0426-01_股份总部",
            "contractType": "0101",
            "contractCode": "G11-MM-2019-357",
            "partyA": "中国石油化工股份有限公司信息化管理部",
            "partyB": "石化盈科信息技术有限责任公司",
            "partyC": null,
            "contractYeartype": "2019",
            "contractTaxAmount": 7,
            "contractNotTaxAmount": 6.03,
            "comprehensiveRate": 0,
            "projectWbsCode": "",
            "createUserId": null,
            "createUserName": null,
            "createTime": "2019-04-26 11:32:12",
            "lastupdateUserId": null,
            "lastupdateUserName": null,
            "lastupdateTime": null,
            "partyACode": null,
            "partyBId": null,
            "partyCId": null,
            "fundType": null,
            "expenditureTypeCode": null,
            "expenditureTypeName": null,
            "assetsAmountSubtotal": 0,
            "expenseItem": null,
            "expenseValue": null,
            "expenseAmount": 0,
            "contractFinalPrice": 0,
            "contractNumber": null,
            "contractPaymentState": null,
            "contractSystemId": null
          },
          {
            "uuid": "044f9dd2913f4216b199df997cbb87ee",
            "contractId": "72ba569d-cfe3-43b5-aa58-909fdace9571",
            "projectId": "588e7a0b59764efca2f0ee396a876fac",
            "contractState": null,
            "purchaseId": "",
            "projectName": "测试项目0426-01_股份总部",
            "contractName": "采购合同-测试项目0426-01_股份总部",
            "contractType": "0101",
            "contractCode": "G11-MM-2019-356",
            "partyA": "中国石油化工股份有限公司信息化管理部",
            "partyB": "石化盈科信息技术有限责任公司",
            "partyC": null,
            "contractYeartype": "2019",
            "contractTaxAmount": 3,
            "contractNotTaxAmount": 2.59,
            "comprehensiveRate": 0,
            "projectWbsCode": "",
            "createUserId": null,
            "createUserName": null,
            "createTime": "2019-04-26 10:55:17",
            "lastupdateUserId": null,
            "lastupdateUserName": null,
            "lastupdateTime": null,
            "partyACode": null,
            "partyBId": null,
            "partyCId": null,
            "fundType": null,
            "expenditureTypeCode": null,
            "expenditureTypeName": null,
            "assetsAmountSubtotal": 0,
            "expenseItem": null,
            "expenseValue": null,
            "expenseAmount": 0,
            "contractFinalPrice": 0,
            "contractNumber": null,
            "contractPaymentState": null,
            "contractSystemId": null
          },
          {
            "uuid": "fb263134b6514adeb574819827b6f3e1",
            "contractId": "074b3c0e-4ae7-4db2-9c76-5ffe2043c757",
            "projectId": "5dfb351a0bcc4cd6a9ae21b87c67f761",
            "contractState": null,
            "purchaseId": "",
            "projectName": "形象进度测试004_集团总部",
            "contractName": "采购合同-形象进度测试004_集团总部",
            "contractType": "0101",
            "contractCode": "GG-11-MM-2019-354",
            "partyA": "中国石油化工集团公司信息化管理部",
            "partyB": "上海众达信息产业有限公司",
            "partyC": "",
            "contractYeartype": "2019",
            "contractTaxAmount": 0,
            "contractNotTaxAmount": 0,
            "comprehensiveRate": 0,
            "projectWbsCode": "",
            "createUserId": null,
            "createUserName": null,
            "createTime": "2019-04-24 15:32:24",
            "lastupdateUserId": null,
            "lastupdateUserName": null,
            "lastupdateTime": null,
            "partyACode": null,
            "partyBId": null,
            "partyCId": null,
            "fundType": null,
            "expenditureTypeCode": null,
            "expenditureTypeName": null,
            "assetsAmountSubtotal": 0,
            "expenseItem": null,
            "expenseValue": null,
            "expenseAmount": 0,
            "contractFinalPrice": 0,
            "contractNumber": null,
            "contractPaymentState": null,
            "contractSystemId": null
          },
          {
            "uuid": "17d76fdd75ae48138940e8b00b7fb646",
            "contractId": "f9289d35-8bc1-4855-9b14-ec4bdf0716b2",
            "projectId": "2f0902c8576947099340d1efb77fea75",
            "contractState": null,
            "purchaseId": "",
            "projectName": "形象进度测试004_股份总部",
            "contractName": "采购合同-形象进度测试004_股份总部",
            "contractType": "0101",
            "contractCode": "GG-11-MM-2019-353",
            "partyA": "中国石油化工股份有限公司信息化管理部",
            "partyB": "上海众达信息产业有限公司",
            "partyC": "",
            "contractYeartype": "2019",
            "contractTaxAmount": 0,
            "contractNotTaxAmount": 0,
            "comprehensiveRate": 0,
            "projectWbsCode": "",
            "createUserId": null,
            "createUserName": null,
            "createTime": "2019-04-24 15:32:05",
            "lastupdateUserId": null,
            "lastupdateUserName": null,
            "lastupdateTime": null,
            "partyACode": null,
            "partyBId": null,
            "partyCId": null,
            "fundType": null,
            "expenditureTypeCode": null,
            "expenditureTypeName": null,
            "assetsAmountSubtotal": 0,
            "expenseItem": null,
            "expenseValue": null,
            "expenseAmount": 0,
            "contractFinalPrice": 0,
            "contractNumber": null,
            "contractPaymentState": null,
            "contractSystemId": null
          },
          {
            "uuid": "3339876e95e04ea0914e019758da4c63",
            "contractId": "6cefcb5a-c2e6-4793-9b39-7efef3cece74",
            "projectId": "76c8d60cdfd9432abcd8adf3e558f349",
            "contractState": null,
            "purchaseId": "",
            "projectName": "形象进度测试003_集团总部",
            "contractName": "采购合同-形象进度测试003_集团总部",
            "contractType": "0101",
            "contractCode": "GG-11-MM-2019-352",
            "partyA": "中国石油化工集团公司信息化管理部",
            "partyB": "石化盈科信息技术有限责任公司",
            "partyC": null,
            "contractYeartype": "2019",
            "contractTaxAmount": 1800,
            "contractNotTaxAmount": 1551.72,
            "comprehensiveRate": 0,
            "projectWbsCode": "",
            "createUserId": null,
            "createUserName": null,
            "createTime": "2019-04-23 17:50:23",
            "lastupdateUserId": null,
            "lastupdateUserName": null,
            "lastupdateTime": null,
            "partyACode": null,
            "partyBId": null,
            "partyCId": null,
            "fundType": null,
            "expenditureTypeCode": null,
            "expenditureTypeName": null,
            "assetsAmountSubtotal": 0,
            "expenseItem": null,
            "expenseValue": null,
            "expenseAmount": 0,
            "contractFinalPrice": 0,
            "contractNumber": null,
            "contractPaymentState": null,
            "contractSystemId": null
          }
        ],
//        data,

        visible: false,
        childrenDrawer: false
      }
    },
    methods: {
      loadOptionDepartment (){
        let _self = this
        var parmasData = 'planYear=' + this.optionDateSelect + '&orgCodes=' + this.orgCodes + '&keyword=' + this.keyWords + '&blMergeLastCol=true'
        apiService.loadOptionDepartment(parmasData).then(r => {
            _self.optionDepartment=r
        }, r => {
        }).catch(
        )
      },
      exportQyxq(){
        let _self=this
        var parmasData='planYear='+this.optionDateSelect+'&orgCodes='+this.orgCodes+'&keyword='+this.keyWords+'&blMergeLastCol=true'
        apiService.exportQyxq(parmasData).then(r=>{
        },r=>{
          _self.$message.error("后台接口异常")
        }).catch(
        )
      },
      loadDate(parmasData){
        let _self=this
        apiService.getDictionary(parmasData).then(r=>{
            debugger
          _self.optionDate=r
          _self.optionDateSelect=r[0].optionName
        },r=>{
            _self.$message.error("后台接口异常")
        }).catch(
        )
      },
      loadInfoData(parmasData){
        let _self=this
        apiService.getItmcDemandXxmms(parmasData).then(r=>{
            _self.infoData=r
        },r=>{
        }).catch(
        )
      },
      loadInfoDataBase(parmasData){
        let _self=this
        apiService.getItmcDemandXxmmsDo(parmasData).then(r=>{
          _self.infoDataBase=r
        },r=>{
//            _self.$message.error("后台接口异常")
        }).catch(
        )
      },
      getItmcDemandXxmmSum(){
        let _self=this
        let parmasData='planYear='+this.optionDateSelect+'&demandType=1&orgCodes='+_self.orgCodes+'&keyword='+_self.keyWords
        apiService.getItmcDemandXxmmsDo(parmasData).then(r=>{
          _self.xxmmSum=r
        },r=>{
            //_self.$message.error("后台接口异常")
        }).catch(
        )

        let infoParmasBaseSum='planYear='+this.optionDateSelect+'&demandType=2&orgCodes='+_self.orgCodes+'&keyword='+_self.keyWords
        apiService.getItmcDemandXxmmsDo(infoParmasBaseSum).then(r=>{
          _self.xxmmSumBase=r
        },r=>{
        }).catch(
        )
      },
      handleChangeDate(value){
        console.log(value);
        console.log(this.optionDateSelect);
      },
      doCheck(){
        let _self=this
        var infoParmas='planYear='+this.optionDateSelect+'&demandType=1&rows=5&page=1&orgCodes='+_self.orgCodes+'&keyword='+_self.keyWords
        this.loadInfoData(infoParmas)
        var infoParmasBase='planYear='+this.optionDateSelect+'&demandType=1&rows=5&page=1&orgCodes='+_self.orgCodes+'&keyword='+_self.keyWords
        this.loadInfoDataBase(infoParmasBase)
      },
      doDetail(record,text,index){
        this.modalRecodes=record
        this.setModal1Visible(true)
        console.log(record)
      },
      setModal1Visible(modal1Visible) {
        this.modalVisible = modal1Visible;
      },




      handleChange(value) {
        console.log(`Selected: ${value}`);
      },
      onChange (value) {
        console.log('onChange ', value)
        this.value = value
      },
      handleDelete(record){
        console.log(record)
      },
      doDelete(key,text,index){
        this.showDrawer()
      },
      showDrawer() {
        this.visible = true
      },
      onClose() {
        this.visible = false
      },
      showChildrenDrawer() {
        this.childrenDrawer = true
      },
      onChildrenDrawerClose() {
        this.childrenDrawer = false
      },
      toAdd(){
        this.$router.push({path: '/add-contract'})
      },
      exportToExcel(){
        this.$gloableF.exportToExcel(this.tHeader, this.filterVal, this.dataSource)
      },


      popupScroll(){
        console.log('popupScroll')
      },
      triggerImport(){
//         触发importRef的click事件
      },
      importfxx(obj) {
        let _this = this;
        let inputDOM = this.$refs.inputer;
        // 通过DOM取文件数据
        this.file = event.currentTarget.files[0];
        var rABS = false; //是否将文件读取为二进制字符串
        var f = this.file;
        var reader = new FileReader();
        //if (!FileReader.prototype.readAsBinaryString) {
        FileReader.prototype.readAsBinaryString = function (f) {
          var binary = "";
          var rABS = false; //是否将文件读取为二进制字符串
          var pt = this;
          var wb; //读取完成的数据
          var outdata;
          var reader = new FileReader();
          reader.onload = function (e) {
            var bytes = new Uint8Array(reader.result);
            var length = bytes.byteLength;
            for (var i = 0; i < length; i++) {
              binary += String.fromCharCode(bytes[i]);
            }
            var XLSX = require('xlsx');
            if (rABS) {
              wb = XLSX.read(btoa(fixdata(binary)), { //手动转化
                type: 'base64'
              });
            } else {
              wb = XLSX.read(binary, {
                type: 'binary'
              });
            }
            outdata = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);//outdata就是你想要的东西
            this.da = [...outdata]
            let arr = []
            this.da.map(v => {
              let obj = {}
              arr.push(v)
            })
            console.log(arr)
            let para = {
              //withList: JSON.stringify(this.da)
              withList: arr
            }
//            _this.$message({
//              message: '请耐心等待导入成功',
//              type: 'success'
//            });
            withImport(para).then(res => {
              window.location.reload()
            })

          }
          reader.readAsArrayBuffer(f);
        }
        if (rABS) {
          reader.readAsArrayBuffer(f);
        } else {
          reader.readAsBinaryString(f);
        }
      },

    },
    created(){
      this.optionDate=[
        {
          "optionName": "2019",
          "status": 0,
          "note": "需求与计划年度下拉框使用",
          "sort": 2,
          "typeCode": "JHNDS",
          "optionCode": "2019"
        },
        {
          "optionName": "2018",
          "status": 0,
          "note": "需求与计划年度下拉框使用",
          "sort": 3,
          "typeCode": "JHNDS",
          "optionCode": "2018"
        },
        {
          "optionName": "2020",
          "status": 0,
          "note": "需求与计划年度下拉框使用",
          "sort": 1,
          "typeCode": "JHNDS",
          "optionCode": "2020"
        },
      ]
      this.optionDateSelect=this.optionDate[0].optionName


        const columns= [
          {
        title: '单位名称',
        dataIndex: 'referOrgName',

      },{
        title: '序号',
        dataIndex: 'demandType',
      }, {
        title: '项目名称',
        dataIndex: 'projectName',
      }, {
        title: '现状及需求',
        dataIndex: 'projectDemand',
      },  {
        title: '建设目标和主要内容',
        dataIndex: 'projectTarget',
      },    {
        title: '建设年限',
        dataIndex: 'projectStarYear',
      },    {
        title: '总投资估算（万元）',
        dataIndex: 'projectInvestSum',
      },  {
            title: '操作',
            dataIndex: 'projectCode',
            key: 'x',
            scopedSlots: { customRender: 'action' },
          },]
        this.columns=columns
//        this.infoData={
//          "pageNum": 1,
//          "pageSize": 5,
//          "size": 2,
//          "startRow": 1,
//          "endRow": 2,
//          "total": 2,
//          "pages": 1,
//          "list": [
//            {
//              "id": "2e086b7a92584109baf69495a653e441",
//              "planCode": "JH000141",
//              "projectCode": "XM00000211",
//              "projectRequirementStatus": 20,
//              "projectName": "测试项目试点",
//              "projectStarYear": "2020",
//              "projectEndYear": "2020",
//              "projectTarget": "222",
//              "note": "",
//              "projectInvestSum": 2,
//              "isDel": 0,
//              "creUserId": 3606141,
//              "creUserName": "王思明",
//              "creTime": 1556435206995,
//              "updUserId": 3606141,
//              "updUserName": "王思明",
//              "updTime": 1556435208313,
//              "projectDemand": "222",
//              "demandType": 1,
//              "sort": 211,
//              "operateNote": null,
//              "projectStausName": null,
//              "planYear": null,
//              "itmcDemandXxConfigList": null,
//              "mainAndConfig": null,
//              "referOrgCode": "ORG000055",
//              "referOrgName": "镇海炼化分公司",
//              "plateOrgCode": "ORG000003",
//              "plateOrgName": "炼化企业",
//              "projectSort": "1",
//              "investSum": null,
//              "orderNum": null
//            },
//            {
//              "id": "f2614bc877894f24a80f71bb3a2d9a4b",
//              "planCode": "JH000137",
//              "projectCode": "XM00000210",
//              "projectRequirementStatus": 20,
//              "projectName": "测试项目试点",
//              "projectStarYear": "2020",
//              "projectEndYear": "2020",
//              "projectTarget": "11",
//              "note": "",
//              "projectInvestSum": 1,
//              "isDel": 0,
//              "creUserId": 1300178,
//              "creUserName": "张捷",
//              "creTime": 1556434779320,
//              "updUserId": 1300178,
//              "updUserName": "张捷",
//              "updTime": 1556434781652,
//              "projectDemand": "111",
//              "demandType": 1,
//              "sort": 210,
//              "operateNote": null,
//              "projectStausName": null,
//              "planYear": null,
//              "itmcDemandXxConfigList": null,
//              "mainAndConfig": null,
//              "referOrgCode": "ORG000067",
//              "referOrgName": "信息化管理部",
//              "plateOrgCode": "ORG000009",
//              "plateOrgName": "总部部门",
//              "projectSort": "1",
//              "investSum": null,
//              "orderNum": null
//            }
//          ],
//          "prePage": 0,
//          "nextPage": 0,
//          "isFirstPage": true,
//          "isLastPage": true,
//          "hasPreviousPage": false,
//          "hasNextPage": false,
//          "navigatePages": 8,
//          "navigatepageNums": [
//            1
//          ],
//          "navigateFirstPage": 1,
//          "navigateLastPage": 1,
//          "firstPage": 1,
//          "lastPage": 1
//        }
        const columnsBase= [
          {
            title: '单位名称',
            dataIndex: 'referOrgName',

          },{
            title: '序号',
            dataIndex: 'demandType',
          }, {
            title: '项目名称',
            dataIndex: 'projectName',
          }, {
            title: '现状及需求',
            dataIndex: 'projectDemand',
          },  {
            title: '主要建设内容',
            dataIndex: 'projectTarget',
          },  {
            title: '总投资估算（万元）',
            dataIndex: 'projectInvestSum',
          }, {
            title: '操作',
            dataIndex: 'projectCode',
            key: 'x',
            scopedSlots: { customRender: 'actionBase' },
          },  ]
        this.columnsBase=columns
        this.infoDataBase={
          "pageNum": 1,
          "pageSize": 5,
          "size": 2,
          "startRow": 1,
          "endRow": 2,
          "total": 2,
          "pages": 1,
          "list": [],
          "prePage": 0,
          "nextPage": 0,
          "isFirstPage": true,
          "isLastPage": true,
          "hasPreviousPage": false,
          "hasNextPage": false,
          "navigatePages": 8,
          "navigatepageNums": [
            1
          ],
          "navigateFirstPage": 1,
          "navigateLastPage": 1,
          "firstPage": 1,
          "lastPage": 1
        }


      let infoParmas='planYear=2019&demandType=1&rows=5&page=1'
      this.loadInfoData(infoParmas)
      let infoParmasBase='planYear='+this.optionDateSelect+'&demandType=1&rows=5&page=1'
      this.loadInfoDataBase(infoParmasBase)
      //获取总金额
      this.getItmcDemandXxmmSum()
      //获取上报部门信息
      // this.loadOptionDepartment ()
      //获取下拉日期
        //let parmasDate={typeCode:'JHNDS'}
        //parmasDate._json=true
        //this.loadDate(parmasDate)
    },
    watch: {
    }
  }
</script>
<style>
  #contractWrap .ant-table-bordered .ant-table-thead > tr > th{
    padding: 9px 16px!important;
  }
  #contractWrap .ant-table-bordered .ant-table-tbody > tr > td{
    padding: 2px 16px!important;
  }
</style>
