<template>
  <div>
    <iframe scrolling="no" style="width: 100%;min-height:600px" :src=url frameborder="0"></iframe>
  </div>
</template>

<script>

  import {urlDomain} from '@/services/domain'
  export default {
    name: "Summary",
    components: {
    },
    data () {
     return {
       url:urlDomain+"/project/enterpries/edemandreport/eDemandReport.html"
     }
    },
    methods: {
    },
    created(){

    },
    watch: {

    }
  }
</script>
<style>

</style>
