<template>
  <div>
    <iframe scrolling="no" style="width: 100%;min-height: 600px" :src=url frameborder="0"  id="iframe"></iframe>
  </div>
</template>

<script>

  import {urlDomain} from '@/services/domain'
  export default {
    name: "Gather1",
    components: {
    },
    data () {
     return {
       url:urlDomain+"/project/headquarters/mdemandcollect/mDemandCollect.html"
     }
    },
    methods: {
    },
    created(){
    },
    mounted(){
      let clientHeight = document.documentElement.clientHeight
      // document.getElementById("iframe").style.height= (clientHeight-70) + 'px'
      console.log(clientHeight)
    },
    watch: {

    }
  }
</script>
<style>
  @import '../../assets/css/common.css';
</style>
