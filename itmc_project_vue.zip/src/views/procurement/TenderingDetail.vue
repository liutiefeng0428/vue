<template>
  <div class="wrap">
    <div class="con-title">
      <span>招投标管理</span>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>基本信息</span>
    </div>
    <div class="container" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">招投标编码：</div>
            <div class="flexC">111</div>
            <div class="flexT">类型：</div>
            <div class="flexC">111</div>
          </div>
          <div class="flexItems1">
            <div class="flexT">招投标项：</div>
            <div class="flexC">111</div>
            <div class="flexT">分类：</div>
            <div class="flexC">111</div>
          </div>
          <div class="flexItems1">
            <div class="flexT">项目名称/开支类型名称：</div>
            <div class="flexC">33</div>
          </div>
          <div class="flexItems1">
            <div class="flexT">招投标名称：</div>
            <div class="flexC">33</div>
          </div>
        </div>
      </div>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>招标文件</span>
    </div>
    <div  style="margin-bottom: 20px">
      <div class="ant-table-content">
        <div class="ant-table-body">
          <table style="width: 100%">
            <thead class="ant-table-thead">
            <tr>
              <th rowspan="1" class=""><div>文件类型</div></th>
              <th rowspan="1" class=""><div>文件名称</div></th>
              <th rowspan="1" class=""><div>上传人</div></th>
              <th rowspan="1" class=""><div>上传时间</div></th>
            </tr>
            </thead>
            <tbody class="ant-table-tbody">
            <tr  v-for="(item,index) in dataInfo">
              <td>{{item.projectName}}</td>
              <td><a>{{item.projectName}}</a></td>
              <td>
                  <span class="ecllipsis">
                    {{item.projectContent}}
                  </span>
              </td>
              <td>{{item.conYear}}</td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>招标结果</span>
    </div>
    <div class="container" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">有效期</div>
            <div class="flexC">111</div>
          </div>
          <div class="flexItems1">
            <div class="flexT">是否有效</div>
            <div class="flexC">22</div>
          </div>
        </div>
      </div>
    </div>
    <div class="con-title">
      <span>中标厂商</span>
    </div>
    <div  style="margin-bottom: 20px">
      <div class="ant-table-content">
        <div class="ant-table-body">
          <table style="width: 100%">
            <thead class="ant-table-thead">
            <tr>
              <th rowspan="1" class=""><div>中标顺序</div></th>
              <th rowspan="1" class=""><div>中标厂商</div></th>
              <th rowspan="1" class=""><div>设备总价合计(元)</div></th>
              <th rowspan="1" class=""><div>操作</div></th>
            </tr>
            </thead>
            <tbody class="ant-table-tbody">
            <tr  v-for="(item,index) in dataInfo">
              <td>{{item.projectName}}</td>
              <td>{{item.projectName}}</td>
              <td>
                  <span class="ecllipsis">
                    {{item.projectContent}}
                  </span>
              </td>
              <td><span><a>查看设备</a></span></td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="con-title">
      <span>中标文档信息</span>
    </div>
    <div  style="margin-bottom: 20px">
      <div class="ant-table-content">
        <div class="ant-table-body">
          <table style="width: 100%">
            <thead class="ant-table-thead">
            <tr>
              <th rowspan="1" class=""><div>文档类型</div></th>
              <th rowspan="1" class=""><div>文档名称</div></th>
              <th rowspan="1" class=""><div>上传人</div></th>
              <th rowspan="1" class=""><div>上传时间</div></th>
            </tr>
            </thead>
            <tbody class="ant-table-tbody">
            <tr  v-for="(item,index) in dataInfo">
              <td>{{item.projectName}}</td>
              <td><a>{{item.projectName}}</a></td>
              <td>
                  <span class="ecllipsis">
                    {{item.projectContent}}
                  </span>
              </td>
              <td>{{item.conYear}}</td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="container" style="text-align: center;margin-top: 20px">
      <div>
        <a-button @click="goBack()">返回</a-button>
      </div>
    </div>
  </div>
</template>

<script>

  import {apiService} from "@/services/apiservice";
  export default {
    name: "TenderingDetail",
    components: {
    },
    data() {
      return {
        dataInfo:[{"id":"326f63b0d36e46f6acc22fadb242cc26","planYear":"2019","belongPlat":"经营管理平台","constrNature":"新开","projectName":"测试导入01","projectContent":"测试导入201905291441","approvalNum":null,"businessArea":"绩效管理","versionsName":"各处申报汇总版","versionsState":"2019-07-01项目二处","constarYear":null,"conendYear":null,"conYear":"2019-2020","investmentChannel":"B01","totalZbSort":100.0,"totalZbHardware":100.0,"totalZbService":100.0,"totalZbOther":100.0,"totalQySort":100.0,"totalQyHardware":100.0,"totalQyService":100.0,"totalQyOther":100.0,"totalSum":800.0,"nyZbSort":5.0,"nyZbHardware":5.0,"nyZbService":5.0,"nyZbOther":5.0,"nyQylhSort":5.0,"nyQylhHardware":5.0,"nyQylhService":5.0,"nyQylhOther":5.0,"nyQyytSort":5.0,"nyQyytHardware":5.0,"nyQyytService":5.0,"nyQyytOther":5.0,"nyQyxsSort":5.0,"nyQyxsHardware":5.0,"nyQyxsService":5.0,"nyQyxsOther":5.0,"nyQykySort":5.0,"nyQykyHardware":5.0,"nyQykyService":5.0,"nyQykyOther":5.0,"nyQyzySort":5.0,"nyQyzyHardware":5.0,"nyQyzyService":5.0,"nyQyzyOther":5.0,"remark":"项目二处备注","nyTotalSum":120.0,"lyZbSort":0.0,"lyZbHardware":0.0,"lyZbService":0.0,"lyZbOther":0.0,"lyQySort":0.0,"lyQyHardware":0.0,"lyQyService":0.0,"lyQyOther":0.0,"nowZbSort":100.0,"nowZbHardware":10.0,"nowZbService":10.0,"nowZbOther":10.0,"nowQySort":10.0,"nowQyHardware":10.0,"nowQyService":10.0,"nowQyOther":0.0,"finTotalSum":160.0,"bureaus":"项目管理二处","isDel":"0","creUserId":"3503632","creUserName":"程大庆","creTime":1561962889577,"updUserId":0.0,"updUserName":null,"updTime":1562033964367,"lyTotalSum":0.0,"nowTotalSum":160.0,"reportStatue":"1","versionTime":null,"replyState":"未上报"},{"id":"3dcc79c9d37440e68f61bb31f4b66bfe","planYear":"2019","belongPlat":"经营管理平台","constrNature":"新开","projectName":"测试导入01","projectContent":"测试导入201905291441","approvalNum":null,"businessArea":"绩效管理","versionsName":"各处申报汇总版","versionsState":"2019-07-01项目二处","constarYear":null,"conendYear":null,"conYear":"2019-2020","investmentChannel":"B01","totalZbSort":100.0,"totalZbHardware":100.0,"totalZbService":100.0,"totalZbOther":100.0,"totalQySort":100.0,"totalQyHardware":100.0,"totalQyService":100.0,"totalQyOther":100.0,"totalSum":800.0,"nyZbSort":5.0,"nyZbHardware":5.0,"nyZbService":5.0,"nyZbOther":5.0,"nyQylhSort":5.0,"nyQylhHardware":5.0,"nyQylhService":5.0,"nyQylhOther":5.0,"nyQyytSort":5.0,"nyQyytHardware":5.0,"nyQyytService":5.0,"nyQyytOther":5.0,"nyQyxsSort":5.0,"nyQyxsHardware":5.0,"nyQyxsService":5.0,"nyQyxsOther":5.0,"nyQykySort":5.0,"nyQykyHardware":5.0,"nyQykyService":5.0,"nyQykyOther":5.0,"nyQyzySort":5.0,"nyQyzyHardware":5.0,"nyQyzyService":5.0,"nyQyzyOther":5.0,"remark":"项目二处备注","nyTotalSum":120.0,"lyZbSort":0.0,"lyZbHardware":0.0,"lyZbService":0.0,"lyZbOther":0.0,"lyQySort":0.0,"lyQyHardware":0.0,"lyQyService":0.0,"lyQyOther":0.0,"nowZbSort":100.0,"nowZbHardware":10.0,"nowZbService":10.0,"nowZbOther":10.0,"nowQySort":10.0,"nowQyHardware":10.0,"nowQyService":10.0,"nowQyOther":0.0,"finTotalSum":160.0,"bureaus":"项目管理一处","isDel":"0","creUserId":"3503630","creUserName":"李伟光","creTime":1561981779966,"updUserId":0.0,"updUserName":null,"updTime":1562033964367,"lyTotalSum":0.0,"nowTotalSum":160.0,"reportStatue":"1","versionTime":null,"replyState":"未上报"},{"id":"db5c6a193b0d445781b00a8434d4620b","planYear":"2019","belongPlat":"经营管理平台","constrNature":"新开","projectName":"测试导入01","projectContent":"测试导入201905291441","approvalNum":null,"businessArea":"绩效管理","versionsName":"各处申报汇总版","versionsState":"2019-07-01项目二处","constarYear":null,"conendYear":null,"conYear":"2019-2020","investmentChannel":"B01","totalZbSort":100.0,"totalZbHardware":100.0,"totalZbService":100.0,"totalZbOther":100.0,"totalQySort":100.0,"totalQyHardware":100.0,"totalQyService":100.0,"totalQyOther":100.0,"totalSum":800.0,"nyZbSort":5.0,"nyZbHardware":5.0,"nyZbService":5.0,"nyZbOther":5.0,"nyQylhSort":5.0,"nyQylhHardware":5.0,"nyQylhService":5.0,"nyQylhOther":5.0,"nyQyytSort":5.0,"nyQyytHardware":5.0,"nyQyytService":5.0,"nyQyytOther":5.0,"nyQyxsSort":5.0,"nyQyxsHardware":5.0,"nyQyxsService":5.0,"nyQyxsOther":5.0,"nyQykySort":5.0,"nyQykyHardware":5.0,"nyQykyService":5.0,"nyQykyOther":5.0,"nyQyzySort":5.0,"nyQyzyHardware":5.0,"nyQyzyService":5.0,"nyQyzyOther":5.0,"remark":"项目二处备注","nyTotalSum":120.0,"lyZbSort":0.0,"lyZbHardware":0.0,"lyZbService":0.0,"lyZbOther":0.0,"lyQySort":0.0,"lyQyHardware":0.0,"lyQyService":0.0,"lyQyOther":0.0,"nowZbSort":100.0,"nowZbHardware":10.0,"nowZbService":10.0,"nowZbOther":10.0,"nowQySort":10.0,"nowQyHardware":10.0,"nowQyService":10.0,"nowQyOther":0.0,"finTotalSum":160.0,"bureaus":"项目管理一处","isDel":"0","creUserId":"3503630","creUserName":"李伟光","creTime":1561981760364,"updUserId":0.0,"updUserName":null,"updTime":1562033964367,"lyTotalSum":0.0,"nowTotalSum":160.0,"reportStatue":"1","versionTime":null,"replyState":"未上报"}]
      }
    },
    methods: {
      goBack(uuid){
          this.$router.go(-1)
      },
    },
    computed: {

    },
    filters:{
    },
    created(){

    }
  }
</script>
<style scoped>
  @import '../../assets/css/common.css';
  .wrap {
    padding: 20px;
    background: #ffffff;
    margin: 10px;
  }
  .ant-table-tbody>tr>td, .ant-table-thead>tr>th{
    border-right:1px solid #e8e8e8;
  }
  .ant-table-body{
    border-left:1px solid #e8e8e8;
    border-top:1px solid #e8e8e8;
  }
</style>
