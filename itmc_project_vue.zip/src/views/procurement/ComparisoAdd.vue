<template>
  <div class="wrap">
    <div class="con-title">
      <span>询比价管理</span>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>基本信息</span>
    </div>
    <!-- 询比价基本信息 -->
    <CompBasicInfo :isNew="isNew" :isEdit="isEdit" :id="id" :compBasicInfo="dataInfo"></CompBasicInfo>

    <div class="con-title">
      <span class="divdLine"></span>
      <span>询比价文件</span>
    </div>
    <!-- 询比价文件 -->
    <UploadFile :isEdit="isEdit" :relationId="id" :businessType="businessTypeXBJ"></UploadFile>

    <div class="con-title">
      <span class="divdLine"></span>
      <span>询比价结果</span>
    </div>
    <ResultInfo :isNew="isNew" :isEdit="isEdit" :id="id" :resultInfo="dataInfo"></ResultInfo>

    <div class="con-title">
      <span class="divdLine"></span>
      <span>中标厂商</span>
      <!-- <a-button style="margin-left:3px"  @click="triggerImport()" icon="upload">选择</a-button> -->
    </div>
    <WinFirm :isNew="isNew" :isEdit="isEdit" :id="id" :winFirmInfo="biddingsupplierList"></WinFirm>

    <div class="con-title">
      <span class="divdLine"></span>
      <span>中标文档信息</span>
    </div>
    <UploadFile :isEdit="isEdit" :relationId="id" :businessType="businessTypeXJZB"></UploadFile>

    <div class="container" style="text-align: center;margin-top: 20px">
      <div>
        <a-button v-if="isEdit" type="primary" @click="saveCompariso">保存</a-button>
        <a-button @click="goBack()">返回</a-button>
      </div>
    </div>
  </div>
</template>

<script>

  import {apiService} from "@/services/apiservice";
  import reqwest from 'reqwest'
  import CompBasicInfo from './model/CompBasicInfo'
  import ResultInfo from './model/ResultInfo'
  import WinFirm from './model/WinFirm'
  import UploadFile from '@/components/operation/UploadFile'
  import Vue from 'vue'
  import $ from "jquery"
  export default {
    name: "ComparisoAdd",
    components: {
      CompBasicInfo,
      ResultInfo,
      WinFirm,
      UploadFile,
    },
    data() {
      return {
        id:'',
        uuidAdd:'',
        isEdit:false,
        isNew:false,
        dataInfo:{},
        biddingsupplierList:[],// 中标厂商列表
        businessTypeXBJ:'XJ', // 询比价文档文档类型
        businessTypeXJZB:'XJZB', // 中标文档文档类型
      }
    },
    methods: {
      uuid(len, radix) {//设置UUID
        var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
        var uuid = [], i;
        radix = radix || chars.length;
        if (len) {
        // Compact form
          for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random()*radix];
          } else {
          // rfc4122, version 4 form
            var r;
            // rfc4122 requires these characters
            uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
            uuid[14] = '4';
            // Fill in random data. At i==19 set the high bits of clock sequence as
            // per rfc4122, sec. 4.1.5
            for (i = 0; i < 36; i++) {
              if (!uuid[i]) {
              r = 0 | Math.random()*16;
              uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
              }
            }
        }
        this.uuidAdd = uuid.join('')
        return uuid.join('');
      },
      // 新增询比价保存信息
      addBidding(parmasData){
        var _self = this
        apiService.addBidding(parmasData).then(r => {
          if(r.result == 200){
            _self.$message.success('保存成功！')
            _self.$router.push({path: "/procurement-list"})
          }else{
            _self.$message.warning(r.msg)
          }
        }, r => {
        }).catch(
        )
      },
      // 编辑询比价保存信息
      editPurchaseInfo(parmasData){
        var _self = this
        apiService.editPurchaseInfo(parmasData).then(r => {
          if(r.result == 200){
            _self.$message.success('保存成功！')
            _self.$router.push({path: "/procurement-list"})
          }else{
            _self.$message.warning(r.msg)
          }
        }, r => {
        }).catch(
        )
      },
      saveCompariso(){
        let _self=this
        Vue.set(this.dataInfo, 'itmcInvestmentBiddingsupplierList', this.biddingsupplierList)
        if(this.dataInfo.editBiddingName){
          if(this.dataInfo.buyType == '1'){
            this.dataInfo.binddingApplyName = this.dataInfo.biddingName + this.dataInfo.editBiddingName + '询比价'
          }else if(this.dataInfo.buyType == '0'){
            this.dataInfo.binddingApplyName = this.dataInfo.feeTypeName + this.dataInfo.editBiddingName + '询比价'
          }
        }
        if(this.isNew){
          Vue.set(this.dataInfo, 'id', this.id)
          let parmasData = {flag: '1', itmcInvestmentBiddingDTO: this.dataInfo}
          parmasData._json=true
          this.addBidding(parmasData)
        }else{
          let parmas = {biddingType:'1', itmcInvestmentBiddingDTO: this.dataInfo}
          parmas._json = true
          this.editPurchaseInfo(parmas)
        }
      },
      goBack(uuid){
          this.$router.go(-1)
      },
      getItmcInvestmentBiddingDetail(){// 获取询比价详情信息
        var params = {id: this.id}
        params._json = true
        apiService.getItmcInvestmentBiddingDetail(params).then(r => {
            this.dataInfo = r
            this.biddingsupplierList = r.itmcInvestmentBiddingsupplierList // 中标厂商列表
            console.log(r)
        }, r => {
        }).catch(
        )
      },
    },
    computed: {
    },
    filters:{
    },
    created(){
      this.uuid(32,16)
      this.id=this.$route.query.id
      this.isEdit = this.$route.query.isEdit
      this.isNew = this.$route.query.isNew

      if(!this.isNew) this.getItmcInvestmentBiddingDetail()
      else{
        var dataInfo = {
          "biddingItemName": "",
          "biddingName": "",
          "biddingNo": "",
          "biddingType": 0,
          "binddingApplyName": "",
          "businessContractor": "",
          "buyType": 0,
          "feeType": 0,
          "id": "",
          "isValid": 0,
          "itmcInvestmentBiddingsupplierList": [],
          "periodEndDate": null,
          "periodStartDate": null,
          "projectId": "",
          "softOrHard": 0,
          "startDate": null,
          "techContractor": ""
        }
        this.dataInfo = dataInfo
      }
    }
  }
</script>
<style>
  @import '../../assets/css/common.css';
  .wrap {
    padding: 20px;
    background: #ffffff;
    margin: 10px;
  }
  .ant-table-tbody>tr>td, .ant-table-thead>tr>th{
    border-right:1px solid #e8e8e8;
  }
  .ant-table-body{
    border-left:1px solid #e8e8e8;
    border-top:1px solid #e8e8e8;
  }
</style>
