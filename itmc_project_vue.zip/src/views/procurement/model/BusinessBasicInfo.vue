<template>
  <div>
    <div class="container" v-if="!isEdit" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">类型</div>
            <div class="flexC">
              {{buyTypeName}}
            </div>
          </div>
          <div v-if="buyTypeName=='项目'" class="flexItems1">
            <div class="flexT">项目名称</div>
            <div class="flexC">
              {{businessBasicInfo.negotiationName}}
            </div>
          </div>
          <div v-if="buyTypeName=='费用'" class="flexItems1">
            <div class="flexT">开支类型名称</div>
            <div class="flexC">
              {{feeTypeName}}
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">谈判名称</div>
            <div class="flexC">
              {{businessBasicInfo.negotiationApplyName}}
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">谈判日期</div>
            <div class="flexC">
              {{businessBasicInfo.startDate}}
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">谈判有效</div>
            <div class="flexC">
              {{businessBasicInfo.validName}}
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container" v-if="isEdit" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">类型</div>
            <div class="flexC">
              <a-select :value="buyTypeName" class="querySelect" @change="handleChangebureausTotal" style="width:200px">
                <a-select-option v-for="item in bureaus" :key="item.bureausCode"> {{item.bureaus}}</a-select-option>
              </a-select>
            </div>
          </div>
          <div v-if="buyTypeName=='项目'" class="flexItems1">
            <div class="flexT">项目名称</div>
            <div class="flexC">
              <SelectListModal @selectMainContent="getNameFromSon" :mainPrjData="mainPrjData" :columns="columns" :biddingName="businessBasicInfo.negotiationName" :getMainProjectByProjectName="getMainProjectByProjectName"></SelectListModal>
            </div>
          </div>
          <div v-if="buyTypeName=='费用'" class="flexItems1">
            <div class="flexT">开支类型名称</div>
            <div class="flexC">
              <a-select :value="feeTypeName" @change="handleFeeTypeChange" class="querySelect" style="width:200px">
                  <a-select-option v-for="item in feeTypeList" :key="item.feeTypeId"> {{item.feeTypeName}}</a-select-option>
              </a-select>
            </div>
          </div>
          <!-- 非老数据的商务谈判名称显示编辑 -->
          <!-- <div v-if="buyTypeName && !isOld" class="flexItems1">
            <div class="flexT">谈判名称</div>
            <div class="flexC" v-if="buyTypeName == '项目'" style="border-right:0">
              {{businessBasicInfo.negotiationName}}
            </div>
            <div class="flexC" v-if="buyTypeName == '费用'" style="border-right:0">
              {{feeTypeName}}
            </div>
            <div class="flexT" style="background:#fff;border-right:0">
              <input type="text" v-model="businessBasicInfo.editNegName" class="ant-input" >
            </div>
            <div class="flexC">商务谈判</div>
          </div> -->
          <div v-if="buyTypeName && !isOld" class="flexItems1">
            <div class="flexT">谈判名称</div>
            <div class="flexC" v-if="buyTypeName == '项目'">
              {{businessBasicInfo.negotiationName}}
              <input style="width: 200px" type="text" class="ant-input" v-model="businessBasicInfo.editNegName">
              <span>商务谈判</span>
            </div>
            <div class="flexC" v-if="buyTypeName == '费用'">
              {{feeTypeName}}
              <input style="width: 200px" type="text" class="ant-input" v-model="businessBasicInfo.editNegName">
              <span>商务谈判</span>
            </div>
          </div>
          <!-- 老数据的询比价名称显示编辑 -->
          <div v-if="isOld" class="flexItems1">
            <div class="flexT">谈判名称</div>
            <div class="flexC">
              <input type="text" v-model="businessBasicInfo.negotiationApplyName" class="ant-input" >
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">谈判日期</div>
            <div class="flexC">
              <a-date-picker placeholder="请选择日期" @change="handleChangeNegotiationDate" v-model="negotiationDate"/>
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">谈判有效</div>
            <div class="flexC">
              <a-select :value="validName" class="querySelect" @change="handleChangeValid" style="width:200px">
                <a-select-option v-for="item in validList" :key="item.validId"> {{item.validName}}</a-select-option>
              </a-select>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
const columns = [
  {
    title: '项目名称',
    dataIndex: 'projectName',
  }, {
    title: '批复金额',
    dataIndex: 'replyTotal',
  }
];
import {apiService} from "@/services/apiservice"
import SelectListModal from './SelectListModal'
import moment from 'moment';
export default {
    name: "BusinessBasicInfo",
    components: {
      SelectListModal,
    },
    data () {
        return {
            bureaus:[{"bureausCode":"0","bureaus":"费用"},{"bureausCode":"1","bureaus":"项目"}],//类型
            buyTypeName:'',// 类型名称
            feeTypeList:[{'feeTypeId':'1',"feeTypeName":'基础基础设施租赁费'},{'feeTypeId':'2',"feeTypeName":'专有软件、核心硬件升级及续保费'},{'feeTypeId':'3',"feeTypeName":'基础设施、应用系统和安全运维'},{'feeTypeId':'4',"feeTypeName":'集团信息系统运维'},{'feeTypeId':'5',"feeTypeName":'系统建设费'},], // 开支类型列表
            feeTypeName:'',// 开支类型名称
            bureausSel:"",//类型
            classifyName:"",//分类
            classify:"",
            validList:[{"validName":"有效","validId":"1"},{"validName":"无效","validId":"2"}], // 谈判是否有效列表
            validName: '',// 是否有效名称
            isOld:false,// 是否为老数据
            currentBiddingName:'',// 当前界面招投标名称(input框)
            mainPrjData:[], // 模态框中使用的项目列表
            columns, // 模态框列设置
            negotiationDate: !(this.businessBasicInfo.negotiationDate)?null:this.moment(this.formatDateTime(this.businessBasicInfo.negotiationDate), this.dateFormat),
        }
    },
    props: ['isEdit','id','businessBasicInfo','isNew'],
    computed: {
    },
    mounted(){
    },
    watch: {
      businessBasicInfo(val,info) {
        // 获取类型
        this.handleChangebureaus(this.businessBasicInfo.buyType)
        // 获取开支类型
        this.handleFeeTypeChange(this.businessBasicInfo.feeType)
        // 获取是否有效
        this.handleChangeValid(this.businessBasicInfo.isValid)
        if(this.isEdit){
          this.negotiationDate = this.moment(this.formatDateTime(this.businessBasicInfo.negotiationDate), this.dateFormat)
        }else{
          this.negotiationDate = this.formatDateTime(this.businessBasicInfo.negotiationDate)
        }
        // 判断是否是数据库里的老数据
        this.getIsOld()
      },
      feeTypeName(){
        this.businessBasicInfo.feeTypeName = this.feeTypeName
      }
    },
    created(){
    },
    methods: {
      // 通过项目名称和招投标名称判断是否为老数据
      getIsOld(){
        /*if(this.buyTypeName == '项目'){
          if(!this.businessBasicInfo.negotiationApplyName || !this.businessBasicInfo.negotiationName) return;
          if(!this.businessBasicInfo.negotiationApplyName.startsWith(this.businessBasicInfo.negotiationName) || !this.businessBasicInfo.negotiationApplyName.endsWith('商务谈判')) this.isOld = true
        }else if(this.buyTypeName == '费用'){
          if(!this.businessBasicInfo.negotiationApplyName || !this.businessBasicInfo.feeType) return;
          if(!this.businessBasicInfo.negotiationApplyName.startsWith(this.feeTypeName) || !this.businessBasicInfo.negotiationApplyName.endsWith('商务谈判')) this.isOld = true
        }*/
        if(!this.businessBasicInfo.editNegName) this.isOld = true

      },
      handleChangeNegotiationDate(value, dateString){
        var dateCurrent = dateString ? this.getDateTime(dateString) : null
        this.businessBasicInfo.negotiationDate = dateCurrent
      },
      // 根据是否有效Id获取是否有效名称
      getValidName(validId){
        if(validId == "1") return "有效"
        else if(validId == "2") return "无效"
        else return ''
      },
      // 根据开支类型ID获取开支类型名称
      getFeeTypeName(feeTypeId){
        if(feeTypeId == "1") return "基础基础设施租赁费"
        else if(feeTypeId == "2") return "专有软件、核心硬件升级及续保费"
        else if(feeTypeId == "3") return "基础设施、应用系统和安全运维"
        else if(feeTypeId == "4") return "集团信息系统运维"
        else if(feeTypeId == "5") return "系统建设费"
        else return ''
      },
      handleFeeTypeChange(value){ // 开支类型
        this.feeTypeName = this.getFeeTypeName(value)
        this.businessBasicInfo.feeType = value
      },
      handleChangeValid(value){//谈判有效
        this.validName = this.getValidName(value)
        this.businessBasicInfo.isValid = value
      },
      // 根据类型获取类型名称
      getBuyTypeName(buyType){
        if(buyType == "0") return "费用"
        else if(buyType == "1") return "项目"
        else return ''
      },
      handleChangebureausTotal(value){
        this.handleChangebureaus(value)
        // 切换类型的时候清空项目名称/开支类型 以及询比价名称的input框
        this.businessBasicInfo.editNegName = ''
        if(value == "0") {
          this.feeTypeName = ''
          this.businessBasicInfo.feeType = ''
        }else if(value == "1") this.businessBasicInfo.negotiationName = ''
      },
      // 切换select,根据类型value值获取名称
      handleChangebureaus(value){
        this.buyTypeName = this.getBuyTypeName(value)
        this.businessBasicInfo.buyType = value
      },
      getNameFromSon(data){
        this.businessBasicInfo.negotiationName = data
      },
      // 获取项目列表
      getMainProjectByProjectName(parmasData){
        var _self = this
        apiService.getMainProjectByProjectName(parmasData).then(r => {
          _self.mainPrjData=r.list
        }, r => {
        }).catch(
        )
      },
      // 格式化时间
      formatDateTime (currentTime) {
        var date = new Date(currentTime);
        var seperator1 = "-";
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = year + seperator1 + month + seperator1 + strDate;
        return currentdate;
      },
      getDateTime(currentTime) {
        var T = new Date(currentTime);
        return T.getTime()
      },
      moment,
    }
}
</script>