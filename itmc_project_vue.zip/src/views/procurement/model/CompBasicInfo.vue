<template>
  <div id="compBasicInfo">
    <div class="container" v-if="!isEdit" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">询比价编码</div>
            <div class="flexC">
              {{compBasicInfo.biddingNo}}
            </div>
            <div class="flexT">类型</div>
            <div class="flexC">
              {{buyTypeName}}
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">询比价项</div>
            <div class="flexC">
              {{comProjectName}}
            </div>
            <div class="flexT">分类</div>
            <div class="flexC">
              {{classifyName}}
            </div>
          </div>
          <div v-if="buyTypeName=='项目'" class="flexItems1">
            <div class="flexT">项目名称</div>
            <div class="flexC">
              {{compBasicInfo.biddingName}}
            </div>
          </div>
          <div v-if="buyTypeName=='费用'" class="flexItems1">
            <div class="flexT">开支类型名称</div>
            <div class="flexC">
              {{feeTypeName}}
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">询比价名称</div>
            <div class="flexC">
              {{compBasicInfo.binddingApplyName}}
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">商务联系人</div>
            <div class="flexC">
              {{compBasicInfo.businessContractor}}
            </div>
            <div class="flexT">
              技术联系人
            </div>
            <div class="flexC">
              {{compBasicInfo.techContractor}}
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">推荐厂商</div>
            <div class="flexC">
              <span>{{compBasicInfo.recommend}}</span>
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">技术对接时间</div>
            <div class="flexC">
              {{compBasicInfo.startDate}}
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container" v-if="isEdit" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">询比价编码</div>
            <div class="flexC">
              <input type="text" v-model="compBasicInfo.biddingNo" class="ant-input" style="width:200px">
            </div>
            <div class="flexT">类型</div>
            <div class="flexC">
              <a-select :value="buyTypeName" class="querySelect" @change="handleChangebureausTotal" style="width:200px">
                <a-select-option v-for="item in bureaus" :key="item.bureausCode"> {{item.bureaus}}</a-select-option>
              </a-select>
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">询比价项</div>
            <div class="flexC">
              <a-select :value="comProjectName" class="querySelect" @change="handleChangeComProject" style="width:200px">
                <a-select-option v-for="item in comProject" :key="item.id"> {{item.proName}}</a-select-option>
              </a-select>
            </div>
            <div class="flexT">分类</div>
            <div class="flexC">
              <a-input readonly style="width: 200px" v-model="classifyName"/>
              <a-button @click="showSoftOrHardModal()" class="ant-btn ant-btn-primary">选择</a-button>
            </div>
          </div>
          <div v-if="buyTypeName=='项目'" class="flexItems1">
            <div class="flexT">项目名称</div>
            <div class="flexC">
              <SelectListModal @selectMainContent="getNameFromSon" :mainPrjData="mainPrjData" :columns="columns" :biddingName="compBasicInfo.biddingName" :getMainProjectByProjectName="getMainProjectByProjectName"></SelectListModal>
            </div>
          </div>
          <div v-if="buyTypeName=='费用'" class="flexItems1">
            <div class="flexT">开支类型名称</div>
            <div class="flexC">
              <a-select :value="feeTypeName" @change="handleFeeTypeChange" class="querySelect" style="width:200px">
                  <a-select-option v-for="item in feeTypeList" :key="item.feeTypeId"> {{item.feeTypeName}}</a-select-option>
              </a-select>
            </div>
          </div>
          <!-- 非老数据的询比价名称显示编辑 -->
          <!-- <div v-if="buyTypeName && buyTypeName != '统采' && !isOld" class="flexItems1">
            <div class="flexT">询比价名称</div>
            <div class="flexC" v-if="buyTypeName == '项目'" style="border-right:0">{{compBasicInfo.biddingName}}</div>
            <div class="flexC" v-if="buyTypeName == '费用'" style="border-right:0">{{feeTypeName}}</div>
            <div class="flexT" style="background:#fff;border-right:0">
              <input type="text" class="ant-input" v-model="compBasicInfo.editBiddingName">
            </div>
            <div class="flexC">询比价</div>
          </div> -->
          <div v-if="buyTypeName && buyTypeName != '统采' && !isOld" class="flexItems1">
            <div class="flexT">询比价名称</div>
            <div class="flexC" v-if="buyTypeName == '项目'">
              {{compBasicInfo.biddingName}}
              <input style="width: 200px" type="text" class="ant-input" v-model="compBasicInfo.editBiddingName">
              <span>询比价</span>
            </div>
            <div class="flexC" v-if="buyTypeName == '费用'">
              {{feeTypeName}}
              <input style="width: 200px" type="text" class="ant-input" v-model="compBasicInfo.editBiddingName">
              <span>询比价</span>
            </div>
          </div>
          <!-- 老数据的询比价名称显示编辑 -->
          <div v-if="buyTypeName != '统采' && isOld" class="flexItems1">
            <div class="flexT">询比价名称</div>
            <div class="flexC">
              <input type="text" v-model="compBasicInfo.binddingApplyName" class="ant-input" >
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">商务联系人</div>
            <div class="flexC">
              <a-select v-model="compBasicInfo.businessContractor" @change="handleBusinessContractorChange" class="querySelect" style="width:200px">
                <a-select-option  v-if="item.bureausPerName" v-for="item in nameList" :key="item.bureausPerName"> {{item.bureausPerName}}</a-select-option>
              </a-select>
            </div>
            <div class="flexT">
              技术联系人
            </div>
            <div class="flexC">
              <a-select :value="compBasicInfo.techContractor" @change="handleTechContractorChange" class="querySelect" style="width:200px">
                <a-select-option v-if="item.bureausPerName" v-for="item in nameList" :key="item.bureausPerName"> {{item.bureausPerName}}</a-select-option>
              </a-select>
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">推荐厂商</div>
            <div class="flexC">
              <span>{{recommend}}</span>
              <a-button @click="showInvestmentSupplier()" class="ant-btn ant-btn-primary">选择</a-button>
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">技术对接时间</div>
            <div class="flexC">
              <a-date-picker placeholder="请选择日期" @change="handleStartDateChange" v-model="startDate"/>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 选择供应商模态框 -->
    <a-modal
      title="选择供应商"
      :width="900"
      centered
      cancelText="取消"
      okText="确认"
      @ok="() => selectInvestmentSupplier()"
      v-model="selectInvestmentModal">
      <div>
        <div style="flex: 1">
          <div>
            <a-input v-model="investmentSupplierSearch" style="width: 250px" />
            <a-button @click="showInvestmentSupplier()" type="primary" icon="search">查询</a-button>
          </div>
          <div style="margin-top: 10px">
            <div class="contentBos">
              <a-table style="width: 100%" bordered :columns="columns_investment" :dataSource="investmentSupplierList" :rowSelection="rowSelection" rowKey="uuid">
              </a-table>
            </div>
          </div>
        </div>
      </div>
    </a-modal>
    <!-- 分类模态框 -->
    <a-modal
      title="添加设备"
      :width="450"
      centered
      okText='添加'
      cancelText='取消'
      @ok="() => addConfigs()"
      v-model="softOrHardModal">
      <div style="height: 352px">
        <div id="affixTableBox">
          <div id="addTableTree">
            <div id="addTreeList" class="ztree mt10 affixTreeList" style="border: none;"> 
              <a-tree
                showLine
                :treeData="treeData"
                @select="onSelect"
              />
            </div>
          </div>
        </div>
      </div>
    </a-modal>
  </div>
</template>
<script>
const columns = [
  {
    title: '项目名称',
    dataIndex: 'projectName',
  }, {
    title: '批复金额',
    dataIndex: 'replyTotal',
  }
];
const columns_investment = [
  {
    title: '供应商名称',
    dataIndex: 'supplierName',
  }
];
import {apiService} from "@/services/apiservice"
import SelectListModal from './SelectListModal'
import Vue from 'vue';
import moment from 'moment';
export default {
    name: "CompBaSicInfo",
    components: {
      SelectListModal,
    },
    data () {
        return {
            bureaus:[{"bureausCode":"0","bureaus":"费用"},{"bureausCode":"1","bureaus":"项目"},{"bureausCode":"2","bureaus":"统采"}],
            feeTypeList:[{'feeTypeId':'1',"feeTypeName":'基础基础设施租赁费'},{'feeTypeId':'2',"feeTypeName":'专有软件、核心硬件升级及续保费'},{'feeTypeId':'3',"feeTypeName":'基础设施、应用系统和安全运维'},{'feeTypeId':'4',"feeTypeName":'集团信息系统运维'},{'feeTypeId':'5',"feeTypeName":'系统建设费'},],
            feeTypeName:'',
            bureausSel:"",//类型
            buyTypeName:'',// 类型名称
            classifyName:"",//分类名称
            classify:"",
            comProject:[{proName:'硬件',id:'1'},{proName:'软件',id:'2'}], // 询比价列表
            comProjectName:"",//询比价项名称
            selectModal:false, // 选择项目模态框
            mainPrjData:[], // 模态框中使用的项目列表
            investmentSupplierSearch:'', // 模态框搜索项——项目名称
            selectedRow: [], // 模态框中选中的行数据
            size:'default',
            columns, // 模态框列设置
            investmentSupplierList:[],// 供应商列表
            recommend:'',// 页面显示的供应商集合
            nameList:[],// 联系人列表
            selectInvestmentModal:false,// 选择供应商模态框
            columns_investment,
            selectedRows:[],//模态框选择的行数据
            softOrHardModal:false,
            treeData: [
            ],
            selectedSoftOrHard:[],
            isOld:false,
            currentBiddingName:'',// 当前界面询比价名称(input框)
            dateFormat: 'YYYY-MM-DD',
            startDate: !(this.compBasicInfo.startDate)?null:this.moment(this.formatDateTime(this.compBasicInfo.startDate), this.dateFormat),
        }
    },
    props: ['isEdit','id','compBasicInfo','isNew'],
    computed: {
      rowSelection() {
        const { selectedRowKeys } = this;
        return {
          onChange: (selectedRowKeys, selectedRows) => {
            this.selectedRows = selectedRows
            console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
          },
          getCheckboxProps: record => ({
            props: {
              name: record.name,
            }
          }),
        }
      }
    },
    watch: {
      compBasicInfo(val,info) {
        // 获取类型
        this.handleChangebureaus(this.compBasicInfo.buyType)
        // 获取询比价项
        this.handleChangeComProject(this.compBasicInfo.softOrHard)
        // 获取开支类型
        this.handleFeeTypeChange(this.compBasicInfo.feeType)
        // 判断是否是数据库里的老数据
        this.getIsOld()
        // 推荐厂商集合
        this.recommend = this.compBasicInfo.recommend
        // 获取分类信息
        this.classifyName = this.compBasicInfo.biddingItemName
        // 格式化时间
        if(this.isEdit){
          this.startDate = !(this.compBasicInfo.startDate)?null:this.moment(this.formatDateTime(this.compBasicInfo.startDate), this.dateFormat)
        }else{
          this.startDate = this.formatDateTime(this.compBasicInfo.startDate)
        }
      },
      feeTypeName(){
        this.compBasicInfo.feeTypeName = this.feeTypeName
      }
    },
    mounted(){
    },
    created(){
      // 获取联系人列表
      this.getNameS()
      // 获取供应商列表
      this.getItmcInvestmentSupplier()
    },
    methods: {
      // 通过项目名称和询比价名称判断是否为老数据
      getIsOld(){
        /*if(this.buyTypeName == '项目'){
          if(!this.compBasicInfo.binddingApplyName || !this.compBasicInfo.biddingName) return;
          if(!this.compBasicInfo.binddingApplyName.startsWith(this.compBasicInfo.biddingName) || !this.compBasicInfo.binddingApplyName.endsWith('询比价')) this.isOld = true
        }else if(this.buyTypeName == '费用'){
          if(!this.compBasicInfo.binddingApplyName || !this.compBasicInfo.feeType) return;
          if(!this.compBasicInfo.binddingApplyName.startsWith(this.feeTypeName) || !this.compBasicInfo.binddingApplyName.endsWith('询比价')) this.isOld = true
        }*/
        if(!this.compBasicInfo.editBiddingName) this.isOld = true
      },
      handleStartDateChange(mom,dateStr){
        this.compBasicInfo.startDate = dateStr ? this.getDateTime(dateStr) : null
        this.startDate = dateStr ? this.moment(dateStr, this.dateFormat): null
      },
      getNameFromSon(data){
        this.compBasicInfo.biddingName = data
      },
      handleBusinessContractorChange(value){ // 商务联系人
        if(value != ''){
          this.compBasicInfo.businessContractor = value
        }
      },
      handleTechContractorChange(value){ // 技术联系人
        if(value != ''){
          this.compBasicInfo.techContractor = value
        }
      },
      handleFeeTypeChange(value){ // 开支类型
        this.feeTypeName = this.getFeeTypeName(value)
        this.compBasicInfo.feeType = value
      },
      handleChangebureausTotal(value){//类型
        this.handleChangebureaus(value)
        // 切换类型的时候清空项目名称/开支类型 以及询比价名称的input框
        this.compBasicInfo.editBiddingName = ''
        if(value == "0") {
          this.feeTypeName = ''
          this.compBasicInfo.feeType = ''
        }else if(value == "1") this.compBasicInfo.biddingName = ''
      },
      handleChangebureaus(value){//类型
        this.buyTypeName = this.getBuyTypeName(value)
        this.compBasicInfo.buyType = value
      },
      handleChangeComProject(value){//询比价项
        this.comProjectName = this.getComProjectName(value)
        this.compBasicInfo.softOrHard = value
      },
      // 获取项目列表
      getMainProjectByProjectName(parmasData){
        var _self = this
        apiService.getMainProjectByProjectName(parmasData).then(r => {
          _self.mainPrjData=r.list
        }, r => {
        }).catch(
        )
      },
      // 获取供应商列表
      getItmcInvestmentSupplier(){
        var _self = this
        let params={supplierName:this.investmentSupplierSearch}
        params._json = true
        apiService.getItmcInvestmentSupplier(params).then(r => {
          _self.investmentSupplierList=r
        }, r => {
        }).catch(
        )
      },
      // 获取联系人列表
      getNameS(){
        var _self = this
        let params={}
        params._json = true
        apiService.getNameS(params).then(r => {
          _self.nameList=r
        }, r => {
        }).catch(
        )
      },
      // 显示选择供应商模态框
      showInvestmentSupplier(){
        this.selectInvestmentModal=true
        this.getItmcInvestmentSupplier()
      },
      // 根据类型获取类型名称
      getBuyTypeName(buyType){
        if(buyType == "0") return "费用"
        else if(buyType == "1") return "项目"
        else if(buyType == "2") return "统采"
        else return ''
      },
      // 根据询比价ID获取询比价名称
      getComProjectName(projectId){
        if(projectId == "2") return "软件"
        else if(projectId == "1") return "硬件"
        else return ''
      },
      // 根据开支类型ID获取开支类型名称
      getFeeTypeName(feeTypeId){
        if(feeTypeId == "1") return "基础基础设施租赁费"
        else if(feeTypeId == "2") return "专有软件、核心硬件升级及续保费"
        else if(feeTypeId == "3") return "基础设施、应用系统和安全运维"
        else if(feeTypeId == "4") return "集团信息系统运维"
        else if(feeTypeId == "5") return "系统建设费"
        else return ''
      },
      // 模态框确认按钮回调函数
      selectInvestmentSupplier(){
        var _self = this
        var investmentSupplierArr = this.recommend ? this.recommend.split('，') : [],
            investmentSupplierList = '';
        // 循环选中的内容将名称放到数组里
        _self.selectedRows.forEach((selectedRow) => {
          if(investmentSupplierArr.indexOf(selectedRow.supplierName) == -1) investmentSupplierArr.push(selectedRow.supplierName)
        })
        // 数组转换为字符串，显示和传给后台
        investmentSupplierList = investmentSupplierArr.join('，')
        this.recommend = investmentSupplierList
        this.compBasicInfo.recommend = investmentSupplierList
        this.selectInvestmentModal = false;
      },
      // 添加分类按钮点击事件
      showSoftOrHardModal(){
        this.softOrHardModal=true
        // 获取分类列表集合
        this.getSoftOrHardList()
      },
      // 获取软件/硬件数据，并渲染tree
      getSoftOrHardList(){
        let _self=this
        let parmasData={softOrHard:this.compBasicInfo.softOrHard}
        parmasData._json = true
        apiService.getSoftOrHardList(parmasData).then(r => {
          this.createAssetTree(r, _self.compBasicInfo.softOrHard) 
        }, r => {
        }).catch(
        )
      },
      // 渲染树函数
      createAssetTree(r, softOrHard)
      {
        // 硬件
        if(softOrHard == "1"){
          var equipment= r.investmentEquipmenttypeList[0] 
          var equinode= this.createNodes(equipment.deviceTypeName,
          equipment.deviceTypeId,
          equipment.deviceTypeList,equipment.deviceMainTypeId) ;
          Vue.set(this.treeData, 0, equinode);
        }else{
          // 软件
          var softwareData= r.investmentSoftwaretypeList[0] 
          var softnode= this.createNodes(softwareData.deviceTypeName,
          softwareData.deviceTypeId,
          softwareData.deviceTypeList,softwareData.deviceMainTypeId) ;
          Vue.set(this.treeData, 1, softnode);
        }
      },
      // 递归函数创建树节点
      createNodes(text,id,list,type)
      {
        let that =this;
        var node ={} ;
        node.title=text;
        node.key=id;
        node.type=type;
        node.children=[];
        if(list)
          list.forEach(function(c,index,data){
            node.children.push(
                that.createNodes(c.deviceTypeName,c.deviceTypeId,c.deviceTypeList,c.deviceMainTypeId))
          });
        return node;
      },
      // 选择分类复选框选择check事件
      onAddSelect(selectedKeys, info) {
        var _self = this;
        _self.selectedSoftOrHard = info.checkedNodes;
      },
      // 选择分类复选框选择select事件
      onSelect (selectedKeys, info) {
        let _self = this
        _self.selectedSoftOrHard = info.selectedNodes;
      },
      // 选择分类确认按钮回调函数
      addConfigs(){
        let _self = this
        var assetsTypeName = _self.selectedSoftOrHard[0].data.props.dataRef.title,
            assetsType = _self.selectedSoftOrHard[0].data.props.dataRef.key;

        this.classifyName = assetsTypeName
        _self.compBasicInfo.biddingItemName = assetsTypeName
        _self.softOrHardModal = false;
      },
      // 格式化时间
      formatDateTime (currentTime) {
        var date = new Date(currentTime);
        var seperator1 = "-";
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = year + seperator1 + month + seperator1 + strDate;
        return currentdate;
      },
      getDateTime(currentTime) {
        var T = new Date(currentTime);
        return T.getTime()
      },
      moment,
    }
}
</script>
<style>
#compBasicInfo .flexT {
  width: 200px;
}
</style>