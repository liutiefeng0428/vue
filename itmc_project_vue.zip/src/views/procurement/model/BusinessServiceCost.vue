<template>
  <div id="serviceCost" style="margin-bottom: 20px;position: relative;">
    <a-button v-if="isEdit" style="position: absolute;top: -38px;left: 76px;" @click="showAddModal()">新增</a-button>
    <div class="ant-table-content">
      <div class="ant-table-body">
        <table style="width: 100%">
          <thead class="ant-table-thead">
          <tr>
            <th style="width: 70px" rowspan="2" colspan="1" class="bableTh">人员级别</th>
            <th rowspan="1" colspan="3" class="bableTh"><div>谈判前</div></th>
            <th rowspan="1" colspan="3" class="bableTh"><div>谈判后</div></th>
            <th rowspan="1" colspan="3" class="bableTh"><div>最终汇报</div></th>
          </tr>
          <tr>
            <th style="width: 60px">工作量(人天)</th>
            <th style="width: 65px">取费标准(元/天)</th>
            <th style="width: 60px">小计(万元)</th>
            <th style="width: 60px">工作量(人天)</th>
            <th style="width: 65px">取费标准(元/天)</th>
            <th style="width: 60px">小计(万元)</th>
            <th style="width: 60px">工作量(人天)</th>
            <th style="width: 65px">取费标准(元/天)</th>
            <th style="width: 60px">小计(万元)</th>
          </tr>
          </thead>
          <tbody v-if="!isEdit" class="ant-table-tbody">
            <tr v-for="(term,index) in businessServiceCost">
              <td >
                <!-- <a-select v-model="term.personlevel" class="querySelect" @change="(v)=>handleChangePersonlevel(v,index)" style="width: 100%">
                  <a-select-option v-for="item in personlevelList" :key="item.levelCode"> {{item.level}}</a-select-option>
                </a-select> -->
                {{term.personlevelName}}
              </td>
              <!-- 谈判前 -->
              <td>
                {{term.workload}}<!-- 工作量 -->
              </td>
              <td>
                {{term.price}}<!-- 取费标准 -->
              </td>
              <td>
                {{term.priceSum}}<!-- 小计 -->
              </td>
              <!-- 谈判后 -->
              <td>
                {{term.negotiationWorkload}}<!-- 工作量 -->
              </td>
              <td>
                {{term.negotiationPrice}}<!-- 取费标准 -->
              </td>
              <td>
                {{term.negotiationPriceSum}}<!-- 小计 -->
              </td>
              <!-- 最终汇报 -->
              <td>
                {{term.finalWorkload}}<!-- 工作量 -->
              </td>
              <td>
                {{term.finalPrice}}<!-- 取费标准 -->
              </td>
              <td>
                {{term.finalPriceSum}}<!-- 小计 -->
              </td>
            </tr>
            <tr>
              <td>合计：</td>
              <td>{{workload}}</td>
              <td></td>
              <td>{{priceSum}}</td>
              <td>{{negotiationWorkload}}</td>
              <td></td>
              <td>{{negotiationPriceSum}}</td>
              <td>{{finalWorkload}}</td>
              <td></td>
              <td>{{finalPriceSum}}</td>
            </tr>
          </tbody>
          <tbody v-if="isEdit" class="ant-table-tbody">
            <tr v-for="(term,index) in businessServiceCost">
              <td >
                <!-- <a-select v-model="term.personlevel" class="querySelect" @change="(v)=>handleChangePersonlevel(v,index)" style="width: 100%">
                  <a-select-option v-for="item in personlevelList" :key="item.levelCode"> {{item.level}}</a-select-option>
                </a-select> -->
                {{term.personlevelName}}
              </td>
              <!-- 谈判前 -->
              <td>
                <!-- <a-input @change="calcTotalPrice(term.workload, term.price, index, 'priceSum')" v-model="term.workload" /> -->
                <a-input-number @change="calcTotalPrice(term.workload, term.price, index, 'priceSum')" v-model="term.workload" /><!-- 工作量 -->
              </td>
              <td>
                {{term.price}}<!-- 取费标准 -->
              </td>
              <td>
                {{term.priceSum}}<!-- 小计 -->
              </td>
              <!-- 谈判后 -->
              <td>
                <!-- <a-input @change="calcTotalPrice(term.negotiationWorkload, term.negotiationPrice, index, 'negotiationPriceSum')" v-model="term.negotiationWorkload" /> -->
                <a-input-number @change="calcTotalPrice(term.negotiationWorkload, term.negotiationPrice, index, 'negotiationPriceSum')" v-model="term.negotiationWorkload" /><!-- 工作量 -->
              </td>
              <td>
                <!-- <a-input @change="calcTotalPrice(term.negotiationWorkload, term.negotiationPrice, index, 'negotiationPriceSum')" v-model="term.negotiationPrice" /> -->
                <a-input-number @change="calcTotalPrice(term.negotiationWorkload, term.negotiationPrice, index, 'negotiationPriceSum')" v-model="term.negotiationPrice" /><!-- 取费标准 -->
              </td>
              <td>
                <a-input v-model="term.negotiationPriceSum" /><!-- 小计 -->
                <!-- <a-input-number v-model="term.negotiationPriceSum" /> -->
              </td>
              <!-- 最终汇报 -->
              <td>
                <!-- <a-input @change="calcTotalPrice(term.finalWorkload, term.finalPrice, index, 'finalPriceSum')" v-model="term.finalWorkload" /> -->
                <a-input-number @change="calcTotalPrice(term.finalWorkload, term.finalPrice, index, 'finalPriceSum')" v-model="term.finalWorkload" /><!-- 工作量 -->
              </td>
              <td>
                <!-- <a-input @change="calcTotalPrice(term.finalWorkload, term.finalPrice, index, 'finalPriceSum')" v-model="term.finalPrice" /> -->
                <a-input-number @change="calcTotalPrice(term.finalWorkload, term.finalPrice, index, 'finalPriceSum')" v-model="term.finalPrice" /><!-- 取费标准 -->
              </td>
              <td>
                <a-input v-model="term.finalPriceSum" /><!-- 小计 -->
                <!-- <a-input-number v-model="term.finalPriceSum" /> -->
              </td>
            </tr>
            <tr>
              <td>合计：</td>
              <td>{{workload}}</td>
              <td></td>
              <td>{{priceSum}}</td>
              <td>{{negotiationWorkload}}</td>
              <td></td>
              <td>{{negotiationPriceSum}}</td>
              <td>{{finalWorkload}}</td>
              <td></td>
              <td>{{finalPriceSum}}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <!-- 添加模态框 -->
    <a-modal
      title="选择设备"
      :width="900"
      centered
      okText='添加'
      cancelText='取消'
      @ok="() => addConfigs()"
      v-model="addModal">
      <div style="height: 352px">
        <div id="affixTableBox">
          <div style="margin-bottom: 20px;">
            <span>项目类型：</span>
            <a-select v-model="dataInfo.itemTypeName" placeholder="选择项目类型" class="querySelect" @change="handleChangeItemType" style="width:200px">
              <a-select-option v-for="item in itemTypeList" :key="item.typeCode"> {{item.type}}</a-select-option>
            </a-select>
          </div>
          <div id="affixTableData">
            <div id="affixTableList">
              <div>
                <a-table style="width: 100%;" ref="deleteMore" :pagination="false" bordered :columns="columns_addLevelList" :dataSource="addLevelListData" :rowSelection="levelRowSelection" rowKey="levelCode">
                </a-table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </a-modal>
  </div>
</template>
<script>
const columns_addLevelList = [
  {
    title: '人员级别',
    dataIndex: 'personLevelName',
    width: 160,
  }, {
    title: '取费标准(元天)',
    dataIndex: 'personMoney',
    width: 160,
  }
];
import {apiService} from "@/services/apiservice"
import SelectListModal from './SelectListModal'
import Vue from 'vue';
export default {
    name: "BusinessServiceCost",
    components: {
      SelectListModal,
    },
    data () {
        return {
            personlevelList:[{"levelCode":"CJYJ","level":"初级一级"},{"levelCode":"CJEJ","level":"初级二级"},{"levelCode":"ZJYJ","level":"中级一级"},{"levelCode":"ZJEJ","level":"中级二级"},{"levelCode":"GJYJ","level":"高级一级"},{"levelCode":"GJEJ","level":"高级二级"},{"levelCode":"ZZJYJ","level":"专家一级"},{"levelCode":"ZZJEJ","level":"专家二级"},{"levelCode":"JZDD","level":"基准低端"},{"levelCode":"JZZZ","level":"基准综合"},{"levelCode":"JZGD","level":"基准高端"}],// 人员级别列表
            itemTypeList:[{"typeCode":"GHZX","type":"规划与咨询"},{"typeCode":"SYTJ","type":"商业套件软件实施"},{"typeCode":"YXWH","type":"运行维护"},{"typeCode":"YYRJ","type":"应用软件定制研发"},],// 项目类型列表
            addModal:false,
            columns_addLevelList,// 新增模态框表列
            addLevelListData:[], // 新增模态框中表格列表
            selectedLevelKeys: [], // 新增模态框选中行key值列表
            selectedLevelRow: [], // 新增模态框选中行数据
            selectedRowKeys: [], 
            businessServiceCostCopy:[], // 当前界面赋值用，传给父组件

        }
    },
    props: ['isEdit','id','businessServiceCost','dataInfo','isNew'],
    computed: {
      levelRowSelection() {
        const { selectedRowKeys } = this;
        return {
          selectedRowKeys,
          onChange: (selectedRowKeys, selectedRows) => {
            this.selectedLevelRow = selectedRows;
            this.selectedRowKeys = selectedRowKeys;
          }
        }
      },
      // 谈判前工作量
      workload:{
        get: function(){
          let workload = 0;
          this.businessServiceCost.map((item) => {
            if(isNaN(item.workload) || item.workload.length == 0) item.workload = 0
            workload += parseFloat(item.workload)
          })
          return parseFloat(workload)
        },
        set:function(){
        }
      },
      // 谈判前小计
      priceSum:{
        get: function(){
          let priceSum = 0;
          this.businessServiceCost.map((item) => {
            if(isNaN(item.priceSum) || item.priceSum.length == 0) item.priceSum = 0
            priceSum += parseFloat(item.priceSum)
          })
          return parseFloat(priceSum).toFixed(4)
        },
        set:function(){
        }
      },
      // 谈判后工作量
      negotiationWorkload:{
        get: function(){
          let negotiationWorkload = 0;
          this.businessServiceCost.map((item) => {
            if(isNaN(item.negotiationWorkload) || item.negotiationWorkload.length == 0) item.negotiationWorkload = 0
            negotiationWorkload += parseFloat(item.negotiationWorkload)
          })
          return parseFloat(negotiationWorkload)
        },
        set:function(){
        }
      },
      // 谈判后小计
      negotiationPriceSum:{
        get: function(){
          let negotiationPriceSum = 0;
          this.businessServiceCost.map((item) => {
            if(isNaN(item.negotiationPriceSum) || item.negotiationPriceSum.length == 0) item.negotiationPriceSum = 0
            negotiationPriceSum += parseFloat(item.negotiationPriceSum)
          })
          return parseFloat(negotiationPriceSum).toFixed(4)
        },
        set:function(){
        }
      },
      // 最终汇报工作量
      finalWorkload:{
        get: function(){
          let finalWorkload = 0;
          this.businessServiceCost.map((item) => {
            if(isNaN(item.finalWorkload) || item.finalWorkload.length == 0) item.finalWorkload = 0
            finalWorkload += parseFloat(item.finalWorkload)
          })
          return parseFloat(finalWorkload)
        },
        set:function(){
        }
      },
      // 最终汇报小计
      finalPriceSum:{
        get: function(){
          let finalPriceSum = 0;
          this.businessServiceCost.map((item) => {
            if(isNaN(item.finalPriceSum) || item.finalPriceSum.length == 0) item.finalPriceSum = 0
            finalPriceSum += parseFloat(item.finalPriceSum)
          })
          return parseFloat(finalPriceSum).toFixed(4)
        },
        set:function(){
        }
      },
    },
    mounted(){
    },
    created(){
    },
    watch: {
      businessServiceCostCopy(val,info) {
        this.sendCostMsg()
      },
      businessServiceCost(val,info) {
        this.businessServiceCost.map((item) => {
          item.personlevelName = this.getPersonlevelName(item.personlevel)
          item.negotiatioPersonlevelName = this.getPersonlevelName(item.negotiatioPersonlevel)
          item.finalPersonlevelName = this.getPersonlevelName(item.finalPersonlevel)
        })
      },
      priceSum(val,info){
        this.$emit('priceSum',this.priceSum)
      },
      negotiationPriceSum(val,info){
        this.$emit('negotiationPriceSum',this.negotiationPriceSum)
      },
      finalPriceSum(val,info){
        this.$emit('finalPriceSum',this.finalPriceSum)
      },
    },
    methods: {
      // 将当前页面的数据发送到父组件
      sendCostMsg(){
         this.$emit('businessServiceCostCopy',this.businessServiceCostCopy)
      },
      // 谈判前人员切换
      handleChangePersonlevel(value, index){
        this.businessServiceCost[index].personlevelName = this.getPersonlevelName(value)
        this.businessServiceCost[index].personlevel = value
      },
      // 谈判后人员切换
      handleChangeNegotiatioPersonlevelName(value){
        this.businessServiceCost.negotiatioPersonlevelName = this.getPersonlevelName(value)
        this.businessServiceCost.negotiatioPersonlevel = value
      },
      // 最终汇报人员切换
      handleChangeFinalPersonlevelName(value){
        this.businessServiceCost.finalPersonlevelName = this.getPersonlevelName(value)
        this.businessServiceCost.finalPersonlevel = value
      },
      // 表格列表当前行小计
      calcTotalPrice(unitPrice, number, index, changeName){
        this.businessServiceCost[index][changeName] = (parseFloat(unitPrice)*parseFloat(number)/10000).toFixed(4);
      },
      // 根据项目类型获取人员级别列表
      getPersonLevelList(parmasData){
        var _self = this
        apiService.getPersonLevelList(parmasData).then(r => {
          _self.addLevelListData=r
        }, r => {
        }).catch(
        )
      },
      // 添加模态框中切换项目类型事件
      handleChangeItemType(value){
        this.dataInfo.itemTypeName = this.getItemTypeName(value)
        this.dataInfo.itemType = value
        this.dataInfo.itemTypeCode = value
        let parmas = {itemTypeCode: value}
        // parmas._json=true
        this.getPersonLevelList(parmas)
      },
      // 点击新增按钮显示新增模态框
      showAddModal(){
        this.dataInfo.itemTypeName = this.dataInfo.itemTypeName ? this.dataInfo.itemTypeName : '规划与咨询'
        this.dataInfo.itemTypeCode = this.dataInfo.itemTypeCode ? this.dataInfo.itemTypeCode : 'GHZX'
        let parmas = {itemTypeCode: this.dataInfo.itemTypeCode}
        this.getPersonLevelList(parmas)
        this.addModal = true
      },
      // 模态框确认按钮的回调事件
      addConfigs(){
          var _self = this;
          var index = _self.businessServiceCost.length;
          var businessServiceCostCopy = this.businessServiceCost.concat()
          for(var i=0; i<_self.selectedLevelRow.length; i++){
            Vue.set(businessServiceCostCopy, index, {
              feeDesc: "",
              feeOrder: "",
              finalPersonlevel: "",
              finalPrice: "",
              finalPriceSum: "",
              finalWorkload: "",
              id: "",
              itemType: _self.selectedLevelRow[i].itemTypeCode,
              itemTypeCode: _self.selectedLevelRow[i].itemTypeCode,
              itemTypeName: _self.selectedLevelRow[i].itemTypeName,
              negotiatioPersonlevel: "",
              negotiationId: "",
              negotiationPrice: "",
              negotiationPriceSum: "",
              negotiationWorkload: "",
              personlevel:_self.selectedLevelRow[i].personLevelCode,
              personlevelName:_self.selectedLevelRow[i].personLevelName,
              price: _self.selectedLevelRow[i].personMoney,
              priceSum: "",
              workload: "",
            })
            index++;
          }
          console.log(this.levelRowSelection)
          console.log(this.selectedRowKeys)
          this.selectedRowKeys = []
          // this.businessServiceCostCopy = this.unique(businessServiceCostCopy, 'personlevel');
          this.businessServiceCostCopy = businessServiceCostCopy;
          _self.addModal = false;
      },
      // 根据唯一标识过滤数组
      unique(arr, name) {
        var hash = {};
        return arr.reduce(function (item, next) {
          hash[next[name]] ? '' : hash[next[name]] = true && item.push(next);
          return item;
        }, []);
      },
      // 根据人员级别ID获取人员级别名称
      getPersonlevelName(personlevelId){
        if(personlevelId == "CJYJ") return "初级一级"
        else if(personlevelId == "CJEJ") return "初级二级"
        else if(personlevelId == "ZJYJ") return "中级一级"
        else if(personlevelId == "ZJEJ") return "中级二级"
        else if(personlevelId == "GJYJ") return "高级一级"
        else if(personlevelId == "GJEJ") return "高级二级"
        else if(personlevelId == "ZZJYJ") return "专家一级"
        else if(personlevelId == "ZZJEJ") return "专家二级"
        else if(personlevelId == "JZDD") return "基准低端"
        else if(personlevelId == "JZZZ") return "基准综合"
        else if(personlevelId == "JZGD") return "基准高端"
        else return ''
      },
      // 根据项目类型ID获取项目类型名称
      getItemTypeName(itemTypeId){
        if(itemTypeId == "GHZX") return "规划与咨询"
        else if(itemTypeId == "SYTJ") return "商业套件软件实施"
        else if(itemTypeId == "YXWH") return "运行维护"
        else if(itemTypeId == "YYRJ") return "应用软件定制研发"
        else return ''
      },
    }
}
</script>
<style>
#serviceCost .ant-table-tbody>tr>td, #serviceCost .ant-table-thead>tr>th {
  padding: 3px 2px!important;
}
#serviceCost .ant-input-number {
  height:28px;
}
#serviceCost .ant-input-number .ant-input-number-input {
  height:26px;
}
.itemTypeSelect{
  position: absolute;
  top: -38px;
  left: 148px;
}
</style>