<template>
  <div>
    <div class="container" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT" style="flex: 4">谈判前报价</div>
            <div class="flexC">{{businessPriceCompare.beforeNegQuote}}</div>
            <div class="flexT" style="flex: 4">优化价</div>
            <div class="flexC">{{businessPriceCompare.afterNegQuote}}</div>
            <div class="flexT" style="flex: 4">谈判汇报价</div>
            <div class="flexC">{{businessPriceCompare.finalNegQuote}}</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import {apiService} from "@/services/apiservice"
export default {
    name: "BusinessPriceCompare",
    components: {
    },
    data () {
        return {
            bureaus:[{"bureausCode":"0","bureaus":"费用"},{"bureausCode":"1","bureaus":"项目"},{"bureausCode":"2","bureaus":"统采"}],
            bureausSel:"",//类型
        }
    },
    props: ['isEdit','isNew','id','businessPriceCompare','priceSum','negotiationPriceSum','finalPriceSum','beforeTotal','afterTotal','finalTotal'],
    computed: {
    },
    watch: {
        priceSum(val, info){
            if(!this.beforeTotal) this.beforeTotal = 0
            if(!this.priceSum) this.priceSum = 0
            this.businessPriceCompare.beforeNegQuote = parseFloat(this.beforeTotal) + parseFloat(this.priceSum)
        },
        beforeTotal(val, info){
            if(!this.beforeTotal) this.beforeTotal = 0
            if(!this.priceSum) this.priceSum = 0
            this.businessPriceCompare.beforeNegQuote = parseFloat(this.beforeTotal) + parseFloat(this.priceSum)
        },
        negotiationPriceSum(val, info){
            if(!this.afterTotal) this.afterTotal = 0
            if(!this.negotiationPriceSum) this.negotiationPriceSum = 0
            this.businessPriceCompare.afterNegQuote = parseFloat(this.afterTotal) + parseFloat(this.negotiationPriceSum)
        },
        afterTotal(val, info){
            if(!this.afterTotal) this.afterTotal = 0
            if(!this.negotiationPriceSum) this.negotiationPriceSum = 0
            this.businessPriceCompare.afterNegQuote = parseFloat(this.afterTotal) + parseFloat(this.negotiationPriceSum)
        },
        finalPriceSum(val, info){
            if(!this.finalTotal) this.finalTotal = 0
            if(!this.finalPriceSum) this.finalPriceSum = 0
            this.businessPriceCompare.finalNegQuote = parseFloat(this.finalTotal) + parseFloat(this.finalPriceSum)
        },
        finalTotal(val, info){
            if(!this.finalTotal) this.finalTotal = 0
            if(!this.finalPriceSum) this.finalPriceSum = 0
            this.businessPriceCompare.finalNegQuote = parseFloat(this.finalTotal) + parseFloat(this.finalPriceSum)
        },
    },
    mounted(){
    },
    created(){
    },
    methods: {
    }
}
</script>