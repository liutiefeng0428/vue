<template>
  <div id="uploadFileBox" style="margin-bottom: 20px">
    <div class="ant-table-content">
      <div class="ant-table-body">
        <table style="width: 100%">
          <thead class="ant-table-thead">
          <tr>
            <th rowspan="1" style="width: 250px"><div>文档类型</div></th>
            <th rowspan="1" style="width: 300px" ><div>文档名称</div></th>
            <th rowspan="1" style="width: 150px"><div>上传人</div></th>
            <th rowspan="1" style="width: 150px"><div>上传时间</div></th>
            <th v-if="isEdit" rowspan="1" colspan="2" style="width: 150px"><div>操作</div></th>
          </tr>
          </thead>
          <tbody class="ant-table-tbody">
            <template v-if="docTypeList" v-for="(item,index) in docTypeList">
              <tr :key='index'>
                <td :title="item.fileTypeName" :rowspan="item.fileList.length"> <!-- 文档类型 -->
                  {{item.fileTypeName}}
                </td>
                <td :title="item.fileName" class="fileName"> <!-- 文档名称 -->
                  <a @click="downloadFile(item.fileList[0].OssItemUrl)">{{item.fileList[0].fileName}}</a>
                </td>
                <td> <!-- 上传人 -->
                  <span class="ecllipsis">
                    {{item.fileList[0].createUserName}}
                  </span>
                </td>
                <td> <!-- 上传时间 -->
                  {{item.fileList[0].createTime}}
                </td>
                <td v-if="isEdit"> <!-- 删除按钮 -->
                  <a-popconfirm  okText="确定" cancelText="取消" v-if="item.fileList[0].fileName" title="确定删除吗?" @confirm="() => handleDelete(item.fileList[0].fileId)">
                    <a>删除</a>
                  </a-popconfirm>
                  <span style="cursor: pointer;" v-else>删除</span>
                </td>
                <td v-if="isEdit" :rowspan="item.fileList.length"> <!-- 上传按钮 -->
                  <a @click="triggerImport(index,item)" icon="upload">上传</a>
                </td>
              </tr>
              <tr v-for="(ele,inx) in item.fileList.length-1" :key="index+'-'+inx">
                <td class="fileName"> <!-- 文档名称 -->
                  <a @click="downloadFile(item.fileList[ele].OssItemUrl)">{{item.fileList[ele].fileName}}</a>
                </td>
                <td> <!-- 上传人 -->
                  <span class="ecllipsis">
                    {{item.fileList[ele].createUserName}}
                  </span>
                </td>
                <td> <!-- 上传时间 -->
                  {{item.fileList[ele].createTime}}
                </td>
                <td v-if="isEdit"> <!-- 删除按钮 -->
                  <a-popconfirm okText="确定" cancelText="取消" title="确定删除吗?" @confirm="() => handleDelete(item.fileList[ele].fileId)">
                    <a>删除</a>
                  </a-popconfirm>
                </td>
              </tr>
            </template>
          </tbody>
        </table>
      </div>
    </div>
    <a-modal
      title="上传文件"
      :width="600"
      centered
      v-model="expVisible"
      @ok="() => uploadFile()"
      @cancel="() => setVersionVisible(false)"
      okText="保存"
      cancelText="取消"
    >
      <div>
        <div class="clearfix">
          <a-upload
            :multiple="true"
            :fileList="fileList"
            :remove="handleRemove"
            :beforeUpload="beforeUpload"
          >
            <a-button>
              <a-icon type="upload"/>
              上传
           </a-button>
          </a-upload>
        </div>

      </div>
    </a-modal>
  </div>
</template>
<script>
import {apiService} from "@/services/apiservice";
import reqwest from 'reqwest'

import Vue from 'vue';
export default {
    name: "UploadFile",
    data () {
        return {
            fileList: [],
            files:null,
            expVisible:false,//上传弹框
            docTypeList: [], // 当前页文档信息列表
            uploadIndex: 0,
            docTypeString:'', // 传给后台使用的文档类型集合
            docType:'', // 文档分类编码
            docTypeName:'', // 文档分类名称
            businessTypeName:'', // 业务类型名称
        }
    },
    components: {
    },
    props: ['isEdit','relationId','businessType'],
    computed: {
    },
    mounted(){
    },
    methods: {
        // 点击删除按钮函数
        handleDelete(fileId){
          this.delDocumentById(fileId)
        },
        // 删除函数
        delDocumentById(fileId){
          let docTypeParmas = "id="+fileId
          apiService.delDocumentById(docTypeParmas).then(r => {
            this.getDocAndDocTypeJson()
          }, r => {
          }).catch(
          )
        },
        // 点击上传按钮函数
        triggerImport(index,item){
          this.uploadIndex = index
          this.docTypeName = item.fileTypeName
          this.docType = item.fileTypeCode
          this.expVisible=true
        },
        // 点击移除文件时的回调
        handleRemove(file) {
          const index = this.fileList.indexOf(file);
          const newFileList = this.fileList.slice();
          newFileList.splice(index, 1);
          this.fileList = newFileList
        },
        // 上传文件之前的钩子
        beforeUpload(file) {
          // this.handleRemove(this.files) //保证只能上传一个文件
          this.files=file
          this.fileList = [...this.fileList, file]
          return false;
        },
        // 模态框取消按钮回调函数 关闭模态框
        setVersionVisible(){
          this.expVisible=false
        },
        // 模态框确认按钮回调函数 保存文件
        uploadFile(){
          let _self=this
          const { fileList } = this;
          const formData = new FormData();
          fileList.forEach((file) => {
            formData.append('files',file);
          })
          formData.append('relationId',this.relationId)
          formData.append('docTypeName',this.docTypeName)
          formData.append('docType',this.docType)
          formData.append('businessType',this.businessType)
          formData.append('businessTypeName',this.businessTypeName)
          console.log(fileList)
          reqwest({
            url: '/project/itmcDocument/uploadFile',
            method: 'post',
            processData: false,
            data: formData,
            success: (r) => {
              if(r.code=='200'){
                _self.fileList = []
                _self.$message.success('上传成功');
                this.getDocAndDocTypeJson()
                _self.expVisible=false
              } else {
                _self.$message.success(r.message);
              }
            },
            error: () => {
              _self.messageInfo="上传失败"
              _self.showMessage=true
              setTimeout(function () {
                _self.showMessage=false
              },800)
              _self.expVisible=false
            },
          });
        },
        // (编辑)获取文档和文档类型
        getDocAndDocTypeJson(){
          let _self=this
          let docTypeParmas="businessType="+this.businessType+"&relationId="+this.relationId+"&docType="
          apiService.getDocAndDocTypeJson(docTypeParmas).then(r => {
            if(r.result.doctype){
              _self.docTypeList = r.result.doctype
              _self.businessTypeName = r.result.typeName
            }
          }, r => {
          }).catch(
          )
        },
        // (查看)获取文档和文档类型
        getDocAndDocTypeUploadedJson(){
          let _self=this
          let docTypeParmas="businessType="+this.businessType+"&relationId="+this.relationId+"&docType="
          apiService.getDocAndDocTypeUploadedJson(docTypeParmas).then(r => {
            if(r.result.doctype){
              _self.docTypeList = r.result.doctype
              _self.businessTypeName = r.result.typeName
            }
          }, r => {
          }).catch(
          )
        },
        downloadFile(url){
          let _self=this
          window.location.href=url
        },
    },
    created(){
      // 获取文档和文档类型
      if(this.isEdit) this.getDocAndDocTypeJson()
      else this.getDocAndDocTypeUploadedJson()
    }
}
</script>
<style>
  #uploadFileBox table {
    table-layout: fixed;
  }
  #uploadFileBox table td {
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }
  #uploadFileBox table .fileName {
    text-align: left;
  }
</style>