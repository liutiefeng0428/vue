<template>
  <div>

    <a-input readonly style="width: 200px" v-model="selectMainContent"/>
    <a-button @click="showSelectModal()" class="ant-btn ant-btn-primary">选择</a-button>
    <!-- 选择项目模态框 -->
    <a-modal
      title="选择项目"
      :width="900"
      centered
      cancelText="取消"
      okText="确认"
      @ok="() => saveProjectName()"
      v-model="selectModal">
      <div>
        <div style="flex: 1">
          <div>
            <a-input v-model="projectNameSearch" style="width: 250px" />
            <a-button @click="showSelectModal()" type="primary" icon="search">查询</a-button>
          </div>
          <div style="margin-top: 10px">
            <div class="contentBos">
              <a-table style="width: 100%" bordered :columns="columns" :dataSource="mainPrjData" :rowSelection="rowSelection" rowKey="uuid">
              </a-table>
            </div>
          </div>
        </div>
      </div>
    </a-modal>
  </div>
</template>
<script>
import {apiService} from "@/services/apiservice";
 
import Vue from 'vue';
export default {
    name: "SelectListModal",
    data () {
        return {
            selectModal:false, // 选择项目模态框
            projectNameSearch:'', // 模态框搜索项——项目名称
            selectedRow: [], // 模态框中选中的行数据
            selectMainContent: ''
        }
    },
    props: ['mainPrjData','columns','biddingName', 'getMainProjectByProjectName'],
    computed: {
      rowSelection() {
        const { selectedRowKeys } = this;
        return {
          type: 'radio',
          onChange: (selectedRowKeys, selectedRows) => {
            this.selectedRows = selectedRows;
            console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
          },
          getCheckboxProps: record => ({
            props: {
              name: record.name,
            }
          }),
        }
      }
    },
    watch: {
      biddingName(val,info) {
        this.selectMainContent = val
      },
    },
    mounted(){
      // this.reset();
      // this.optionDateSelect=this.optionDate[0].optionName
    },
    created(){
    },
    methods: {
      // 获取表格列表数据
      showSelectModal(){
        this.selectModal=true
        var projectInfo = {projectName: this.projectNameSearch, rows: 5, page: 1}
        this.getMainProjectByProjectName(projectInfo)
      },
      // 模态框确认按钮回调函数
      saveProjectName(){
        this.selectMainContent = this.selectedRows[0].projectName;
        this.sendMsg(this.selectMainContent)
        this.selectModal = false;
      },
      sendMsg(selectMainContent){
        this.$emit('selectMainContent', selectMainContent)
      }
    }
}
</script>