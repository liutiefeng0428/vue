<template>
  <div id="softOrHardListModal">
    <a-button style="position: absolute;top: -38px;left: 76px;" @click="showAddModal">新增</a-button>
    <!-- 添加模态框 -->
    <a-modal
      title="添加设备"
      :width="450"
      centered
      okText='添加'
      cancelText='取消'
      @ok="() => addConfigs1()"
      v-model="addModal">
      <div style="height: 352px">
        <div id="affixTableBox">
          <div id="addTableTree">
            <div >
              <span class="demandline"></span>
              <span class="demandtitle">设备分类</span>
            </div>
            <div id="addTreeList" class="ztree mt10 affixTreeList" style="border: none;"> 
              <a-tree
                v-if="!isSingle"
                showLine
                :treeData="treeData"
                @check="onAddSelect"
                checkable
                :checkStrictly="true"
                v-model="selectedKeys"
              />
              <a-tree
                v-else
                showLine
                :treeData="treeData"
                @select="onAddSelect"
              />
            </div>
          </div>
        </div>
      </div>
    </a-modal>
  </div>
</template>
<script>

import {apiService} from "@/services/apiservice"
import Vue from 'vue';
export default {
    name: "SoftAndHardListModal",
    components: {
    },
    data () {
        return {
            addModal:false,
            addProductRow: [],
            selectedKeys:[],
            treeData: [
              { title: '硬件分类', key: '0'},
              { title: '软件分类', key: '1'},
            ],
        }
    },
    props: ['isSingle'],
    computed: {
    },
    watch: {
    },
    mounted(){
    },
    created(){
    },
    methods: {
      // 添加设备复选框选择check事件
      onAddSelect(selectedKeys, info) {
        var _self = this;
        _self.selectedKeys = selectedKeys
        if(this.isSingle){
          _self.addProductRow = info.selectedNodes;
        }else{
          _self.addProductRow = info.checkedNodes;
        }
      },
      // 添加按钮点击事件
      showAddModal(){
        this.selectedKeys = []
        this.addProductRow = []
        this.addModal=true
        this.getItmcInvestmentDevicetypeList()
      },
      // 获取软件/硬件数据，并渲染tree
      getItmcInvestmentDevicetypeList(){
        let _self=this
        let parmasData={deviceType:0, deviceTypeId:''}
        apiService.getItmcInvestmentDevicetypeList(parmasData).then(r => {
          this.createAssetTree(r) 
        }, r => {
        }).catch(
        )
      },
      // 渲染树函数
      createAssetTree(r)
      {
        // 硬件
        var equipment= r.investmentEquipmenttypeList[0] 
        var equinode= this.createNodes(equipment.deviceTypeName,
        equipment.deviceTypeId,
        equipment.deviceTypeList,equipment.deviceMainTypeId) ;
        Vue.set(this.treeData, 0, equinode);
        // 软件
        var softwareData= r.investmentSoftwaretypeList[0] 
        var softnode= this.createNodes(softwareData.deviceTypeName,
        softwareData.deviceTypeId,
        softwareData.deviceTypeList,equipment.deviceMainTypeId) ;
        Vue.set(this.treeData, 1, softnode);
      },
      // 递归函数创建树节点
      createNodes(text,id,list,type)
      {
        let that =this;
        var node ={} ;
        node.title=text;
        node.key=id;
        node.type=type;
        node.children=[];
        // if(list) node.disableCheckbox = true
        if(list)
          list.forEach(function(c,index,data){
            node.children.push(
                that.createNodes(c.deviceTypeName,c.deviceTypeId,c.deviceTypeList,c.deviceMainTypeId))
          });
        return node;
      },
      // 添加设备确认按钮回调函数
      addConfigs1(){
        let _self = this
        this.$emit('addProductRow', _self.addProductRow)
        _self.addModal = false;
      },
    }
}
</script>