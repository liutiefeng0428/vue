<template>
  <div style="position: relative;">
    <a-button v-if="isEdit" style="position: absolute;top: -38px;left: 80px;" @click="showInvestmentSupplier()" icon="upload">选择</a-button>
    <div style="margin-bottom: 20px">
      <div class="ant-table-content">
        <div class="ant-table-body">
          <table style="width: 100%">
            <thead class="ant-table-thead">
            <tr>
              <th v-if="winFirmInfo[0] && winFirmInfo[0].bidOrder" rowspan="1" class=""><div>中标顺序</div></th>
              <th rowspan="1" class=""><div>中标厂商</div></th>
              <th rowspan="1" class=""><div>设备总价合计(元)</div></th>
              <th rowspan="1" class=""><div>操作</div></th>
            </tr>
            </thead>
            <tbody class="ant-table-tbody">
            <tr v-for="(item,index) in winFirmInfo" :key='index'>
              <td v-if="item.bidOrder">{{'第'+item.bidOrder+'中标厂商'}}</td>
              <td>{{item.supplierName}}</td>
              <td>
                  <span class="ecllipsis">
                    {{item.sumBiddingPrice}}
                  </span>
              </td>
              <td>
                <span><a @click="showEquipment(id, item.supplierId)">管理设备</a></span>
              </td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <!-- 选择供应商模态框 -->
    <a-modal
      title="选择供应商"
      :width="900"
      centered
      cancelText="取消"
      okText="确认"
      @ok="() => selectInvestmentSupplier()"
      v-model="selectInvestmentModal">
      <div>
        <div style="flex: 1">
          <div>
            <a-input v-model="investmentSupplierSearch" style="width: 250px" />
            <a-button @click="showInvestmentSupplier()" type="primary" icon="search">查询</a-button>
          </div>
          <div style="margin-top: 10px">
            <div class="contentBos">
              <a-table style="width: 100%" bordered :columns="columns_investment" :dataSource="investmentSupplierList" :rowSelection="rowSelection" rowKey="uuid">
              </a-table>
            </div>
          </div>
        </div>
      </div>
    </a-modal>
    <a-drawer
      title="设备管理"
      width="calc(100% - 200px)"
      @close="onClose"
      :visible="visible"
      :wrapStyle="{height: 'calc(100% - 108px)',overflow: 'auto',paddingBottom: '108px'}"
    >
      <ShowEquipmentList :isEdit="isEdit" @visibleChild="getStatusFromSon" :visible="visible" :binddingId="id" :supplierId="supplierId"></ShowEquipmentList>
    </a-drawer>
  </div>
</template>
<script>
const columns_investment = [
  {
    title: '供应商名称',
    dataIndex: 'supplierName',
  }
];

import {apiService} from "@/services/apiservice"
import ShowEquipmentList from "./ShowEquipmentList"
import Vue from "vue"

export default {
    name: "WinFirm",
    components: {
      ShowEquipmentList
    },
    data () {
        return {
          selectInvestmentModal:false,// 选择供应商模态框
          investmentSupplierList:[],// 供应商列表
          columns_investment,
          investmentSupplierSearch:'', // 模态框搜索项——项目名称
          visible:false,
          binddingId:'',
          supplierId:'',
          selectedRowKeys:[],
          selectedRows:[],
        }
    },
    props: ['isEdit','id','winFirmInfo','isNew'],
    computed: {
      rowSelection() {
        const { selectedRowKeys } = this;
        return {
          selectedRowKeys,
          onChange: (selectedRowKeys, selectedRows) => {
            this.selectedRowKeys = selectedRowKeys
            this.selectedRows = selectedRows
            console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
          },
          getCheckboxProps: record => ({
            props: {
              name: record.name,
            }
          }),
        }
      }
    },
    mounted(){
      // this.reset();
      // this.optionDateSelect=this.optionDate[0].optionName
    },
    created(){
    },
    methods: {
      // 获取供应商列表
      getItmcInvestmentSupplier(){
        var _self = this
        let params={supplierName:this.investmentSupplierSearch}
        params._json = true
        apiService.getItmcInvestmentSupplier(params).then(r => {
          _self.investmentSupplierList=r
        }, r => {
        }).catch(
        )
      },
      // 模态框确认按钮回调函数
      selectInvestmentSupplier(){
        var _self = this
        var length = _self.winFirmInfo.length
        console.log(_self.selectedRows)
        _self.selectedRows.forEach((selectedRow) => {
          Vue.set(_self.winFirmInfo, length, {
            "bidOrder": 0,
            "biddingId": this.id,
            "deliverDate": null,
            "factoryName": null,
            "isBid": 0,
            "isDel": 0,
            "sumBiddingPrice": null,
            "supplierId": selectedRow.id,
            "supplierName": selectedRow.supplierName,
            "supplierOrder": 0,
            "supplierStatus": 0,
          })
          length++
        })
        this.selectInvestmentModal = false;
      },
      // 显示选择供应商模态框
      showInvestmentSupplier(){
        this.selectedRowKeys = []
        this.selectedRows = []
        this.selectInvestmentModal=true
        this.getItmcInvestmentSupplier()
      },
      showEquipment(binddingId, supplierId){
        this.supplierId = supplierId
        this.visible = true
        // this.$router.push({path: "/show-equipment", query: {binddingId: binddingId, supplierId: supplierId}})
      },
      getStatusFromSon(data){
        this.visible = data
      },
      onClose(){
        this.visible = false
      }
    }
}
</script>