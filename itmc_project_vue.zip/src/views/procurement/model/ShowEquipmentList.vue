<template>
  <div class="">
    <div class="con-title">
      <span class="divdLine"></span>
      <span>设备管理</span>
      <!-- <a-button style="margin-left:10px;" @click="toAdd()">新增</a-button> -->
    </div>
    <div style="position: relative;">
      <SoftAndHardListModal v-if="isEdit" :isSingle="true" @addProductRow="getSoftOrHardListFromSon"></SoftAndHardListModal>
      <div id="showEquipment">
        <div class="ant-table-content">
          <div class="ant-table-body">
            <table style="width: 100%;">
              <thead class="ant-table-thead">
                <tr>
                  <th style="width: 100px;" rowspan="2" class=""><div>类型</div></th>
                  <th style="width: 80px;" rowspan="2" class=""><div>配置名称</div></th>
                  <th style="width: 100px;" rowspan="2" class=""><div>产品名称</div></th>
                  <th style="width: 60px;" rowspan="2" class=""><div>品牌</div></th>
                  <th style="width: 60px;" rowspan="2" class=""><div>型号</div></th>
                  <th style="width: 100px;" rowspan="2" class=""><div>配置指标</div></th>
                  <th style="width: 50px;" rowspan="2" class=""><div>数量</div></th>
                  <th style="width: 60px;" rowspan="2" class=""><div>单价</div></th>
                  <th style="width: 50px;" rowspan="2" class=""><div>折扣</div></th>
                  <th style="width: 60px;" rowspan="2" class=""><div>价格</div></th>
                  <th style="width: 60px;" rowspan="2" class=""><div>折后价</div></th>
                  <th style="width: 50px;" rowspan="2" class=""><div>设备数量</div></th>
                  <th style="width: 60px;" rowspan="2" class=""><div>总价</div></th>
                  <th v-if="isEdit" style="width: 80px;" rowspan="2" class=""><div>操作</div></th>
                </tr>
              </thead>
              <tbody class="ant-table-tbody">
                <template v-for="(item,index) in equipmentList">
                  <tr :key='index'>
                    <td :title="item.deviceTypeName" :rowspan="item.configList.length"><!-- 类型 -->
                        {{item.deviceTypeName}}
                    </td>
                    <td :title="item.configName" :rowspan="item.configList.length"><!-- 配置名称 -->
                      <span class="ecllipsis">
                        {{item.configName}}
                      </span>
                    </td>
                    <td :title="item.brandName" :rowspan="item.configList.length"><!-- 产品名称 -->
                      <span class="ecllipsis">
                        {{item.brandName}}
                      </span>
                    </td>
                    <td :title="item.pinPai" :rowspan="item.configList.length"><!-- 品牌 -->
                      {{item.pinPai}}
                    </td>
                    <td :title="item.productDesc" :rowspan="item.configList.length"><!-- 型号 -->
                      {{item.productDesc}}
                    </td>
                    <td :title="item.configList[0].configDesc"><!-- 配置指标 -->
                      <span class="ecllipsis">
                        {{item.configList[0].configDesc}}
                      </span>
                    </td>
                    <td :title="item.configList[0].configQuantity"><!-- 数量 -->
                      {{item.configList[0].configQuantity}}
                    </td>
                    <td :title="item.configList[0].configPrice"><!-- 单价 -->
                      {{item.configList[0].configPrice}}
                    </td>
                    <td :title="item.configList[0].configDiscount"><!-- 折扣 -->
                      {{item.configList[0].configDiscount}}
                    </td>
                    <td :title="item.price" :rowspan="item.configList.length"><!-- 价格 -->
                      {{item.price}}
                    </td>
                    <td :title="item.discountPrice" :rowspan="item.configList.length"><!-- 折后价 -->
                      {{item.discountPrice}}
                    </td>
                    <td :title="item.quantity" :rowspan="item.configList.length"><!-- 设备数量 -->
                      {{item.quantity}}
                    </td>
                    <td :title="item.totalPrice" :rowspan="item.configList.length"><!-- 总价 -->
                      {{item.totalPrice}}
                    </td>
                    <td v-if="isEdit" :rowspan="item.configList.length"> <!-- 操作按钮 -->
                      <a @click="editConfigs(index,item)" icon="upload">编辑</a>
                      <a-popconfirm placement="left" okText="确定" cancelText="取消" title="确定删除吗?" @confirm="() => handleDelete(index, item)">
                        <a>删除</a>
                      </a-popconfirm>
                    </td>
                  </tr>
                  <tr v-for="(ele,inx) in item.configList.length-1" :key="index+'-'+inx">
                    <td :title="item.configList[ele].configDesc"><!-- 配置指标 -->
                      <span class="ecllipsis">
                        {{item.configList[ele].configDesc}}
                      </span>
                    </td>
                    <td :title="item.configList[ele].configQuantity"><!-- 数量 -->
                      {{item.configList[ele].configQuantity}}
                    </td>
                    <td :title="item.configList[ele].configPrice"><!-- 单价 -->
                      {{item.configList[ele].configPrice}}
                    </td>
                    <td :title="item.configList[ele].configDiscount"><!-- 折扣 -->
                      {{item.configList[ele].configDiscount}}
                    </td>
                  </tr>
                </template>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- 设备配置编辑模态框 -->
    <a-modal
      title="设备配置编辑"
      :width="900"
      centered
      okText='添加'
      cancelText='取消'
      @ok="() => addAndEditConfigs()"
      v-model="setModal">
      <div style="height: 330px">
        <div>
          <div>
            <div class="container" style="margin-bottom: 20px;display: flex;padding: 0">
              <div style="flex: 1">
                <div class="flexBox1">
                  <div class="flexItems1">
                    <div style="width: 150px;" class="flexT">类型</div>
                    <div class="flexC">
                      <input type="text" v-if="!isEditConfig" v-model="deviceConfig.deviceTypeName" class="ant-input" style="width:200px">
                      <span v-else>{{deviceConfig.deviceTypeName}}</span>
                    </div>
                    <div style="width: 150px;" class="flexT">配置名称</div>
                    <div class="flexC">
                      <input type="text" v-model="deviceConfig.configName" class="ant-input" style="width:200px">
                    </div>
                  </div>
                  <div class="flexItems1">
                    <div style="width: 150px;" class="flexT">产品名称</div>
                    <div class="flexC">
                      <input type="text" v-model="deviceConfig.brandName" class="ant-input" style="width:200px">
                    </div>
                    <div style="width: 150px;" class="flexT">品牌</div>
                    <div class="flexC">
                      <input type="text" v-model="deviceConfig.pinPai" class="ant-input" style="width:200px">
                    </div>
                  </div>
                  <div class="flexItems1">
                    <div style="width: 150px;" class="flexT">型号</div>
                    <div class="flexC">
                      <input type="text" v-model="deviceConfig.productDesc" class="ant-input" style="width:200px">
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- 添加配置表格 -->
            <div>
              <div class="ant-table-content">
                <div class="ant-table-body">
                  <table style="width: 100%; table-layout: fixed;">
                    <thead class="ant-table-thead">
                      <tr>
                        <th class=""><div>配置指标</div></th>
                        <th class=""><div>单价</div></th>
                        <th class=""><div>数量</div></th>
                        <th class=""><div>折扣</div></th>
                        <th class=""><div>操作</div></th>
                      </tr>
                    </thead>
                    <tbody class="ant-table-tbody">
                      <tr  v-for="(item,index) in deviceConfig.biddingDeviceConfigList">
                        <td>
                          <a-input v-model="item.configDesc" />
                        </td>
                        <td>
                          <!-- <a-input v-model="item.price" /> -->
                          <a-input-number v-model="item.price" />
                        </td>
                        <td>
                          <!-- <a-input v-model="item.quantity" /> -->
                          <a-input-number v-model="item.quantity" />
                        </td>
                        <td>
                          <!-- <a-input v-model="item.discount" /> -->
                          <a-input-number v-model="item.discount" />
                        </td>
                        <td>
                          <a @click="addDeviceConfig(index)">添加</a>
                          <a v-if="deviceConfig.biddingDeviceConfigList.length > 1" @click="deleteDeviceConfig(index)">删除</a>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div class="container" style="margin-bottom: 20px;display: flex;padding: 0">
              <div style="flex: 1">
                <div class="flexBox1">
                  <div class="flexItems1">
                    <div style="width: 100px;" class="flexT">价格</div>
                    <div class="flexC">
                      <!-- <input type="text" v-model="priceTotal" class="ant-input" style="width: 150px;"> -->
                      <a-input-number v-model="priceTotal" style="width: 150px;" />
                    </div>
                    <div style="width: 100px;" class="flexT">折扣后价格</div>
                    <div class="flexC">
                      <!-- <input type="text" v-model="discountPriceTotal" class="ant-input" style="width: 150px;"> -->
                      <a-input-number v-model="discountPriceTotal" style="width: 150px;" />
                    </div>
                    <div style="width: 100px;" class="flexT">数量</div>
                    <div class="flexC">
                      <!-- <input type="text" v-model="deviceConfig.quantity" class="ant-input" style="width: 150px;"> -->
                      <a-input-number v-model="deviceConfig.quantity" style="width: 150px;" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </a-modal>
    <div class="container" style="text-align: center;margin-top: 20px">
      <div>
        <a-button @click="onClose">返回</a-button>
        <a-button v-if="isEdit" type="primary" >保存</a-button>
      </div>
    </div>
  </div>
</template>
<script>
  import {apiService} from "@/services/apiservice"
  import SoftAndHardListModal from './SoftAndHardListModal'
  import Vue from 'vue';
export default {
    name: "showEquipment",
    components: {
      SoftAndHardListModal
    },
    data () {
        return {
            bureausSel:"", //类型
            softAndHardList:[],
            equipmentList:[], // 展示设备列表
            configName:'', // 设备名称
            brandName:'', // 产品名称
            isAccessories:'', // 是否为配件

            setModal:false, // 设备配置编辑模态框
            deviceConfig:{},// 模态框——数据对象
            price:'',// 模态框——价格
            discountPrice:'',// 模态框——折后价格
            totalPrice:'',// 模态框——总价格
            visibleChild: true,
            isEditConfig: false,

        }
    },
    props: ['binddingId', 'supplierId', 'isEdit'],
    computed: {
      // 模态框——价格
      priceTotal:{
        get: function(){
          let priceTotal = 0;
          if(this.deviceConfig.biddingDeviceConfigList && this.deviceConfig.biddingDeviceConfigList.length > 0){
            this.deviceConfig.biddingDeviceConfigList.map((item) => {
              if(isNaN(item.price) || (item.price.length == 0)) item.price = 0
              if((item.quantity.length == 0) || isNaN(item.quantity)) item.quantity = 0
              priceTotal += (parseFloat(item.price) * parseInt(item.quantity))
            })
            return parseFloat(priceTotal).toFixed(2)
          }
        },
        set:function(){
        }
      },
      // 模态框——折后价格
      discountPriceTotal:{
        get: function(){
          let discountPriceTotal = 0;
          if(this.deviceConfig.biddingDeviceConfigList && this.deviceConfig.biddingDeviceConfigList.length > 0){
            this.deviceConfig.biddingDeviceConfigList.map((item) => {
              if(isNaN(item.price) || !item.price ) item.price = 0
              if(isNaN(item.quantity) || !item.quantity) item.quantity = 0
              if(isNaN(item.discount) || !item.discount) item.discount = 0
              discountPriceTotal += (parseFloat(item.price) * parseInt(item.quantity) * parseFloat(item.discount))
            })
            return parseFloat(discountPriceTotal).toFixed(2)
          }
        },
        set:function(){
        }
      },
    },
    watch: {
      softAndHardList(val,info){
        var _self = this
        var index = _self.deviceConfig.length
        _self.deviceConfig = Object.assign({},{
          "binddingId": this.binddingId,
          "brandName": '',
          "configName": '',
          "deviceOrder": '',
          "deviceTypeName": val[0].data.props.dataRef.title,
          "deviceType": val[0].data.props.dataRef.key,
          "discount": '',
          "discountPrice": '',
          "dollarPrice": '',
          "id": '',
          "isAccessories": '',
          "pinPai": "",
          "price": "",
          "productDesc": '',
          "quantity": '',
          "softOrHard": '',
          "supplierName":'',
          "softOrHard": val[0].data.props.dataRef.type,
          "biddingDeviceConfigList":[{
            "binddingDeviceId": '',
            "configDesc": '',
            "configOrder": '',
            "discount": "",
            "id": "",
            "price": '',
            "quantity": '',
            "rmbOrDoller": '',
          }]
        });
      }
    },
    mounted(){
    },
    created(){
      // let parmasData = {binddingId:'A470F4BF-7625-48EA-B896-A06642687917', supplierId:'4652a784-9e2f-48fe-9786-ee59df38a38c', configName:this.configName, brandName: this.brandName, isAccessories: this.isAccessories}
      let parmasData = {binddingId:'2327B707-16CC-4963-AD82-4463D24587A0', supplierId:'56da0c1a-36a2-45c2-937a-0cf24416ab50', configName:this.configName, brandName: this.brandName, isAccessories: this.isAccessories}
      parmasData._json = true
      this.geiBiddingDeviceList(parmasData)
    },
    methods: {
      // 表格列表当前行小计
      calcTotalPrice(unitPrice, number, index, changeName){
        this.businessSoftAndHardCost[index][changeName] = (parseFloat(unitPrice)*parseFloat(number)/10000).toFixed(4);
      },
      // 新增按钮点击事件
      toAdd(){

      },
      // 获取设备_中标商设备列表
      geiBiddingDeviceList(params){
        apiService.geiBiddingDeviceList(params).then(r => {
            this.equipmentList = r.result.deviceList
        }, r => {
        }).catch(
        )
      },
      // 招投标/询比价设备_编辑修改设备
      updateBiddingDevice(params){
        apiService.updateBiddingDevice(params).then(r => {
        }, r => {
        }).catch(
        )
      },
      // 招投标/询比价设备新增_保存设备
      saveBiddingDevice(params){
        apiService.saveBiddingDevice(params).then(r => {
        }, r => {
        }).catch(
        )
      },
      // 删除函数
      delBiddingDevice(fileId){
        let docTypeParmas = "id="+fileId
        apiService.delBiddingDevice(docTypeParmas).then(r => {
          this.toDelete()
        }, r => {
        }).catch(
        )
      },
      toDelete(index){
        this.businessSoftAndHardCost.splice(index, 1)
      },
      // 设备管理界面设备删除事件
      handleDelete(index, item){
        this.equipmentList.splice(index, 1)
      },
      // 模态框中添加一行配置指标
      addDeviceConfig(index){
        var _self = this
        var length = _self.deviceConfig.biddingDeviceConfigList.length;
        Vue.set(_self.deviceConfig.biddingDeviceConfigList, length, {
          "binddingDeviceId": '',
          "configDesc": '',
          "configOrder": '',
          "discount": "",
          "id": "",
          "price": '',
          "quantity": '',
          "rmbOrDoller": '',
        })
      },
      // 模态框点击确认按钮在表格中添加一条数据
      addAndEditConfigs(){
        var _self = this
        var length = _self.equipmentList.length
        Vue.set(_self.equipmentList, length, {
          "binddingId": _self.deviceConfig.binddingId,
          "brandName": _self.deviceConfig.brandName,
          "configName": _self.deviceConfig.configName,
          "deviceId": _self.deviceConfig.deviceId,
          "deviceOrder": _self.deviceConfig.deviceOrder,
          "deviceTypeName": _self.deviceConfig.deviceTypeName,
          "deviceType": _self.deviceConfig.deviceType,
          "discountPrice": _self.discountPriceTotal,
          "dollarPrice": _self.deviceConfig.dollarPrice,
          "isAccessories": _self.deviceConfig.isAccessories,
          "pinPai":  _self.deviceConfig.pinPai,
          "price":  _self.priceTotal,
          "productDesc": _self.deviceConfig.productDesc,
          "quantity": _self.deviceConfig.quantity,
          "softOrHard": _self.deviceConfig.softOrHard,
          "totalPrice":parseInt(_self.deviceConfig.quantity)*(_self.discountPriceTotal),
          "configList":[],
        })
        _self.deviceConfig.biddingDeviceConfigList.forEach(function(val, index){
          Vue.set(_self.equipmentList[length].configList, index, {
            "binddingDeviceId": val.binddingDeviceId,
            "configDesc": val.configDesc,
            "configOrder": val.configOrder,
            "configDiscount": val.discount,
            "configId": val.id,
            "configPrice": val.price,
            "configQuantity": val.quantity,
            "rmbOrDoller": val.rmbOrDoller,
          })
        })
        this.setModal = false
      },
      // 模态框中删除一行配置指标
      deleteDeviceConfig(index){
        var _self = this
        _self.deviceConfig.biddingDeviceConfigList.splice(index, 1)
      },
      // 从子组件获取选中的设备信息
      getSoftOrHardListFromSon(data){
        console.log(data)
          this.softAndHardList = data
          this.setModal = true
      },
      onClose(){
        this.visibleChild = false
        this.$emit('visibleChild', this.visibleChild)
      },
      editConfigs(index, item){
        this.isEditConfig = true
        this.setModal = true
      },
    }
}
</script>
<style>
.ecllipsis{
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  width:120px;
  display: inline-block;
}
#showEquipment .ant-table-tbody>tr>td, #showEquipment .ant-table-thead>tr>th {
  padding:3px 3px!important;
}
.ant-input-number {
  height:28px;
  width:100%;
}
</style>