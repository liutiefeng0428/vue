<template>
  <div>
    <div class="container" v-if="!isEdit" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">招投标编码</div>
            <div class="flexC">
              {{tendBasicInfo.biddingNo}}
            </div>
            <div class="flexT">类型</div>
            <div class="flexC">
              {{buyTypeName}}
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">招投标项</div>
            <div class="flexC">
              {{comProjectName}}
            </div>
            <div class="flexT">分类</div>
            <div class="flexC">
              {{classifyName}}
            </div>
          </div>
          <div v-if="buyTypeName=='项目'" class="flexItems1">
            <div class="flexT">项目名称</div>
            <div class="flexC">
              {{tendBasicInfo.biddingName}}
            </div>
          </div>
          <div v-if="buyTypeName=='费用'" class="flexItems1">
            <div class="flexT">开支类型名称</div>
            <div class="flexC">
              {{feeTypeName}}
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">招投标名称</div>
            <div class="flexC">
              {{tendBasicInfo.binddingApplyName}}
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container" v-if="isEdit" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">招投标编码</div>
            <div class="flexC">
              <input type="text" v-model="tendBasicInfo.biddingNo" class="ant-input" style="width:200px">
            </div>
            <div class="flexT">类型</div>
            <div class="flexC">
              <a-select :value="buyTypeName" class="querySelect" @change="handleChangebureausTotal" style="width:200px">
                <a-select-option v-for="item in bureaus" :key="item.bureausCode"> {{item.bureaus}}</a-select-option>
              </a-select>
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">招投标项</div>
            <div class="flexC">
              <a-select :value="comProjectName" class="querySelect" @change="handleChangeComProject" style="width:200px">
                <a-select-option v-for="item in comProject" :key="item.id"> {{item.proName}}</a-select-option>
              </a-select>
            </div>
            <div class="flexT">分类</div>
            <div class="flexC">
              <a-input readonly style="width: 200px" v-model="classifyName"/>
              <a-button @click="showSoftOrHardModal()" class="ant-btn ant-btn-primary">选择</a-button>
            </div>
          </div>
          <div v-if="buyTypeName=='项目'" class="flexItems1">
            <div class="flexT">项目名称</div>
            <div class="flexC">
              <SelectListModal @selectMainContent="getNameFromSon" :mainPrjData="mainPrjData" :columns="columns" :biddingName="tendBasicInfo.biddingName" :getMainProjectByProjectName="getMainProjectByProjectName"></SelectListModal>
            </div>
          </div>
          <div v-if="buyTypeName=='费用'" class="flexItems1">
            <div class="flexT">开支类型名称</div>
            <div class="flexC">
              <a-select :value="feeTypeName" @change="handleFeeTypeChange" class="querySelect" style="width:200px">
                  <a-select-option v-for="item in feeTypeList" :key="item.feeTypeId"> {{item.feeTypeName}}</a-select-option>
              </a-select>
            </div>
          </div>
          <!-- 非老数据的招投标名称显示编辑 -->
          <!-- <div v-if="buyTypeName && buyTypeName != '统采' && !isOld" class="flexItems1">
            <div class="flexT">招投标名称</div>
            <div class="flexC" v-if="buyTypeName == '项目'" style="border-right:0">{{tendBasicInfo.biddingName}}</div>
            <div class="flexC" v-if="buyTypeName == '费用'" style="border-right:0">{{feeTypeName}}</div>
            <div class="flexT" style="background:#fff;border-right:0">
              <input type="text"  v-model="tendBasicInfo.editBiddingName" class="ant-input" >
            </div>
            <div class="flexC">招投标</div>
          </div> -->
          <div v-if="buyTypeName && buyTypeName != '统采' && !isOld" class="flexItems1">
            <div class="flexT">招投标名称</div>
            <div class="flexC" v-if="buyTypeName == '项目'">
              {{tendBasicInfo.biddingName}}
              <input style="width: 200px" type="text" class="ant-input" v-model="tendBasicInfo.editBiddingName">
              <span>招投标</span>
            </div>
            <div class="flexC" v-if="buyTypeName == '费用'">
              {{feeTypeName}}
              <input style="width: 200px" type="text" class="ant-input" v-model="tendBasicInfo.editBiddingName">
              <span>招投标</span>
            </div>
          </div>
          <!-- 老数据的招投标名称显示编辑 -->
          <div v-if="buyTypeName != '统采' && isOld" class="flexItems1">
            <div class="flexT">招投标名称</div>
            <div class="flexC">
              <input type="text" v-model="tendBasicInfo.binddingApplyName" class="ant-input" >
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 添加模态框 -->
    <a-modal
      title="添加设备"
      :width="450"
      centered
      okText='添加'
      cancelText='取消'
      @ok="() => addConfigs()"
      v-model="softOrHardModal">
      <div style="height: 352px">
        <div id="affixTableBox">
          <div id="addTableTree">
            <div id="addTreeList" class="ztree mt10 affixTreeList" style="border: none;"> 
              <a-tree
                showLine
                :treeData="treeData"
                @select="onSelect"
              />
            </div>
          </div>
        </div>
      </div>
    </a-modal>
  </div>
</template>
<script>
const columns = [
  {
    title: '项目名称',
    dataIndex: 'projectName',
  }, {
    title: '批复金额',
    dataIndex: 'replyTotal',
  }
];
import {apiService} from "@/services/apiservice"
import SelectListModal from './SelectListModal'
import Vue from 'vue';
export default {
    name: "TendBaSicInfo",
    components: {
      SelectListModal,
    },
    data () {
        return {
            bureaus:[{"bureausCode":"0","bureaus":"费用"},{"bureausCode":"1","bureaus":"项目"},{"bureausCode":"2","bureaus":"统采"}],
            feeTypeList:[{'feeTypeId':'1',"feeTypeName":'基础基础设施租赁费'},{'feeTypeId':'2',"feeTypeName":'专有软件、核心硬件升级及续保费'},{'feeTypeId':'3',"feeTypeName":'基础设施、应用系统和安全运维'},{'feeTypeId':'4',"feeTypeName":'集团信息系统运维'},{'feeTypeId':'5',"feeTypeName":'系统建设费'},],
            feeTypeName:'',
            buyTypeName:'',// 类型名称
            classifyName:"",//分类名称
            classify:"",
            comProject:[{proName:'硬件',id:'1'},{proName:'软件',id:'2'}],
            comProjectName:"",//招投标项名称
            mainPrjData:[], // 模态框中使用的项目列表
            investmentSupplierSearch:'', // 模态框搜索项——项目名称
            selectedRow: [], // 模态框中选中的行数据
            size:'default',
            columns, // 模态框列设置
            investmentSupplierList:[],// 供应商列表
            recommend:'',// 页面显示的供应商集合
            nameList:[],// 联系人列表
            selectInvestmentModal:false,// 选择供应商模态框
            selectedRows:[],//模态框选择的行数据
            softOrHardModal:false,
            treeData: [
            ],
            selectedSoftOrHard:[],
            isOld:false,// 是否为老数据
            currentBiddingName:'',// 当前界面招投标名称(input框)
        }
    },
    props: ['isEdit','id','tendBasicInfo','isNew'],
    computed: {
      rowSelection() {
        const { selectedRowKeys } = this;
        return {
          type: 'radio',
          onChange: (selectedRowKeys, selectedRows) => {
            this.selectedRows = selectedRows;
            console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
          },
          getCheckboxProps: record => ({
            props: {
              name: record.name,
            }
          }),
        }
      }
    },
    watch: {
      tendBasicInfo(val,info) {
        // 获取类型
        this.handleChangebureaus(this.tendBasicInfo.buyType)
        // 获取招投标项
        this.handleChangeComProject(this.tendBasicInfo.softOrHard)
        // 获取开支类型
        this.handleFeeTypeChange(this.tendBasicInfo.feeType)
        // 判断是否是数据库里的老数据
        this.getIsOld()
        // 获取分类信息
        this.classifyName = this.tendBasicInfo.biddingItemName
      },
      feeTypeName(){
        this.tendBasicInfo.feeTypeName = this.feeTypeName
      }
    },
    mounted(){
    },
    created(){
    },
    methods: {
      // 通过项目名称和招投标名称判断是否为老数据
      getIsOld(){
        /*if(this.buyTypeName == '项目'){
          if(!this.tendBasicInfo.binddingApplyName || !this.tendBasicInfo.biddingName) return;
          if(!this.tendBasicInfo.binddingApplyName.startsWith(this.tendBasicInfo.biddingName) || !this.tendBasicInfo.binddingApplyName.endsWith('招投标')) this.isOld = true
        }else if(this.buyTypeName == '费用'){
          if(!this.tendBasicInfo.binddingApplyName || !this.tendBasicInfo.feeType) return;
          if(!this.tendBasicInfo.binddingApplyName.startsWith(this.feeTypeName) || !this.tendBasicInfo.binddingApplyName.endsWith('招投标')) this.isOld = true
        }*/
        if(!this.tendBasicInfo.editBiddingName) this.isOld = true
      },
      getNameFromSon(data){
          this.tendBasicInfo.biddingName = data
      },
      handleFeeTypeChange(value){ // 开支类型
          this.feeTypeName = this.getFeeTypeName(value)
          this.tendBasicInfo.feeType = value
      },
      handleChangebureausTotal(value){//类型
        this.handleChangebureaus(value)
        // 切换类型的时候清空项目名称/开支类型 以及询比价名称的input框
        this.tendBasicInfo.editBiddingName = ''
        if(value == "0") {
          this.feeTypeName = ''
          this.tendBasicInfo.feeType = ''
        }else if(value == "1") this.tendBasicInfo.biddingName = ''
      },
      handleChangebureaus(value){//类型
          this.buyTypeName = this.getBuyTypeName(value)
          this.tendBasicInfo.buyType = value
      },
      handleChangeComProject(value){//招投标项
          this.comProjectName = this.getComProjectName(value)
          this.tendBasicInfo.softOrHard = value
      },
      // 获取项目列表
      getMainProjectByProjectName(parmasData){
        var _self = this
        apiService.getMainProjectByProjectName(parmasData).then(r => {
          _self.mainPrjData=r.list
        }, r => {
        }).catch(
        )
      },
      // 根据类型获取类型名称
      getBuyTypeName(buyType){
        if(buyType == "0") return "费用"
        else if(buyType == "1") return "项目"
        else if(buyType == "2") return "统采"
        else return ''
      },
      // 根据招投标ID获取招投标名称
      getComProjectName(projectId){
        if(projectId == "1") return "硬件"
        else if(projectId == "2") return "软件"
        else return ''
      },
      // 根据开支类型ID获取开支类型名称
      getFeeTypeName(feeTypeId){
        if(feeTypeId == "1") return "基础基础设施租赁费"
        else if(feeTypeId == "2") return "专有软件、核心硬件升级及续保费"
        else if(feeTypeId == "3") return "基础设施、应用系统和安全运维"
        else if(feeTypeId == "4") return "集团信息系统运维"
        else if(feeTypeId == "5") return "系统建设费"
        else return ''
      },
      // 添加分类按钮点击事件
      showSoftOrHardModal(){
        this.softOrHardModal=true
        // 获取分类列表集合
        this.getSoftOrHardList()
      },
      // 获取软件/硬件数据，并渲染tree
      getSoftOrHardList(){
        let _self=this
        let parmasData={softOrHard:this.tendBasicInfo.softOrHard}
        parmasData._json = true
        apiService.getSoftOrHardList(parmasData).then(r => {
          this.createAssetTree(r, _self.tendBasicInfo.softOrHard) 
        }, r => {
        }).catch(
        )
      },
      // 渲染树函数
      createAssetTree(r, softOrHard)
      {
        // 硬件
        if(softOrHard == "1"){
          var equipment= r.investmentEquipmenttypeList[0] 
          var equinode= this.createNodes(equipment.deviceTypeName,
          equipment.deviceTypeId,
          equipment.deviceTypeList,equipment.deviceMainTypeId) ;
          Vue.set(this.treeData, 0, equinode);
        }else{
          // 软件
          var softwareData= r.investmentSoftwaretypeList[0] 
          var softnode= this.createNodes(softwareData.deviceTypeName,
          softwareData.deviceTypeId,
          softwareData.deviceTypeList,softwareData.deviceMainTypeId) ;
          Vue.set(this.treeData, 1, softnode);
        }
      },
      // 递归函数创建树节点
      createNodes(text,id,list,type)
      {
        let that =this;
        var node ={} ;
        node.title=text;
        node.key=id;
        node.type=type;
        node.children=[];
        if(list)
          list.forEach(function(c,index,data){
            node.children.push(
                that.createNodes(c.deviceTypeName,c.deviceTypeId,c.deviceTypeList,c.deviceMainTypeId))
          });
        return node;
      },
      // 添加设备复选框选择check事件
      onAddSelect(selectedKeys, info) {
        var _self = this;
        _self.selectedSoftOrHard = info.checkedNodes;
      },
      // 添加设备复选框选择select事件
      onSelect (selectedKeys, info) {
        let _self = this
        _self.selectedSoftOrHard = info.selectedNodes;
      },
      // 添加设备确认按钮回调函数
      addConfigs(){
        let _self = this
        var assetsTypeName = _self.selectedSoftOrHard[0].data.props.dataRef.title,
            assetsType = _self.selectedSoftOrHard[0].data.props.dataRef.key;

        this.classifyName = assetsTypeName
        _self.tendBasicInfo.biddingItemName = assetsType
        _self.softOrHardModal = false;
      },
    }
}
</script>