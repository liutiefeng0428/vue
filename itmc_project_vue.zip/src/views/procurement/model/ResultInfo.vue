<template>
  <div id="resultInfo">
    <div v-if="!isEdit" class="container" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">有效期</div>
            <div class="flexC">
              {{periodStartDate + '至' + periodEndDate}}
            </div>
            
            <div class="flexT">是否有效</div>
            <div class="flexC">
              {{validName}}
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-if="isEdit" class="container" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">有效期</div>
            <div class="flexC">
              <a-date-picker
                format="YYYY-MM-DD"
                :value="periodStartDate"
                placeholder="开始日期"
                @change="handleStartDateChange"
              />
              <a-date-picker
                format="YYYY-MM-DD"
                placeholder="结束日期"
                :value="periodEndDate"
                @change="handleEndDateChange"
              />
            </div>
            
            <div class="flexT">是否有效</div>
            <div class="flexC">
              <a-select :value="validName" class="querySelect" @change="handleChangeValid" style="width:200px">
                <a-select-option v-for="item in validList" :key="item.validId"> {{item.validName}}</a-select-option>
              </a-select>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import {apiService} from "@/services/apiservice"
import Vue from 'vue';
import moment from 'moment';

export default {
    name: "ResultInfo",
    components: {
    },
    data () {
        return {
            validList:[{"validName":"有效","validId":"1"},{"validName":"无效","validId":"2"}], // 是否有效列表
            validName: '',// 是否有效名称
            dateFormat: 'YYYY-MM-DD',
            periodStartDate: !(this.resultInfo.periodStartDate)?null:this.moment(this.formatDateTime(this.resultInfo.periodStartDate), this.dateFormat),
            periodEndDate: !(this.resultInfo.periodEndDate)?null:this.moment(this.formatDateTime(this.resultInfo.periodEndDate), this.dateFormat),
        }
    },
    props: ['isEdit','id','resultInfo','isNew'],
    computed: {
    },
    watch: {
      resultInfo(val, info){
        if(this.isEdit){
          this.periodStartDate = !(this.resultInfo.periodStartDate)?null:this.moment(this.formatDateTime(this.resultInfo.periodStartDate), this.dateFormat)
          this.periodEndDate = !(this.resultInfo.periodEndDate)?null:this.moment(this.formatDateTime(this.resultInfo.periodEndDate), this.dateFormat)
        }else{
          this.periodStartDate = this.formatDateTime(this.resultInfo.periodStartDate)
          this.periodEndDate = this.formatDateTime(this.resultInfo.periodEndDate)
        }
        this.validName = this.getValidName(this.resultInfo.isValid)
      }
    },
    mounted(){
    },
    created(){
    },
    methods: {
      handleChangeValid(value){//类型
        if(value != ''){
          this.validName = this.getValidName(value)
          this.resultInfo.isValid = value
        }
      },
      handleStartDateChange(mom,dateStr){
        this.resultInfo.periodStartDate = dateStr ? this.getDateTime(dateStr) : null
        this.periodStartDate = dateStr ? this.moment(dateStr, this.dateFormat) : null
      },
      handleEndDateChange(mom,dateStr){
        this.resultInfo.periodEndDate = dateStr ? this.getDateTime(dateStr) : null
        this.periodEndDate = dateStr ? this.moment(dateStr, this.dateFormat) : null
      },
      // 根据是否有效Id获取是否有效名称
      getValidName(validId){
        if(validId == "1") return "有效"
        else if(validId == "2") return "无效"
      },
      formatDateTime (currentTime) {
        var date = new Date(currentTime);
        var seperator1 = "-";
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        var strDate = date.getDate();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        var currentdate = year + seperator1 + month + seperator1 + strDate;
        return currentdate;
      },
      getDateTime(currentTime) {
        var T = new Date(currentTime);
        return T.getTime()
      },
      moment,

    }
}
</script>
<style>
#resultInfo .flexT {
    width: 130px;
}
</style>