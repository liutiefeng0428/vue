<template>
  <div>
    <div class="container" v-if="!isEdit" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">建设内容</div>
            <div class="flexC">
              {{businessContent.implementContent}}
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">谈判备注</div>
            <div class="flexC">
              {{businessContent.negotiationRemark}}
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container" v-if="isEdit" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">建设内容</div>
            <div class="flexC">
              <textarea name="" v-model="businessContent.implementContent" style="width: 100%" rows="2" placeholder="请输入建设内容" ></textarea>
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">谈判备注</div>
            <div class="flexC">
              <textarea name="" v-model="businessContent.negotiationRemark" style="width: 100%" rows="2" placeholder="请输入谈判备注" ></textarea>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>

import {apiService} from "@/services/apiservice"

export default {
    name: "BusinessContent",
    components: {
    },
    data () {
        return {
            bureausSel:"",//类型
        }
    },
    props: ['isEdit','id','businessContent','isNew'],
    computed: {
    },
    mounted(){
    },
    created(){
    },
    methods: {
    }
}
</script>