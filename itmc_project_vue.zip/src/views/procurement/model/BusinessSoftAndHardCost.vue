<template>
  <div id="softOrHardCost">
    <!-- <a-button style="position: absolute;top: -38px;left: 76px;" @click="goBack()">新增</a-button> -->
    <SoftAndHardListModal v-if="isEdit" @addProductRow="getSoftOrHardListFromSon"></SoftAndHardListModal>
    <div>
      <div class="ant-table-content">
        <div class="ant-table-body">
          <table v-if="isEdit" style="width: 100%; table-layout: fixed;">
            <thead class="ant-table-thead">
              <tr>
                <th rowspan="2" class=""><div>类型</div></th>
                <th rowspan="2" class=""><div>名称</div></th>
                <th rowspan="2" class=""><div>品牌</div></th>
                <th rowspan="2" class=""><div>型号</div></th>
                <th rowspan="2" class=""><div>配置指标</div></th>
                <th rowspan="2" class=""><div>数量</div></th>
                <th rowspan="2" class=""><div>原价</div></th>
                <th rowspan="1" colspan="2" class="bableTh"><div>谈判前</div></th>
                <th rowspan="1" colspan="2" class="bableTh"><div>谈判后</div></th>
                <th rowspan="1" colspan="2" class="bableTh"><div>最终汇报</div></th>
                <th rowspan="2" class=""><div>操作</div></th>
              </tr>
              <tr>
                <th>单价</th>
                <th>小计(万元)</th>
                <th>单价</th>
                <th>小计(万元)</th>
                <th>单价</th>
                <th>小计(万元)</th>
              </tr>
            </thead>
            <tbody class="ant-table-tbody editBusinessTable">
              <tr  v-for="(item,index) in businessSoftAndHardCost">
                <td>{{item.softOrHard}}
                </td>
                <td>
                  <a-input v-model="item.deviceName" />
                </td>
                <td>
                  <a-input v-model="item.pinPai" />
                </td>
                <td>
                  <a-input v-model="item.typeName" />
                </td>
                <td>
                  <a-input v-model="item.deviceConfig" />
                </td>
                <td>
                  <!-- <a-input @change="calcAllTotalPrice(item.quantity, item.beforePrice, item.afterPrice, item.finalPrice, index)" v-model="item.quantity" /> -->
                  <a-input-number @change="calcAllTotalPrice(item.quantity, item.beforePrice, item.afterPrice, item.finalPrice, index)" v-model="item.quantity" />
                </td>
                <td>
                  <!-- <a-input v-model="item.price" /> -->
                  <a-input-number v-model="item.price" />
                </td>
                <td>
                  <!-- <a-input @change="calcTotalPrice(item.quantity, item.beforePrice, index, 'beforeTotal')" v-model="item.beforePrice" /> -->
                  <a-input-number @change="calcTotalPrice(item.quantity, item.beforePrice, index, 'beforeTotal')" v-model="item.beforePrice" />
                </td>
                <td>
                  <a-input v-model="item.beforeTotal" />
                  <!-- <a-input-number v-model="item.beforeTotal" /> -->
                </td>
                <td>
                  <!-- <a-input @change="calcTotalPrice(item.quantity, item.afterPrice, index, 'afterTotal')" v-model="item.afterPrice" /> -->
                  <a-input-number @change="calcTotalPrice(item.quantity, item.afterPrice, index, 'afterTotal')" v-model="item.afterPrice" />
                </td>
                <td>
                  <a-input v-model="item.afterTotal" />
                  <!-- <a-input-number v-model="item.afterTotal" /> -->
                </td>
                <td>
                  <!-- <a-input @change="calcTotalPrice(item.quantity, item.finalPrice, index, 'finalTotal')" v-model="item.finalPrice" /> -->
                  <a-input-number @change="calcTotalPrice(item.quantity, item.finalPrice, index, 'finalTotal')" v-model="item.finalPrice" />
                </td>
                <td>
                  <a-input v-model="item.finalTotal" />
                  <!-- <a-input-number v-model="item.finalTotal" /> -->
                </td>
                <td><a @click="toDelete(index)">删除</a></td>
              </tr>
              <tr>
                <td>合计：</td>
                <td colspan="6"></td>
                <td></td>
                <td>{{beforeTotal}}</td>
                <td></td>
                <td>{{afterTotal}}</td>
                <td></td>
                <td>{{finalTotal}}</td>
                <td></td>
              </tr>
            </tbody>
          </table>
          <table v-if="!isEdit" style="width: 100%; table-layout: fixed;">
            <thead class="ant-table-thead">
              <tr>
                <th rowspan="2" class=""><div>类型</div></th>
                <th rowspan="2" class=""><div>名称</div></th>
                <th rowspan="2" class=""><div>品牌</div></th>
                <th rowspan="2" class=""><div>型号</div></th>
                <th rowspan="2" class=""><div>配置指标</div></th>
                <th rowspan="2" class=""><div>数量</div></th>
                <th rowspan="2" class=""><div>原价</div></th>
                <th rowspan="1" colspan="2" class="bableTh"><div>谈判前</div></th>
                <th rowspan="1" colspan="2" class="bableTh"><div>谈判后</div></th>
                <th rowspan="1" colspan="2" class="bableTh"><div>最终汇报</div></th>
              </tr>
              <tr>
                <th>单价</th>
                <th>小计(万元)</th>
                <th>单价</th>
                <th>小计(万元)</th>
                <th>单价</th>
                <th>小计(万元)</th>
              </tr>
            </thead>
            <tbody class="ant-table-tbody editBusinessTable">
              <tr  v-for="(item,index) in businessSoftAndHardCost">
                <td>
                  {{item.softOrHard}}
                </td>
                <td>
                  {{item.deviceName}}
                </td>
                <td>
                  {{item.pinPai}}
                </td>
                <td>
                  {{item.typeName}}
                </td>
                <td>
                  {{item.deviceConfig}}
                </td>
                <td>
                  {{item.quantity}}
                </td>
                <td>
                  {{item.price}}
                </td>
                <td>
                  {{item.beforePrice}}
                </td>
                <td>
                  {{item.beforeTotal}}
                </td>
                <td>
                  {{item.afterPrice}}
                </td>
                <td>
                  {{item.afterTotal}}
                </td>
                <td>
                  {{item.finalPrice}}
                </td>
                <td>
                  {{item.finalTotal}}
                </td>
              </tr>
              <tr>
                <td>合计：</td>
                <td colspan="6"></td>
                <td></td>
                <td>{{beforeTotal}}</td>
                <td></td>
                <td>{{afterTotal}}</td>
                <td></td>
                <td>{{finalTotal}}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="container" style="margin:20px 0;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">工作量核对说明</div>
            <div class="flexC">
              <textarea v-if="isEdit" v-model="dataInfo.workload" name="" style="width: 100%" rows="2" placeholder="请输入建设内容" ></textarea>
              <span v-if="!isEdit">{{dataInfo.workload}}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
  import {apiService} from "@/services/apiservice"
  import SoftAndHardListModal from './SoftAndHardListModal'
  import Vue from 'vue';
export default {
    name: "BusinessSoftAndHardCost",
    components: {
      SoftAndHardListModal
    },
    data () {
        return {
            bureausSel:"",//类型
            softAndHardList:[],

        }
    },
    props: ['isEdit','id','businessSoftAndHardCost','dataInfo','isNew'],
    computed: {
      // 谈判前小计
      beforeTotal:{
        get: function(){
          let beforeTotal = 0;
          this.businessSoftAndHardCost.map((item) => {
            if(isNaN(item.beforeTotal) || item.beforeTotal.length == 0) item.beforeTotal = 0
            beforeTotal += parseFloat(item.beforeTotal)
          })
          return parseFloat(beforeTotal).toFixed(4)
        },
        set:function(){
        }
      },
      // 谈判后小计
      afterTotal:{
        get: function(){
          let afterTotal = 0;
          this.businessSoftAndHardCost.map((item) => {
            if(isNaN(item.afterTotal) || item.afterTotal.length == 0) item.afterTotal = 0
            afterTotal += parseFloat(item.afterTotal)
          })
          return parseFloat(afterTotal).toFixed(4)
        },
        set:function(){
        }
      },
      // 最终汇报小计
      finalTotal:{
        get: function(){
          let finalTotal = 0;
          this.businessSoftAndHardCost.map((item) => {
            if(isNaN(item.finalTotal) || item.finalTotal.length == 0) item.finalTotal = 0
            finalTotal += parseFloat(item.finalTotal)
          })
          return parseFloat(finalTotal).toFixed(4)
        },
        set:function(){
        }
      },
    },
    watch: {
      beforeTotal(val,info){
        this.$emit('beforeTotal',this.beforeTotal)
      },
      afterTotal(val,info){
        this.$emit('afterTotal',this.afterTotal)
      },
      finalTotal(val,info){
        this.$emit('finalTotal',this.finalTotal)
      },
      softAndHardList(val,info){
        var _self = this
        var index = _self.businessSoftAndHardCost.length

        for(var i=0; i<val.length; i++){
          Vue.set(_self.businessSoftAndHardCost, index, {
            // assetsModle: _self.val[i].data.props.dataRef.type,
            // assetsType: _self.val[i].data.props.dataRef.key,
            // assetsTypeName: _self.val[i].data.props.dataRef.title,
            "afterPrice": '',
            "pinPai": '',
            "typeName": '',
            "deviceConfig": '',
            "afterTotal": '',
            "beforePrice": '',
            "beforeTotal": '',
            "deviceName": '',
            "finalPrice": '',
            "finalTotal": '',
            "id": "",
            "negotiationId": "",
            "price": '',
            "quantity": '',
            "softOrHard": val[i].data.props.dataRef.title
          })
          index++;
        }
      }
    },
    mounted(){
    },
    created(){
    },
    methods: {
      // 表格列表当前行小计
      calcTotalPrice(unitPrice, number, index, changeName){
        this.businessSoftAndHardCost[index][changeName] = (parseFloat(unitPrice)*parseFloat(number)/10000).toFixed(4);
      },
      calcAllTotalPrice(quantity, beforePrice, afterPrice, finalPrice, index){
        this.businessSoftAndHardCost[index].beforeTotal = (parseFloat(beforePrice)*parseFloat(quantity)/10000).toFixed(4);
        this.businessSoftAndHardCost[index].afterTotal = (parseFloat(afterPrice)*parseFloat(quantity)/10000).toFixed(4);
        this.businessSoftAndHardCost[index].finalTotal = (parseFloat(finalPrice)*parseFloat(quantity)/10000).toFixed(4);
      },
      toDelete(index){
        this.businessSoftAndHardCost.splice(index, 1)
      },
      // 从子组件获取选中的设备信息
      getSoftOrHardListFromSon(data){
          this.softAndHardList = data
      },
    }
}
</script>
<style>
#softOrHardCost {
  position: relative;
}
#softOrHardCost .ant-input-number {
  height:28px;
  width:100%;
}
#softOrHardCost .ant-input-number .ant-input-number-input {
  height:26px;
}
#softOrHardCost table td {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
}

.ant-table-tbody.editBusinessTable>tr>td {
  padding: 3px 1px!important;
}
</style>