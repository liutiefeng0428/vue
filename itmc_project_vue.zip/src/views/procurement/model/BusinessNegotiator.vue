<template>
  <div>
    <div class="container" v-if="!isEdit" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">甲方人员</div>
            <div class="flexC">
              {{businessNegotiator.partA}}
            </div>
            <div class="flexC">
              {{businessNegotiator.partAPerson}}
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">乙方人员</div>
            <div class="flexC">
              {{businessNegotiator.partB}}
            </div>
            <div class="flexC">
              {{businessNegotiator.partBPerson}}
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container" v-if="isEdit" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">甲方人员</div>
            <div class="flexC">
              <!-- <a-select :value="businessNegotiator.partA" class="querySelect" @change="handleChangebureaus" style="width:200px">
                <a-select-option v-for="item in bureausList" :key="item.bureausCode"> {{item.bureaus}}</a-select-option>
              </a-select> -->
              <input v-model="businessNegotiator.partA" type="text" class="ant-input">
            </div>
            <div class="flexC">
              <!-- <a-select :value="partAPerson" placeholder="请选择处室人员" mode="multiple" class="querySelect" @change="handleChangePartAPerson" style="width:100%">
                <a-select-option v-if="item.bureausPerName" v-for="item in nameList" :key="item.bureausPerName"> {{item.bureausPerName}}</a-select-option>
              </a-select> -->
              <input style="width: calc(100% - 100px)" v-model="businessNegotiator.partAPerson" type="text" class="ant-input">
              <a-button v-if="businessNegotiator.partA == '信息部'" @click="showPersonSupplier()" class="ant-btn ant-btn-primary">选择</a-button>
            </div>
          </div>
          <div class="flexItems1">
            <div class="flexT">乙方人员</div>
            <div class="flexC">
              <input style="width: calc(100% - 100px)" v-model="businessNegotiator.partB" type="text" class="ant-input">
              <a-button @click="showInvestmentSupplier()" class="ant-btn ant-btn-primary">选择</a-button>
            </div>
            <div class="flexC">
              <input v-model="businessNegotiator.partBPerson" type="text" class="ant-input" placeholder="请输入人员名称">
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 选择供应商模态框 -->
    <a-modal
      title="选择供应商"
      :width="900"
      centered
      cancelText="取消"
      okText="确认"
      @ok="() => selectInvestmentSupplier()"
      v-model="selectInvestmentModal">
      <div>
        <div style="flex: 1">
          <div>
            <a-input v-model="investmentSupplierSearch" style="width: 250px" />
            <a-button @click="showInvestmentSupplier()" type="primary" icon="search">查询</a-button>
          </div>
          <div style="margin-top: 10px">
            <div class="contentBos">
              <a-table style="width: 100%" bordered :columns="columns_investment" :dataSource="investmentSupplierList" :rowSelection="rowSelection" rowKey="uuid">
              </a-table>
            </div>
          </div>
        </div>
      </div>
    </a-modal>
    <!-- 选择甲方人员模态框 -->
    <a-modal
      title="选择人员"
      :width="500"
      centered
      cancelText="取消"
      okText="确认"
      @ok="() => selectPersonSupplier()"
      v-model="selectPersonModal">
      <div>
        <div style="flex: 1">
          <!-- <div>
            <a-input v-model="investmentSupplierSearch" style="width: 250px" />
            <a-button @click="showInvestmentSupplier()" type="primary" icon="search">查询</a-button>
          </div> -->
          <div style="margin-top: 10px">
            <div class="contentBos">
              <a-table style="width: 100%" bordered :columns="columns_person" :dataSource="nameList" :rowSelection="selectPersonRowSelection" rowKey="uuid">
              </a-table>
            </div>
          </div>
        </div>
      </div>
    </a-modal>
  </div>
</template>
<script>
const columns_investment = [
  {
    title: '供应商名称',
    dataIndex: 'supplierName',
  }
];
const columns_person = [
  {
    title: '人员姓名',
    dataIndex: 'bureausPerName',
  }
];
import {apiService} from "@/services/apiservice"

export default {
    name: "BusinessNegotiator",
    components: {
    },
    data () {
        return {
            bureaus:[{"bureausCode":"0","bureaus":"费用"},{"bureausCode":"1","bureaus":"项目"},{"bureausCode":"2","bureaus":"统采"}],
            bureausSel:"",//类型
            recommend:"",//乙方人员
            selectedRows:[],
            selectInvestmentModal:false,// 选择供应商模态框(乙方人员)
            selectPersonModal:false,// 选择处室人员模态框(甲方人员)
            investmentSupplierSearch:'', // 模态框搜索项——供应商名称
            investmentSupplierList:[],// 供应商列表(乙方人员)
            columns_investment,
            columns_person,
            bureausList:[],// 处室列表(甲方)
            nameList:[],// 处室人员列表(甲方)
            partAPerson:[],// 处室人员显示(甲方)
            selectedPersonRows:[], // 甲方人员模态框中选中的行数据集合
        }
    },
    props: ['isEdit','id','businessNegotiator','isNew'],
    computed: {
      rowSelection() {
        const { selectedRowKeys } = this;
        return {
          onChange: (selectedRowKeys, selectedRows) => {
            this.selectedRows = selectedRows
            console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
          },
          getCheckboxProps: record => ({
            props: {
              name: record.name,
            }
          }),
        }
      },
      selectPersonRowSelection() {
        const { selectedRowKeys } = this;
        return {
          onChange: (selectedRowKeys, selectedRows) => {
            this.selectedPersonRows = selectedRows;
          }
        }
      },
    },
    watch: {
      // businessNegotiator(val, info){
      //   this.partAPerson = this.businessNegotiator.partAPerson.replace(/\*/g, ' ').trim().split(' ')
      //   console.log(this.partAPerson)
      // }
    },
    mounted(){
      // this.reset();
      // this.optionDateSelect=this.optionDate[0].optionName
    },
    created(){
      if(this.isNew && !this.businessNegotiator.partA) this.businessNegotiator.partA = '信息部'
      this.getItmcBureaus()
      this.getNameS()
    },
    methods: {
      handleChangebureaus(value){//处室人员列表（甲方）
        if(value != ''){
          this.businessNegotiator.partA = value
        }
      },
      handleChangePartAPerson(value){ // 处室人员（甲方）
        console.log(value)
        this.partAPerson = value // 显示
      },
      // 显示选择供应商模态框
      showInvestmentSupplier(){
        this.selectInvestmentModal=true
        this.getItmcInvestmentSupplier()
      },
      // 显示选择甲方人员模态框
      showPersonSupplier(){
        this.selectPersonModal=true
        this.getNameS()
      },
      // 获取处室（甲方人员）
      getItmcBureaus(){
        var _self = this
        apiService.getBureaus1({}).then(r => {
          _self.bureausList=r
        }, r => {
        }).catch(
        )
      },
      // 获取联系人列表(甲方人员)
      getNameS(){
        var _self = this
        let params={}
        params._json = true
        apiService.getNameS(params).then(r => {
          var nameList = []
          r.forEach(function(item, index){
            if(item.bureausPerName) nameList.push(item)
          })
          _self.nameList=nameList

        }, r => {
        }).catch(
        )
      },
      // 获取供应商列表(乙方人员)
      getItmcInvestmentSupplier(){
        var _self = this
        let params={supplierName:this.investmentSupplierSearch}
        params._json = true
        apiService.getItmcInvestmentSupplier(params).then(r => {
          _self.investmentSupplierList=r
        }, r => {
        }).catch(
        )
      },
      // 乙方模态框确认按钮回调函数
      selectInvestmentSupplier(){
        var _self = this
        var investmentSupplierArr = this.recommend ? this.recommend.split('，') : [],
            investmentSupplierList = '';
        // 循环选中的内容将名称放到数组里
        _self.selectedRows.forEach((selectedRow) => {
          if(investmentSupplierArr.indexOf(selectedRow.supplierName) == -1) investmentSupplierArr.push(selectedRow.supplierName)
        })
        // 数组转换为字符串，显示和传给后台
        investmentSupplierList = investmentSupplierArr.join('，')
        this.recommend = investmentSupplierList
        this.businessNegotiator.recommend = investmentSupplierList
        this.selectInvestmentModal = false;
      },
      // 甲方人员模态框确认按钮回调函数
      selectPersonSupplier(){//businessNegotiator.partAPerson
        let _self = this
        var partAPersonString = '',
            partAPersonArr = [];
        partAPersonArr = this.businessNegotiator.partAPerson.replace(/\*/g, ' ').trim().split(' ')
        _self.selectedPersonRows.forEach(function(val, index){
          if(partAPersonArr.indexOf(val.bureausPerName) == -1) partAPersonArr.push(val.bureausPerName)
        })
        this.businessNegotiator.partAPerson = partAPersonArr.join('*')
        this.selectPersonModal = false
      }
    }
}
</script>