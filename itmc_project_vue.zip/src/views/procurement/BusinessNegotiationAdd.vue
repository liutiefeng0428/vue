<template>
  <div class="wrap">
    <div class="con-title">
      <span>商务谈判管理</span>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>基本信息</span>
    </div>
    <BusinessBasicInfo :isNew="isNew" :isEdit="isEdit" :id="id" :businessBasicInfo="dataInfo"></BusinessBasicInfo>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>谈判内容</span>
    </div>
    <BusinessContent :isNew="isNew" :isEdit="isEdit" :id="id" :businessContent="dataInfo"></BusinessContent>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>谈判人员</span>
    </div>
    <BusinessNegotiator :isNew="isNew" :isEdit="isEdit" :id="id" :businessNegotiator="dataInfo"></BusinessNegotiator>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>工作量核对</span>
    </div>
    <div class="con-title">
      <span>实施服务费</span>
      <!-- <a-button @click="goBack()">新增</a-button> -->
    </div>
    <BusinessServiceCost :isNew="isNew" @priceSum="getPriceSumFormSon" @negotiationPriceSum="getNegotiationPriceSumFormSon" @finalPriceSum="getFinalPriceSumFormSon" @businessServiceCostCopy="getBusinessServiceCostFormSon" :isEdit="isEdit" :id="id" :dataInfo="dataInfo" :businessServiceCost="negotiationServiceDTOList"></BusinessServiceCost>
    <div class="con-title">
      <span>软硬件费用</span>
      <!-- <a-button @click="goBack()">新增</a-button> -->
    </div>
    <BusinessSoftAndHardCost :isNew="isNew" @beforeTotal="getBeforeTotalFormSon" @afterTotal="getAfterTotalFormSon" @finalTotal="getFinalTotalFormSon" :isEdit="isEdit" :id="id" :dataInfo="dataInfo" :businessSoftAndHardCost="negotiationDeviceDTOList"></BusinessSoftAndHardCost>
    <div class="con-title">
      <span>价格比对</span>
    </div>
    <BusinessPriceCompare :isNew="isNew" :priceSum="priceSum" :negotiationPriceSum="negotiationPriceSum" :finalPriceSum="finalPriceSum" :beforeTotal="beforeTotal" :afterTotal="afterTotal" :finalTotal="finalTotal" :isEdit="isEdit" :id="id" :businessPriceCompare="dataInfo"></BusinessPriceCompare>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>谈判纪要</span>
    </div>
    <UploadFile :isEdit="isEdit" :relationId="id" :businessType="businessTypeTPJY"></UploadFile>
    <div class="container" style="text-align: center;margin-top: 20px">
      <div>
        <a-button v-if="isEdit" type="primary" @click="saveBusinessNegotiation()">保存</a-button>
        <a-button @click="goBack()">返回</a-button>
      </div>
    </div>
  </div>
</template>

<script>
  import {apiService} from "@/services/apiservice";
  import BusinessBasicInfo from './model/BusinessBasicInfo'
  import BusinessContent from './model/BusinessContent'
  import BusinessNegotiator from './model/BusinessNegotiator'
  import BusinessServiceCost from './model/BusinessServiceCost'
  import BusinessSoftAndHardCost from './model/BusinessSoftAndHardCost'
  import BusinessPriceCompare from './model/BusinessPriceCompare'
  import UploadFile from '@/components/operation/UploadFile'
  import Vue from 'vue';

  export default {
    name: "BusinessNegotiationAdd",
    components: {
      BusinessBasicInfo,
      BusinessContent,
      BusinessNegotiator,
      BusinessServiceCost,
      BusinessSoftAndHardCost,
      BusinessPriceCompare,
      UploadFile,
    },
    data() {
      return {
        expVisible:false,
        isEdit:true,
        isNew:false,
        id:'',
        dataInfo:[],
        negotiationServiceDTOList:[], //实施服务费
        negotiationDeviceDTOList:[], //软硬件费用
        businessTypeTPJY:'TPJY', // 附件上传需要的BusinessType
        priceSum:0, // 实施服务费——谈判前小计
        negotiationPriceSum:0, // 实施服务费——谈判后小计
        finalPriceSum:0, // 实施服务费——最终汇报小计
        beforeTotal:0, // 软硬件——谈判前小计
        afterTotal:0, // 软硬件——谈判后小计
        finalTotal:0, // 软硬件——最终汇报小计
      }
    },
    methods: {
      goBack(uuid){
          this.$router.go(-1)
      },
      // 从实施服务费子组件获取列表数据
      getBusinessServiceCostFormSon(data){
          this.negotiationServiceDTOList = data
      },
      // 从实施服务费子组件获取谈判前小计
      getPriceSumFormSon(data){
          this.priceSum = data
      },
      // 从实施服务费子组件获取谈判后小计
      getNegotiationPriceSumFormSon(data){
          this.negotiationPriceSum = data
      },
      // 从实施服务费子组件获取最终汇报小计
      getFinalPriceSumFormSon(data){
          this.finalPriceSum = data
      },
      // 从软硬件子组件获取谈判前小计
      getBeforeTotalFormSon(data){
          this.beforeTotal = data
      },
      // 从软硬件子组件获取谈判后小计
      getAfterTotalFormSon(data){
          this.afterTotal = data
      },
      // 从软硬件子组件获取最终汇报小计
      getFinalTotalFormSon(data){
          this.finalTotal = data
      },
      handleChangebureaus(){},
      getItmcInvestmentNegotiationDTODetail(){// 获取商务管控详情信息
        var params = {id: this.id}
        params._json = true
        apiService.getItmcInvestmentNegotiationDTODetail(params).then(r => {
            this.dataInfo = r
            this.negotiationServiceDTOList = r.itmcNegotiationServiceDTOList // 实施服务费
            this.negotiationDeviceDTOList = r.itmcNegotiationDeviceDTOList // 软硬件费用
            console.log(r)
        }, r => {
        }).catch(
        )
      },
      // 新增商务谈判保存信息
      addNegotiation(parmasData){
        var _self = this
        apiService.addNegotiation(parmasData).then(r => {
          if(r.result == 200){
            _self.$message.success('保存成功！')
            _self.$router.push({path: "/procurement-list"})
          }else{
            _self.$message.warning(r.msg)
          }
        }, r => {
        }).catch(
        )
      },
      // 编辑商务谈判保存信息
      editPurchaseInfo(parmasData){
        var _self = this
        apiService.editPurchaseInfo(parmasData).then(r => {
          if(r.result == 200){
            _self.$message.success('保存成功！')
            _self.$router.push({path: "/procurement-list"})
          }else{
            _self.$message.warning(r.msg)
          }
        }, r => {
        }).catch(
        )
      },
      // 保存商务谈判信息
      saveBusinessNegotiation(){
        console.log(this.dataInfo)
        console.log(this.negotiationServiceDTOList)
        Vue.set(this.dataInfo, 'itmcNegotiationServiceDTOList', this.negotiationServiceDTOList)
        if(this.dataInfo.editNegName){
          if(this.dataInfo.buyType == '1'){
            this.dataInfo.negotiationApplyName = this.dataInfo.negotiationName + this.dataInfo.editNegName + '商务谈判'
          }else if(this.dataInfo.buyType == '0'){
            this.dataInfo.negotiationApplyName = this.dataInfo.feeTypeName + this.dataInfo.editNegName + '商务谈判'
          }
        }
        if(this.isNew){
          Vue.set(this.dataInfo, 'id', this.id)
          this.addNegotiation(this.dataInfo)
        }else{
          var parmas = {biddingType:'3', itmcInvestmentNegotiation: this.dataInfo}
          parmas._json = true
          this.editPurchaseInfo(parmas)
        }
      }
    },
    computed: {

    },
    filters:{
    },
    created(){
      this.id=this.$route.query.id
      this.isEdit = this.$route.query.isEdit
      this.isNew = this.$route.query.isNew

      if(!this.isNew) this.getItmcInvestmentNegotiationDTODetail()
      else{
        var dataInfo = {
          "afterNegQuote": 0,
          "beforeNegQuote": 0,
          "buyType": 0,
          "feeType": 0,
          "finalNegQuote": 0,
          "id": "",
          "implementContent": "",
          "isDel": 0,
          "isValid": 0,
          "itemType": "",
          "itemTypeCode": "",
          "itmcNegotiationDeviceDTOList": [],
          "itmcNegotiationServiceDTOList": [],
          "negotiationApplyName": "",
          "negotiationDate": "",
          "negotiationName": "",
          "negotiationRemark": "",
          "partA": "",
          "partAPerson": "",
          "partB": "",
          "partBPerson": "",
          "workload": ""
        }
        this.dataInfo = dataInfo
        this.negotiationServiceDTOList = dataInfo.itmcNegotiationServiceDTOList // 实施服务费
        this.negotiationDeviceDTOList = dataInfo.itmcNegotiationDeviceDTOList // 软硬件费用
      }
    }
  }
</script>
<style>
  @import '../../assets/css/common.css';
  .wrap {
    padding: 20px;
    background: #ffffff;
    margin: 10px;
  }
 /* .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 15px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .flexBox1{
    border-top: 1px solid #e8e8e8;
    border-left: 1px solid #e8e8e8;
  }
  .flexItems1{
    display: flex;
    box-sizing: border-box;
  }
  .flexT{
    width: 240px;
    text-align: right;
    padding:5px 10px;
    background: #fafafa;
    border-right: 1px solid #e8e8e8;
    border-bottom: 1px solid #e8e8e8;
  }
  .flexC{
    flex: 8;
    text-align: left;
    padding:5px 10px;
    border-right: 1px solid #e8e8e8;
    border-bottom: 1px solid #e8e8e8;
  }*/
  .ant-table-tbody>tr>td, .ant-table-thead>tr>th{
    border-right:1px solid #e8e8e8;
  }
  .ant-table-body{
    border-left:1px solid #e8e8e8;
    border-top:1px solid #e8e8e8;
  }
</style>
