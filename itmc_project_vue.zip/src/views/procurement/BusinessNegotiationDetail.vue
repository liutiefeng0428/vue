<template>
  <div class="wrap">
    <div class="con-title">
      <span>商务谈判管理</span>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>基本信息</span>
    </div>
    <div class="container" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">类型</div>
            <div class="flexC">111</div>
          </div>
          <div class="flexItems1">
            <div class="flexT">项目名称/项目类型</div>
            <div class="flexC">22</div>
          </div>
          <div class="flexItems1">
            <div class="flexT">谈判名称</div>
            <div class="flexC">44</div>
          </div>
          <div class="flexItems1">
            <div class="flexT">谈判日期</div>
            <div class="flexC">55</div>
          </div>
          <div class="flexItems1">
            <div class="flexT">谈判有效</div>
            <div class="flexC">66</div>
          </div>
        </div>
      </div>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>谈判内容</span>
    </div>
    <div class="container" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">建设内容</div>
            <div class="flexC">111</div>
          </div>
          <div class="flexItems1">
            <div class="flexT">谈判备注</div>
            <div class="flexC">22</div>
          </div>
        </div>
      </div>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>谈判人员</span>
    </div>
    <div class="container" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">甲方人员</div>
            <div class="flexC">111</div>
            <div class="flexC">111</div>
          </div>
          <div class="flexItems1">
            <div class="flexT">乙方人员</div>
            <div class="flexC">22</div>
            <div class="flexC">22</div>
          </div>
        </div>
      </div>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>工作量核对</span>
    </div>
    <div class="con-title">
      <span>实施服务费</span>
    </div>
    <div  style="margin-bottom: 20px">
      <div class="ant-table-content">
        <div class="ant-table-body">
          <table style="width: 100%">
            <thead class="ant-table-thead">
            <tr>
              <th rowspan="1" colspan="4" class="bableTh"><div>谈判前</div></th>
              <th rowspan="1" colspan="4" class="bableTh"><div>谈判后</div></th>
              <th rowspan="1" colspan="4" class="bableTh"><div>最终汇报</div></th>
            </tr>
            <tr>
              <th>工作量(人天)</th>
              <th>人员级别</th>
              <th>取费标准(元/天)</th>
              <th>小计(万元)</th>
              <th>工作量(人天)</th>
              <th>人员级别</th>
              <th>取费标准(元/天)</th>
              <th>小计(万元)</th>
              <th>工作量(人天)</th>
              <th>人员级别</th>
              <th>取费标准(元/天)</th>
              <th>小计(万元)</th>
            </tr>
            </thead>
            <tbody class="ant-table-tbody">
            <tr  v-for="(item,index) in dataInfo">
              <td>{{item.projectName}}</td>
              <td style="width: 150px">{{item.projectName}}</td>
              <td>
                  <span class="ecllipsis">
                    {{item.projectContent}}
                  </span>
              </td>
              <td>{{item.conYear}}</td>
              <td>{{item.constrNature}}</td>
              <td>{{item.totalSum}}</td>
              <td>{{item.totalSum}}</td>
              <td>{{item.totalSum}}</td>
              <td>{{item.totalSum}}</td>
              <td>{{item.totalSum}}</td>
              <td>{{item.totalSum}}</td>
              <td>{{item.totalSum}}</td>
            </tr>
            <tr>
              <td>求合计</td>
              <td></td>
              <td></td>
              <td>求合计</td>
              <td>求合计</td>
              <td></td>
              <td></td>
              <td>求合计</td>
              <td>求合计</td>
              <td></td>
              <td></td>
              <td>求合计</td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="con-title">
      <span>软硬件费用</span>
    </div>
    <div>
      <div class="ant-table-content">
        <div class="ant-table-body">
          <table style="width: 100%">
            <thead class="ant-table-thead">
            <tr>
              <th rowspan="2" class=""><div>类型</div></th>
              <th rowspan="2" class=""><div>名称</div></th>
              <th rowspan="2" class=""><div>数量</div></th>
              <th rowspan="2" class=""><div>原件</div></th>
              <th rowspan="1" colspan="2" class="bableTh"><div>谈判前</div></th>
              <th rowspan="1" colspan="2" class="bableTh"><div>谈判后</div></th>
              <th rowspan="1" colspan="2" class="bableTh"><div>最终汇报</div></th>
            </tr>
            <tr>
              <th>折扣(小数)</th>
              <th>小计</th>
              <th>折扣(小数)</th>
              <th>小计</th>
              <th>折扣(小数)</th>
              <th>小计</th>
            </tr>
            </thead>
            <tbody class="ant-table-tbody">
            <tr  v-for="(item,index) in dataInfo">
              <td>{{item.projectName}}</td>
              <td>{{item.projectName}}</td>
              <td>
                  <span class="ecllipsis">
                    {{item.projectContent}}
                  </span>
              </td>
              <td>{{item.conYear}}</td>
              <td>{{item.constrNature}}</td>
              <td>{{item.totalSum}}</td>
              <td>{{item.totalSum}}</td>
              <td>{{item.totalSum}}</td>
              <td>{{item.totalSum}}</td>
              <td>{{item.totalSum}}</td>
            </tr>
            <tr>
              <td>合计：</td>
              <td></td>
              <td></td>
              <td>求原价平均数</td>
              <td>求折扣平均数</td>
              <td>求合计</td>
              <td>求折扣平均数</td>
              <td>求合计</td>
              <td>求折扣平均数</td>
              <td>求合计</td>
            </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="container" style="margin:20px 0;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">工作量说明</div>
            <div class="flexC">111</div>
          </div>
        </div>
      </div>
    </div>
    <div class="con-title">
      <span>价格比对</span>
    </div>
    <div class="container" style="margin-bottom: 20px;display: flex;padding: 0">
      <div style="flex: 1">
        <div class="flexBox1">
          <div class="flexItems1">
            <div class="flexT">谈判前报价</div>
            <div class="flexC">111</div>
            <div class="flexT">优化价</div>
            <div class="flexC">111</div>
            <div class="flexT">谈判汇报价</div>
            <div class="flexC">111</div>
          </div>
        </div>
      </div>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>谈判纪要</span>
    </div>
    <div>
      <div class="ant-table-content">
        <div class="ant-table-body">
          <table style="width: 100%">
            <thead class="ant-table-thead">
            <tr>
              <th rowspan="1" class=""><div>文件类型</div></th>
              <th rowspan="1" class=""><div>文件</div></th>
              <th rowspan="1" class=""><div>上传人</div></th>
              <th rowspan="1" class=""><div>上传时间</div></th>
            </tr>
            </thead>
            <tbody class="ant-table-tbody">
              <tr>
                <td rowspan="2">商务谈判结果</td>
                <template>
                  <td style="width: 150px"> <a>11111</a></td>
                  <td>
                   1111
                  </td>
                  <td>2222</td>
                </template>
              </tr>
              <tr>
                <td>
                  <a>11111</a>
                </td>
                <td>
                  11111
                </td>
                <td>2222</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="container" style="text-align: center;margin-top: 20px">
      <div>
        <a-button @click="goBack()">返回</a-button>
      </div>
    </div>
  </div>
</template>

<script>

  import {apiService} from "@/services/apiservice";
  export default {
    name: "BusinessNegotiationDetail",
    components: {
    },
    data() {
      return {
        dataInfo:[{"id":"326f63b0d36e46f6acc22fadb242cc26","planYear":"2019","belongPlat":"经营管理平台","constrNature":"新开","projectName":"测试导入01","projectContent":"测试导入201905291441","approvalNum":null,"businessArea":"绩效管理","versionsName":"各处申报汇总版","versionsState":"2019-07-01项目二处","constarYear":null,"conendYear":null,"conYear":"2019-2020","investmentChannel":"B01","totalZbSort":100.0,"totalZbHardware":100.0,"totalZbService":100.0,"totalZbOther":100.0,"totalQySort":100.0,"totalQyHardware":100.0,"totalQyService":100.0,"totalQyOther":100.0,"totalSum":800.0,"nyZbSort":5.0,"nyZbHardware":5.0,"nyZbService":5.0,"nyZbOther":5.0,"nyQylhSort":5.0,"nyQylhHardware":5.0,"nyQylhService":5.0,"nyQylhOther":5.0,"nyQyytSort":5.0,"nyQyytHardware":5.0,"nyQyytService":5.0,"nyQyytOther":5.0,"nyQyxsSort":5.0,"nyQyxsHardware":5.0,"nyQyxsService":5.0,"nyQyxsOther":5.0,"nyQykySort":5.0,"nyQykyHardware":5.0,"nyQykyService":5.0,"nyQykyOther":5.0,"nyQyzySort":5.0,"nyQyzyHardware":5.0,"nyQyzyService":5.0,"nyQyzyOther":5.0,"remark":"项目二处备注","nyTotalSum":120.0,"lyZbSort":0.0,"lyZbHardware":0.0,"lyZbService":0.0,"lyZbOther":0.0,"lyQySort":0.0,"lyQyHardware":0.0,"lyQyService":0.0,"lyQyOther":0.0,"nowZbSort":100.0,"nowZbHardware":10.0,"nowZbService":10.0,"nowZbOther":10.0,"nowQySort":10.0,"nowQyHardware":10.0,"nowQyService":10.0,"nowQyOther":0.0,"finTotalSum":160.0,"bureaus":"项目管理二处","isDel":"0","creUserId":"3503632","creUserName":"程大庆","creTime":1561962889577,"updUserId":0.0,"updUserName":null,"updTime":1562033964367,"lyTotalSum":0.0,"nowTotalSum":160.0,"reportStatue":"1","versionTime":null,"replyState":"未上报"},{"id":"3dcc79c9d37440e68f61bb31f4b66bfe","planYear":"2019","belongPlat":"经营管理平台","constrNature":"新开","projectName":"测试导入01","projectContent":"测试导入201905291441","approvalNum":null,"businessArea":"绩效管理","versionsName":"各处申报汇总版","versionsState":"2019-07-01项目二处","constarYear":null,"conendYear":null,"conYear":"2019-2020","investmentChannel":"B01","totalZbSort":100.0,"totalZbHardware":100.0,"totalZbService":100.0,"totalZbOther":100.0,"totalQySort":100.0,"totalQyHardware":100.0,"totalQyService":100.0,"totalQyOther":100.0,"totalSum":800.0,"nyZbSort":5.0,"nyZbHardware":5.0,"nyZbService":5.0,"nyZbOther":5.0,"nyQylhSort":5.0,"nyQylhHardware":5.0,"nyQylhService":5.0,"nyQylhOther":5.0,"nyQyytSort":5.0,"nyQyytHardware":5.0,"nyQyytService":5.0,"nyQyytOther":5.0,"nyQyxsSort":5.0,"nyQyxsHardware":5.0,"nyQyxsService":5.0,"nyQyxsOther":5.0,"nyQykySort":5.0,"nyQykyHardware":5.0,"nyQykyService":5.0,"nyQykyOther":5.0,"nyQyzySort":5.0,"nyQyzyHardware":5.0,"nyQyzyService":5.0,"nyQyzyOther":5.0,"remark":"项目二处备注","nyTotalSum":120.0,"lyZbSort":0.0,"lyZbHardware":0.0,"lyZbService":0.0,"lyZbOther":0.0,"lyQySort":0.0,"lyQyHardware":0.0,"lyQyService":0.0,"lyQyOther":0.0,"nowZbSort":100.0,"nowZbHardware":10.0,"nowZbService":10.0,"nowZbOther":10.0,"nowQySort":10.0,"nowQyHardware":10.0,"nowQyService":10.0,"nowQyOther":0.0,"finTotalSum":160.0,"bureaus":"项目管理一处","isDel":"0","creUserId":"3503630","creUserName":"李伟光","creTime":1561981779966,"updUserId":0.0,"updUserName":null,"updTime":1562033964367,"lyTotalSum":0.0,"nowTotalSum":160.0,"reportStatue":"1","versionTime":null,"replyState":"未上报"},{"id":"db5c6a193b0d445781b00a8434d4620b","planYear":"2019","belongPlat":"经营管理平台","constrNature":"新开","projectName":"测试导入01","projectContent":"测试导入201905291441","approvalNum":null,"businessArea":"绩效管理","versionsName":"各处申报汇总版","versionsState":"2019-07-01项目二处","constarYear":null,"conendYear":null,"conYear":"2019-2020","investmentChannel":"B01","totalZbSort":100.0,"totalZbHardware":100.0,"totalZbService":100.0,"totalZbOther":100.0,"totalQySort":100.0,"totalQyHardware":100.0,"totalQyService":100.0,"totalQyOther":100.0,"totalSum":800.0,"nyZbSort":5.0,"nyZbHardware":5.0,"nyZbService":5.0,"nyZbOther":5.0,"nyQylhSort":5.0,"nyQylhHardware":5.0,"nyQylhService":5.0,"nyQylhOther":5.0,"nyQyytSort":5.0,"nyQyytHardware":5.0,"nyQyytService":5.0,"nyQyytOther":5.0,"nyQyxsSort":5.0,"nyQyxsHardware":5.0,"nyQyxsService":5.0,"nyQyxsOther":5.0,"nyQykySort":5.0,"nyQykyHardware":5.0,"nyQykyService":5.0,"nyQykyOther":5.0,"nyQyzySort":5.0,"nyQyzyHardware":5.0,"nyQyzyService":5.0,"nyQyzyOther":5.0,"remark":"项目二处备注","nyTotalSum":120.0,"lyZbSort":0.0,"lyZbHardware":0.0,"lyZbService":0.0,"lyZbOther":0.0,"lyQySort":0.0,"lyQyHardware":0.0,"lyQyService":0.0,"lyQyOther":0.0,"nowZbSort":100.0,"nowZbHardware":10.0,"nowZbService":10.0,"nowZbOther":10.0,"nowQySort":10.0,"nowQyHardware":10.0,"nowQyService":10.0,"nowQyOther":0.0,"finTotalSum":160.0,"bureaus":"项目管理一处","isDel":"0","creUserId":"3503630","creUserName":"李伟光","creTime":1561981760364,"updUserId":0.0,"updUserName":null,"updTime":1562033964367,"lyTotalSum":0.0,"nowTotalSum":160.0,"reportStatue":"1","versionTime":null,"replyState":"未上报"}]
      }
    },
    methods: {
      goBack(uuid){
          this.$router.go(-1)
      },
    },
    computed: {

    },
    filters:{
    },
    created(){

    }
  }
</script>
<style scoped>
  @import '../../assets/css/common.css';
  .wrap {
    padding: 20px;
    background: #ffffff;
    margin: 10px;
  }
  .ant-table-tbody>tr>td, .ant-table-thead>tr>th{
    border-right:1px solid #e8e8e8;
  }
  .ant-table-body{
    border-left:1px solid #e8e8e8;
    border-top:1px solid #e8e8e8;
  }

</style>
