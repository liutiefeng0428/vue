<template>
  <div class="wrap">
    <div class="con-title">
      <span>招投标管理</span>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>基本信息</span>
    </div>
    <TendBasicInfo :isNew="isNew" :isEdit="isEdit" :tendBasicInfo="dataInfo"></TendBasicInfo>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>招标文件</span>
    </div>
    <UploadFile :isEdit="isEdit" :relationId="id" :businessType="businessTypeXBJ"></UploadFile>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>招标结果</span>
    </div>
    <ResultInfo :isNew="isNew" :isEdit="isEdit" :id="id" :resultInfo="dataInfo"></ResultInfo>
    <div class="con-title">
      <span>中标厂商</span>
      <!-- <a-button @click="triggerImport()" icon="upload">选择</a-button> -->
    </div>
    <WinFirm :isNew="isNew" :isEdit="isEdit" :id="id" :winFirmInfo="biddingsupplierList"></WinFirm>
    <div class="con-title">
      <span>中标文档信息</span>
    </div>
    <UploadFile :isEdit="isEdit" :relationId="id" :businessType="businessTypeXJZB"></UploadFile>
    <div class="container" style="text-align: center;margin-top: 20px">
      <div>
        <a-button v-if="isEdit" type="primary" @click="saveTendering">保存</a-button>
        <a-button @click="goBack()">返回</a-button>
      </div>
    </div>
  </div>
</template>

<script>

  import {apiService} from "@/services/apiservice";
  import TendBasicInfo from './model/TendBasicInfo'
  import ResultInfo from './model/ResultInfo'
  import WinFirm from './model/WinFirm'
  import UploadFile from '@/components/operation/UploadFile'
  import Vue from 'vue'
  export default {
    name: "TenderingAdd",
    components: {
      TendBasicInfo,
      ResultInfo,
      WinFirm,
      UploadFile,
    },
    data() {
      return {
        id:"",
        isEdit:true,
        isNew:false,
        dataInfo:[],
        biddingsupplierList:[],// 中标厂商列表
        businessTypeXBJ:'ZB', // 招投标文档文档类型
        businessTypeXJZB:'ZBZB', // 中标文档文档类型
      }
    },
    methods: {
      goBack(uuid){
          this.$router.go(-1)
      },
      getItmcInvestmentBiddingDetail(){// 获取招投标详情信息
        var params = {id: this.id}
        params._json = true
        apiService.getItmcInvestmentBiddingDetail(params).then(r => {
            this.dataInfo = r
            this.biddingsupplierList = r.itmcInvestmentBiddingsupplierList // 中标厂商列表
            console.log(r)
        }, r => {
        }).catch(
        )
      },
      // 新增询比价保存信息
      addBidding(parmasData){
        var _self = this
        apiService.addBidding(parmasData).then(r => {
          if(r.result == 200){
            _self.$message.success('保存成功！')
            _self.$router.push({path: "/procurement-list"})
          }else{
            _self.$message.warning(r.msg)
          }
        }, r => {
        }).catch(
        )
      },
      // 编辑询比价保存信息
      editPurchaseInfo(parmasData){
        var _self = this
        apiService.editPurchaseInfo(parmasData).then(r => {
          if(r.result == 200){
            _self.$message.success('保存成功！')
            _self.$router.push({path: "/procurement-list"})
          }else{
            _self.$message.warning(r.msg)
          }
        }, r => {
        }).catch(
        )
      },
      saveTendering(){
        let _self=this
        Vue.set(this.dataInfo, 'itmcInvestmentBiddingsupplierList', this.biddingsupplierList)
        if(this.dataInfo.editBiddingName){
          if(this.dataInfo.buyType == '1'){
            this.dataInfo.binddingApplyName = this.dataInfo.biddingName + this.dataInfo.editBiddingName + '招投标'
          }else if(this.dataInfo.buyType == '0'){
            this.dataInfo.binddingApplyName = this.dataInfo.feeTypeName + this.dataInfo.editBiddingName + '招投标'
          }
        }
        if(this.isNew){
          Vue.set(this.dataInfo, 'id', this.id)
          let parmasData = {flag: '2', itmcInvestmentBiddingDTO: this.dataInfo}
          parmasData._json=true
          this.addBidding(parmasData)
        }else{
          let parmas = {biddingType:'2', itmcInvestmentBiddingDTO: this.dataInfo}
          parmas._json = true
          this.editPurchaseInfo(parmas)
        }
      },
    },
    computed: {

    },
    filters:{
    },
    created(){
      this.id=this.$route.query.id
      this.isEdit = this.$route.query.isEdit
      this.isNew = this.$route.query.isNew

      if(!this.isNew) this.getItmcInvestmentBiddingDetail()
      else{
        var dataInfo = {
          "biddingItemName": "",
          "biddingName": "",
          "biddingNo": "",
          "biddingType": 0,
          "binddingApplyName": "",
          "businessContractor": "",
          "buyType": 0,
          "feeType": 0,
          "id": "",
          "isValid": 0,
          "itmcInvestmentBiddingsupplierList": [],
          "periodEndDate": null,
          "periodStartDate": null,
          "projectId": "",
          "softOrHard": 0,
          "startDate": null,
          "techContractor": "",
          "recommend":""
        }
        this.dataInfo = dataInfo
      }
    }
  }
</script>
<style scoped>
  @import '../../assets/css/common.css';
  .wrap {
    padding: 20px;
    background: #ffffff;
    margin: 10px;
  }
  .ant-table-tbody>tr>td, .ant-table-thead>tr>th{
    border-right:1px solid #e8e8e8;
  }
  .ant-table-body{
    border-left:1px solid #e8e8e8;
    border-top:1px solid #e8e8e8;
  }
</style>
