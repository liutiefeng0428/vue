<template>
  <div class="wrap">
    <div style="margin-bottom:16px;">
      <span>年度:</span>
      <a-select :value="optionDateSelect" defaultValue="" class="querySelect" @change="handleChangeDate" style="width:160px">
        <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
      </a-select>
      <span style="margin-left: 15px;">采购方式:</span>
      <a-select :value="plateSelect" class="querySelect" @change="handleChangePlate" style="width:160px">
        <a-select-option v-for="item in plateArr" :key="item.id"> {{item.plateType}}</a-select-option>
      </a-select>
      <span style="margin-left: 15px;">名称:</span>
      <a-input v-model="proName" style="width: 160px"></a-input>
      <span style="margin-left: 15px;">项目名称/开支类型:</span>
      <a-input v-model="proType" style="width: 160px"></a-input>
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="queryTable" icon="search">查询</a-button>
      </span>
    </div>
    <div style="margin-bottom: 20px">
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="toAdd('0')" icon="plus">添加询比价申请</a-button>
      </span>
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="toAdd('1')" icon="plus">添加招投标方案</a-button>
      </span>
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="toAdd('2')" icon="plus">添加商务谈判单</a-button>
      </span>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>采购管理列表</span>
      <span class="unitText" style="top:15px">单位：万元</span>
    </div>
    <div>
      <div>
        <div class="ant-table-content">
          <div class="ant-table-body">
            <table style="width: 100%">
              <thead class="ant-table-thead">
              <tr>
                <th rowspan="1" class=""><div>序号</div></th>
                <th rowspan="1" class=""><div>采购方式</div></th>
                <th rowspan="1" class=""><div>名称</div></th>
                <th rowspan="1" class=""><div>项目名称/开支类型</div></th>
                <th rowspan="1" class=""><div>有效期</div></th>
                <th rowspan="1" class=""><div>有效性</div></th>
                <th colspan="1" class=""><div>操作</div></th>
              </tr>
              </thead>
              <tbody class="ant-table-tbody">
              <tr  v-for="(item,index) in dataInfo" :key="index">
                <td>{{index+1}}</td>
                <td v-if="item.biddingType=='1'">询比价</td>
                <td v-else-if="item.biddingType=='2'">招投标</td>
                <td v-else-if="item.biddingType=='3'">商务谈判</td>
                <td>
                  <span class="ecllipsis">
                    <a @click="toDetail(index)">{{item.name}}</a>
                  </span>
                </td>
                <td>{{item.applyName}}</td>
                <td>{{item.validity}}</td>
                <td v-if="item.isValid=='0'">无效</td>
                <td v-else>有效</td>
                <td style="width: 160px">
                  <a @click="handleEdit('0')">
                    <a-icon type="edit"/>
                    编辑
                  </a>
                  <a-divider type="vertical"/>
                  <a-popconfirm title="确定删除吗?"  okText="确定" cancelText="取消" @confirm="() => handleDelete(record.id)">
                    <a>删除</a>
                  </a-popconfirm>
                </td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <!--<a-modal
      title="导入年度费用预算"
      :width="600"
      centered
      v-model="expVisible"
      @ok="() => saveVersion()"
      @cancel="() => setVersionVisible(false)"
      okText="保存"
      cancelText="取消"
    >
      <div>
        <div class="clearfix">
        </div>
      </div>
    </a-modal>-->

  </div>
</template>

<script>
  import {apiService} from "@/services/apiservice";
  import search from '../../components/procurement/search';
  export default {
    name: "ProcurementList",
    data() {
      return {
        plateArr:[
          {id:'',plateType:"--请选择--"},
          {id:'1',plateType:"询比价"},
          {id:'2',plateType:"招投标"},
          {id:'3',plateType:"商务谈判"}],
        plateSelect:"",//采购方式
        optionDate: [],
        optionDateSelect: '全部',//年度
        proName:"",//名称
        proType:"",//项目名称/开支类型
        dataInfo:[]
      }
    },
    components:{search},
    methods: {
      handleEdit(type){
        if(type=='0'){
          this.$router.push({path: "/compariso-add", query: {id:type}})
        }else if(type=='1'){
          this.$router.push({path: "/tendering-add", query: {id:type}})
        }else if(type=='2'){
          this.$router.push({path: "/business-add", query: {id:type}})
        }

      },
      handleDelete(id){},
      toAdd(type){
          debugger
        if(type=='0'){
          this.$router.push({path: "/compariso-add", query: {id:type}})
        }else if(type=='1'){
          this.$router.push({path: "/tendering-add", query: {id:type}})
        }else if(type=='2'){
          this.$router.push({path: "/business-add", query: {id:type}})
        }

      },
      toDetail(type){
        if(type=='0'){
          this.$router.push({path: "/compariso-detail", query: {id:type}})
        }else if(type=='1'){
          this.$router.push({path: "/tendering-detail", query: {id:type}})
        }else if(type=='2'){
          this.$router.push({path: "/business-detail", query: {id:type}})
        }

      },
      loadDate(){
        var _self = this
        var parmasData = "typeCode=JHNDM"
        apiService.getDictionary1(parmasData).then(r => {
          console.log(r)
          _self.optionDate = r
          // _self.optionDateSelect = _self.optionDate[0].optionCode

        }, r => {
        }).catch(

        )
      },

      handleChangePlate(value){
        console.log(value)
        if(value != ''){
          this.plateSelect = value
        }
      },
      handleChangeDate(value){
        console.log(value)
        if(value != null&& value != ''){
          this.optionDateSelect = value
        }
      },
      loadTable(params){
        let _self = this
        apiService.getItmcPurchaseList(params).then(r => {
           console.log(r)
           _self.dataInfo = r.result
        })
      },
      queryTable(){
        let optionDateSelect=this.optionDateSelect
        if(this.optionDateSelect=='全部'){
          optionDateSelect=""
        }
        let _self = this
        var ItmcPurDTO = {
            year: _self.optionDateSelect,//年度
            biddingType:_self.plateSelect,//采购方式
            name:_self.proName,//名称
            applyName:_self.proType,//项目名称/开支类型
          }
        if(this.optionDateSelect == '全部') {
          ItmcPurDTO.year = '0'
        }
          ItmcPurDTO._json = true
          console.log(ItmcPurDTO)
          this.loadTable(ItmcPurDTO)
      },
    },
    created(){
      var params = {
          year: '0',//年度
          biddingType:'',//采购方式
          name:'',//名称
          applyName:'',//项目名称/开支类型
      }
      params._json = true
      this.loadTable(params)
      this.loadDate()
    }
  }
</script>
<style scoped>
  @import '../../assets/css/common.css';
  .wrap {
    background: #ffffff;
    padding: 20px;
    height: 100%;
  }
  #headSearch > span {
    margin-left: 10px;
  }
  #headSearch {
    align-items: center;
  }
  .ant-table-tbody > tr > td {
    border: 1px solid #e8e8e8;
    text-align: center;
  }
  .ant-table-thead > tr > th {
    border-left: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
    text-align: center;
  }
  .ant-table-thead tr {
    border-top: 1px solid #e8e8e8;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    right: 25px;
  }

</style>
