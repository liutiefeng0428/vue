<template>
  <div class="wrap">
    <div style="margin-bottom:16px;">
      <span>年度:</span>
      <a-select :value="optionDateSelect" class="querySelect" @change="handleChangeDate" style="width:160px">
        <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
      </a-select>
      <span style="margin-left: 15px;">采购方式:</span>
      <a-select :value="plateSelect" class="querySelect" @change="handleChangePlate" style="width:160px">
        <a-select-option v-for="item in biddingTypeList" :key="item.typeCode"> {{item.typeName}}</a-select-option>
      </a-select>
      <span style="margin-left: 15px;">名称:</span>
      <a-input v-model="proName" style="width: 160px"></a-input>
      <span style="margin-left: 15px;">项目名称/开支类型:</span>
      <a-input v-model="proType" style="width: 160px"></a-input>
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="queryTable" icon="search">查询</a-button>
      </span>

    </div>
    <div style="margin-bottom: 20px">
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="toAdd('1')" icon="plus">添加询比价申请</a-button>
      </span>
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="toAdd('2')" icon="plus">添加招投标方案</a-button>
      </span>
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="toAdd('3')" icon="plus">添加商务谈判单</a-button>
      </span>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>采购管理列表</span>
      <span class="unitText" style="top:15px">单位：万元</span>
    </div>
    <div id="procurementList">
      <div>
        <a-table style="width: 100%;" :columns="columns" :dataSource="dataInfo" rowKey="uuid" :scroll="{ y: 240 }">
          <span slot="serialNum" slot-scope="text, record, index">
            <span>{{index+1}}</span>
          </span>
          <span slot="biddingType" slot-scope="text, record, index">
            <span v-if="record.biddingType=='1'">询比价</span>
            <span v-else-if="record.biddingType=='2'">招投标</span>
            <span v-else-if="record.biddingType=='3'">商务谈判</span>
          </span>
          <span slot="contractCode" slot-scope="text, record, index">
            <span :title="record.contractCode">{{record.contractCode}}</span>
          </span>
          <span slot="name" slot-scope="text, record, index">
            <a :title="record.name" @click="toDetail(record.biddingType, record.id)">{{record.name}}</a>
          </span>
          <span slot="applyName" slot-scope="text, record, index">
            <span :title="record.applyName">{{record.applyName}}</span>
          </span>
          <span slot="validity" slot-scope="text, record, index">
            <span :title="record.validity">{{record.validity}}</span>
          </span>
          <span slot="isValid" slot-scope="text, record, index">
            <span v-if="record.isValid=='0'" title="无效">无效</span>
            <span v-else title="有效">有效</span>
          </span>
          <span slot="action" slot-scope="text, record, index">
            <a @click="handleEdit(record.biddingType, record.id)" >编辑</a>
            <a-popconfirm title="确定删除吗?" okText="确定" cancelText="取消" @confirm="() => handleDelete(record.id, record.biddingType)">
                <a>删除</a>
            </a-popconfirm>
          </span>
        </a-table>
        <!-- <div class="ant-table-content">
          <div class="ant-table-body">
            <table style="width: 100%">
              <thead class="ant-table-thead">
              <tr>
                <th rowspan="1" class=""><div>序号</div></th>
                <th rowspan="1" class=""><div>采购方式</div></th>
                <th rowspan="1" class=""><div>名称</div></th>
                <th rowspan="1" class=""><div>项目名称/开支类型</div></th>
                <th rowspan="1" class=""><div>时间</div></th>
                <th rowspan="1" class=""><div>有效性</div></th>
                <th colspan="1" class=""><div>操作</div></th>
              </tr>
              </thead>
              <tbody class="ant-table-tbody">
              <tr  v-for="(item,index) in dataInfo">
                <td>{{index+1}}</td>
                <td v-if="index=='0'">询比价</td>
                <td v-else-if="index=='1'">招投标</td>
                <td v-else>商务谈判</td>
                <td>
                  <span class="ecllipsis">
                    <a @click="toDetail(index)">{{item.projectContent}}</a>
                  </span>
                </td>
                <td>{{item.conYear}}</td>
                <td>{{item.constrNature}}</td>
                <td>{{item.totalSum}}</td>
                <td style="width: 160px">
                  <a @click="handleEdit('0')">
                    <a-icon type="edit"/>
                    编辑
                  </a>
                  <a-divider type="vertical"/>
                  <a-popconfirm title="确定删除吗?"  okText="确定" cancelText="取消" @confirm="() => handleDelete(record.id)">
                    <a>删除</a>
                  </a-popconfirm>
                </td>
              </tr>
              </tbody>
            </table>
          </div>
        </div> -->
      </div>
    </div>
  </div>
</template>

<script>
const columns = [
  {
    title: '序号',
    dataIndex: 'serialNum',
    width: 50,
    scopedSlots: { customRender: 'serialNum' }
  },
  {
    title: '采购方式',
    dataIndex: 'biddingType',
    width: 100,
    scopedSlots: { customRender: 'biddingType' }
  }, {
    title: '名称',
    dataIndex: 'name',
    width: 150,
    className: 'column-name',
    scopedSlots: { customRender: 'name' }
  }, {
    title: '项目名称/开支类型',
    dataIndex: 'applyName',
    width: 120,
    scopedSlots: { customRender: 'applyName' }
  }, {
    title: '时间',
    dataIndex: 'validity',
    width: 150,
    scopedSlots: { customRender: 'validity' }
  }, {
    title: '有效性',
    dataIndex: 'isValid',
    width: 70,
    scopedSlots: { customRender: 'isValid' }
  }, {
    title: '操作',
    dataIndex: 'action',
    width: 100,
    scopedSlots: { customRender: 'action' }
  }
];
  import {apiService} from "@/services/apiservice";
  export default {
    name: "ProcurementList",
    data() {
      return {
        plateArr:["","经营管理平台","生产营运平台","客户服务平台","技术支撑平台","新技术应用类"],
        biddingTypeList:[{'typeCode':'', 'typeName':'全部'},{'typeCode':'1', 'typeName':'询比价'},{'typeCode':'2', 'typeName':'招投标'},{'typeCode':'3', 'typeName':'商务谈判'}],
        plateSelect:"",
        optionDate: [],
        optionDateSelect: '',
        proName:"",
        proType:"",
        dataInfo:[],
        columns:columns,
        isNew: false,

      }
    },
    methods: {
      handleEdit(type, id){
        if(type=='1'){
          this.$router.push({path: "/compariso-add", query: {type:type, id:id, isEdit:true,isNew: false}})
        }else if(type=='2'){
          this.$router.push({path: "/tendering-add", query: {type:type, id:id, isEdit:true,isNew: false}})
        }else if(type=='3'){
          this.$router.push({path: "/business-add", query: {type:type, id:id, isEdit:true,isNew: false}})
        }

      },
      handleDelete(id, biddingType){
        let parmasData = {biddingType:biddingType, id:id}
        parmasData._json = true
        this.delItmcPurchaseList(parmasData)
      },
      toAdd(type){
        if(type=='1'){
          this.$router.push({path: "/compariso-add", query: {id:this.uuid(32, 16), isEdit:true,isNew: true}})
        }else if(type=='2'){
          this.$router.push({path: "/tendering-add", query: {id:this.uuid(32, 16), isEdit:true,isNew: true}})
        }else if(type=='3'){
          this.$router.push({path: "/business-add", query: {id:this.uuid(32, 16), isEdit:true,isNew: true}})
        }

      },
      toDetail(type, id){
        if(type=='1'){
          this.$router.push({path: "/compariso-add", query: {type:type, id:id, isEdit:false,isNew: false}})
        }else if(type=='2'){
          this.$router.push({path: "/tendering-add", query: {type:type, id:id, isEdit:false,isNew: false}})
        }else if(type=='3'){
          this.$router.push({path: "/business-add", query: {type:type, id:id, isEdit:false,isNew: false}})
        }

      },
      loadDate(parmasData){
        let _self = this
        // apiService.getVersionName(parmasData).then(r => {
        apiService.getDictionary1(parmasData).then(r => {
          _self.optionDate=r
          _self.optionDateSelect = _self.optionDate[0].optionCode
        }, r => {
        }).catch(
        )
      },
      loadTable(params){
          let _self = this
          apiService.getItmcPurchaseList(params).then(r => {
          console.log(r)
          // if(r.result.length <= 0){
          //     this.showTable = true
          // }else {
          //     this.showTable = false
          // }
          _self.dataInfo = r
          })
      },
      delItmcPurchaseList(parmasData){
          let _self = this
          apiService.delItmcPurchaseList(parmasData).then(r => {
            if(r.result == 200){
              // 重新获取表格数据列表
              var params = {rows: this.pageSize, page: this.currentPage, year:this.optionDateSelect, biddingType:this.plateSelect, name:this.proName, applyName:this.proType}
              params._json = true
              this.loadTable(params)
            }
          })
      },
      handleChangePlate(value){
        this.plateSelect = value
      },
      handleChangeDate(value){
        this.optionDateSelect = value
      },
      queryTable(){
        let optionDateSelect=this.optionDateSelect
        if(this.optionDateSelect=='全部'){
          optionDateSelect=""
        }
        var params = {year:optionDateSelect,biddingType:this.plateSelect,name:this.proName,applyName:this.proType}
        params._json = true
        this.loadTable(params)
      },
      uuid(len, radix) {//设置UUID
        var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
        var uuid = [], i;
        radix = radix || chars.length;
        if (len) {
        // Compact form
          for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random()*radix];
          } else {
          // rfc4122, version 4 form
            var r;
            // rfc4122 requires these characters
            uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
            uuid[14] = '4';
            // Fill in random data. At i==19 set the high bits of clock sequence as
            // per rfc4122, sec. 4.1.5
            for (i = 0; i < 36; i++) {
              if (!uuid[i]) {
              r = 0 | Math.random()*16;
              uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
              }
            }
        }
        this.uuidAdd = uuid.join('')
        return uuid.join('');
      },
    },
    created(){
      // let parmasData={}
      // parmasData._json=true
      // 获取年度列表
      var parmasData = "typeCode=JHNDM"
      this.loadDate(parmasData)
      // 获取表格数据列表
      var params = {rows: this.pageSize, page: this.currentPage, year:this.optionDateSelect, biddingType:this.plateSelect, name:this.proName, applyName:this.proType}
      params._json = true
      this.loadTable(params)
    }
  }
</script>
<style >
  @import '../../assets/css/common.css';
  .wrap {
    background: #ffffff;
    padding: 20px;
    height: 100%;
  }
  #headSearch > span {
    margin-left: 10px;
  }
  #headSearch {
    align-items: center;
  }
  .ant-table-tbody > tr > td {
    border: 1px solid #e8e8e8;
    text-align: center;
  }
  .ant-table-thead > tr > th {
    border-left: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
    border-bottom: none;
    text-align: center;
  }
  .ant-table-thead tr {
    border-top: 1px solid #e8e8e8;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    right: 25px;
  }
  #procurementList table {
    width: 100%;
    table-layout: fixed;
  }
  #procurementList table tbody tr td{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
  }
</style>
