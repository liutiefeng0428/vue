<template>
  <div class="wrap">
    <div style="margin-bottom:16px;">
      <span>资产种类:</span>
      <a-select defaultValue="" class="querySelect" @change="handleChangeDate" style="width:160px">
        <a-select-option v-for="item in optionDate" :key="item.versionsName"> {{item.versionsName}}</a-select-option>
      </a-select>
      <span style="margin-left: 15px;">编码:</span>
      <a-input v-model="proName" style="width: 160px"></a-input>
      <span style="margin-left: 15px;">关键信息:</span>
      <a-input v-model="proName" style="width: 160px"></a-input>
    </div>
    <div style="margin-bottom: 20px">
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="queryTable" icon="search">查询</a-button>
      </span>
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="handleEdit()" icon="plus">新增</a-button>
      </span>
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="toAdd('1')" icon="plus">下载模板</a-button>
      </span>
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="toAdd('2')" icon="plus">导入</a-button>
      </span>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>资产管理</span>
      <span class="unitText" style="top:15px">单位：万元</span>
    </div>
    <div>
      <div>
        <div class="ant-table-content">
          <div class="ant-table-body">
            <table style="width: 100%">
              <thead class="ant-table-thead">
              <tr>
                <th rowspan="1" class=""><div>序号</div></th>
                <th rowspan="1" class=""><div>种类</div></th>
                <th rowspan="1" class=""><div>类型</div></th>
                <th rowspan="1" class=""><div>资产识别码</div></th>
                <th rowspan="1" class=""><div>配置名称</div></th>
                <th rowspan="1" class=""><div>品牌/产品名称/型号</div></th>
                <th colspan="1" class=""><div>当前有效</div></th>
                <th rowspan="1" class=""><div>单价</div></th>
                <th colspan="1" class=""><div>数量(台、套)</div></th>
                <th colspan="1" class=""><div>折扣</div></th>
                <th rowspan="1" class=""><div>折扣后价格</div></th>
                <th colspan="1" class=""><div>操作</div></th>
              </tr>
              </thead>
              <tbody class="ant-table-tbody">
              <tr  v-for="(item,index) in dataInfo">
                <td>{{item.conYear}}</td>
                <td>{{item.conYear}}</td>
                <td>
                  <span class="ecllipsis">
                    <a @click="toDetail(index)">{{item.projectContent}}</a>
                  </span>
                </td>
                <td>{{item.conYear}}</td>
                <td>{{item.constrNature}}</td>
                <td>{{item.totalSum}}</td>
                <td>{{item.conYear}}</td>
                <td>{{item.constrNature}}</td>
                <td>{{item.totalSum}}</td>
                <td>{{item.constrNature}}</td>
                <td>{{item.totalSum}}</td>
                <td style="width: 160px">
                  <a @click="handleEdit('0')">
                    <a-icon type="edit"/>
                    编辑
                  </a>
                  <a-divider type="vertical"/>
                  <a-popconfirm title="确定删除吗?"  okText="确定" cancelText="取消" @confirm="() => handleDelete(record.id)">
                    <a>删除</a>
                  </a-popconfirm>
                </td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <!--<a-modal
      title="导入年度费用预算"
      :width="600"
      centered
      v-model="expVisible"
      @ok="() => saveVersion()"
      @cancel="() => setVersionVisible(false)"
      okText="保存"
      cancelText="取消"
    >
      <div>
        <div class="clearfix">
        </div>
      </div>
    </a-modal>-->

  </div>
</template>

<script>

  import {apiService} from "@/services/apiservice";
  export default {
    name: "resourceList",
    data() {
      return {
        plateArr:["","经营管理平台","生产营运平台","客户服务平台","技术支撑平台","新技术应用类"],
        plateSelect:"",
        optionDate: [],
        optionDateSelect: '',
        proName:"",
        proType:"",
        dataInfo:[{"id":"326f63b0d36e46f6acc22fadb242cc26","planYear":"2019","belongPlat":"经营管理平台","constrNature":"新开","projectName":"测试导入01","projectContent":"测试导入201905291441","approvalNum":null,"businessArea":"绩效管理","versionsName":"各处申报汇总版","versionsState":"2019-07-01项目二处","constarYear":null,"conendYear":null,"conYear":"2019-2020","investmentChannel":"B01","totalZbSort":100.0,"totalZbHardware":100.0,"totalZbService":100.0,"totalZbOther":100.0,"totalQySort":100.0,"totalQyHardware":100.0,"totalQyService":100.0,"totalQyOther":100.0,"totalSum":800.0,"nyZbSort":5.0,"nyZbHardware":5.0,"nyZbService":5.0,"nyZbOther":5.0,"nyQylhSort":5.0,"nyQylhHardware":5.0,"nyQylhService":5.0,"nyQylhOther":5.0,"nyQyytSort":5.0,"nyQyytHardware":5.0,"nyQyytService":5.0,"nyQyytOther":5.0,"nyQyxsSort":5.0,"nyQyxsHardware":5.0,"nyQyxsService":5.0,"nyQyxsOther":5.0,"nyQykySort":5.0,"nyQykyHardware":5.0,"nyQykyService":5.0,"nyQykyOther":5.0,"nyQyzySort":5.0,"nyQyzyHardware":5.0,"nyQyzyService":5.0,"nyQyzyOther":5.0,"remark":"项目二处备注","nyTotalSum":120.0,"lyZbSort":0.0,"lyZbHardware":0.0,"lyZbService":0.0,"lyZbOther":0.0,"lyQySort":0.0,"lyQyHardware":0.0,"lyQyService":0.0,"lyQyOther":0.0,"nowZbSort":100.0,"nowZbHardware":10.0,"nowZbService":10.0,"nowZbOther":10.0,"nowQySort":10.0,"nowQyHardware":10.0,"nowQyService":10.0,"nowQyOther":0.0,"finTotalSum":160.0,"bureaus":"项目管理二处","isDel":"0","creUserId":"3503632","creUserName":"程大庆","creTime":1561962889577,"updUserId":0.0,"updUserName":null,"updTime":1562033964367,"lyTotalSum":0.0,"nowTotalSum":160.0,"reportStatue":"1","versionTime":null,"replyState":"未上报"},{"id":"3dcc79c9d37440e68f61bb31f4b66bfe","planYear":"2019","belongPlat":"经营管理平台","constrNature":"新开","projectName":"测试导入01","projectContent":"测试导入201905291441","approvalNum":null,"businessArea":"绩效管理","versionsName":"各处申报汇总版","versionsState":"2019-07-01项目二处","constarYear":null,"conendYear":null,"conYear":"2019-2020","investmentChannel":"B01","totalZbSort":100.0,"totalZbHardware":100.0,"totalZbService":100.0,"totalZbOther":100.0,"totalQySort":100.0,"totalQyHardware":100.0,"totalQyService":100.0,"totalQyOther":100.0,"totalSum":800.0,"nyZbSort":5.0,"nyZbHardware":5.0,"nyZbService":5.0,"nyZbOther":5.0,"nyQylhSort":5.0,"nyQylhHardware":5.0,"nyQylhService":5.0,"nyQylhOther":5.0,"nyQyytSort":5.0,"nyQyytHardware":5.0,"nyQyytService":5.0,"nyQyytOther":5.0,"nyQyxsSort":5.0,"nyQyxsHardware":5.0,"nyQyxsService":5.0,"nyQyxsOther":5.0,"nyQykySort":5.0,"nyQykyHardware":5.0,"nyQykyService":5.0,"nyQykyOther":5.0,"nyQyzySort":5.0,"nyQyzyHardware":5.0,"nyQyzyService":5.0,"nyQyzyOther":5.0,"remark":"项目二处备注","nyTotalSum":120.0,"lyZbSort":0.0,"lyZbHardware":0.0,"lyZbService":0.0,"lyZbOther":0.0,"lyQySort":0.0,"lyQyHardware":0.0,"lyQyService":0.0,"lyQyOther":0.0,"nowZbSort":100.0,"nowZbHardware":10.0,"nowZbService":10.0,"nowZbOther":10.0,"nowQySort":10.0,"nowQyHardware":10.0,"nowQyService":10.0,"nowQyOther":0.0,"finTotalSum":160.0,"bureaus":"项目管理一处","isDel":"0","creUserId":"3503630","creUserName":"李伟光","creTime":1561981779966,"updUserId":0.0,"updUserName":null,"updTime":1562033964367,"lyTotalSum":0.0,"nowTotalSum":160.0,"reportStatue":"1","versionTime":null,"replyState":"未上报"},{"id":"db5c6a193b0d445781b00a8434d4620b","planYear":"2019","belongPlat":"经营管理平台","constrNature":"新开","projectName":"测试导入01","projectContent":"测试导入201905291441","approvalNum":null,"businessArea":"绩效管理","versionsName":"各处申报汇总版","versionsState":"2019-07-01项目二处","constarYear":null,"conendYear":null,"conYear":"2019-2020","investmentChannel":"B01","totalZbSort":100.0,"totalZbHardware":100.0,"totalZbService":100.0,"totalZbOther":100.0,"totalQySort":100.0,"totalQyHardware":100.0,"totalQyService":100.0,"totalQyOther":100.0,"totalSum":800.0,"nyZbSort":5.0,"nyZbHardware":5.0,"nyZbService":5.0,"nyZbOther":5.0,"nyQylhSort":5.0,"nyQylhHardware":5.0,"nyQylhService":5.0,"nyQylhOther":5.0,"nyQyytSort":5.0,"nyQyytHardware":5.0,"nyQyytService":5.0,"nyQyytOther":5.0,"nyQyxsSort":5.0,"nyQyxsHardware":5.0,"nyQyxsService":5.0,"nyQyxsOther":5.0,"nyQykySort":5.0,"nyQykyHardware":5.0,"nyQykyService":5.0,"nyQykyOther":5.0,"nyQyzySort":5.0,"nyQyzyHardware":5.0,"nyQyzyService":5.0,"nyQyzyOther":5.0,"remark":"项目二处备注","nyTotalSum":120.0,"lyZbSort":0.0,"lyZbHardware":0.0,"lyZbService":0.0,"lyZbOther":0.0,"lyQySort":0.0,"lyQyHardware":0.0,"lyQyService":0.0,"lyQyOther":0.0,"nowZbSort":100.0,"nowZbHardware":10.0,"nowZbService":10.0,"nowZbOther":10.0,"nowQySort":10.0,"nowQyHardware":10.0,"nowQyService":10.0,"nowQyOther":0.0,"finTotalSum":160.0,"bureaus":"项目管理一处","isDel":"0","creUserId":"3503630","creUserName":"李伟光","creTime":1561981760364,"updUserId":0.0,"updUserName":null,"updTime":1562033964367,"lyTotalSum":0.0,"nowTotalSum":160.0,"reportStatue":"1","versionTime":null,"replyState":"未上报"}]

      }
    },
    methods: {
      handleEdit(type){
          this.$router.push({path: "/resource-add", query: {id:type}})
      },
      handleDelete(id){},
      toAdd(type){
        if(type=='0'){
          this.$router.push({path: "/compariso-add", query: {id:type}})
        }else if(type=='1'){
          this.$router.push({path: "/tendering-add", query: {id:type}})
        }else if(type=='2'){
          this.$router.push({path: "/business-add", query: {id:type}})
        }

      },
      toDetail(type){
          this.$router.push({path: "/resource-detail", query: {id:type}})
      },
      loadDate(parmasData){
        let _self = this
        apiService.getVersionName(parmasData).then(r => {
          _self.optionDate=r
        }, r => {
        }).catch(
        )
      },

      handleChangePlate(value){
        this.plateSelect = value
      },
      handleChangeDate(value){
        this.optionDateSelect = value
      },
      queryTable(){
        let departSelect=this.departSelect
        if(this.departSelect=='全部'){
          departSelect=""
        }
        var params = {planYear:this.planYear,versionsName:this.optionDateSelect,belongPlat:this.plateSelect,constrNature:this.natureSelect,investmentChannel:this.channelSelect,bureaus:departSelect,keywords:this.keywords}
        params._json = true
        this.loadTable(params)
      },
    },
    created(){
      let parmasData={}
      parmasData._json=true
      this.loadDate(parmasData)
      var params = {planYear:this.planYear,versionsName:this.optionDateSelect,belongPlat:this.plateSelect,constrNature:this.natureSelect,investmentChannel:this.channelSelect,bureaus:this.departSelect,keywords:this.keywords,flag:'2'}
      params._json = true
      this.loadTable(params)
    }
  }
</script>
<style scoped>
  @import '../../assets/css/common.css';
  .wrap {
    background: #ffffff;
    padding: 20px;
    height: 100%;
  }
  #headSearch > span {
    margin-left: 10px;
  }
  #headSearch {
    align-items: center;
  }
  .ant-table-tbody > tr > td {
    border: 1px solid #e8e8e8;
    text-align: center;
  }
  .ant-table-thead > tr > th {
    border-left: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
    text-align: center;
  }
  .ant-table-thead tr {
    border-top: 1px solid #e8e8e8;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    right: 25px;
  }

</style>
