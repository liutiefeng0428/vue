<template>
  <div class="wrap" style="margin: 10px">
    <a-card :bordered="false">

      <!-- 左侧面板 -->
      <div class="table-page-search-wrapper">
        <a-form layout="inline">
          <a-row :gutter="12" style="padding:0 10px">
            <!--<a-col :md="7" :sm="8">-->
            <a-form-item label="字典名称">
              <a-input placeholder="请输入字典名称" v-model="queryParam.dictName"
                       style="width: 100%;"></a-input>
            </a-form-item>
            <!--</a-col>-->
            <!--<a-col :md="7" :sm="8">-->
            <a-form-item label="字典编号">
              <a-input placeholder="请输入字典编号" v-model="queryParam.dictCode"
                       style="width: 100%;"></a-input>
            </a-form-item>
            <!--</a-col>-->
            <!--<a-col :md="7" :sm="8">-->
            <span style="overflow: hidden;" class="table-page-search-submitButtons">
              <a-button type="primary" @click="searchQuery" icon="search">查询</a-button>
              <a-button type="primary" @click="searchReset" icon="reload" style="margin-left: 8px">重置</a-button>
              <a-button style="margin-bottom: 20px" @click="handleAdd" type="primary" icon="plus">添加</a-button>
              <a-button style="margin-bottom: 20px" @click="handleAddDetail" type="primary" icon="plus">添加项目明细</a-button>
            </span>

            <!--</a-col>-->
          </a-row>
          <!--<a-row style="margin-top: 15px">
            <a-col :md="24" :sm="24">
              <a-button style="margin-bottom: 20px" @click="handleAdd" type="primary" icon="plus">添加</a-button>
              &lt;!&ndash;<a-button type="primary" icon="download" @click="handleExportXls">导出</a-button>&ndash;&gt;
              &lt;!&ndash;&lt;!&ndash;<a-upload name="file" :showUploadList="false" :multiple="false" :action="importExcelUrl"&ndash;&gt;&ndash;&gt;
              &lt;!&ndash;<a-upload name="file" :showUploadList="false" :multiple="false" :action="importExcelUrl"&ndash;&gt;
              &lt;!&ndash;@change="handleImportExcel">&ndash;&gt;
              &lt;!&ndash;<a-button type="primary" icon="import">导入</a-button>&ndash;&gt;
              &lt;!&ndash;</a-upload>&ndash;&gt;
            </a-col>
          </a-row>-->
        </a-form>

        <div style="width: 100%">
          <a-spin v-show="isLoadding" style="text-align: center;width:100%">
          </a-spin>
          <a-table
            bordereds
            ref="table"
            rowKey="id"
            size="middle"
            :columns="columns"
            :dataSource="infoData"
            @change="handleTableChange">
          <span slot="action" slot-scope="text, record">
            <a @click="handleEdit(record)">
              <a-icon type="edit"/>
              编辑
            </a>
            <a-divider type="vertical"/>
            <a @click="editDictItem(record)"><a-icon type="setting"/> 字典配置</a>
            <a-divider type="vertical"/>
             <a-popconfirm title="确定删除吗?" @confirm="() => handleDelete(record.id)">
              <a>删除</a>
            </a-popconfirm>

          </span>
          </a-table>
        </div>
      </div>
      <!--新增-->
      <a-modal
        title="查看信息化建设与应用需求"
        :width="600"
        centered
        v-model="modalVisible"
        @ok="() => addTable()"
        @cancel="() => setModal1Visible(false)"
        okText="确认"
        cancelText="关闭">
        <div>
          <div class="ant-spin-container">
            <form class="ant-form ant-form-horizontal">
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="dictName" title="字典名称" class="ant-form-item-required">字典名称</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control has-success">
                  <span class="ant-form-item-children">
                    <input placeholder="请输入字典名称" type="text" data-__meta="[object Object]"
                           data-__field="[object Object]" id="" class="ant-input" v-model="addDictName">
                  </span><!---->
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="dictCode" title="字典编码" class="ant-form-item-required">字典编码</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control has-success">
                <span class="ant-form-item-children">
                <input placeholder="请输入字典编码" type="text" data-__meta="[object Object]" data-__field="[object Object]"
                       id="dictCode" class="ant-input" v-model="addDictCode">
                </span>
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="description" title="描述" class="">描述</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control">
                  <span class="ant-form-item-children">
                  <input placeholder="请输入描述信息"  type="text" data-__meta="[object Object]" data-__field="[object Object]"
                         class="ant-input" v-model="addDescription">
                  </span><!---->
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </a-modal>
      <!--新增项目明细-->
      <a-modal
        title="添加项目明细"
        :width="600"
        centered
        v-model="modalVisibleDetail"
        @ok="() => addBudgetSource()"
        @cancel="() => setModalDetailVisible(false)"
        okText="确认"
        cancelText="关闭">
        <div>
          <div class="ant-spin-container">
            <form class="ant-form ant-form-horizontal">
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="projectType" title="开支类型" class="">开支类型</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control has-success">
                  <span class="ant-form-item-children">
                    <a-select :value=projectTypeSel  class="querySelect" @change="handleChangeType" style="width:100%">
                      <a-select-option v-for="item in projectType" :key="item.code"> {{item.name}}</a-select-option>
                    </a-select>
                  </span>
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="projectName" title="项目" class="">项目</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control has-success">
                    <span class="ant-form-item-children">
                      <a-select :value=projectNameSel @change="handleChangeProName" class="querySelect" style="width:100%">
                        <a-select-option v-for="item in projectName" :key="item.code"> {{item.name}}</a-select-option>
                      </a-select>
                    </span>
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="ProjectDetailType" title="项目明细" class="">项目明细</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control">
                    <span class="ant-form-item-children">
                      <input type="text"  id="" class="ant-input" v-model="ProjectDetailType">
                    </span>
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="budgetSource" title="预算来源" class="">预算来源</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control">
                    <span class="ant-form-item-children">
                      <a-select :value=budgetSourceSel @change="handleChangebudgetSource" class="querySelect" style="width:100%">
                        <a-select-option v-for="item in budgetSource" :key="item.code"> {{item.name}}</a-select-option>
                      </a-select>
                    </span>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </a-modal>
      <!-- <AddProjectDetailType :modalVisibleDetail="modalVisibleDetail" :projectType="projectType" :projectTypeSel="projectTypeSel" :projectTypeSelText="projectTypeSelText" :projectName="projectName" :projectNameSel="projectNameSel" :projectNameSelText="projectNameSelText"></AddProjectDetailType> -->
      <!--编辑-->
      <a-modal
        title="查看信息化建设与应用需求"
        :width="600"
        centered
        v-model="editModalVisible"
        @ok="() => editTable(false)"
        @cancel="() => setModal1VisibleEdit(false)"
        okText="确认"
        cancelText="关闭">
        <div>
          <div class="ant-spin-container">
            <form class="ant-form ant-form-horizontal">
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="dictName" title="字典名称" class="ant-form-item-required">字典名称</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control has-success">
                  <span class="ant-form-item-children">
                    <input placeholder="请输入字典名称" type="text" data-__meta="[object Object]"
                           data-__field="[object Object]" id="dictName" class="ant-input" v-model="editDictName">
                  </span><!---->
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="dictCode" title="字典编码" class="ant-form-item-required">字典编码</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control has-success">
                <span class="ant-form-item-children">
                <input placeholder="请输入字典编码" type="text" data-__meta="[object Object]" data-__field="[object Object]"
                       id="" class="ant-input" v-model="editDictCode">
                </span>
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="description" title="描述" class="">描述</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control">
                  <span class="ant-form-item-children">
                  <input type="text" data-__meta="[object Object]" data-__field="[object Object]"
                         class="ant-input" v-model="editDescription">
                  </span><!---->
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </a-modal>
      <!--配置新增-->
      <a-modal
        title="查看信息化建设与应用需求"
        :width="700"
        centered
        v-model="addModalVisibleConfi"
        @ok="() => addModalConfig()"
        @cancel="() => setModal1VisibleConfig(false)"
        okText="确认"
        cancelText="关闭">
        <div class="ant-spin-nested-loading">
          <div class="ant-spin-container">
            <form class="ant-form ant-form-horizontal">
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="itemText" title="名称" class="ant-form-item-required">名称</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control">
                  <span class="ant-form-item-children">
                    <input placeholder="请输入名称" type="text" data-__meta="[object Object]" data-__field="[object Object]"
                           id="itemText" class="ant-input" v-model="itemTextAdd">
                  </span><!---->
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="itemValue" title="数据值" class="ant-form-item-required">数据值</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control"><span class="ant-form-item-children">
                <input placeholder="请输入数据值" type="text" data-__meta="[object Object]" data-__field="[object Object]"
                       id="itemValue" class="ant-input"  v-model="itemValueAdd">
              </span><!---->
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="description" title="描述" class="">描述</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control">
                  <span class="ant-form-item-children">
                    <input placeholder="请输入描述信息" type="text" data-__meta="[object Object]" data-__field="[object Object]" id="description"
                           class="ant-input" v-model="descriptionAddConf">
                  </span><!---->
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="sortOrder" title="排序值" class="">排序值</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control has-success">
                  <span class="ant-form-item-children">
                    <div class="ant-input-number" data-__meta="[object Object]" data-__field="[object Object]"
                         id="sortOrder">
                      <div class="ant-input-number-handler-wrap">
                        <span class="ant-input-number-handler ant-input-number-handler-up " unselectable="unselectable"
                              role="button" aria-label="Increase Value">
                          <i class="ant-input-number-handler-up-inner anticon anticon-up">
                            <svg viewBox="64 64 896 896" data-icon="up" width="1em" height="1em" fill="currentColor"
                                 aria-hidden="true" class="">
                              <path
                                d="M890.5 755.3L537.9 269.2c-12.8-17.6-39-17.6-51.7 0L133.5 755.3A8 8 0 0 0 140 768h75c5.1 0 9.9-2.5 12.9-6.6L512 369.8l284.1 391.6c3 4.1 7.8 6.6 12.9 6.6h75c6.5 0 10.3-7.4 6.5-12.7z"></path></svg></i></span><span
                        class="ant-input-number-handler ant-input-number-handler-down ant-input-number-handler-down-disabled"
                        unselectable="unselectable" role="button" aria-label="Decrease Value" aria-disabled="true"><i
                        class="ant-input-number-handler-down-inner anticon anticon-down">
                        <svg viewBox="64 64 896 896" data-icon="down" width="1em" height="1em" fill="currentColor"
                             aria-hidden="true" class="">
                          <path
                            d="M884 256h-75c-5.1 0-9.9 2.5-12.9 6.6L512 654.2 227.9 262.6c-3-4.1-7.8-6.6-12.9-6.6h-75c-6.5 0-10.3 7.4-6.5 12.7l352.6 486.1c12.8 17.6 39 17.6 51.7 0l352.6-486.1c3.9-5.3.1-12.7-6.4-12.7z"></path></svg></i></span></div><div
                      role="spinbutton" aria-valuemin="1" aria-valuenow="1" class="ant-input-number-input-wrap">
                      <input autocomplete="off" min="1" step="1" type="number" class="ant-input-number-input" v-model="sortOrderAddConf">
                    </div>
                    </div>
        值越小越靠前，支持小数
      </span><!---->
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label title="是否启用" class="">是否启用</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control">
                  <span class="ant-form-item-children">
                    <button type="button" role="switch" class="ant-switch " @click="isSwitch=!isSwitch" :class="isSwitch?'ant-switch-checked':''" aria-checked="true"
                            ant-click-animating="true">
                      <span class="ant-switch-inner">启用</span>
                      <div class="ant-click-animating-node">

                      </div>
                    </button>
                  </span><!---->
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </a-modal>
      <!--配置编辑-->
      <a-modal
        title="查看信息化建设与应用需求"
        :width="600"
        centered
        v-model="editModalVisibleConfig"
        @ok="() => editTableConfig()"
        @cancel="() => setModal1VisibleEditConfig(false)"
        okText="确认"
        cancelText="关闭">
        <div>
          <div class="ant-spin-container">
            <form class="ant-form ant-form-horizontal">
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="dictName" title="名称" class="ant-form-item-required">字典名称</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control has-success">
                  <span class="ant-form-item-children">
                    <input placeholder="请输入字典名称" type="text" data-__meta="[object Object]"
                           data-__field="[object Object]" id="" class="ant-input" v-model="editDictNameConfig">
                  </span><!---->
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="dictCode" title="数据值" class="ant-form-item-required">数据值</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control has-success">
                <span class="ant-form-item-children">
                <input placeholder="请输入字典数据值" type="text" data-__meta="[object Object]" data-__field="[object Object]"
                       class="ant-input" v-model="editDictCodeConfig">
                </span>
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="description" title="描述" class="">描述</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control">
                  <span class="ant-form-item-children">
                  <input placeholder="请输入描述信息" type="text" data-__meta="[object Object]" data-__field="[object Object]"
                         class="ant-input" v-model="editDescription">
                  </span><!---->
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </a-modal>

      <div>
        <a-drawer
          title="操作"
          :width="700"
          @close="onClose"
          :visible="visible"
          :wrapStyle="{height: 'calc(100% - 108px)',overflow: 'auto',paddingBottom: '108px'}"
        >
          <div
            :style="{
          padding:'10px',
          border: '1px solid #e9e9e9',
          background: '#fff',
        }"
          >
            <div class="table-page-search-wrapper">
              <a-form layout="inline" :form="form">
                <a-row :gutter="10">
                  <a-col :md="8" :sm="12">
                    <a-form-item label="名称">
                      <a-input style="width: 120px;" placeholder="请输入名称" v-model="queryParam.itemText"></a-input>
                    </a-form-item>
                  </a-col>
                  <a-col :md="9" :sm="24">
                    <a-form-item label="状态" style="width: 170px" :labelCol="labelCol" :wrapperCol="wrapperCol">
                      <a-select
                        placeholder="请选择"
                        v-model="queryParam.status"
                      >
                        <a-select-option value="1">正常</a-select-option>
                        <a-select-option value="0">禁用</a-select-option>
                      </a-select>
                    </a-form-item>
                  </a-col>
                  <a-col :md="7" :sm="24">
              <span style="float: left;" class="table-page-search-submitButtons">
                <a-button type="primary" @click="searchQueryConfig">搜索</a-button>
                <a-button type="primary" @click="searchResetConfig" style="margin-left: 8px">重置</a-button>
              </span>
                  </a-col>
                </a-row>
                <a-row style="margin-top: 10px">
                  <a-col :md="2" :sm="24">
                    <a-button style="margin-bottom: 10px" type="primary" @click="handleAddConfig">新增</a-button>
                  </a-col>
                </a-row>
              </a-form>
            </div>

            <div>
              <a-table
                ref="table"
                rowKey="id"
                size="small"
                :columns="columnsConfig"
                :dataSource="dataSourceConfig"

                @change="handleTableChangeConfig"
              >

          <span slot="action" slot-scope="text, record">
            <a @click="handleEditConfig(record)">编辑</a>
            <a-divider type="vertical"/>
            <a-popconfirm title="确定删除吗?" @confirm="() => handleDeleteConfig(record)">
              <a>删除</a>
            </a-popconfirm>
          </span>

              </a-table>
            </div>
          </div>
        </a-drawer>
      </div>
    </a-card>
  </div>
</template>

<script>

  import {apiService} from "@/services/apiservice";
  import $ from "jquery";
  import AddProjectDetailType from './AddProjectDetailType.vue'
  export default {
    name: "DictList",
    components: {
      AddProjectDetailType,
    },
    data() {
      return {
        isLoadding:false,
        modalVisible: false,
        modalVisibleDetail: false,
        visible: false,
        // 查询条件
        queryParam: {
          dictCode: "",
          dictName: "",
          itemText:"",
          status:"",
        },
        configId:"",
        editId:"",
        addModalVisible: false,
        editModalVisible: false,
        // 主页表头
        columns: [
          {
            title: '#',
            dataIndex: '',
            key: 'rowIndex',
            width: 120,
            align: "center",
            customRender: function (t, r, index) {
              return parseInt(index) + 1;
            }
          },
          {
            title: '字典名称',
            align: "left",
            dataIndex: 'optionName',
          },
          {
            title: '字典编号',
            align: "left",
            dataIndex: 'typeCode',
          },
          {
            title: '操作',
            dataIndex: 'action',
            align: "center",
            scopedSlots: {customRender: 'action'},
          }
        ],
        infoData: null,
        infoPagination:5,
        addDictCode: "",
        addDictName: "",
        addDescription: '',
        editDictName: "",
        editDictCode: "",
        editDescription: '',
        columnsConfig: [
          {
            title: '名称',
            align: "left",
            dataIndex: 'optionName',
          },
          {
            title: '数据值',
            align: "left",
            dataIndex: 'optionCode',
            width: 100,
          },
          {
            title: '描述',
            align: "left",
            dataIndex: 'note',
          },
          {
            title: '操作',
            dataIndex: 'action',
            align: "center",
            width: 150,
            scopedSlots: {customRender: 'action'},
          }],
        dataSourceConfig:null,
        infoPaginationConfig:10,
        form:null,
        labelCol: {
          xs: {span: 8},
          sm: {span: 5},
        },
        wrapperCol: {
          xs: {span: 16},
          sm: {span: 19},
        },
        itemTextAdd:"",
        itemValueAdd:"",
        descriptionAddConf:"",
        sortOrderAddConf:"",
        addModalVisibleConfi:false,
        isSwitch:false,
        editModalVisibleConfig:false,
        editDictCodeConfig:"",
        editDictNameConfig:"",
        projectType:[],//开支类型
        projectTypeSel:"",
        projectTypeSelText:"",
        projectName:[],//项目名称
        projectNameSel:"",
        projectNameSelText:"",
        ProjectDetailType:"",//选择项目明细
        budgetSource:[// 预算来源
          {
            code: '机关财务处',
            name: '机关财务处',
          },
          {
            code: '股份财务部',
            name: '股份财务部',
          },
          {
            code: '集团财务部',
            name: '集团财务部',
          }
        ],
        budgetSourceSel:''
      }
    },
    computed: {
    },
    methods: {
      loadTable(parmasData){
        let _self = this
        //主页table数据
        apiService.getDictionaryFList(parmasData).then(r => {
          _self.infoData = r
          _self.isLoadding=false
        }, r => {
        }).catch(
        )
      },
      loadTableConfig(parmasData){
        let _self = this
        //主页table数据
        apiService.getDictionaryList(parmasData).then(r => {
            _self.dataSourceConfig = r
        }, r => {

        }).catch(
        )
      },
      handleAddConfig(){
        this.addModalVisibleConfi = true;
      },
      handleAddDetail(){
        this.modalVisibleDetail = true;
      },
      addTable(){
        let _self = this
        _self.modalVisible = false
        let parmasData={typeCode:this.addDictCode,optionName:this.addDictName,note:this.addDescription}
        parmasData._json=true
        apiService.insertFDictionary(parmasData).then(r => {
            _self.$message.success("添加成功")
            //刷新数据
//            let parmas = {typeCode: _self.queryParam.dictCode, optionName: _self.queryParam.dictName}
//            _self.loadTable(parmas);

        }, r => {
          _self.$message.success("添加成功1")

        }).catch(
        )
      },
      editTable(){
        let _self = this
        this.editModalVisible = false
        let parmasData={id:this.editId,optionName:this.editDictName,typeCode:this.editDictCode,note:this.editDescription}
        parmasData._json=true
        apiService.updateFDictionary(parmasData).then(r => {
          if (r.result) {
            _self.$message.success("添加成功")
            //刷新数据
            let parmas = {typeCode: this.queryParam.dictCode, optionName: this.queryParam.dictName}
            parmas._json=true
            _self.loadTable(parmas);
          } else {
            _self.$message.error("后台接口异常")
          }
        }, r => {
        }).catch(
        )
      },
      editTableConfig(){
        let _self = this
        this.editModalVisibleConfig = false
        let parmasData={id:this.configId,optionName:this.editDictNameConfig,optionNameCode:this.editDictCodeConfig,note:this.editDescription}
        parmasData._json=true
        apiService.updateDictionary(parmasData).then(r => {
        }, r => {
          if (r.success) {
            _self.$message.success("添加成功")
            let parmas = {dictCode: this.queryParam.dictCode, dictName: this.queryParam.dictName}
            parmas._json=true
            _self.loadTableConfig(parmas);
          } else {
            _self.$message.error("后台接口异常")
          }
        }).catch(
        )
      },
      addModalConfig (){
        let _self = this
        this.addModalVisibleConfi  = false
        let status=0
        if(this.isSwitch){
          status=1
        }
        let pamas={typeCode:this.configId,status:status, optionName:_self.itemTextAdd,optionCode:_self.itemValueAdd,note:_self.descriptionAddConf, sort:_self.sortOrderAddConf}
        pamas._json=true
        apiService.insertDictionary(pamas).then(r => {
          _self.$message.success("添加成功")
          let parmas = {dictCode: _self.queryParam.dictCode, dictName: _self.queryParam.dictName}
          parmas._json=true
          _self.loadTableConfig(parmas);
        }, r => {
        }).catch(
        )
      },
      handleTableChange(){
      },
      handleTableChangeConfig(){
      },
      handleEditConfig(recode){
        this.editModalVisibleConfig=true
        this.editDictNameConfig=recode.optionName
        this.editDictCodeConfig=recode.optionCode
        this.editDescription=recode.note
        this.configId=recode.id
      },
      handleDeleteConfig(recode){
        let _self=this;
        let parmasData="id="+recode.id

        apiService.deleteDictionary(parmasData).then(r => {
        }, r => {
            _self.$message.success("删除成功")
          let parmas = {typeCode:_self.configId,optionName: _self.queryParam.itemText, status: _self.queryParam.status}
          parmas._json=true
          _self.loadTableConfig(parmas);

        }).catch(
        )
      },
      handleDelete(id){
        let _self=this;
        let parmasData={id:id}
        parmasData._json=true
        apiService.deleteFDictionary(parmasData).then(r => {
        }, r => {
          if (r.success) {
            _self.$message.success("添加成功")
            let parmas = {dictCode: this.queryParam.dictCode, dictName: this.queryParam.dictName}
            parmas._json=true
            _self.loadTable(parmas);
          } else {
            _self.$message.error("后台接口异常")
          }
        }).catch(
        )
      },
      editDictItem(record) {
        this.configId=record.typeCode
        this.visible = true;
        let parmasData={typeCode:this.configId}
        parmasData._json=true
        this.loadTableConfig(parmasData)
      },
      onClose() {
        this.visible = false
      },
      handleEdit(recode){
        this.editModalVisible = true;
        this.editDictCode =recode.typeCode
        this.editDictName =recode.optionName
        this.editDescription =recode.note
        this.editId=recode.id
      },
      handleAdd(){
        this.modalVisible = true;
        this.addDictCode=""
        this.optionName=""
        this.addDictName=""
      },
      handleExportXls(){
      },
      handleImportExcel(){
      },
      searchQuery(){
        let parmas = {typeCode: this.queryParam.dictCode, optionName: this.queryParam.dictName}
        parmas._json=true
        this.loadTable(parmas);
      },
      searchQueryConfig(){
        let parmas = {typeCode:this.configId,optionName: this.queryParam.itemText, status: this.queryParam.status}
        parmas._json=true
        this.loadTableConfig(parmas);
      },
      setModal1Visible(){
         this.modalVisible=false
      },
      setModalDetailVisible(){
        this.modalVisibleDetail=false
      },
      setModal1VisibleEdit(){
        this.editModalVisible=false
      },
      setModal1VisibleEditConfig(){
        this.editModalVisibleConfig=false
      },
      setModal1VisibleConfig(){
        this.addModalVisibleConfi=false
      },
      searchReset() {
        var _self = this;
        _self.queryParam.dictName = "";
        _self.queryParam.dictCode = "";
        let parmasData={optionName:'',optionCode:''}
        parmasData._json=true
        _self.loadTable(parmasData)
      },
      searchResetConfig(){
        var _self = this;
        _self.queryParam.itemText  = "";
        _self.queryParam.status  = "";
      },
      handleChangeType(value){
        var obj=this.projectType.find(function (obj) {
          return obj.code === value
        })
        let _self=this
        _self.projectName=[]
        if(!value){
            this.$message.warning("请先选择开支类型")
        }
        this.projectTypeSel=value
        this.projectTypeSelText=obj.name
        let projectTypeParmas={"parentCode":value, "version":this.version}
        projectTypeParmas._json=true
        apiService.getItmcProjectTypeList(projectTypeParmas).then(r => {
          _self.projectName=r
          _self.projectNameSel=r[0].code

        }, r => {
        }).catch(
        )
      },
      handleChangeProName(value){
        var obj=this.projectName.find(function (obj) {
          return obj.code === value
        })
        this.projectNameSel=value
        this.projectNameSelText=obj.name
      },
      handleChangebudgetSource(value){
        var obj=this.budgetSource.find(function (obj) {
          return obj.code === value
        })
        this.budgetSourceSel=value
        this.budgetSourceSelText=obj.name
      },
      addBudgetSource(){
        let _self = this
        _self.modalVisibleDetail = false
        let parmasData={parentCode:_self.projectNameSel,name:_self.ProjectDetailType,budgetSource:_self.budgetSourceSel}
        parmasData._json=true
        apiService.saveItmcProjectDetailType(parmasData).then(r => {
            _self.$message.success("添加成功")
        }, r => {
          // _self.$message.success("添加成功")
        }).catch(
        )
      },
      getItmcProjectTypeList(parmasData){
        let _self=this
        apiService.getItmcProjectTypeList(parmasData).then(r => {
          _self.projectType=r
          if(r.length>0){
            _self.projectTypeSel=r[0].code

            var obj= _self.projectType.find(function (obj) {
              return obj.code === _self.projectTypeSel
            })
            _self.projectTypeSelText=obj.name
            let projectNameParmas={"parentCode": _self.projectTypeSel, version: _self.version}
            projectNameParmas._json=true
            apiService.getItmcProjectTypeList(projectNameParmas).then(r1 => {
              _self.projectName=r1
              if(r1.length>0){
                _self.projectNameSel=r1[0].code
                var obj=_self.projectName.find(function (obj) {
                  return obj.code === _self.projectNameSel
                })
                _self.projectNameSelText=obj.name
              }

            }, r => {
            }).catch(
            )
          }
        }, r => {
        }).catch(
        )
      }
    },
    watch: {
    },
    created(){
      this.isLoadding=true
      let parmasData={optionName:'',typeCode:''}
      parmasData._json=true
      this.loadTable(parmasData)
      let projectTypeParmas={"parentCode":'0'}
      projectTypeParmas._json=true
      this.getItmcProjectTypeList(projectTypeParmas)
    }
  }
</script>

<style scoped>
  /** Button按钮间距 */
  .ant-btn {
    margin-left: 3px
  }

  .table-operator {
    margin-bottom: 10px
  }

  .ant-tree li span.ant-tree-switcher, .ant-tree li span.ant-tree-iconEle {
    width: 0px
  }

  .ant-card-wider-padding .ant-card-body{
    padding: 0 !important;
  }
  .ant-table-tbody>tr>td, .ant-table-thead>tr>th{
    border-left: 1px solid #e8e8e8!important;
    text-align: center!important;
  }
  .ant-table-body{
    border-top: 1px solid #e8e8e8!important;
    border-right: 1px solid #e8e8e8!important;
  }
</style>
