<template>
  <div>
      <a-modal
        title="添加项目明细"
        :width="600"
        centered
        v-model="modalVisibleDetail"
        @ok="() => addTable()"
        @cancel="() => setModalDetailVisible(false)"
        okText="确认"
        cancelText="关闭">
        <div>
          <div class="ant-spin-container">
            <form class="ant-form ant-form-horizontal">
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="projectType" title="开支类型" class="">开支类型</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control has-success">
                  <span class="ant-form-item-children">
                    <a-select :value=projectTypeSel  class="querySelect" @change="handleChangeType" style="width:100%">
                      <a-select-option v-for="item in projectType" :key="item.code"> {{item.name}}</a-select-option>
                    </a-select>
                  </span>
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="projectName" title="项目" class="">项目</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control has-success">
                    <span class="ant-form-item-children">
                      <a-select :value=projectNameSel class="querySelect" style="width:100%">
                        <a-select-option v-for="item in projectName" :key="item.code"> {{item.name}}</a-select-option>
                      </a-select>
                    </span>
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="ProjectDetailType" title="项目明细" class="">项目明细</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control">
                    <span class="ant-form-item-children">
                      <input type="text"  id="" class="ant-input" v-model="ProjectDetailType">
                    </span>
                  </div>
                </div>
              </div>
              <div class="ant-row ant-form-item">
                <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                  <label for="budgetSource" title="预算来源" class="">预算来源</label>
                </div>
                <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                  <div class="ant-form-item-control">
                    <span class="ant-form-item-children">
                      <a-select :value=budgetSourceSel class="querySelect" style="width:100%">
                        <a-select-option v-for="item in budgetSource" :key="item.code"> {{item.name}}</a-select-option>
                      </a-select>
                    </span>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </a-modal>
  </div>
</template>
<script>
  import {apiService} from "@/services/apiservice";
  export default {
    name: "AddProjectDetailType",
    data() {
      return {
        // projectType:[],//开支类型
        // projectTypeSel:"",
        // projectTypeSelText:"",
        // projectName:[],//项目名称
        // projectNameSel:"",
        // projectNameSelText:"",
        ProjectDetailType:"",//选择项目明细
        budgetSource:[// 预算来源
          {
            code: '机关财务处',
            name: '机关财务处',
          },
          {
            code: '股份财务部',
            name: '股份财务部',
          },
          {
            code: '集团财务部',
            name: '集团财务部',
          }
        ],
        budgetSourceSel:'',
        modalVisible:''
      }
    },
    props: ['modalVisibleDetail', 'projectType', 'projectTypeSel', 'projectTypeSelText', 'projectName', 'projectNameSel', 'projectNameSelText'],
    computed: {
    },
    methods: {
      setModalDetailVisible(){
        // this.modalVisibleDetail=false
      },
      handleChangeType(value){
        var obj=this.projectType.find(function (obj) {
          return obj.code === value
        })
        let _self=this
        _self.projectName=[]
        if(!value){
            this.$message.warning("请先选择开支类型")
        }
        this.projectTypeSel=value
        this.projectTypeSelText=obj.name
        let projectTypeParmas={"parentCode":value, "version":this.version}
        projectTypeParmas._json=true
        apiService.getItmcProjectTypeList(projectTypeParmas).then(r => {
          _self.projectName=r
          _self.projectNameSel=r[0].code

        }, r => {
        }).catch(
        )
      }
    },
    watch: {
    },
    created(){
      // this.modalVisible = this.modalVisibleDetail;
      // let projectTypeParmas={"parentCode":'0'}
      // projectTypeParmas._json=true
      // this.getItmcProjectTypeList(projectTypeParmas)
    }
  }
</script>