<template>
  <div style="margin: 24px">
    <a-card :bordered="false">
      <div class="table-page-search-wrapper">
        <a-form layout="inline">
          <div>
            <a-form-item label="计划年份">
              <a-select
                :size="size"
                :defaultValue=optionDate[0].optionName
                style="width: 200px"
                @change="handleChangeDate"
                v-model="optionDateSelect"
              >
                <a-select-option v-for="item in optionDate" :key="item.optionCode" :value="item.optionCode">
                  {{item.optionName}}
                </a-select-option>
              </a-select>
            </a-form-item>
            <a-form-item label="关键字搜索">
              <a-input placeholder="请输入关键字" v-model="keyWords"/>
            </a-form-item>
            <a-form-item label="主管处室">
              <a-select
                :size="size"
                :defaultValue=bureausArr[0].bureaus
                style="width: 200px"
                @change="handleChangeBureaus"
                v-model="bureaus"
              >
                <a-select-option v-for="item in bureausArr" :key="item.bureausCode" :value="item.bureausCode">
                  {{item.bureaus}}
                </a-select-option>
              </a-select>
            </a-form-item>
          </div>
          <div style="margin:16px 0;">
            <span class="table-page-search-submitButtons">
              <a-button type="primary" @click="doCheck">查询</a-button>
            </span>
            <button @click="toAdd" data-v-227ef8f8="" type="button" class="ant-btn ant-btn-primary">
              <i class="anticon anticon-plus">
                <svg viewBox="64 64 896 896" data-icon="plus" width="1em" height="1em" fill="currentColor"
                     aria-hidden="true" class="">
                  <path d="M482 152h60q8 0 8 8v704q0 8-8 8h-60q-8 0-8-8V160q0-8 8-8z"></path>
                  <path d="M176 474h672q8 0 8 8v60q0 8-8 8H176q-8 0-8-8v-60q0-8 8-8z"></path>
                </svg>
              </i>
              <span>新增</span>
            </button>
            <span class="table-page-search-submitButtons">
              <a-button type="primary">同步SUIP</a-button>
            </span>

          </div>
        </a-form>
      </div>
    </a-card>
    <!--表格-->
    <div style="padding: 0px 32px;background: #fff">
      <div class="ant-alert ant-alert-info" style="display: flex">
        <span style="flex: 1">正式项目计划</span>
        <span style="text-align: right;flex: 1;">单位：万元</span>
      </div>
    </div>
    <div id="contractWrap">
      <div style="background: #fff; padding: 0px 32px;">
        <a-table bordered :columns="columns" :dataSource="infoData.list" :pagination="{ pageSize: pageSize }">
          <a slot="action" slot-scope="text, record, index" href="javascript:;">
            <a @click="doDetail(record,text,index)">查看详情</a>
            <a-divider type="vertical"/>
            <a-popconfirm title="确定删除吗?" @confirm="() => handleDelete(record)">
              <a>删除</a>
            </a-popconfirm>
          </a>
        </a-table>
      </div>
    </div>

    <a-modal
      title="查看信息化建设与应用需求"
      :width="700"
      centered
      v-model="modalVisible"
      @ok="() => setModal1Visible(false)"
      @cancel="() => setModal1Visible(false)"
      okText="确认"
      cancelText="关闭"
    >
      <div>
        <a-form-item
          label="需求类型"
          style="margin-bottom: 0"
        >
          <a-radio :defaultChecked="true" :disabled="true">信息化应用需求</a-radio>
          <a-radio :defaultChecked="false" :disabled="true">基础设施和信息安全需求</a-radio>
        </a-form-item>
        <a-form-item
          label="项目名称"
          style="margin-bottom: 0"
        >
          <a-input v-model="modalRecodes.projectName"
            :disabled="true"
            placeholder="Please input your name"
          />
        </a-form-item>
        <a-form-item
          label="项目年限"
          style="margin-bottom: 0"
        >
          <a-input v-model="modalRecodes.projectStarYear"
                   :disabled="true"
                   style="width: 80px"
          />
          -
           <a-input v-model="modalRecodes.projectEndYear"
                    :disabled="true"
                    style="width: 80px"
         />
        </a-form-item>
        <a-form-item
          label="现状及需求"
          style="margin-bottom: 0"
        >
          <a-textarea v-model="modalRecodes.projectDemand"
                   :disabled="true"
          />
        </a-form-item>
        <a-form-item
          label="建设目标和主要内容"
          style="margin-bottom: 0"
        >
          <a-textarea v-model="modalRecodes.projectTarget"
                      :disabled="true"
          />
        </a-form-item>
        <a-form-item
          label="投资总估算"
          style="margin-bottom: 0"
        >
          <a-input v-model="modalRecodes.projectInvestSum"
                   :disabled="true"
          />
        </a-form-item>
        <a-form-item
          label="备注"
          style="margin-bottom: 0"
        >
          <a-textarea v-model="modalRecodes.note"
                      :disabled="true"
          />
        </a-form-item>
       </div>
    </a-modal>

  </div>
</template>

<script>

  const  dataSource=[
    {
      "uuid": "0ac4150587464b89aa8abf5443cd33fd",
      "contractId": "2f08c943-90ec-4792-b3c4-b1338fa40ef5",
      "projectId": "588e7a0b59764efca2f0ee396a876fac",
      "contractState": null,
      "purchaseId": "",
      "projectName": "测试项目0426-01_股份总部",
      "contractName": "采购合同-测试项目0426-01_股份总部",
      "contractType": "0101",
      "contractCode": "G11-MM-2019-357",
      "partyA": "中国石油化工股份有限公司信息化管理部",
      "partyB": "石化盈科信息技术有限责任公司",
      "partyC": null,
      "contractYeartype": "2019",
      "contractTaxAmount": 7,
      "contractNotTaxAmount": 6.03,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-26 11:32:12",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    },
    {
      "uuid": "044f9dd2913f4216b199df997cbb87ee",
      "contractId": "72ba569d-cfe3-43b5-aa58-909fdace9571",
      "projectId": "588e7a0b59764efca2f0ee396a876fac",
      "contractState": null,
      "purchaseId": "",
      "projectName": "测试项目0426-01_股份总部",
      "contractName": "采购合同-测试项目0426-01_股份总部",
      "contractType": "0101",
      "contractCode": "G11-MM-2019-356",
      "partyA": "中国石油化工股份有限公司信息化管理部",
      "partyB": "石化盈科信息技术有限责任公司",
      "partyC": null,
      "contractYeartype": "2019",
      "contractTaxAmount": 3,
      "contractNotTaxAmount": 2.59,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-26 10:55:17",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    },
    {
      "uuid": "fb263134b6514adeb574819827b6f3e1",
      "contractId": "074b3c0e-4ae7-4db2-9c76-5ffe2043c757",
      "projectId": "5dfb351a0bcc4cd6a9ae21b87c67f761",
      "contractState": null,
      "purchaseId": "",
      "projectName": "形象进度测试004_集团总部",
      "contractName": "采购合同-形象进度测试004_集团总部",
      "contractType": "0101",
      "contractCode": "GG-11-MM-2019-354",
      "partyA": "中国石油化工集团公司信息化管理部",
      "partyB": "上海众达信息产业有限公司",
      "partyC": "",
      "contractYeartype": "2019",
      "contractTaxAmount": 0,
      "contractNotTaxAmount": 0,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-24 15:32:24",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    },
    {
      "uuid": "17d76fdd75ae48138940e8b00b7fb646",
      "contractId": "f9289d35-8bc1-4855-9b14-ec4bdf0716b2",
      "projectId": "2f0902c8576947099340d1efb77fea75",
      "contractState": null,
      "purchaseId": "",
      "projectName": "形象进度测试004_股份总部",
      "contractName": "采购合同-形象进度测试004_股份总部",
      "contractType": "0101",
      "contractCode": "GG-11-MM-2019-353",
      "partyA": "中国石油化工股份有限公司信息化管理部",
      "partyB": "上海众达信息产业有限公司",
      "partyC": "",
      "contractYeartype": "2019",
      "contractTaxAmount": 0,
      "contractNotTaxAmount": 0,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-24 15:32:05",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    },
    {
      "uuid": "3339876e95e04ea0914e019758da4c63",
      "contractId": "6cefcb5a-c2e6-4793-9b39-7efef3cece74",
      "projectId": "76c8d60cdfd9432abcd8adf3e558f349",
      "contractState": null,
      "purchaseId": "",
      "projectName": "形象进度测试003_集团总部",
      "contractName": "采购合同-形象进度测试003_集团总部",
      "contractType": "0101",
      "contractCode": "GG-11-MM-2019-352",
      "partyA": "中国石油化工集团公司信息化管理部",
      "partyB": "石化盈科信息技术有限责任公司",
      "partyC": null,
      "contractYeartype": "2019",
      "contractTaxAmount": 1800,
      "contractNotTaxAmount": 1551.72,
      "comprehensiveRate": 0,
      "projectWbsCode": "",
      "createUserId": null,
      "createUserName": null,
      "createTime": "2019-04-23 17:50:23",
      "lastupdateUserId": null,
      "lastupdateUserName": null,
      "lastupdateTime": null,
      "partyACode": null,
      "partyBId": null,
      "partyCId": null,
      "fundType": null,
      "expenditureTypeCode": null,
      "expenditureTypeName": null,
      "assetsAmountSubtotal": 0,
      "expenseItem": null,
      "expenseValue": null,
      "expenseAmount": 0,
      "contractFinalPrice": 0,
      "contractNumber": null,
      "contractPaymentState": null,
      "contractSystemId": null
    }
  ];
  const data = [];
  for (let i = 0; i < dataSource.length; i++) {
    data.push({
      key: i,
      name: dataSource[i].contractName,
      amount:dataSource[i].contractNotTaxAmount,
      contractCode:dataSource[i].contractCode,
      partyA:dataSource[i].partyA,
//      contractCode: `London Park no. ${i}`,
    });
  }


  import { TreeSelect } from 'ant-design-vue'
  const SHOW_PARENT = TreeSelect.SHOW_PARENT
  import {apiService} from "@/services/apiservice";
  import ATextarea from "ant-design-vue/es/input/TextArea";
  export default {
    name: "ProjectBank",
    components: {
      ATextarea
      //  STable,
    },
    data () {
      return {
        optionDate:[],
        optionDateSelect:'',
        keyWords:'',
        bureaus:'',
        bureausArr:'',
        orgCodes:'',
        infoData:[],
        pageSize:10,
        columns:[],
        modalVisible: false,

        modalRecodes:{
            projectName:'',
            projectDemand:'',
            projectInvestSum:'',
            projectTarget:'',
            projectStarYear:'',
            projectEndYear:'',
            note:''
        },



        size: 'default',
        value: [],
        SHOW_PARENT,


      }
    },
    methods: {
      loadDate(parmasData){
        let _self=this
        apiService.getDictionary(parmasData).then(r=>{
        },r=>{
          if(r.success){
         _self.optionDate=r
              _self.optionDateSelect=r[0].optionName
          }else{
            _self.$message.error("后台接口异常")
          }
        }).catch(
        )
      },
      loadBureaus(){
        let _self=this
        apiService.getBureaus({}).then(r=>{
        },r=>{
          if(r.success){
            _self.bureausArr=r
            _self.bureaus=r[0].bureaus
          }else{
            _self.$message.error("后台接口异常")
          }
        }).catch(
        )
      },
      loadInfoData(parmasData){
        let _self=this
        apiService.getItmcDemandXxmms(parmasData).then(r=>{
        },r=>{
          if(r.success){
            _self.infoData=r
            _self.pageSize=r.pageSize
            let columns= [
              {
                title: '项目名称',
                dataIndex: 'projectName',

              },{
                title: '项目总金额',
                dataIndex: 'projectAmt',
              }, {
                title: '年度指导计划',
                dataIndex: 'advisePlan',
              }, {
                title: '建设年限',
                dataIndex: 'constarYear',
              },  {
                title: '建设性质',
                dataIndex: 'constrNatureName',
              },    {
                title: '建设内容',
                dataIndex: 'consGoals',
              },    {
                title: '所属平台',
                dataIndex: 'belongPlatName',
              },     {
                title: '主管处室',
                dataIndex: 'bureaus',
              },     {
                title: '年度',
                dataIndex: 'conendYear',
              },     {
                title: '同步状态',
                dataIndex: 'ssrc_SUIP',
              },  {
                title: '操作',
                dataIndex: 'projectCode',
                key: 'x',
                scopedSlots: { customRender: 'action' },
              },
            ]
            _self.columns=columns
          }else{
            _self.$message.error("后台接口异常")
          }
        }).catch(
        )
      },
      handleChangeDate(value){
        console.log(value);
        console.log(this.optionDateSelect);
      },
      handleChangeBureaus(){
        console.log(value);
        console.log(this.bureaus);
      },
      doCheck(){
          let parmasData={typeCode:'JHND',keyWords:this.keyWords,bureaus:this.bureaus};
          this.loadDate(parmasData)
          this.loadBureaus()
          let infoParmas={projectYear:this.optionDateSelect,keyWords:this.keyWords,bureaus:this.bureaus,rows:5,page:1}
          this.loadInfoData(infoParmas)
      },
      doDetail(record,text,index){
        this.modalRecodes=record
        this.setModal1Visible(true)
        console.log(record)

        console.log(text)
        console.log(index)
      },
      handleDelete(record){
        console.log(record)

        apiService.delProDetails(parmasData).then(r=>{
        },r=>{
          if(r.success){
            _self.infoData=r
            _self.pageSize=r.pageSize
            let columns= [
              {
                title: '项目名称',
                dataIndex: 'projectName',

              },{
                title: '项目总金额',
                dataIndex: 'projectAmt',
              }, {
                title: '年度指导计划',
                dataIndex: 'advisePlan',
              }, {
                title: '建设年限',
                dataIndex: 'constarYear',
              },  {
                title: '建设性质',
                dataIndex: 'constrNatureName',
              },    {
                title: '建设内容',
                dataIndex: 'consGoals',
              },    {
                title: '所属平台',
                dataIndex: 'belongPlatName',
              },     {
                title: '主管处室',
                dataIndex: 'bureaus',
              },     {
                title: '年度',
                dataIndex: 'conendYear',
              },     {
                title: '同步状态',
                dataIndex: 'ssrc_SUIP',
              },  {
                title: '操作',
                dataIndex: 'projectCode',
                key: 'x',
                scopedSlots: { customRender: 'action' },
              },
            ]
            _self.columns=columns
          }else{
            _self.$message.error("后台接口异常")
          }
        }).catch(
        )

      },
      setModal1Visible(modal1Visible) {
        this.modalVisible = modal1Visible;
      },




      handleChange(value) {
        console.log(`Selected: ${value}`);
      },
      onChange (value) {
        console.log('onChange ', value)
        this.value = value
      },
      handleDelete(record){
        this.$message.error("测试错误消息")
        this.$message.success("测试警告")
        this.$message.warn("测试警告")
        console.log(record)
      },
      doDelete(key,text,index){
        this.showDrawer()
      },
      showDrawer() {
        this.visible = true
      },
      onClose() {
        this.visible = false
      },
      showChildrenDrawer() {
        this.childrenDrawer = true
      },
      onChildrenDrawerClose() {
        this.childrenDrawer = false
      },
      toAdd(){
        this.$router.push({path: '/add-contract'})
      },
      exportToExcel(){
        this.$gloableF.exportToExcel(this.tHeader, this.filterVal, this.dataSource)
      },


      popupScroll(){
        console.log('popupScroll')
      },
      triggerImport(){
//         触发importRef的click事件
      },
      importfxx(obj) {
        let _this = this;
        let inputDOM = this.$refs.inputer;
        // 通过DOM取文件数据
        this.file = event.currentTarget.files[0];
        var rABS = false; //是否将文件读取为二进制字符串
        var f = this.file;
        var reader = new FileReader();
        //if (!FileReader.prototype.readAsBinaryString) {
        FileReader.prototype.readAsBinaryString = function (f) {
          var binary = "";
          var rABS = false; //是否将文件读取为二进制字符串
          var pt = this;
          var wb; //读取完成的数据
          var outdata;
          var reader = new FileReader();
          reader.onload = function (e) {
            var bytes = new Uint8Array(reader.result);
            var length = bytes.byteLength;
            for (var i = 0; i < length; i++) {
              binary += String.fromCharCode(bytes[i]);
            }
            var XLSX = require('xlsx');
            if (rABS) {
              wb = XLSX.read(btoa(fixdata(binary)), { //手动转化
                type: 'base64'
              });
            } else {
              wb = XLSX.read(binary, {
                type: 'binary'
              });
            }
            outdata = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);//outdata就是你想要的东西
            this.da = [...outdata]
            let arr = []
            this.da.map(v => {
              let obj = {}
              arr.push(v)
            })
            console.log(arr)
            let para = {
              //withList: JSON.stringify(this.da)
              withList: arr
            }
//            _this.$message({
//              message: '请耐心等待导入成功',
//              type: 'success'
//            });
            withImport(para).then(res => {
              window.location.reload()
            })

          }
          reader.readAsArrayBuffer(f);
        }
        if (rABS) {
          reader.readAsArrayBuffer(f);
        } else {
          reader.readAsBinaryString(f);
        }
      },

    },
    created(){
        this.optionDate=[
          {
            "optionName": "2020",
            "status": 0,
            "note": "需求与计划年度下拉框使用",
            "sort": 1,
            "typeCode": "JHNDS",
            "optionCode": "2020"
          },
          {
            "optionName": "2019",
            "status": 0,
            "note": "需求与计划年度下拉框使用",
            "sort": 2,
            "typeCode": "JHNDS",
            "optionCode": "2019"
          },
          {
            "optionName": "2018",
            "status": 0,
            "note": "需求与计划年度下拉框使用",
            "sort": 3,
            "typeCode": "JHNDS",
            "optionCode": "2018"
          }
        ]
        this.optionDateSelect=this.optionDate[0].optionName
        this.bureausArr=[
          {
            "id": "69c2c9ae8d744036a147880c1c6c3874",
            "bureaus": "部门领导",
            "bureausCode": "ORG000257",
            "bureausName": "信息化业务组织中国石油化工集团公司总部部门信息化管理部部门领导",
            "isDel": null,
            "creUserId": null,
            "creUserName": null,
            "creTime": null,
            "updUserId": null,
            "updUserName": null,
            "updTime": null
          },
          {
            "id": "4c8d3c5fe5f649209901c37adad35884",
            "bureaus": "综合管理处",
            "bureausCode": "ORG000168",
            "bureausName": "信息化业务组织中国石油化工集团公司总部部门信息化管理部综合管理处",
            "isDel": null,
            "creUserId": null,
            "creUserName": null,
            "creTime": null,
            "updUserId": null,
            "updUserName": null,
            "updTime": null
          },
          {
            "id": "6f79905036d04e4e9dd113f29802a0d6",
            "bureaus": "投资计划处",
            "bureausCode": "ORG000143",
            "bureausName": "信息化业务组织中国石油化工集团公司总部部门信息化管理部投资计划处",
            "isDel": null,
            "creUserId": null,
            "creUserName": null,
            "creTime": null,
            "updUserId": null,
            "updUserName": null,
            "updTime": null
          },
          {
            "id": "840bb1cb64bb43ebab77560d2025fa35",
            "bureaus": "项目管理一处",
            "bureausCode": "ORG000162",
            "bureausName": "信息化业务组织中国石油化工集团公司总部部门信息化管理部项目管理一处",
            "isDel": null,
            "creUserId": null,
            "creUserName": null,
            "creTime": null,
            "updUserId": null,
            "updUserName": null,
            "updTime": null
          },
          {
            "id": "7ce03fa25e054da9a5c8f535c53f6ce7",
            "bureaus": "项目管理二处",
            "bureausCode": "ORG000163",
            "bureausName": "信息化业务组织中国石油化工集团公司总部部门信息化管理部项目管理二处",
            "isDel": null,
            "creUserId": null,
            "creUserName": null,
            "creTime": null,
            "updUserId": null,
            "updUserName": null,
            "updTime": null
          },
          {
            "id": "9f853270a892433988e41e324e4a2297",
            "bureaus": "应用管理处",
            "bureausCode": "ORG000161",
            "bureausName": "信息化业务组织中国石油化工集团公司总部部门信息化管理部应用管理处",
            "isDel": null,
            "creUserId": null,
            "creUserName": null,
            "creTime": null,
            "updUserId": null,
            "updUserName": null,
            "updTime": null
          },
          {
            "id": "e54a3b89af5c4ceea981816fd1b21c32",
            "bureaus": "系统管理处",
            "bureausCode": "ORG000165",
            "bureausName": "信息化业务组织中国石油化工集团公司总部部门信息化管理部系统管理处",
            "isDel": null,
            "creUserId": null,
            "creUserName": null,
            "creTime": null,
            "updUserId": null,
            "updUserName": null,
            "updTime": null
          },
          {
            "id": "f411ed4d9bbc4e1c980bbdef0aaf0db9",
            "bureaus": "安全技术管理处",
            "bureausCode": "ORG000164",
            "bureausName": "信息化业务组织中国石油化工集团公司总部部门信息化管理部安全技术管理处",
            "isDel": null,
            "creUserId": null,
            "creUserName": null,
            "creTime": null,
            "updUserId": null,
            "updUserName": null,
            "updTime": null
          },
          {
            "id": "fc243bef7b6745d2a5fde99e369e077d",
            "bureaus": "总师秘书",
            "bureausCode": "ORG000258",
            "bureausName": "信息化业务组织中国石油化工集团公司总部部门信息化管理部总师秘书",
            "isDel": null,
            "creUserId": null,
            "creUserName": null,
            "creTime": null,
            "updUserId": null,
            "updUserName": null,
            "updTime": null
          }
        ]
        this.bureaus=this.bureausArr[0].bureaus
        const columns= [
          {
        title: '项目名称',
        dataIndex: 'projectName',

      },{
        title: '项目总金额',
        dataIndex: 'projectAmt',
      }, {
        title: '年度指导计划',
        dataIndex: 'advisePlan',
      }, {
        title: '建设年限',
        dataIndex: 'constarYear',
      },  {
        title: '建设性质',
        dataIndex: 'constrNatureName',
      },    {
        title: '建设内容',
        dataIndex: 'consGoals',
      },    {
        title: '所属平台',
        dataIndex: 'belongPlatName',
      },     {
            title: '主管处室',
            dataIndex: 'bureaus',
          },     {
            title: '年度',
            dataIndex: 'conendYear',
          },     {
            title: '同步状态',
            dataIndex: 'ssrc_SUIP',
          },  {
            title: '操作',
            dataIndex: 'projectCode',
            key: 'x',
            scopedSlots: { customRender: 'action' },
            width:'160px'
          },
        ]
        this.columns=columns
        this.infoData={
          "pageNum": 1,
          "pageSize": 5,
          "size": 5,
          "startRow": 1,
          "endRow": 5,
          "total": 50,
          "pages": 10,
          "list": [
            {
              "projectCode": "2025--060--063",
              "operDept": "中原油田分公司",
              "projectYear": "2025",
              "projectName": "测试项目0505-09",
              "advisePlan": 2300,
              "bureaus": "投资计划处",
              "bureausCode": "ORG000143",
              "belongPlat": "1601",
              "proCategory": "自主开发类项目",
              "constarYear": "2025",
              "conendYear": "2025",
              "constrNature": "XK",
              "projectAmt": 1020,
              "itmcConstrContentList": null,
              "explain": null,
              "startworkYear": null,
              "consGoals": "23",
              "isDel": 0,
              "creUserId": 3503629,
              "creUserName": "刘保书",
              "creTime": 1557042101632,
              "updUserId": 3503629,
              "updUserName": "刘保书",
              "updTime": 1557042101632,
              "belongPlatName": "经营管理平台",
              "constrNatureName": "新开",
              "projectType": 1,
              "masterProjectId": null,
              "operDeptCode": "ORG201011",
              "pmName": "",
              "bureausPerNameOne": "",
              "bureausPerNameTwo": "",
              "pmEmail": null,
              "bureausPerName": "张日勇",
              "companyType": null,
              "pmId": null,
              "bureausPerId": null,
              "bureausPerOneId": null,
              "bureausPerTwoId": null,
              "provinceCode": null,
              "provinceName": null,
              "batchType": null,
              "proLevelMark": "GM02",
              "uuid": "dba7145bdd9b46f3955f451e66aefe36",
              "ssrc_SUIP": "0",
              "ssrc_ERP": "0",
              "erp_CODE": null
            },
            {
              "projectCode": "2025--059--052",
              "operDept": "东北油气分公司",
              "projectYear": "2025",
              "projectName": "测试项目0505-08",
              "advisePlan": 2300,
              "bureaus": "投资计划处",
              "bureausCode": "ORG000143",
              "belongPlat": "1601",
              "proCategory": "自主开发类项目",
              "constarYear": "2025",
              "conendYear": "2025",
              "constrNature": "XK",
              "projectAmt": 1020,
              "itmcConstrContentList": null,
              "explain": null,
              "startworkYear": null,
              "consGoals": "342543",
              "isDel": 0,
              "creUserId": 3503629,
              "creUserName": "刘保书",
              "creTime": 1557041934550,
              "updUserId": 3503629,
              "updUserName": "刘保书",
              "updTime": 1557041934550,
              "belongPlatName": "经营管理平台",
              "constrNatureName": "新开",
              "projectType": 1,
              "masterProjectId": null,
              "operDeptCode": "ORG201019",
              "pmName": "",
              "bureausPerNameOne": "",
              "bureausPerNameTwo": "",
              "pmEmail": null,
              "bureausPerName": "张日勇",
              "companyType": null,
              "pmId": null,
              "bureausPerId": null,
              "bureausPerOneId": null,
              "bureausPerTwoId": null,
              "provinceCode": null,
              "provinceName": null,
              "batchType": null,
              "proLevelMark": "GM02",
              "uuid": "8aefb9cbc46b4cb1bef14fbe5e33375d",
              "ssrc_SUIP": "0",
              "ssrc_ERP": "0",
              "erp_CODE": null
            },
            {
              "projectCode": "2025--058--0167",
              "operDept": "中原油田分公司",
              "projectYear": "2025",
              "projectName": "测试项目0505-07",
              "advisePlan": 2300,
              "bureaus": "投资计划处",
              "bureausCode": "ORG000143",
              "belongPlat": "1602",
              "proCategory": "自主开发类项目",
              "constarYear": "2025",
              "conendYear": "2025",
              "constrNature": "XK",
              "projectAmt": 1020,
              "itmcConstrContentList": null,
              "explain": null,
              "startworkYear": null,
              "consGoals": "55",
              "isDel": 0,
              "creUserId": 3503629,
              "creUserName": "刘保书",
              "creTime": 1557041868370,
              "updUserId": 3503629,
              "updUserName": "刘保书",
              "updTime": 1557041868370,
              "belongPlatName": "生产营运平台",
              "constrNatureName": "新开",
              "projectType": 1,
              "masterProjectId": null,
              "operDeptCode": "ORG201011",
              "pmName": "",
              "bureausPerNameOne": "",
              "bureausPerNameTwo": "",
              "pmEmail": null,
              "bureausPerName": "张日勇",
              "companyType": null,
              "pmId": null,
              "bureausPerId": null,
              "bureausPerOneId": null,
              "bureausPerTwoId": null,
              "provinceCode": null,
              "provinceName": null,
              "batchType": null,
              "proLevelMark": "GM02",
              "uuid": "21bada2e3f014db6875eea6667542769",
              "ssrc_SUIP": "0",
              "ssrc_ERP": "0",
              "erp_CODE": null
            },
            {
              "projectCode": "2025--057--0129",
              "operDept": "江苏油田分公司",
              "projectYear": "2025",
              "projectName": "测试项目0505-06",
              "advisePlan": 2300,
              "bureaus": "投资计划处",
              "bureausCode": "ORG000143",
              "belongPlat": "1603",
              "proCategory": "自主开发类项目",
              "constarYear": "2025",
              "conendYear": "2025",
              "constrNature": "XK",
              "projectAmt": 1020,
              "itmcConstrContentList": null,
              "explain": null,
              "startworkYear": null,
              "consGoals": "76876",
              "isDel": 0,
              "creUserId": 3503629,
              "creUserName": "刘保书",
              "creTime": 1557040032122,
              "updUserId": 3503629,
              "updUserName": "刘保书",
              "updTime": 1557040032121,
              "belongPlatName": "客户服务平台",
              "constrNatureName": "新开",
              "projectType": 1,
              "masterProjectId": null,
              "operDeptCode": "ORG201013",
              "pmName": "",
              "bureausPerNameOne": "",
              "bureausPerNameTwo": "",
              "pmEmail": null,
              "bureausPerName": "张日勇",
              "companyType": null,
              "pmId": null,
              "bureausPerId": null,
              "bureausPerOneId": null,
              "bureausPerTwoId": null,
              "provinceCode": null,
              "provinceName": null,
              "batchType": null,
              "proLevelMark": "GM02",
              "uuid": "66476325835b48dfa6da948bac09a6b0",
              "ssrc_SUIP": "0",
              "ssrc_ERP": "0",
              "erp_CODE": null
            },
            {
              "projectCode": "2025--056--0138",
              "operDept": "东北油气分公司",
              "projectYear": "2025",
              "projectName": "测试项目0505-05",
              "advisePlan": 2300,
              "bureaus": "投资计划处",
              "bureausCode": "ORG000143",
              "belongPlat": "1602",
              "proCategory": "自主开发类项目",
              "constarYear": "2025",
              "conendYear": "2025",
              "constrNature": "XK",
              "projectAmt": 1020,
              "itmcConstrContentList": null,
              "explain": null,
              "startworkYear": null,
              "consGoals": "123",
              "isDel": 0,
              "creUserId": 3503629,
              "creUserName": "刘保书",
              "creTime": 1557039423248,
              "updUserId": 3503629,
              "updUserName": "刘保书",
              "updTime": 1557039423248,
              "belongPlatName": "生产营运平台",
              "constrNatureName": "新开",
              "projectType": 1,
              "masterProjectId": null,
              "operDeptCode": "ORG201019",
              "pmName": "",
              "bureausPerNameOne": "",
              "bureausPerNameTwo": "",
              "pmEmail": null,
              "bureausPerName": "张日勇",
              "companyType": null,
              "pmId": null,
              "bureausPerId": null,
              "bureausPerOneId": null,
              "bureausPerTwoId": null,
              "provinceCode": null,
              "provinceName": null,
              "batchType": null,
              "proLevelMark": "GM02",
              "uuid": "605197532a9246e19dc97f01b6925a1c",
              "ssrc_SUIP": "0",
              "ssrc_ERP": "0",
              "erp_CODE": null
            }
          ],
          "prePage": 0,
          "nextPage": 2,
          "isFirstPage": true,
          "isLastPage": false,
          "hasPreviousPage": false,
          "hasNextPage": true,
          "navigatePages": 8,
          "navigatepageNums": [
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8
          ],
          "navigateFirstPage": 1,
          "navigateLastPage": 8,
          "firstPage": 1,
          "lastPage": 8
        }



      //接口调用
      //let parmasData={typeCode:'JHND'};
      //  this.loadDate(parmasData)
      //this.loadBureaus()
      //let infoParmas={projectYear:this.optionDateSelect,keyWords:this.keyWords,bureaus:this.bureaus,rows:5,page:1}
      //this.loadInfoData(infoParmas)


    },
    watch: {
      /*
       'selectedRows': function (selectedRows) {
       this.needTotalList = this.needTotalList.map(item => {
       return {
       ...item,
       total: selectedRows.reduce( (sum, val) => {
       return sum + val[item.dataIndex]
       }, 0)
       }
       })
       }
       */
    }
  }
</script>
<style>
  #contractWrap .ant-table-bordered .ant-table-thead > tr > th{
    padding: 9px 16px!important;
  }
  #contractWrap .ant-table-bordered .ant-table-tbody > tr > td{
    padding: 2px 16px!important;
  }
</style>
