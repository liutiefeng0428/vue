<template>
  <div class="wrap">
    <div>
      <a-transfer
        :dataSource="mockData"
        :titles="['Source', 'Target']"
        :targetKeys="targetKeys"
        :selectedKeys="selectedKeys"
        @change="handleChange"
        @selectChange="handleSelectChange"
        @scroll="handleScroll"
        :render="item=>item.title"
        :disabled="disabled"
      />
      <a-switch
        unCheckedChildren="disabled"
        checkedChildren="disabled"
        :checked="disabled"
        @change="handleDisable"
        style="margin-top: 16px"
      />
    </div>
  </div>
</template>

<script>

  //  const columns = [
  //    {
  //      title: '项目名称',
  //      dataIndex: 'optionName',
  //      width: 150,
  //    }, {
  //      title: '总投资',
  //      dataIndex: 'optionName',
  //      width: 150,
  //    }, {
  //      title: '本次申请',
  //      dataIndex: 'optionName',
  //    }, {
  //      title: '累计下达',
  //      dataIndex: 'optionName',
  //    }, {
  //      title: '剩余',
  //      dataIndex: 'optionName',
  //    }, {
  //      title: '建设年限',
  //      dataIndex: 'optionName',
  //    }, {
  //      title: '建设性质',
  //      dataIndex: 'optionName',
  //    }, {
  //      title: '所属平台',
  //      dataIndex: 'optionName',
  //    }, {
  //      title: '建设内容',
  //      dataIndex: 'optionName',
  //    },
  //    {
  //      title: '操作',
  //      dataIndex: 'operation',
  //      scopedSlots: { customRender: 'operation' },
  //      width:100,
  //    }
  //  ];
  //
  //  const data = [
  //    {
  //      "id": 67,
  //      "optionName": "(复核意见/复核驳回)常用语",
  //      "status": 0,
  //      "note": "ff",
  //      "sort": null,
  //      "typeCode": "FHYJBH",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 68,
  //      "optionName": "(复核意见/复核同意)常用语",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "FHYJTY",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 69,
  //      "optionName": "付款单位(中国石化集团资产经营管理有限公司)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "FKDW",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 70,
  //      "optionName": "付款单位(中国石油化工股份有限公司总部机关财务处)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "FKDW",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 71,
  //      "optionName": "付款单位(中国石油化工集团有限公司)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "FKDW",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 72,
  //      "optionName": "付款单位(总部石油化工股份有限公司总部)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "FKDW",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 73,
  //      "optionName": "反馈",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "FKYJ",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 74,
  //      "optionName": "公司性质",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "GSXZ",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 75,
  //      "optionName": "费用合同类型",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "HTLXFY",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 76,
  //      "optionName": "项目合同类型",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "HTLXXM",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 77,
  //      "optionName": "甲方",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "JF",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 78,
  //      "optionName": "计划类型",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "JHLX",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 79,
  //      "optionName": "下拉框年份",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "JHND",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 80,
  //      "optionName": "建设性质",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "JSFL",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 81,
  //      "optionName": "建设意见",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "JSXZ",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 82,
  //      "optionName": "查询合同付款明细-付款单位",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "PayerName",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 83,
  //      "optionName": "软件",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "PFZLYS",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 84,
  //      "optionName": "硬件",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "PFZLYS",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 85,
  //      "optionName": "省份",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "PROVINC",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 86,
  //      "optionName": "省份",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "PROVINCE",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 87,
  //      "optionName": "税码",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "SMD",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 88,
  //      "optionName": "（项目/系统）所属平台",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "SSPT",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 89,
  //      "optionName": "资金使用类型",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "SYLX",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 90,
  //      "optionName": "项目分类",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "XMFL",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 91,
  //      "optionName": "业务部门(项目批复金额表)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "YWBM",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 92,
  //      "optionName": "业务种类(可研批复项目上传文件类型)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "YWZL",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 93,
  //      "optionName": "资金类型(项目批复金额表)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "ZJLX",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    }
  //  ];

  export default {
    name: "InvestmentPlan",
    data() {
     const mockData = [];
      for (let i = 0; i < 20; i++) {
        mockData.push({
          key: i.toString(),
          title: `content${i + 1}`,
          description: `description of content${i + 1}`,
          disabled: i % 3 < 1,
        });
      }

      const oriTargetKeys = mockData
        .filter(item => +item.key % 3 > 1)
        .map(item => item.key);
      return {
        mockData,
        targetKeys: oriTargetKeys,
        selectedKeys: ['1', '4'],
        disabled: false,
      }
    },
    methods: {
      handleChange(nextTargetKeys, direction, moveKeys) {
        this.targetKeys = nextTargetKeys

        console.log('targetKeys: ', nextTargetKeys);
        console.log('direction: ', direction);
        console.log('moveKeys: ', moveKeys);
      },
      handleSelectChange(sourceSelectedKeys, targetSelectedKeys) {
        this.selectedKeys = [...sourceSelectedKeys, ...targetSelectedKeys]

        console.log('sourceSelectedKeys: ', sourceSelectedKeys);
        console.log('targetSelectedKeys: ', targetSelectedKeys);
      },
      handleScroll(direction, e) {
        console.log('direction:', direction);
        console.log('target:', e.target);
      },
      handleDisable(disabled) {
        this.disabled = disabled
      },
    },
    computed: {},
    created(){
      this.optionDate = [
        {
          "id": 399,
          "optionName": "2019",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 1,
          "typeCode": "JHNDS",
          "optionCode": "2019",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 400,
          "optionName": "2020",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 2,
          "typeCode": "JHNDS",
          "optionCode": "2020",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 401,
          "optionName": "2021",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 3,
          "typeCode": "JHNDS",
          "optionCode": "2021",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        }
      ]
    }
  }
</script>
<style>
  .wrap {
    background: #ffffff;
    padding: 15px;
  }

  #headSearch > span {
    margin-left: 10px;
  }

  #headSearch {
    align-items: center;
  }

  .ant-table-tbody > tr > td {
    border: 1px solid #e8e8e8;
  }

  .ant-table-thead > tr > th {
    border-left: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
  }

  .ant-table-thead tr {
    border-top: 1px solid #e8e8e8;
  }
  /*.ant-table-thead > tr > th, .ant-table-tbody > tr > td{*/
    /*padding: 6px 16px;*/
  /*}*/
</style>
