<template>
  <div class="wrap">
    <div style="margin-bottom:16px;">
      <span>年度:</span>
      <a-select :value=optionDateSelect class="querySelect" @change="handleChangeDate" style="width: 120px">
        <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
      </a-select>
      <span class="table-page-search-submitButtons">
          <a-button type="primary" icon="search">查询</a-button>
          <a-button  type="primary" @click="triggerImport()" icon="upload">导入</a-button>
          <a-button  type="primary" @click="reportFileExport()" icon="download">导出</a-button>
      </span>
      <button :class="disabledBtn?'ant-btn-primary-disable':''" @click="authrReport" type="button"  v-bind:disabled="disabledBtn" class="ant-btn ant-btn-primary"><span>提 交</span></button>
      <!--<a-button type="primary" @click="authrReport" v-bind:disabled="disabledBtn">提交</a-button>-->
    </div>
    <div class="con-title" style="margin-top: 20px">
      <span class="divdLine"></span>
      <span>年度信息化项目投资建议计划填报（{{reportStatueText}}）</span>
    </div>
    <div>
      <div style="position: relative">
        <span class="unitText" style="top:20px">单位：万元</span>
        <a-tabs defaultActiveKey="1" @change="callback">
          <a-tab-pane tab="股份" key="B01">
            <div class="ant-table-content">
              <div class="ant-table-body">
                <table style="width: 100%" id="declareTable">
                  <thead class="ant-table-thead">
                    <tr>
                      <th rowspan="2" class=""><div>序号</div></th>
                      <th rowspan="2" class=""><div>项目编码</div></th>
                      <th rowspan="2" class=""><div>项目名称</div></th>
                      <th rowspan="2" class=""><div>项目内容</div></th>
                      <th rowspan="2" class=""><div>建设年限</div></th>
                      <th rowspan="2" class=""><div>建设性质</div></th>
                      <th rowspan="2" class=""><div>总投资</div></th>
                      <th colspan="2" class=""><div>投资完成情况</div></th>
                      <th rowspan="2" class=""><div>{{optionDateSelect}}年建议计划</div></th>
                      <!-- <th rowspan="2" class=""><div>业务领域</div></th> -->
                      <!-- <th rowspan="2" class=""><div>所属平台</div></th> -->
                      <th rowspan="2" class=""><div>初步方案</div></th>
                    </tr>
                    <tr>
                      <th><div>截止上年累计完成</div></th>
                      <th><div>当年预计完成</div></th>
                    </tr>
                  </thead>
                  <tbody class="ant-table-tbody">
                    <tr  v-for="(item,index) in dataInfo" :key="index">
                      <td>{{index+1}}</td>
                      <td :title="item.projectNum">{{item.projectNum}}</td>
                      <td :title="item.projectName">
                        <span class="ecllipsis">
                          <a @click="toDetail(item)">{{item.projectName}}</a>
                        </span>
                      </td>
                      <td :title="item.projectContent">
                        <!--<a-tooltip>-->
                           <!--<template slot='title'>-->
                             <!--{{item.projectContent}}-->
                           <!--</template>-->
                           <span class="ecllipsis">
                           {{item.projectContent}}
                            </span>
                            <!--</a-tooltip>-->
                        </td>
                      <td :title="item.conYear">{{item.conYear}}</td>
                      <td :title="item.constrNature">{{item.constrNature}}</td>
                      <td :title="item.totalSum">{{item.totalSum}}</td>
                      <td :title="item.lyTotalSum">{{item.lyTotalSum}}</td>
                      <td :title="item.nowTotalSum">{{item.nowTotalSum}}</td>
                      <td :title="item.nyTotalSum">{{item.nyTotalSum}}</td>
                      <!-- <td :title="item.businessArea">{{item.businessArea}}</td> -->
                      <!-- <td :title="item.belongPlat">{{item.belongPlat}}</td> -->
                      <td>
                        <template v-if="item.fileName !='' && item.fileName != null">
                          <!-- <a-button @click="downloadDoc(item.fileName)" type="link" icon="download" class="ant-btn ant-btn-sm downBtn"></a-button> -->
                          <a @click="downloadDoc(item.fileName)">下载</a>
                        </template>
                      </td>
                    </tr>
                    <tr>
                      <td colspan="6" style="text-align: right"><span style="margin-right: 5px;">合计：</span></td>
                      <td>{{parseFloat(totalSumAll).toFixed(2)}}</td>
                      <td>{{parseFloat(lyTotalSumAll).toFixed(2)}}</td>
                      <td>{{parseFloat(nowTotalSumAll).toFixed(2)}}</td>
                      <td>{{parseFloat(nyTotalSumAll).toFixed(2)}}</td>
                      <td></td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </a-tab-pane>
          <a-tab-pane tab="集团" key="B02" forceRender>
            <div class="ant-table-content">
              <div class="ant-table-body">
                <table style="width: 100%" id="declareTable1">
                  <thead class="ant-table-thead">
                  <tr>
                    <th rowspan="2" class=""><div>序号</div></th>
                    <th rowspan="2" class=""><div>项目编码</div></th>
                    <th rowspan="2" class=""><div>项目名称</div></th>
                    <th rowspan="2" class=""><div>项目内容</div></th>
                    <th rowspan="2" class=""><div>建设年限</div></th>
                    <th rowspan="2" class=""><div>建设性质</div></th>
                    <th rowspan="2" class=""><div>总投资</div></th>
                    <th colspan="2" class=""><div>投资完成情况</div></th>
                    <th rowspan="2" class=""><div>{{optionDateSelect}}年建议计划</div></th>
                    <!-- <th rowspan="2" class=""><div>业务领域</div></th> -->
                    <!-- <th key="typeCode" rowspan="2" class=""><div>所属平台</div></th> -->
                    <th rowspan="2" class=""><div>初步方案</div></th>
                  </tr>
                  <tr>
                    <th><div>截止上年累计完成</div></th>
                    <th><div>当年预计完成</div></th>
                  </tr>
                  </thead>
                  <tbody class="ant-table-tbody">
                  <tr  v-for="(item,index) in dataInfo2" :key='index'>
                    <td>{{index+1}}</td>
                    <td :title="item.projectNum">{{item.projectNum}}</td>
                    <td :title="item.projectName">
                      <span class="ecllipsis">
                        <a @click="toDetail(item)">{{item.projectName}}</a>
                      </span>
                    </td>
                    <td :title="item.projectContent">
                      <span class="ecllipsis">
                        {{item.projectContent}}
                      </span>
                     </td>
                    <td :title="item.conYear">{{item.conYear}}</td>
                    <td :title="item.constrNature">{{item.constrNature}}</td>
                    <td :title="item.totalSum">{{item.totalSum}}</td>
                    <td :title="item.lyTotalSum">{{item.lyTotalSum}}</td>
                    <td :title="item.nowTotalSum">{{item.nowTotalSum}}</td>
                    <td :title="item.nyTotalSum">{{item.nyTotalSum}}</td>
                    <!-- <td :title="item.businessArea">{{item.businessArea}}</td> -->
                    <!-- <td :title="item.belongPlat">{{item.belongPlat}}</td> -->
                    <td>
                      <template v-if="item.fileName !='' && item.fileName != null">
                        <!-- <a-button @click="downloadDoc(item.fileName)" type="link" icon="download" class="ant-btn ant-btn-sm downBtn"></a-button> -->
                        <a @click="downloadDoc(item.fileName)">下载</a>
                      </template>
                    </td>
                  </tr>
                  <tr>
                    <td colspan="6" style="text-align: right"><span  style="margin-right: 5px;">合计：</span></td>
                    <td>{{parseFloat(totalSumAll2).toFixed(2)}}</td>
                    <td>{{parseFloat(lyTotalSumAll2).toFixed(2)}}</td>
                    <td>{{parseFloat(nowTotalSumAll2).toFixed(2)}}</td>
                    <td>{{parseFloat(nyTotalSumAll2).toFixed(2)}}</td>
                    <td></td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </a-tab-pane>
        </a-tabs>
      </div>
    </div>
    <a-modal
      title="导入年度信息化项目投资计划"
      :width="600"
      centered
      v-model="expVisible"
      @ok="() => saveFile()"
      @cancel="() => setVersionVisible(false)"
      okText="保存"
      cancelText="取消"
    >
      <div>
        <div class="clearfix">
          <a-upload
            :multiple="true"
            :fileList="fileList"
            :remove="handleRemove"
            :beforeUpload="beforeUpload"
          >
            <a-button>
              <a-icon type="upload"/>
              上传
           </a-button>
          </a-upload>
        </div>
        <div style="margin-top: 10px;">
          <a @click="downloadFile">本处室年度投资计划填报模板下载</a>
        </div>

      </div>
    </a-modal>
  </div>
</template>

<script>

  import {apiService} from "@/services/apiservice";
  import reqwest from 'reqwest'
  import $ from "jquery";
  export default {
    name: "Declare",
    data() {
      return {
        disabledBtn:false,
        optionDate: [],
        optionDateSelect: '',
        investmentChannel:"B01",
        dataInfo:[],
        dataInfo2:[],
        expVisible:false,
        fileList: [],
        files:null,
        reportStatue:"0",
        reportStatueText:"未提交",
      }
    },
    computed:{
      totalSumAll(){
        let totalSumAll = 0;
        this.dataInfo.map((item) => {if(!isNaN(item.totalSum)) totalSumAll += item.totalSum})
        if(isNaN(totalSumAll)){
          return 0
        }
        return totalSumAll
      },
      lyTotalSumAll(){
        let lyTotalSumAll = 0;
        this.dataInfo.map((item) => {if(!isNaN(item.lyTotalSum)) lyTotalSumAll += item.lyTotalSum})
        if(isNaN(lyTotalSumAll)){
          return 0
        }
        return lyTotalSumAll
      },
      nowTotalSumAll(){
        let nowTotalSumAll = 0;
        this.dataInfo.map((item) => {if(!isNaN(item.nowTotalSum)) nowTotalSumAll += item.nowTotalSum})
        if(isNaN(nowTotalSumAll)){
          return 0
        }
        return nowTotalSumAll
      },
      nyTotalSumAll(){
        let nyTotalSumAll = 0;
        this.dataInfo.map((item) => {if(!isNaN(item.nyTotalSum)) nyTotalSumAll += item.nyTotalSum})
        if(isNaN(nyTotalSumAll)){
          return 0
        }
        return nyTotalSumAll
      },
      totalSumAll2(){
        let totalSumAll2 = 0;
        this.dataInfo2.map((item) => {if(!isNaN(item.totalSum)) totalSumAll2 += item.totalSum})
        if(isNaN(totalSumAll2)){
          return 0
        }
        return totalSumAll2
      },
      lyTotalSumAll2(){
        let lyTotalSumAll2 = 0;
        this.dataInfo2.map((item) => {if(!isNaN(item.lyTotalSum)) lyTotalSumAll2 += item.lyTotalSum})
        if(isNaN(lyTotalSumAll2)){
          return 0
        }
        return lyTotalSumAll2
      },
      nowTotalSumAll2(){
        let nowTotalSumAll2 = 0;
        this.dataInfo2.map((item) => {if(!isNaN(item.nowTotalSum)) nowTotalSumAll2 += item.nowTotalSum})
        if(isNaN(nowTotalSumAll2)){
          return 0
        }
        return nowTotalSumAll2
      },
      nyTotalSumAll2(){
        let nyTotalSumAll2 = 0;
        this.dataInfo2.map((item) => {if(!isNaN(item.nyTotalSum)) nyTotalSumAll2 += item.nyTotalSum})
        if(isNaN(nyTotalSumAll2)){
          return 0
        }
        return nyTotalSumAll2
      },
    },
    methods: {
      downloadFile(){
        let _self=this
        window.location.href='/project/itmcAut/downloadFile?planYear='+_self.optionDateSelect+"&flagExport=1"
      },
      downloadDoc(projectName){
        let _self=this
        // window.location.href='/project/itmcAut/reportFileWord?planYear='+_self.optionDateSelect+"&fileName="+projectName
        let docParams = {planYear:_self.optionDateSelect,fileName:projectName}
        console.log(docParams)
        docParams._json = true
        apiService.reportFileWord(docParams).then(r => {
          window.location.href= r
        })
      },
      reportFileExport(){
        if(this.dataInfo2.length<=0&&this.dataInfo.length<=0){
          this.$message.warning("暂无可导出数据......")
          return
        }
        window.location.href='/project/itmcAut/reportFileExport?planYear='+this.optionDateSelect
      },
      authrReport(){
        let _self=this
        if(_self.dataInfo2.length<=0&&_self.dataInfo.length<=0){
          this.$message.warning("暂无可提交数据......")
          return
        }
        let parmasData={planYear:this.optionDateSelect}
        parmasData._json=true
        apiService.authrReport(parmasData).then(r => {
            if(r.result=='0000'){
              _self.$message.success("提交成功")
              _self.disabledBtn=true
              var params = {planYear: _self.optionDateSelect,investmentChannel:"B01",flag:'1'}
              params._json = true
              _self.loadTable(params)
              var params2 = {planYear:_self.optionDateSelect,investmentChannel:"B02",flag:'1'}
              params2._json = true
              _self.loadTable2(params2)
            }else{
              _self.$message.warning(r.msg)
            }
        }, r => {
        }).catch(
        )
      },
      toDetail(item){
        let constrNature='0'
        if(item.constrNature=='续建'){
          constrNature="1"
        }
        this.$router.push({path: "/check-new", query: {planYear:this.optionDateSelect,id:item.id,constrNature:constrNature,investmentChannel:this.investmentChannel}})
      },
      setVersionVisible(){
        this.expVisible=false
      },
      handleRemove(file) {
        const index = this.fileList.indexOf(file);
        const newFileList = this.fileList.slice();
        newFileList.splice(index, 1);
        this.fileList = newFileList
      },
      beforeUpload(file) {
        // this.handleRemove(this.files) //保证只能上传一个文件
        this.files=file
        this.fileList = [...this.fileList, file]
        return false;
      },
      saveFile(){
        let _self=this
        const { fileList } = this;
        const formData = new FormData();
        fileList.forEach((file) => {
          formData.append('file',file);
        })
        // formData.append('file', this.files);
        formData.append('planYear',this.optionDateSelect)

        reqwest({
          url: '/project/itmcAut/exportfile',
          method: 'post',
          processData: false,
          data: formData,
          success: (r) => {
            if(r.result=='0000'){
              _self.fileList = []
              _self.$message.success('上传成功');
              _self.expVisible=false
              var params = {planYear: _self.optionDateSelect,investmentChannel:"B01",flag:'1'}
              params._json = true
              _self.loadTable(params)
              var params2 = {planYear:_self.optionDateSelect,investmentChannel:"B02",flag:'1'}
              params2._json = true
              _self.loadTable2(params2)
            }else if(r.result=='9999'){
              _self.$message.success(r.msg);
            }

          },
          error: () => {
            _self.messageInfo="上传失败"
            _self.showMessage=true
            setTimeout(function () {
              _self.showMessage=false
            },800)
            _self.expVisible=false
          },
        });
      },
      triggerImport(){
        this.expVisible=true
      },
      loadDate(){
        var _self = this
        var parmasData = "typeCode=JHNDS"
        apiService.getDictionary1(parmasData).then(r => {
          _self.optionDate = r
          // _self.optionDateSelect = _self.optionDate[0].optionCode

        }, r => {
        }).catch(

        )
      },
      loadTable(parmasData){
        var _self = this
        apiService.getPlanAut(parmasData).then(r => {
            _self.dataInfo=r.list
          if(r.list.length>0){
            _self.reportStatue=r.list[0].reportStatue
            if(_self.reportStatue=='0'){
              _self.reportStatueText='未提交'
              _self.disabledBtn=false
            }else{
              _self.reportStatueText='已提交'
              _self.disabledBtn=true
            }
          }else{
            _self.reportStatueText='未提交'
            _self.disabledBtn=true
            console.log(" _self.disabledBtn")
            console.log( _self.disabledBtn)
          }

        }, r => {
        }).catch(
        )
      },
      loadTable2(parmasData){
        var _self = this
        apiService.getPlanAut(parmasData).then(r => {
          _self.dataInfo2=r.list
          if(r.list.length>0){
            _self.reportStatue=r.list[0].reportStatue
            if(_self.reportStatue=='0'){
              _self.reportStatueText='未提交'
              _self.disabledBtn=false
            }else{
              _self.reportStatueText='已提交'
              _self.disabledBtn=true
            }
          }else{
            _self.reportStatueText='未提交'
            _self.disabledBtn=true
          }
        }, r => {
        }).catch(
        )
      },
      handleChangeDate(value){
        this.optionDateSelect = value
        var params = {planYear: this.optionDateSelect,investmentChannel:this.investmentChannel,flag:'1'}
        params._json = true
        this.loadTable(params)
        var params2 = {planYear:this.optionDateSelect,investmentChannel:"B02",flag:'1'}
        params2._json = true
        this.loadTable2(params2)
      },
      callback(value){
        if(value=='B01'){
          if(this.dataInfo.length>0){
            this.disabledBtn=false
          }else{
            this.disabledBtn=true
          }
        }
        if(value=='B02'){
          if(this.dataInfo2.length>0){
            this.disabledBtn=false
          }else{
            this.disabledBtn=true
          }
        }

        this.investmentChannel=value
      },
      onDelete(outerIndex, innerIndex){
      },
    },
    created(){
      var date = new Date();
      var m = date.getMonth() + 1;
      if(m >= 8){
        this.optionDateSelect=(new Date().getFullYear())+1;
        console.log(this.optionDateSelect);
      }else{
        this.optionDateSelect=new Date().getFullYear();
      }
      this.loadDate()

      var params = {planYear:this.optionDateSelect,investmentChannel:"B01",flag:'1'}
      params._json = true
      this.loadTable(params)
      var params2 = {planYear:this.optionDateSelect,investmentChannel:"B02",flag:'1'}
      params2._json = true
      this.loadTable2(params2)
    }
  }
</script>
<style>
  .wrap {
    background: #ffffff;
    padding: 15px;
  }

  #headSearch > span {
    margin-left: 10px;
  }

  #headSearch {
    align-items: center;
  }

  .ant-table-tbody > tr > td {
    border: 1px solid #e8e8e8;
  }

  .ant-table-thead > tr > th {
    border-left: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
  }

  .ant-table-thead tr {
    border-top: 1px solid #e8e8e8;
  }

  #declareTable1 .ant-table-thead > tr > th,#declareTable1 .ant-table-tbody > tr > td {
    padding: 0px 3px!important;
  }
  #declareTable .ant-table-thead > tr > th,#declareTable .ant-table-tbody > tr > td {
    padding: 0px 3px!important;
  }
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 20px;
    position: relative;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    top:20px;
    right: 25px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }
  .ant-tabs-bar{
    margin: 0!important;
    border-bottom: none!important;
  }
  .ant-table-body table{
    margin-top: 0!important;
  }
  .ant-table-tbody>tr>td, .ant-table-thead>tr>th{
    font-size: 12px;
    text-align: center;
  }
  .ecllipsis{
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    width: 150px;
    display: inline-block;
  }
  .ant-btn-primary-disable{
    background-color: rgb(131, 180, 234)!important;
  }
  .downBtn {
    border: none;
    color: rgb(0, 121, 254);
    background: none;
  }
  .downBtn:hover {
    background: none;
  }
</style>
