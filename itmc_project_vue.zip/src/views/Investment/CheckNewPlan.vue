<template>
  <div class="wrap">
    <div class="con-title" style="margin-top: 0">
      <!--<span class="divdLine"></span>-->
      <span>年度信息化项目投资建议计划</span>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>基本信息</span>
    </div>
    <div>
      <div>
        <div class="flexBox">
          <div class="flexTitle">项目名称:</div>
          <div class="flexCon">{{dataInfo.projectName}}</div>
          <div class="flexTitle">建设年限:</div>
          <div class="flexCon">{{dataInfo.conYear}}</div>
        </div>
        <div class="flexBox">
          <div class="flexTitle">所属平台:</div>
          <div class="flexCon">{{dataInfo.belongPlat}}</div>
<!--          <div class="flexTitle">业务领域:</div>
          <div class="flexCon">{{dataInfo.businessArea}}</div>-->
          <div class="flexTitle">业务处室:</div>
          <div class="flexCon">{{dataInfo.bureaus}}</div>
        </div>
        <div class="flexBox">
          <div class="flexTitle">建设性质:</div>
          <div class="flexCon">{{dataInfo.constrNature}}</div>
          <div class="flexTitle">项目分类:</div>
          <div class="flexCon">
            {{dataInfo.projectCategory}}
          </div>
        </div>

      </div>
    </div>
    <div class="flexBox">
      <div class="flexTitle">投资分类:</div>
      <div class="flexCon">
        {{dataInfo.projectInvest}}
      </div>
      <div class="flexTitle">费用来源:</div>
      <div class="flexCon">
        {{dataInfo.expenseFrom}}
      </div>
    </div>
    <div class="flexBox cbfa">           
      <div class="flexTitle">初步方案:</div>
      <div class="flexCon">
        <a  @click="reportFileWord(dataInfo)">{{dataInfo.fileName}}</a>
        <!-- <a-button @click="reportFileWord(dataInfo)" type="link" icon="download" class="ant-btn ant-btn-sm downBtn"></a-button> -->
      </div>
       <div class="flexTitle">批复文号:</div>
      <div class="flexCon">{{dataInfo.approvalNum}}</div>
    </div>
    <div class="flexBox">
      <div class="flexTitle">项目内容:</div>
      <div class="flexCon" style="flex: 18" v-html="dataInfo.projectContent ? dataInfo.projectContent.replace(/(\r\n)|(\n)/g,'<br/>') : ''"></div>
    </div>
    <div class="con-title" style="margin-top: 20px">
      <span class="divdLine"></span>
      <span>投资建议计划</span>
      <span class="unitText" style="top:15px">单位：万元</span>
    </div>
    <div>
      <div>
            <div class="ant-table-content">
              <div class="ant-table-body">
                <table style="width: 100%">
                  <thead class="ant-table-thead">
                    <tr>
                      <th class="" colspan="2"><div>投资情况\投资构成</div></th>
                      <th class=""><div>小计</div></th>
                      <th class=""><div>软件配置费</div></th>
                      <th class=""><div>硬件配置费</div></th>
                      <th class=""><div>技术服务费</div></th>
                      <th class=""><div>其他费</div></th>
                    </tr>
                  </thead>
                  <tbody class="ant-table-tbody">
                    <tr>
                      <td colspan="2">总投资</td>
                      <td>{{dataInfo.totalSum}}</td>
                      <td>{{dataInfo.totalZbSort+dataInfo.totalQySort}}</td>
                      <td>{{dataInfo.totalZbHardware+dataInfo.totalQyHardware}}</td>
                      <td>{{dataInfo.totalZbService+dataInfo.totalQyService}}</td>
                      <td>{{dataInfo.totalZbOther+dataInfo.totalQyOther}}</td>
                    </tr>
                    <tr>
                      <td rowspan="2">{{investmentChannel}}</td>
                      <td>总部</td>
                      <td>{{dataInfo.totalZbSubtotalSum}}</td>
                      <td>{{dataInfo.totalZbSort}}</td>
                      <td>{{dataInfo.totalZbHardware}}</td>
                      <td>{{dataInfo.totalZbService}}</td>
                      <td>{{dataInfo.totalZbOther}}</td>
                    </tr>
                    <tr>
                      <td>企业</td>
                      <td>{{dataInfo.totalQySubtotalSum}}</td>
                      <td>{{dataInfo.totalQySort}}</td>
                      <td>{{dataInfo.totalQyHardware}}</td>
                      <td>{{dataInfo.totalQyService}}</td>
                      <td>{{dataInfo.totalQyOther}}</td>
                    </tr>
                    <tr>
                      <td colspan="2">{{planYear}}年投资建议计划</td>
                      <td>{{dataInfo.nyTotalSum }}</td>
                      <td>{{dataInfo.nyZbSort+
                        dataInfo.nyQyytSort+dataInfo.nyQylhSort+dataInfo.nyQyxsSort+dataInfo.nyQykySort+dataInfo.nyQyzySort
                        }}</td>
                      <td>{{dataInfo.nyZbHardware+
                        dataInfo.nyQyytHardware+dataInfo.nyQylhHardware+dataInfo.nyQyxsHardware+dataInfo.nyQykyHardware+dataInfo.nyQyzyHardware
                        }}</td>
                      <td>{{dataInfo.nyZbService+
                        dataInfo.nyQyytService+dataInfo.nyQylhService+dataInfo.nyQyxsService+dataInfo.nyQykyService+dataInfo.nyQyzyService
                        }}</td>
                      <td>{{dataInfo.nyZbOther+
                        dataInfo.nyQyytOther+dataInfo.nyQylhOther+dataInfo.nyQyxsOther+dataInfo.nyQykyOther+dataInfo.nyQyzyOther
                        }}</td>
                    </tr>
                    <tr>
                      <td rowspan="7">{{investmentChannel}}</td>
                      <td>总部</td>
                      <td>{{dataInfo.nyZbSubtotalSum}}</td>
                      <td>{{dataInfo.nyZbSort}}</td>
                      <td>{{dataInfo.nyZbHardware}}</td>
                      <td>{{dataInfo.nyZbService}}</td>
                      <td>{{dataInfo.nyZbOther}}</td>
                    </tr>
                    <tr>
                      <td>企业小计</td>
                      <td>{{dataInfo.nyQyytSubtotalSum+
                        dataInfo.nyQylhSubtotalSum+
                        dataInfo.nyQyxsSubtotalSum+
                        dataInfo.nyQykySubtotalSum+
                        dataInfo.nyQyzySubtotalSum}}</td>
                      <td>{{dataInfo.nyQyytSort+dataInfo.nyQylhSort+dataInfo.nyQyxsSort+ dataInfo.nyQykySort+dataInfo.nyQyzySort}}</td>
                      <td>{{dataInfo.nyQyytHardware+dataInfo.nyQylhHardware+dataInfo.nyQyxsHardware+dataInfo.nyQykyHardware+dataInfo.nyQyzyHardware}}</td>
                      <td>{{dataInfo.nyQyytService+dataInfo.nyQylhService+dataInfo.nyQyxsService+dataInfo.nyQykyService+dataInfo.nyQyzyService}}</td>
                      <td>{{dataInfo.nyQyytOther+dataInfo.nyQylhOther+dataInfo.nyQyxsOther+dataInfo.nyQykyOther+dataInfo.nyQyzyOther}}</td>
                    </tr>
                    <tr>
                      <td>油田板块</td>
                      <td>{{dataInfo.nyQyytSubtotalSum}}</td>
                      <td>{{dataInfo.nyQyytSort}}</td>
                      <td>{{dataInfo.nyQyytHardware}}</td>
                      <td>{{dataInfo.nyQyytService}}</td>
                      <td>{{dataInfo.nyQyytOther}}</td>
                    </tr>
                    <tr>
                      <td>炼化板块</td>
                      <td>{{dataInfo.nyQylhSubtotalSum}}</td>
                      <td>{{dataInfo.nyQylhSort}}</td>
                      <td>{{dataInfo.nyQylhHardware}}</td>
                      <td>{{dataInfo.nyQylhService}}</td>
                      <td>{{dataInfo.nyQylhOther}}</td>
                    </tr>
                    <tr>
                      <td>销售板块</td>
                      <td>{{dataInfo.nyQyxsSubtotalSum}}</td>
                      <td>{{dataInfo.nyQyxsSort}}</td>
                      <td>{{dataInfo.nyQyxsHardware}}</td>
                      <td>{{dataInfo.nyQyxsService}}</td>
                      <td>{{dataInfo.nyQyxsOther}}</td>
                    </tr>
                    <tr>
                      <td>科研板块</td>
                      <td>{{dataInfo.nyQykySubtotalSum}}</td>
                      <td>{{dataInfo.nyQykySort}}</td>
                      <td>{{dataInfo.nyQykyHardware}}</td>
                      <td>{{dataInfo.nyQykyService}}</td>
                      <td>{{dataInfo.nyQykyOther}}</td>
                    </tr>
                    <tr>
                      <td>专业公司</td>
                      <td>{{dataInfo.nyQyzySubtotalSum}}</td>
                      <td>{{dataInfo.nyQyzySort}}</td>
                      <td>{{dataInfo.nyQyzyHardware}}</td>
                      <td>{{dataInfo.nyQyzyService}}</td>
                      <td>{{dataInfo.nyQyzyOther}}</td>
                    </tr>
                    <template v-if="dataInfo.constrNature=='续建'">
                      <tr>
                        <td colspan="2">截止去年下达</td>
                        <td>{{dataInfo.lyQyTotalSum}}</td>
                        <td>{{dataInfo.lyZbSort+dataInfo.lyQySort}}</td>
                        <td>{{dataInfo.lyZbHardware+dataInfo.lyQyHardware}}</td>
                        <td>{{dataInfo.lyZbService+dataInfo.lyQyService}}</td>
                        <td>{{dataInfo.lyZbOther+dataInfo.lyQyOther}}</td>
                      </tr>
                      <tr>
                        <td rowspan="2">{{investmentChannel}}</td>
                        <td>总部</td>
                        <td>{{dataInfo.lyZbSubtotalSum}}</td>
                        <td>{{dataInfo.lyZbSort}}</td>
                        <td>{{dataInfo.lyZbHardware}}</td>
                        <td>{{dataInfo.lyZbService}}</td>
                        <td>{{dataInfo.lyZbOther}}</td>
                      </tr>
                      <tr>
                        <td>企业</td>
                        <td>{{dataInfo.lyQySubtotalSum}}</td>
                        <td>{{dataInfo.lyQySort}}</td>
                        <td>{{dataInfo.lyQyHardware}}</td>
                        <td>{{dataInfo.lyQyService}}</td>
                        <td>{{dataInfo.lyQyOther}}</td>
                      </tr>
                      <tr>
                        <td colspan="2">预计当年完成情况</td>
                        <td>{{dataInfo.nowTotalSum}}</td>
                        <td>{{dataInfo.nowZbSort+dataInfo.nowQySort}}</td>
                        <td>{{dataInfo.nowZbHardware+dataInfo.nowQyHardware}}</td>
                        <td>{{dataInfo.nowZbService+dataInfo.nowQyService}}</td>
                        <td>{{dataInfo.nowZbOther+dataInfo.nowQyOther}}</td>
                      </tr>
                      <tr>
                        <td rowspan="2">{{investmentChannel}}</td>
                        <td>总部</td>
                        <td>{{dataInfo.nowZbSubtotalSum}}</td>
                        <td>{{dataInfo.nowZbSort}}</td>
                        <td>{{dataInfo.nowZbHardware}}</td>
                        <td>{{dataInfo.nowZbService}}</td>
                        <td>{{dataInfo.nowZbOther}}</td>
                      </tr>
                      <tr>
                        <td>企业</td>
                        <td>{{dataInfo.nowQySubtotalSum}}</td>
                        <td>{{dataInfo.nowQySort}}</td>
                        <td>{{dataInfo.nowQyHardware}}</td>
                        <td>{{dataInfo.nowQyService}}</td>
                        <td>{{dataInfo.nowQyOther}}</td>
                      </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </div>
      </div>

    </div>
    <div class="container" style="margin-top: 20px;text-align: center">
      <div>
        <a-button @click="goBack()" class="ant-btn ant-btn-primary">返回</a-button>
      </div>
    </div>
  </div>
</template>

<script>

  import {apiService} from "@/services/apiservice";
  export default {
    name: "CheckNewProject",
    data() {
      return {
        dataInfo:{},
        //dataInfo:"",
        investmentChannel:"股份",
        constrNature:"新开",
        planYear:"",
        optionDateSelect:"",
      }
    },
    methods: {
      reportFileWord(item){
        let fileWord = {planYear:item.planYear,fileName:item.fileName,versionsName:this.optionDateSelect}
        fileWord._json = true
        apiService.exportWord(fileWord).then(r => {
          window.location.href= r
        })
        // window.location.href='/project/itmcAut/reportFileWord?planYear='+item.planYear+"&fileName="+item.fileName
      },
      loadTable(parmasData){
        var _self = this
        apiService.getPlanAut(parmasData).then(r => {
            _self.dataInfo=r.list[0]
        }, r => {
        }).catch(
        )
      },
      goBack(){
        this.$router.go(-1)
      }
    },
    created(){
      if(this.$route.query.constrNature=='1'){
          this.constrNature='续建'
      }
      if(this.$route.query.investmentChannel=='B02'){
          this.investmentChannel='集团'
      }
      this.optionDateSelect=this.$route.query.versionsName
      this.planYear=this.$route.query.planYear
      if(!this.$route.query.planYear){
        this.planYear=new Date().getFullYear()
      }
      var params = {planYear: this.planYear,id:this.$route.query.id,flag:'2'}
      params._json = true
      this.loadTable(params)
    }
  }
</script>
<style>
  .wrap {
    background: #ffffff;
    padding:15px;
  }

  #headSearch > span {
    margin-left: 10px;
  }

  #headSearch {
    align-items: center;
  }

  .ant-table-tbody > tr > td {
    border: 1px solid #e8e8e8;
  }

  .ant-table-thead > tr > th {
    border-left: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
  }

  .ant-table-thead tr {
    border-top: 1px solid #e8e8e8;
  }

  /*.ant-table-thead > tr > th, .ant-table-tbody > tr > td {*/
    /*padding: 6px 16px;*/
  /*}*/
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 20px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }
  .flexBox{
    display: flex;
  }
  .flexTitle{
    flex: 2;
    text-align: right;
    padding: 5px;
  }
  .flexCon{
    flex: 8;
    text-align: left;
    padding: 5px;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    right: 25px;
  }
  .downBtn {
    border: none;
    color: rgb(0, 121, 254);
    background: none;
  }
  .downBtn:hover {
    background: none;
  }
  .cbfa {
    align-items: center
  }
</style>
