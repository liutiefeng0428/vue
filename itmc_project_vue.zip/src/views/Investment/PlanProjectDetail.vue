<template>
  <div class="wrap">
    <div style="margin-bottom:16px;">
      <span>版本名称:</span>
      <a-select :value="optionDateSelect" class="querySelect" @change="handleChangeDate" style="width:160px">
        <a-select-option v-for="item in optionDate" :key="item.versionsName"> {{item.versionsName}}</a-select-option>
      </a-select>
      <span style="margin-left: 15px;">所属平台:</span>
      <a-select :value=plateSelect class="querySelect" @change="handleChangePlate" style="width:160px">
        <a-select-option v-for="item in plateArr" :key="item"> {{item}}</a-select-option>
      </a-select>
      <span style="margin-left: 15px;">建设性质:</span>
      <a-select :value=natureSelect class="querySelect" @change="handleChangeNature" style="width: 160px">
        <a-select-option v-for="item in constrNatureArr" :key="item"> {{item}}</a-select-option>
      </a-select>
      <span style="margin-left: 15px;">资金来源:</span>
      <a-select :value=channelSelect class="querySelect" @change="handleChangeChannel" style="width:160px">
        <a-select-option v-for="item in investmentChannelArr" :key="item.id"> {{item.name}}</a-select-option>
      </a-select>

    </div>
    <div style="margin-bottom: 20px">
      <span>业务处室:</span>
      <a-select defaultValue="全部" class="querySelect" @change="handleChangeDepart" style="width:160px">
        <a-select-option v-for="item in departArr" :key="item"> {{item}}</a-select-option>
      </a-select>
      <span style="margin-left: 15px;">项目关键字:</span>
      <a-input v-model="keywords" style="width: 160px"></a-input>
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="queryTable" icon="search">查询</a-button>
      </span>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>{{planYear}}年投资建议计划项目明细</span>
      <span class="unitText" style="top:15px">单位：万元</span>
    </div>
    <div>
      <div>
        <div class="ant-table-content">
          <div class="ant-table-body">
            <table style="width: 100%">
              <thead class="ant-table-thead">
              <tr>
                <th rowspan="2" class=""><div>序号</div></th>
                <th rowspan="2" class=""><div>项目编码</div></th>
                <th rowspan="2" class=""><div>项目名称</div></th>
                <th rowspan="2" class=""><div>项目内容</div></th>
                <th rowspan="2" class=""><div>建设年限</div></th>
                <th rowspan="2" class=""><div>建设性质</div></th>
                <th rowspan="2" class=""><div>总投资</div></th>
                <th colspan="2" class=""><div>投资完成情况</div></th>
                <th rowspan="2" class=""><div>{{planYear}}年建议计划</div></th>
                <!-- <th rowspan="2" class=""><div>所属平台</div></th> -->
                <th rowspan="2" class=""><div>业务处室</div></th>
                <th rowspan="2" class=""><div>初步方案</div></th>
              </tr>
              <tr>
                <th><div>截止上年累计完成</div></th>
                <th><div>当年预计完成</div></th>
              </tr>
              </thead>
              <tbody class="ant-table-tbody">
              <tr  v-for="(item,index) in dataInfo">
                <td>{{index+1}}</td>
                <td :title="item.projectNum">{{item.projectNum}}</td>
                <td :title="item.projectName" style="text-align: left;">
                  <span class="prjName">
                    <a @click="toDetail(item)">{{item.projectName}}</a>
                  </span>
                </td>
                <td :title="item.projectContent">
                  <span class="ecllipsis">
                    {{item.projectContent}}
                  </span>
                </td>
                <td :title="item.conYear">{{item.conYear}}</td>
                <td :title="item.constrNature">{{item.constrNature}}</td>
                <td :title="item.totalSum">{{item.totalSum}}</td>
                <td :title="item.lyTotalSum">{{item.lyTotalSum||'0'}}</td>
                <td :title="item.nowTotalSum">{{item.nowTotalSum||'0'}}</td>
                <td :title="item.nyTotalSum">{{item.nyTotalSum||'0'}}</td>
                <!-- <td :title="item.belongPlat">{{item.belongPlat}}</td> -->
                <td :title="item.businessArea">{{item.bureaus}}</td>
                <td>
                  <template v-if="item.fileName !='' && item.fileName != null">
                    <!-- <a-button @click="exportWord(item.fileName)" type="link" icon="download" class="ant-btn ant-btn-sm downBtn"></a-button> -->
                    <a @click="exportWord(item.fileName)">下载</a>
                  </template>
                </td>
              </tr>
              <tr>
                <td colspan="6" style="text-align: right"><span style="margin-right: 5px">合计：</span></td>
                <td>{{parseFloat(totalSumAll).toFixed(2)}}</td>
                <td>{{parseFloat(lyTotalSumAll).toFixed(2)}}</td>
                <td>{{parseFloat(nowTotalSumAll).toFixed(2)}}</td>
                <td>{{parseFloat(nyTotalSumAll).toFixed(2)}}</td>
                <td></td>
                <td></td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="container" style="text-align: center;margin-top: 20px">
      <div>
        <a-button  type="primary" @click="goBack()">返回</a-button>
      </div>
    </div>
    <a-modal
      title="导入年度费用预算"
      :width="600"
      centered
      v-model="expVisible"
      @ok="() => saveVersion()"
      @cancel="() => setVersionVisible(false)"
      okText="保存"
      cancelText="取消"
    >
      <div>
        <div class="clearfix">
        </div>
      </div>
    </a-modal>

  </div>
</template>

<script>

  import {apiService} from "@/services/apiservice";
  export default {
    name: "PlanProjectDetail",
    data() {
      return {
        keywords:"",
        investmentChannel:"0",
        dataInfo:[],
        dataInfo2:[],
        constrNatureArr:["","新开","续建"],
        investmentChannelArr:[{id:"",name:""},{id:"B01",name:"股份"},{id:"B02",name:"集团"}],
        plateArr:["","经营管理平台","生产营运平台","客户服务平台","技术支撑平台","新技术应用平台"],
        departArr:["全部","综合处","计划处","项目一处","项目二处","应用处","系统处","安全处"],
        plateSelect:"",
        natureSelect:"",
        channelSelect:"",
        departSelect:"",
        expVisible:false,
        optionDate: [],
        optionDateSelect: '',
        isAll:"",
        planYear:"",

      }
    },
    computed:{
      totalSumAll(){
        let totalSumAll = 0;
        this.dataInfo.map((item) => {if(!isNaN(item.totalSum)) totalSumAll += item.totalSum})
        if(isNaN(totalSumAll)){
          return 0
        }
        return totalSumAll
      },
      lyTotalSumAll(){
        let lyTotalSumAll = 0;
        this.dataInfo.map((item) => {if(!isNaN(item.lyTotalSum)) lyTotalSumAll += item.lyTotalSum})
        if(isNaN(lyTotalSumAll)){
          return 0
        }
        return lyTotalSumAll
      },
      nowTotalSumAll(){
        let nowTotalSumAll = 0;
        this.dataInfo.map((item) => {if(!isNaN(item.nowTotalSum)) nowTotalSumAll += item.nowTotalSum})
        if(isNaN(nowTotalSumAll)){
          return 0
        }
        return nowTotalSumAll
      },
      nyTotalSumAll(){
        let nyTotalSumAll = 0;
        this.dataInfo.map((item) => {if(!isNaN(item.nyTotalSum)) nyTotalSumAll += item.nyTotalSum})
        if(isNaN(nyTotalSumAll)){
          return 0
        }
        return nyTotalSumAll
      },
      totalSumAll2(){
        let totalSumAll2 = 0;
        this.dataInfo2.map((item) => {if(!isNaN(item.totalSum)) totalSumAll2 += item.totalSum})
        if(isNaN(totalSumAll2)){
          return 0
        }
        return totalSumAll2
      },
      lyTotalSumAll2(){
        let lyTotalSumAll2 = 0;
        this.dataInfo2.map((item) => {if(!isNaN(item.lyTotalSum)) lyTotalSumAll2 += item.lyTotalSum})
        if(isNaN(lyTotalSumAll2)){
          return 0
        }
        return lyTotalSumAll2
      },
      nowTotalSumAll2(){
        let nowTotalSumAll2 = 0;
        this.dataInfo2.map((item) => {if(!isNaN(item.nowTotalSum)) nowTotalSumAll2 += item.nowTotalSum})
        if(isNaN(nowTotalSumAll2)){
          return 0
        }
        return nowTotalSumAll2
      },
      nyTotalSumAll2(){
        let nyTotalSumAll2 = 0;
        this.dataInfo2.map((item) => {if(!isNaN(item.nyTotalSum)) nyTotalSumAll2 += item.nyTotalSum})
        if(isNaN(nyTotalSumAll2)){
          return 0
        }
        return nyTotalSumAll2
      },
    },
    methods: {
      exportWord(projectName){
        let _self=this
        let wordParams = {planYear:_self.planYear,fileName:projectName,versionsName:this.optionDateSelect}
        wordParams._json = true
        apiService.exportWord(wordParams).then(r => {
          window.location.href= r
        })
        // window.location.href='/project/itmcAut/reportFileWord?planYear='+_self.planYear+"&fileName="+projectName
      },
      goBack(){
         this.$router.go(-1)
      },
      loadMsg(){
        this.isAll=this.$route.query.isAll  //1代表全部
        if(this.$route.query.constrNature=='0'){
          this.natureSelect=""
        }else{
          this.natureSelect=this.$route.query.constrNature
        }
       if(this.$route.query.belongPlat=='0'){
         this.plateSelect=""
       }else{
         this.plateSelect=this.$route.query.belongPlat
       }
       if(this.$route.query.investmentChannel=='0' ){
         this.channelSelect=''
       }else{
         this.channelSelect=this.$route.query.investmentChannel //投资渠道
       }
       this.planYear=this.$route.query.planYear
       if(!this.$route.query.planYear){
         this.planYear=new Date().getFullYear()
       }

      },
      toDetail(item){
        let constrNature='0'
        if(item.constrNature=='续建'){
          constrNature="1"
        }
        this.$router.push({path: "/check-plan", query: {id:item.id,constrNature:constrNature,investmentChannel:item.investmentChannel,planYear:this.planYear,versionsName:this.optionDateSelect}})
      },
      setVersionVisible(){
        this.expVisible=false
      },
      loadDate(parmasData){
        let _self = this
        apiService.getVersionName(parmasData).then(r => {
          _self.optionDate=r
        }, r => {
        }).catch(
        )
      },
      loadTable(parmasData){
        var _self = this
        apiService.getPlanAut(parmasData).then(r => {
            _self.dataInfo=r.list
        }, r => {
        }).catch(
        )
      },
      handleChangePlate(value){
        this.plateSelect = value
      },
      handleChangeNature(value){
        this.natureSelect = value
      },
      handleChangeChannel(value){
        this.channelSelect = value
      },
      handleChangeDepart(value){
        this.departSelect = value
      },
      handleChangeDate(value){
        this.optionDateSelect = value
      },
      queryTable(){
        let departSelect=this.departSelect
        if(this.departSelect=='全部'){
          departSelect=""
        }
        var params = {planYear:this.planYear,versionsName:this.optionDateSelect,belongPlat:this.plateSelect,constrNature:this.natureSelect,investmentChannel:this.channelSelect,bureaus:departSelect,keywords:this.keywords,flag:'2'}
        params._json = true
        this.loadTable(params)
      },
    },
    created(){
      this.loadMsg()
      this.optionDateSelect=this.$route.query.versionsName
      let parmasData={planYear:this.planYear}
      parmasData._json=true
      this.loadDate(parmasData)  //获取版本名称
      var params = {planYear:this.planYear,versionsName:this.optionDateSelect,belongPlat:this.plateSelect,constrNature:this.natureSelect,investmentChannel:this.channelSelect,bureaus:this.departSelect,keywords:this.keywords,flag:'2'}
      params._json = true
      this.loadTable(params)
    }
  }
</script>
<style>
  .wrap {
    background: #ffffff;
    padding:15px;
  }

  #headSearch > span {
    margin-left: 10px;
  }

  #headSearch {
    align-items: center;
  }

  .ant-table-tbody > tr > td {
    border: 1px solid #e8e8e8;
  }

  .ant-table-thead > tr > th {
    border-left: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
  }

  .ant-table-thead tr {
    border-top: 1px solid #e8e8e8;
  }

  /*.ant-table-thead > tr > th, .ant-table-tbody > tr > td {*/
    /*padding:5px !important;*/
  /*}*/
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 15px;
    position: relative;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    right: 25px;
  }
  .ecllipsis{
       overflow: hidden;
       text-overflow: ellipsis;
       white-space: nowrap;
       width:150px;
       display: inline-block;
     }
  .prjName{
    width:200px;
    display: inline-block;
  }
</style>
