<template>
  <div class="wrap">
    <div class="con-head">
      <span>年度:</span>
      <a-select  :value=planYear class="querySelect" @change="handleChangeDate" style="width: 120px">
        <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
      </a-select>
      <a-button type="primary" @click="versionExportfile">导入新版本</a-button>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>年度信息化项目投资计划编制版本管理</span>
      <span class="unitText" style="top: 15px;">单位：万元</span>
    </div>
    <div class="container" style="padding:0">
      <div>
        <div class="ant-table-content">
          <div class="ant-table-tbody">
            <table style="width: 100%;">
              <thead class="ant-table-thead"><tr>
                <th key="version" class="ant-table-align-left" style="text-align: left;"><div>版本名称</div></th>
                <th key="content" class="ant-table-align-left" style="text-align: left;"><div>说明</div></th>
                <th key="optionName" class="ant-table-align-left" style="text-align: left;"><div>生成时间</div></th>
                <th key="typeCode" class="ant-table-align-left" style="text-align: left;"><div>操作</div></th></tr></thead>
              <tbody class="ant-table-tbody">
                <tr v-for="(item,index) in itmcPlanAuthorizedListOne">
                  <td><a @click="toQuVersion(item.versionsName)">{{item.versionsName}}</a></td>
                  <td>{{item.versionsState}}</td>
                  <td v-if="item">{{item.versionTime}}</td>
                  <td>
                    <span @click="exportVersion(item.versionsName)"><a>导出</a></span>
                    <span @click="printExportFile(item.versionsName)"><a>报表打印</a></span>
                    <span @click="projectPrintExportFile(item.versionsName)"><a>汇报表</a></span>
                    <span>
                      <a-popconfirm
                        title="确定删除吗?"
                        okText="确定"
                        cancelText="取消"
                        @confirm="() => deleteCurr(item)">
                       <a href="javascript:;">删除</a>
                     </a-popconfirm>
                    </span>
                  </td>
                </tr>
                <tr v-if="itmcPlanAuthorizedListTwo.length>0">
                  <td><a @click="toQuVersion('各处填报汇总版')">各处填报汇总版</a></td>
                  <td>
                    <div v-for="(item,index) in itmcPlanAuthorizedListTwo">
                       {{item.versionsState}}
                    </div>
                  </td>
                  <td>
                    <div  v-if="itmcPlanAuthorizedListTwo[0]">
                      {{itmcPlanAuthorizedListTwo[0].versionTime}}
                    </div>
                  </td>
                  <td>
                    <span @click="exportVersion('各处填报汇总版')"><a>导出</a></span>
                    <span @click="printExportFile('各处填报汇总版')"><a>报表打印</a></span>
                    <span>
                      <a-popconfirm
                        title="确定删除吗?"
                        okText="确定"
                        cancelText="取消"
                        @confirm="() => deleteCurr(item)">
                       <a href="javascript:;">删除</a>
                     </a-popconfirm>
                    </span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <a-modal
        title="导入新版本"
        :width="600"
        centered
        v-model="versionMVisible"
        @ok="() => saveVersion()"
        @cancel="() => setVersionVisible(false)"
        okText="导入"
        cancelText="取消"
      >
        <div>
          <div style="display: flex;margin-bottom: 20px">
            <span style="flex:2;text-align: right;margin-right: 10px">版本名称:</span>
            <a-input style="flex: 8" size="small" v-model="versionNameModal"/>
          </div>
          <div style="display: flex">
            <span style="flex: 2;text-align: right;margin-right: 10px">版本说明:</span>
            <a-textarea style="flex: 8" v-model="versionContentModal" :rows="4"/>
          </div>
          <div style="display: flex;margin-top: 15px">
            <span style="flex: 2;text-align: right;margin-right: 10px">请选择文件:</span>
            <div style="flex: 8">
              <a-upload
                :multiple="true"
                :fileList="fileList"
                :remove="handleRemove"
                :beforeUpload="beforeUpload"
              >
                <a-button>
                  <a-icon type="upload" /> 上传
               </a-button>
              </a-upload>
            </div>
          </div>
          <div style="margin-top: 10px;display: flex">
            <span style="flex: 2;text-align: right;margin-right: 10px"></span>
            <div style="flex: 8">
             <a @click="downloadFile">本处室年度投资计划填报模板下载</a>
            </div>
          </div>
        </div>
      </a-modal>
    </div>
  </div>
</template>

<script>
  import reqwest from 'reqwest'
  import {apiService} from "@/services/apiservice";
  export default {
    name: "EditionManagement",
    components: {
    },
    data() {
      return {
        optionDate:[],
        planYear:"",
        infoData:{},
        itmcPlanAuthorizedListOne:[],
        itmcPlanAuthorizedListTwo:[],
        versionMVisible:false,
        versionNameModal:"",
        versionContentModal:"",
        fileList: [],
        files:null,
      }
    },
    methods: {
      downloadFile(){
        let _self=this
        window.location.href='/project/itmcAut/downloadFile?planYear='+_self.planYear+"&flagExport=2"
      },
      handleRemove(file) {
        const index = this.fileList.indexOf(file);
        const newFileList = this.fileList.slice();
        newFileList.splice(index, 1);
        this.fileList = newFileList
      },
      beforeUpload(file) {
        // this.handleRemove(this.files) //保证只能上传一个文件
        this.files=file
        this.fileList = [...this.fileList, file]
        return false;
      },
      handleUpload() {
        const { fileList } = this;
        const formData = new FormData();
        fileList.forEach((file) => {
          formData.append('files[]', file);
        });
        this.uploading = true
        reqwest({
          url: '/project/itmcAut/exportfile',
          method: 'post',
          processData: false,
          data: formData,
          success: () => {
            this.fileList = []
            this.uploading = false
            this.$message.success('upload successfully.');
          },
          error: () => {
            this.uploading = false
            this.$message.error('upload failed.');
          },
        });
      },
      printExportFile(versionsName){
          window.location.href='/project/itmcAut/printExportFile?versionsName='+versionsName+"&planYear="+this.planYear
      },
      projectPrintExportFile(versionsName){
          window.location.href='/project/itmcAut/printProjectDetailsExportFile?versionsName='+versionsName+"&planYear="+this.planYear
      },
      exportVersion(versionsName){
        window.location.href='/project/itmcAut/exportVersion?versionsName='+versionsName+"&planYear="+this.planYear
      },
      deleteCurr(item){
        var _self=this
        var parmasData={"versionsName":item.versionsName,"planYear":this.planYear}
        parmasData._json=true
        apiService.exportVerDel(parmasData).then(r => {
          _self.$message.success("删除成功")
          let parmas={planYear:_self.planYear}
          parmas._json=true
          _self.loadTable(parmas)
        }, r => {
        }).catch(
        )
      },
      setVersionVisible(){
        this.versionMVisible=false
      },
      versionExportfile(){
        this.versionMVisible=true
      },
      saveVersion(){
        var _self=this
        const { fileList } = this;
        const formData = new FormData();
        fileList.forEach((file) => {
          formData.append('file',file);
        })
        // formData.append('file', this.files);
        formData.append('planYear',this.planYear);
        formData.append('versionsName', this.versionNameModal);
        formData.append('versionsState',this.versionContentModal);
        reqwest({
          url: '/project/itmcAut/versionExportfile',
          method: 'post',
          processData: false,
          data: formData,
          success: (r) => {
            if(r.result=='0000'){
              this.fileList = []
              this.$message.success('上传成功');
              this.versionMVisible=false
              let parmas={planYear:_self.planYear}
              parmas._json=true
              _self.loadTable(parmas)
            }else if(r.result=='9999'){
              this.$message.success(r.msg);
            }
          },
          error: () => {
            this.$message.error('上传失败');
          },
        });
      },
      loadDate(){
        var _self=this
        var parmasData="typeCode=JHNDS"
        apiService.getDictionary1(parmasData).then(r => {
          _self.optionDate=r
          // _self.planYear=_self.optionDate[0].optionCode
          let parmas={planYear:_self.planYear}
          parmas._json=true
          _self.loadTable(parmas)
        }, r => {
        }).catch(
        )
      },
      handleChangeDate(value){
        this.planYear=value
        let parmasData={planYear:value}
        parmasData._json=true
        this.loadTable(parmasData)
      },
      loadTable(parmasData){
        let _self = this
        apiService.versionCtrolList(parmasData).then(r => {
          _self.infoData = r
          _self.itmcPlanAuthorizedListOne=r.itmcPlanAuthorizedListOne
          _self.itmcPlanAuthorizedListTwo=r.itmcPlanAuthorizedListTwo
        }, r => {
        }).catch(
        )
      },
      toQuVersion(versionsName){
        localStorage.setItem("versionName",versionsName);
        this.$router.push({path: "/sub-total", query: {planYear:this.planYear ,versionsName:versionsName}})
      },
    },
    computed: {
    },
    filters:{
      formatDateTime (inputTime) {
        var date = new Date(inputTime);
        var y = date.getFullYear();
        var m = date.getMonth() + 1;
        m = m < 10 ? ('0' + m) : m;
        var d = date.getDate();
        d = d < 10 ? ('0' + d) : d;
        var h = date.getHours();
        h = h < 10 ? ('0' + h) : h;
        var minute = date.getMinutes();
        var second = date.getSeconds();
        minute = minute < 10 ? ('0' + minute) : minute;
        second = second < 10 ? ('0' + second) : second;
        return y + '-' + m + '-' + d + ' ' + '　' + h + ':' + minute + ':' + second;
      }
    },
    created(){
      var date = new Date();
      var m = date.getMonth() + 1;
      if(m >= 8){
        this.planYear=(new Date().getFullYear())+1;
      }else{
        this.planYear=new Date().getFullYear();
      }
      this.loadDate()
    }
  }
</script>
<style>
  .wrap {
    padding: 15px;
    background: #ffffff;
    margin: 10px;
  }
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 15px;
    position: relative;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    top:5px;
    right: 25px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    /*background: rgb(16, 110, 190);*/
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .con-head{
    margin-bottom: 20px;
  }
  .ant-table-tbody table{
    border-top: 1px solid #e8e8e8;
    border-left: 1px solid #e8e8e8;
  }
  .ant-table-tbody > tr > td{
    border-bottom: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
    -webkit-transition: all 0.3s, border 0s;
    transition: all 0.3s, border 0s;
  }
  .ant-table-thead > tr > th{
    border-right: 1px solid #e8e8e8;
  }
  .ant-table-thead > tr > th, .ant-table-tbody > tr > td{
    padding: 0 3px;
    text-align: center;
  }
  .ant-table-thead>tr>th div{
    text-align: center;
    font-size: 12px;
    color: #666666;
    font-weight: 700;
  }
</style>
