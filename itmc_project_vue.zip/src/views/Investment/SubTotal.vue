<template>
  <div class="wrap">
    <div class="con-title">
      <span class="divdLine"></span>
      <span>{{planYear}}年投资建议计划分类汇总</span>
    </div>
    <div style="margin:16px 0;">
      <span>版本名称:</span>
      <a-select :value="optionDateSelect" class="querySelect" @change="handleChangeDate" style="width: 300px">
        <a-select-option v-for="item in optionDate" :key="item.versionsName"> {{item.versionsName}}</a-select-option>
      </a-select>
    </div>
    <div>
      <div style="position:relative;">
        <span class="unitText">单位：万元</span>
        <a-tabs defaultActiveKey="1" @change="callback">
          <a-tab-pane tab="股份" key="B01">
            <div class="ant-table-content">
              <div class="ant-table-body">
                <table style="width: 100%">
                  <thead class="ant-table-thead">
                    <tr>
                      <th rowspan="2" colspan="3" class=""><div>统计维度</div></th>
                      <th rowspan="2" class=""><div>项目数</div></th>
                      <th rowspan="2" class=""><div>总投资</div></th>
                      <th colspan="2" class=""><div>投资完成情况</div></th>
                      <th rowspan="2" class=""><div>{{planYear}}年建议计划</div></th>
                    </tr>
                    <tr>
                      <th><div>截止上年累计完成</div></th>
                      <th><div>当年预计完成</div></th>
                    </tr>
                  </thead>
                  <tbody class="ant-table-tbody" v-if="dataInfo&&dataInfo.subTotalInfoList[0].projectnNum>0">
                    <tr>
                      <td colspan="3">信息合计</td>
                      <td><span><a @click="toDetail('1','0','0')">{{dataInfo.subTotalInfoList[0].projectnNum||'0'}}</a></span></td>
                      <td>{{dataInfo.subTotalInfoList[0].totalSum}}</td>
                      <td>{{dataInfo.subTotalInfoList[0].lyTotalSum}}</td>
                      <td>{{dataInfo.subTotalInfoList[0].nowTotalSum}}</td>
                      <td>{{dataInfo.subTotalInfoList[0].nyTotalSum}}</td>
                    </tr>
                    <tr>
                      <td colspan="2" :rowspan="2">建设性质维度</td>
                      <td>新开</td>
                      <td><span><a @click="toDetail('0','新开','0')">{{dataInfo.subTotalConNatureInfoList[0].projectnNum}}</a></span></td>
                      <td>{{dataInfo.subTotalConNatureInfoList[0].totalSum}}</td>
                      <td>{{dataInfo.subTotalConNatureInfoList[0].lyTotalSum}}</td>
                      <td>{{dataInfo.subTotalConNatureInfoList[0].nowTotalSum}}</td>
                      <td>{{dataInfo.subTotalConNatureInfoList[0].nyTotalSum}}</td>
                    </tr>
                    <tr v-if="dataInfo.subTotalConNatureInfoList.length>1">
                      <td>续建</td>
                      <td><span><a @click="toDetail('0','续建','0')">{{dataInfo.subTotalConNatureInfoList[1].projectnNum}}</a></span></td>
                      <td>{{dataInfo.subTotalConNatureInfoList[1].totalSum}}</td>
                      <td>{{dataInfo.subTotalConNatureInfoList[1].lyTotalSum}}</td>
                      <td>{{dataInfo.subTotalConNatureInfoList[1].nowTotalSum}}</td>
                      <td>{{dataInfo.subTotalConNatureInfoList[1].nyTotalSum}}</td>
                    </tr>
                    <tr v-if="dataInfo.subTotalConNatureInfoList.length<=1">
                      <td>续建</td>
                      <td><span><a @click="toDetail('0','续建','0')">0</a></span></td>
                      <td>0</td>
                      <td>0</td>
                      <td>0</td>
                      <td>0</td>
                    </tr>
                    <template v-for="(item,index) in dataInfoList">
                      <tr>
                        <td v-if="index=='0'" :rowspan="dataInfoList.length*3">平台维度</td>
                        <td :rowspan="3">{{item.belongPlat}}</td>
                        <td>小计</td>
                        <td><span><a @click="toDetail('0','0',item.belongPlat)">{{item.projectnNum}}</a></span></td>
                        <td>{{item.totalSum}}</td>
                        <td>{{item.lyTotalSum}}</td>
                        <td>{{item.nowTotalSum}}</td>
                        <td>{{item.nyTotalSum}}</td>
                      </tr>
                      <tr>
                        <td>{{item.children[0].constrNature}}</td>
                        <td><span><a @click="toDetail('0',item.children[0].constrNature,item.belongPlat)">{{item.children[0].projectnNum}}</a></span></td>
                        <td>{{item.children[0].totalSum}}</td>
                        <td>{{item.children[0].lyTotalSum}}</td>
                        <td>{{item.children[0].nowTotalSum}}</td>
                        <td>{{item.children[0].nyTotalSum}}</td>
                      </tr>

                      <tr v-if="item.children.length>1">
                        <td>
                           <span v-if="item.children.length>1">
                            {{item.children[1].constrNature}}
                          </span>
                        </td>
                        <td>
                          <span v-if="item.children.length>1">
                            <span><a @click="toDetail('0',item.children[1].constrNature,item.belongPlat)">
                            {{item.children[1].projectnNum}}
                            </a></span>
                          </span>
                        </td>
                        <td>
                          <span v-if="item.children.length>1">
                            {{item.children[1].totalSum}}
                          </span>
                        </td>
                        <td>
                          <span v-if="item.children.length>1">
                            {{item.children[1].lyTotalSum}}
                          </span>
                        </td>
                        <td>
                          <span v-if="item.children.length>1">
                            {{item.children[1].nowTotalSum}}
                          </span>
                        </td>
                        <td>
                          <span v-if="item.children.length>1">
                            {{item.children[1].nyTotalSum}}
                          </span>
                        </td>
                      </tr>
                      <tr v-if="item.children.length==1">
                        <td><span v-if="item.children[0].constrNature=='新开'">续建</span><span v-if="item.children[0].constrNature=='续建'">新开</span></td>
                        <td>
                          <span><a @click="toDetail('0','续建',item.belongPlat)">
                             0
                           </a></span>
                        </td>
                        <td>
                         0
                        </td>
                        <td>
                          0
                        </td>
                        <td>
                          0
                        </td>
                        <td>
                           0
                        </td>
                    </tr>
                    </template>
                  </tbody>
                </table>
              </div>
            </div>

          </a-tab-pane>
          <a-tab-pane tab="集团" key="B02" forceRender>
            <div class="ant-table-content">
              <div class="ant-table-body">
                <table style="width: 100%">
                  <thead class="ant-table-thead">
                  <tr>
                    <th rowspan="2" colspan="3" class=""><div>统计维度</div></th>
                    <th rowspan="2" class=""><div>项目数</div></th>
                    <th rowspan="2" class=""><div>总投资</div></th>
                    <th colspan="2" class=""><div>投资完成情况</div></th>
                    <th rowspan="2" class=""><div>{{planYear}}年建议计划</div></th>
                  </tr>
                  <tr>
                    <th><div>截止上年累计完成</div></th>
                    <th><div>当年预计完成</div></th>
                  </tr>
                  </thead>
                  <tbody class="ant-table-tbody" v-if="dataInfo2&&dataInfo2.subTotalInfoList[0].projectnNum>0">
                  <tr>
                    <td colspan="3">信息合计</td>
                    <td><span><a @click="toDetail('1','0','0')">{{dataInfo2.subTotalInfoList[0].projectnNum||'0'}}</a></span></td>
                    <td>{{dataInfo2.subTotalInfoList[0].totalSum}}</td>
                    <td>{{dataInfo2.subTotalInfoList[0].lyTotalSum}}</td>
                    <td>{{dataInfo2.subTotalInfoList[0].nowTotalSum}}</td>
                    <td>{{dataInfo2.subTotalInfoList[0].nyTotalSum}}</td>
                  </tr>
                  <tr>
                    <td colspan="2" :rowspan="dataInfo2.subTotalConNatureInfoList.length">建设性质维度</td>
                    <td>新开</td>
                    <td><span><a @click="toDetail('0','新开','0')">{{dataInfo2.subTotalConNatureInfoList[0].projectnNum}}</a></span></td>
                    <td>{{dataInfo2.subTotalConNatureInfoList[0].totalSum}}</td>
                    <td>{{dataInfo2.subTotalConNatureInfoList[0].lyTotalSum}}</td>
                    <td>{{dataInfo2.subTotalConNatureInfoList[0].nowTotalSum}}</td>
                    <td>{{dataInfo2.subTotalConNatureInfoList[0].nyTotalSum}}</td>
                  </tr>
                  <tr v-if="dataInfo2.subTotalConNatureInfoList.length>1">
                    <td>续建</td>
                    <td><span><a @click="toDetail('0','续建','0')">{{dataInfo2.subTotalConNatureInfoList[1].projectnNum}}</a></span></td>
                    <td>{{dataInfo2.subTotalConNatureInfoList[1].totalSum}}</td>
                    <td>{{dataInfo2.subTotalConNatureInfoList[1].lyTotalSum}}</td>
                    <td>{{dataInfo2.subTotalConNatureInfoList[1].nowTotalSum}}</td>
                    <td>{{dataInfo2.subTotalConNatureInfoList[1].nyTotalSum}}</td>
                  </tr>
                  <template v-for="(item,index) in dataInfoList2">
                    <tr>
                      <td v-if="index=='0'" :rowspan="dataInfoList2.length*3">平台维度</td>
                      <td :rowspan="3">{{item.belongPlat}}</td>
                      <td>小计</td>
                      <td><span><a @click="toDetail('0','0',item.belongPlat)">{{item.projectnNum}}</a></span></td>
                      <td>{{item.totalSum}}</td>
                      <td>{{item.lyTotalSum}}</td>
                      <td>{{item.nowTotalSum}}</td>
                      <td>{{item.nyTotalSum}}</td>
                    </tr>
                    <tr>
                      <td>{{item.children[0].constrNature}}</td>
                      <td><span><a @click="toDetail('0',item.children[0].constrNature,item.belongPlat)">{{item.children[0].projectnNum}}</a></span></td>
                      <td>{{item.children[0].totalSum}}</td>
                      <td>{{item.children[0].lyTotalSum}}</td>
                      <td>{{item.children[0].nowTotalSum}}</td>
                      <td>{{item.children[0].nyTotalSum}}</td>
                    </tr>
                    <tr v-if="item.children.length>1">
                      <td>
                           <span v-if="item.children.length>1">
                            {{item.children[1].constrNature}}
                          </span>
                      </td>
                      <td>
                          <span v-if="item.children.length>1">
                             <span><a @click="toDetail('0',item.children[1].constrNature,item.belongPlat)">
                            {{item.children[1].projectnNum}}
                            </a></span>
                          </span>
                      </td>
                      <td>
                          <span v-if="item.children.length>1">
                            {{item.children[1].totalSum}}
                          </span>
                      </td>
                      <td>
                          <span v-if="item.children.length>1">
                            {{item.children[1].lyTotalSum}}
                          </span>
                      </td>
                      <td>
                          <span v-if="item.children.length>1">
                            {{item.children[1].nowTotalSum}}
                          </span>
                      </td>
                      <td>
                          <span v-if="item.children.length>1">
                            {{item.children[1].nyTotalSum}}
                          </span>
                      </td>
                    </tr>
                    <tr v-if="item.children.length==1">
                      <td>续建</td>
                      <td>
                          <span><a @click="toDetail('0','续建',item.belongPlat)">
                             0
                           </a></span>
                      </td>
                      <td>
                        0
                       </td>
                      <td>
                        0
                      </td>
                      <td>
                        0
                      </td>
                      <td>
                        0
                     </td>
                    </tr>
                  </template>
                  </tbody>
                </table>
              </div>
            </div>
          </a-tab-pane>
        </a-tabs>
      </div>
    </div>
    <div class="container" style="text-align: center;margin-top: 20px">
      <div>
        <a-button type="primary" @click="goBack()">返回</a-button>
      </div>
    </div>
  </div>
</template>

<script>

  import {apiService} from "@/services/apiservice";
  export default {
    name: "SubTotal",
    data() {
      return {
        versionsName:"",
        planYear:"",
        optionDate: [],
        optionDateSelect: '',
        investmentChannel:"B01",
        dataInfo:"",
        dataInfo2:"",
        dataInfoList:[],
        List2:[],
      }
    },
    methods: {
      toDetail(all,constrNature,belongPlat){
       this.$router.push({path:'/plan-detail',query:{isAll:all,constrNature:constrNature,belongPlat:belongPlat,investmentChannel:this.investmentChannel,planYear:this.planYear,versionsName:this.optionDateSelect}})
      },
      goBack(){
          this.$router.go(-1)
      },
      loadDate(parmasData){
          let _self = this
          apiService.getVersionName(parmasData).then(r => {
            _self.optionDate=r
          }, r => {
          }).catch(
          )
      },
      loadTable(parmasData){
        var _self = this
        apiService.subtotal(parmasData).then(r => {
            _self.dataInfo=r
            var subTotalPlatInfoList=[]
            subTotalPlatInfoList=_self.dataInfo.subTotalPlatInfoList
            var subTotalInfoByPlatList=_self.dataInfo.subTotalInfoByPlatList
            for(var i=0;i<subTotalPlatInfoList.length;i++){
                for(var j=0;j<subTotalInfoByPlatList.length;j++){
                    if(subTotalPlatInfoList[i].belongPlat==subTotalInfoByPlatList[j].belongPlat){
                        if(subTotalPlatInfoList[i]['children']){
                          subTotalPlatInfoList[i]['children'].push(subTotalInfoByPlatList[j])
                        }else{
                          subTotalPlatInfoList[i]['children']=[]
                          subTotalPlatInfoList[i]['children'].push(subTotalInfoByPlatList[j])
                        }

                    }
                }
            }
          _self.dataInfoList= subTotalPlatInfoList
        }, r => {
        }).catch(
        )
      },
      loadTable2(parmasData){
        var _self = this
        apiService.subtotal(parmasData).then(r => {
          _self.dataInfo2=r
          var subTotalPlatInfoList=[]
          subTotalPlatInfoList=_self.dataInfo2.subTotalPlatInfoList
          var subTotalInfoByPlatList=_self.dataInfo2.subTotalInfoByPlatList
          for(var i=0;i<subTotalPlatInfoList.length;i++){
            for(var j=0;j<subTotalInfoByPlatList.length;j++){
              if(subTotalPlatInfoList[i].belongPlat==subTotalInfoByPlatList[j].belongPlat){
                if(subTotalPlatInfoList[i]['children']){
                  subTotalPlatInfoList[i]['children'].push(subTotalInfoByPlatList[j])
                }else{
                  subTotalPlatInfoList[i]['children']=[]
                  subTotalPlatInfoList[i]['children'].push(subTotalInfoByPlatList[j])
                }

              }
            }
          }
          _self.dataInfoList2= subTotalPlatInfoList
        }, r => {
        }).catch(
        )
      },
      handleChangeDate(value){
        this.optionDateSelect = value
        localStorage.setItem("versionName",value);
        var params = {versionsName:this.optionDateSelect,investmentChannel:"B01",planYear:this.planYear}
        params._json = true
        this.loadTable(params)
        var params2 = {versionsName:this.optionDateSelect,investmentChannel:"B02",planYear:this.planYear}
        params2._json = true
        this.loadTable2(params2)
      },
      callback(value){
        this.investmentChannel=value
      },
    },
    created(){
      this.versionsName=localStorage.getItem("versionName");
      this.optionDateSelect=localStorage.getItem("versionName");
      this.planYear=this.$route.query.planYear
      if(!this.$route.query.planYear){
        this.planYear=new Date().getFullYear()
      }
      let parmasData={planYear:this.planYear}
      parmasData._json=true
      this.loadDate(parmasData)
      var params = {versionsName:this.versionsName,investmentChannel:"B01",planYear:this.planYear}
      params._json = true
      this.loadTable(params)
      var params2 = {versionsName:this.versionsName,investmentChannel:"B02",planYear:this.planYear}
      params2._json = true
      this.loadTable2(params2)
    }
  }
</script>
<style>
  .wrap {
    background: #ffffff;
    padding: 15px;
  }

  #headSearch > span {
    margin-left: 10px;
  }

  #headSearch {
    align-items: center;
  }

  .ant-table-tbody > tr > td {
    border: 1px solid #e8e8e8;
  }

  .ant-table-thead > tr > th {
    border-left: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
  }

  .ant-table-thead tr {
    border-top: 1px solid #e8e8e8;
  }

  .ant-table-thead > tr > th, .ant-table-tbody > tr > td {
    padding: 0px 3px!important;
  }

  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 20px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    top:20px;
    right: 25px;
  }
</style>
