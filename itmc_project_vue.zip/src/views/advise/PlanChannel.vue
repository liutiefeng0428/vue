<template>
  <div>
    <iframe scrolling="no" style="width: 100%;" src="" frameborder="0"  id="iframe"></iframe>
  </div>
</template>

<script>

  export default {
    name: "PlanChannel",
    components: {
    },
    data () {
     return {

     }
    },
    methods: {
    },
    created(){

    },
    watch: {

    }
  }
</script>
<style>

</style>
