<template>
  <div>
    <iframe scrolling="no" style="width: 100%;" :src=url frameborder="0" id="iframe"></iframe>
  </div>
</template>

<script>

  import {urlDomain} from '@/services/domain'
  export default {
    name: "PlanSummary",
    components: {
    },
    data () {
     return {
       url:urlDomain+"/project/headquarters/mplancollect/mPlanCollect.html"
     }
    },
    methods: {
    },
    created(){
    },
    mounted(){
      let clientHeight = document.documentElement.clientHeight
      document.getElementById("iframe").style.height= (clientHeight-70) + 'px'
    },
    watch: {

    }
  }
</script>
<style>
  @import '../../assets/css/common.css';
</style>
