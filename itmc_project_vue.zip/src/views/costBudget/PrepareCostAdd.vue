<template>
  <div class="wrap">
    <div class="con-title">
      <span class="divdLine"></span>
      <span>添加年度费用预算</span>
    </div>
    <div class="common-title">
      <span>基本信息</span>
      <span class="unitText">单位：万元</span>
    </div>
    <div class="container">
      <div class="define-table">
        <div class="table-head" style=" border-left: 1px solid #ccc;">
          <div class="table-item"  style="display: flex;align-items: center">选择处室</div>
          <div class="table-item" style="display: flex;align-items: center">项目明细</div>
          <div class="table-item" style="display: flex;align-items: center">具体明细</div>
          <div class="table-item">{{parseInt(planYear) - 1}}年预计完成</div>
          <div class="table-item" style="border-bottom: none; height: 70px;">变化说明</div>
        </div>
        <div class="tbl-rt" style="border-right: 1px solid #ccc;border-right: 1px solid #ccc;">
          <div class="table-rt">
            <div class="table-body">
              <div class="table-item">
                <!--<a-select :value=bureausSel class="querySelect"  style="width:100%">-->
                <a-select :value=bureausSel class="querySelect" @change="handleChangebureaus" style="width:100%">
                  <a-select-option v-for="item in bureaus" :key="item.bureausCode"> {{item.bureaus}}</a-select-option>
                </a-select>
              </div>
              <div class="table-item">
                <a-select :value="ProjectDetailTypeSel" class="querySelect" @change="handleChangeDetailType" style="width:100%">
                  <a-select-option v-for="item in ProjectDetailType" :key="item.code"> {{item.name}}</a-select-option>
                </a-select>
              </div>
              <div class="table-item" style="display: flex;align-items: center">
                <input class="lastYearBudget ant-input" type="text" v-model="specificDetails">
              </div>
              <div class="table-item">
                <input type="text" v-model="LastYearBudget" class="qymoneyAmout ant-input" style="margin: -5px 0px;">
              </div>
            </div>
            <div class="table-head">
              <div class="table-item"  style="display: flex;align-items: center">开支类型</div>
              <div class="table-item" style="display: flex;align-items: center">总部</div>
              <div class="table-item" style="display: flex;align-items: center"></div>
              <div class="table-item" style="display: flex;align-items: center"></div>
              <!--<div class="table-item">优化预算</div>-->
            </div>
            <div class="table-body">
              <div class="table-item" >
                <a-select :value=projectTypeSel  class="querySelect" @change="handleChangeType" style="width:100%">
                  <a-select-option v-for="item in projectType" :key="item.code"> {{item.name}}</a-select-option>
                </a-select>
              </div>
              <div class="table-item" style="display: flex;align-items: center"><input class="qymoneyAmout ant-input" type="number" v-model="zbMoney"></div>
              <div class="table-item"></div>
              <div class="table-item"></div>
              <!--<div class="table-item">-->
              <!--<input type="text" v-model="OptimizeBudgetAmount" class="qymoneyAmout ant-input" style="margin: -5px 0px;">-->
              <!--</div>-->
            </div>
            <div class="table-head">
              <div class="table-item" style="display: flex;align-items: center">项目</div>
              <div class="table-item" style="display: flex;align-items: center">分摊</div>
              <div class="table-item"></div>
              <div class="table-item"></div>
              <!--<div class="table-item" >{{planYear}}年总预算</div>-->
            </div>
            <div class="table-body">
              <div class="table-item" style="border-right:none;">
                <a-select :value=projectNameSel class="querySelect" @change="handleChangeProName" style="width:100%">
                  <a-select-option v-for="item in projectName" :key="item.code"> {{item.name}}</a-select-option>
                </a-select>

              </div>
              <div class="table-item" style="border-right:none;overflow: hidden;display: flex;align-items: center" >
                <!--                <span>
                                  {{totalSumAll}}
                                </span>
                                <span class="shareMount">

                                  <i class="ant-alert-icon anticon anticon-info-circle"><svg viewBox="64 64 896 896" data-icon="info-circle" width="1em" height="1em" fill="currentColor" aria-hidden="true" class=""><path style="color:rgb(24, 144, 255);" d="M512 64C264.6 64 64 264.6 64 512s200.6 448 448 448 448-200.6 448-448S759.4 64 512 64zm32 664c0 4.4-3.6 8-8 8h-48c-4.4 0-8-3.6-8-8V456c0-4.4 3.6-8 8-8h48c4.4 0 8 3.6 8 8v272zm-32-344a48.01 48.01 0 0 1 0-96 48.01 48.01 0 0 1 0 96z"></path></svg></i>
                                  请在下面添加企业分摊
                                </span>-->
                <input class="qymoneyAmout ant-input" type="number" v-model="qyMoney">
              </div>
              <div class="table-item"></div>
              <div class="table-item"></div>
              <!--<div class="table-item" style="border-right:none;">-->
              <!--<input type="text" v-model="budgetAmount" class="qymoneyAmout ant-input" style="margin: -5px 0px;">-->
              <!--</div>-->
            </div>
          </div>
          <div class="table-head" style="border-bottom:none;box-sizing: border-box">
            <textarea name="" id="" cols="30" rows="10" placeholder="请输入变化说明" v-model="instructions"></textarea>
          </div>
        </div>
      </div>
    </div>
    <div class="common-title">
      <span>内容及工作量</span>
    </div>
    <div class="container">
      <div class="edit_container"  style="height:150px">
        <quill-editor
          style="height:100px"
          v-model="content"
          ref="myQuillEditor"
          :options="editorOption"
          @blur="onEditorBlur($event)" @focus="onEditorFocus($event)"
          @change="onEditorChange($event)">
        </quill-editor>
      </div>
    </div>
    <div class="common-title">
      <span>费用预算</span>
    </div>
    <div class="container" style="margin-bottom:20px">
      <div class="edit_container" style="height:150px">
        <quill-editor
          style="height:100px"
          v-model="contentFY"
          ref="myQuillEditorFY"
          :options="editorOptionFY"
          @blur="onEditorBlurFY($event)" @focus="onEditorFocusFY($event)"
          @change="onEditorChangeFY($event)">
        </quill-editor>
      </div>
    </div>
    <!--    <div class="common-title">
          <span>企业分摊</span>
          <a-button type="primary" @click="addTepl()" icon="plus">添加</a-button>
          <a-button type="primary" @click="addTepl()" icon="plus">添加股份</a-button>
          <a-button type="primary" @click="addTepl()" icon="plus">添加集团</a-button>
          <span class="unitText">单位：万元</span>
        </div>-->
    <!--    <div class="container">
          <div>
            <a-tabs defaultActiveKey="1" @change="callback">
              <a-tab-pane v-for="(item,index) in infactTabMock"  :tab="item.tabName"  :key="item.tabCode">
              </a-tab-pane>
            </a-tabs>
            <div class="ant-table-content">
              <div class="ant-table-body">
                <table class="" style="width: 100%"><colgroup><col style="width: 120px; min-width: 120px;"><col><col></colgroup>
                  <thead class="ant-table-thead">
                  <tr>
                    <th key="rowIndex" class="ant-table-align-center" style="text-align: center;"><div>序号</div></th>
                    <th key="fullName" class="ant-table-align-left" style="text-align: left;"><div>企业名称</div></th>
                    <th key="typeCode" class="ant-table-align-left" style="text-align: left;"><div>金额</div></th>
                    <th key="enterprisesBasis" class="ant-table-align-left" style="text-align: left;"><div>依据</div></th>
                  </tr>
                  </thead>
                  <tbody class="ant-table-tbody">
                  <tr v-for="(itemInner,indexInner) in infactTableMock" v-if="itemInner.parentCode==currentTabCode">
                    <td style="text-align: center;"><span class="ant-table-row-indent indent-level-0" style="padding-left: 0px;"></span>{{indexInner+1}}</td>
                    <td style="text-align: left;">{{itemInner.orgName}}</td>
                    <td style="text-align: left;"><div data-orgcode="record">
                      <input type="text" v-model="itemInner.qyMoney" :data-orgcode="itemInner" class="qymoneyAmout ant-input" style="margin: -5px 0px;"></div>
                    </td>
                    <td style="text-align: left;">
                      <div data-orgcode="record">
                        <input type="text" v-model="itemInner.enterprisesBasis" :data-orgcode="itemInner" class="enterprisesBasis ant-input" style="margin: -5px 0px;">
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td></td>
                    <td>合计：</td>
                    <td>{{tabSum}}</td>
                    <td></td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>-->
    <div class="container" style="text-align: center;margin-top: 20px">
      <div>
        <a-button type="primary" @click="saveEdit()">保存</a-button>
        <a-button @click="goBack()">返回</a-button>
      </div>
    </div>
    <!--企业分摊添加-->
    <a-modal
      title="查看信息化建设与应用需求"
      :width="600"
      centered
      v-model="modalVisible"
      @ok="() => initTable()"
      @cancel="() => setModal1Visible(false)"
      okText="确认"
      cancelText="关闭"
    >
      <div>
        <div style="flex: 1">
          <div class="con-title">
            <span class="divdLine"></span>
            <span>请选择企业</span>
          </div>
          <a-tree
            :loadData="onLoadData"
            checkable
            @expand="onExpand"
            :expandedKeys="expandedKeys"
            :autoExpandParent="autoExpandParent"
            v-model="checkedKeys"
            @select="onSelect"
            :selectedKeys="selectedKeys"
            :treeData="treeData"
          />
        </div>
      </div>
    </a-modal>
  </div>
</template>

<script>

  import {quillEditor} from "vue-quill-editor"; //调用编辑器
  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css';
  import {apiService} from "@/services/apiservice";
  import $ from 'jquery'

  export default {
    name: "ReportAdd",
    components: {
      quillEditor
    },
    data() {
      return {
        defaultProps: {
          children: 'children',
          label: 'label'
        },
        loadCurObj:[], //详情后台返回分摊数据
        currentTabCode:"", //tab切换显示对象对应table
        infactTabMock:[],//实际tab信息
        loadInfactTabMock:[],//tab后台返回详情数据
        loadInfactTabMock1:[],
        infactTableMock:[],//实际table的数据
        infactTableMock1:[],
        curObj:{},
        dataOrg:[],//接口调用获取到企业名称
        dataOrgQy:[],//接口调用获取到企业名称
//        dataOrg,//接口调用获取到企业名称
        treeData:[],//转换成树形结构
        treeDataQy:[],//转换成树形结构
//        treeDataParent:[],
        checkedKeys: [''],//企业名称选择的数组
        checkMock:[], //选择的企业对象数组
        planYear:"",

        ouId:"",
        version:"",
        bureaus:[],//处室
        bureausSel:"",
        bureausSelText:"",
        projectType:[],//开支类型
        projectTypeSel:"",
        projectTypeSelText:"",
        projectName:[],//项目名称
        projectNameSel:"",
        projectNameSelText:"",
        ProjectDetailType:[],//选择项目明细
        ProjectDetailTypeSel:"",
        ProjectDetailTypeSelText:"",
        content:"",
        contentText:"",
        editorOption: {
          modules:{
            toolbar:[
              ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
              ['blockquote', 'code-block']
            ]
          },
          placeholder: '请输入内容及工作量',
        },
        contentFY: "",
        contentFYText:"",
        editorOptionFY: {
          modules:{
            toolbar:[
              ['bold', 'italic', 'underline', 'strike'],        // toggled buttons
              ['blockquote', 'code-block']
            ]
          },
          placeholder: '请输入费用测算',
        },
        zbMoney:"",
        specificDetails:"",
        LastYearBudget:"",
        budgetAmount:"",
        OptimizeBudgetAmount:"",
        qyMoney:"",
        instructions:"",
        optionDateSelect:"",
        modalVisible:false,
        expandedKeys: [''],
        autoExpandParent: true,
        selectedKeys: [],
        tabMock:[],
        tabSameMock:[],
//        trArr:[],
//        模拟根据id获取到当地的元素
        items: [
          {id:1,"ExpenditureType":"专有软件、核心硬件升级及续保费","projectName":"专有软件运行维护","projectDetail":'SPA维护',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市黄浦区金陵东路569号17楼"},
          {id:2,"ExpenditureType":"专有软件、核心硬件升级及续保费","projectName":"专有软件运行维护","projectDetail":'SPA维护',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市奉贤区南桥镇立新路12号2楼"},
          {id:3,"ExpenditureType":"专有软件、核心硬件升级及续保费","projectName":"专有软件运行维护","projectDetail":'微软产品',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市崇明县城桥镇八一路739号"},
          {id:4,"ExpenditureType":"专有软件、核心硬件升级及续保费","projectName":"专有软件运行维护","projectDetail":'西门子维护',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市青浦区青浦镇章浜路24号"},
//       小计
          {id:5,"ExpenditureType":"专有软件、核心硬件升级及续保费","projectName":"专有软件运行维护","projectDetail":'小计',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":""},
          {id:6,"ExpenditureType":"专有软件、核心硬件升级及续保费","projectName":"SPA维护","projectDetail":'小型机及储续保',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市金山区龙胜路1431号一层"},
          {id:7,"ExpenditureType":"专有软件、核心硬件升级及续保费","projectName":"SPA维护","projectDetail":'网络安全续保',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市闵行区都市路2988号2楼"},
//          小计
          {id:8,"ExpenditureType":"专有软件、核心硬件升级及续保费","projectName":"SPA维护","projectDetail":'小计',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":""},
//        合计
          {id:9,"ExpenditureType":"专有软件、核心硬件升级及续保费","projectName":"SPA维护","projectDetail":'合计',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":""},

          {id:10,"ExpenditureType":"111专有软件、核心硬件升级及续保费","projectName":"222专有软件运行维护","projectDetail":'44SPA维护',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市黄浦区金陵东路569号17楼"},
          {id:11,"ExpenditureType":"111专有软件、核心硬件升级及续保费","projectName":"222专有软件运行维护","projectDetail":'55SPA维护',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市奉贤区南桥镇立新路12号2楼"},
//  小计
          {id:12,"ExpenditureType":"111专有软件、核心硬件升级及续保费","projectName":"222专有软件运行维护","projectDetail":'小计',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":""},
          {id:13,"ExpenditureType":"111专有软件、核心硬件升级及续保费","projectName":"333专有软件运行维护","projectDetail":'66SPA维护',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市奉贤区南桥镇立新路12号2楼"},
          {id:14,"ExpenditureType":"111专有软件、核心硬件升级及续保费","projectName":"333专有软件运行维护","projectDetail":'66SPA维护',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市奉贤区南桥镇立新路12号2楼"},
          {id:15,"ExpenditureType":"111专有软件、核心硬件升级及续保费","projectName":"333专有软件运行维护","projectDetail":'77SPA维护',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市奉贤区南桥镇立新路12号2楼"},
          {id:16,"ExpenditureType":"111专有软件、核心硬件升级及续保费","projectName":"333专有软件运行维护","projectDetail":'77SPA维护',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市奉贤区南桥镇立新路12号2楼"},
          {id:17,"ExpenditureType":"111专有软件、核心硬件升级及续保费","projectName":"333专有软件运行维护","projectDetail":'77SPA维护',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市奉贤区南桥镇立新路12号2楼"},
          {id:18,"ExpenditureType":"111专有软件、核心硬件升级及续保费","projectName":"333专有软件运行维护","projectDetail":'77SPA维护',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":"上海市奉贤区南桥镇立新路12号2楼"},

//   小计
          {id:2,"ExpenditureType":"111专有软件、核心硬件升级及续保费","projectName":"333专有软件运行维护","projectDetail":'小计',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":""},
//  合计
          {id:2,"ExpenditureType":"111专有软件、核心硬件升级及续保费","projectName":"333专有软件运行维护","projectDetail":'合计',"general":"150","shareAmount":"100","totalAmount":"250","explain":"说明","substance":"工作内容","cost":""},


        ],
        currentObj:null,
        columns: [
          {
            title: '#',
            dataIndex: '',
            key: 'rowIndex',
            width: 120,
            align: "center",
            customRender: function (t, r, index) {
              return parseInt(index) + 1;
            }
          },
          {
            title: '企业名称',
            align: "left",
            dataIndex: 'fullName',
          },
          {
            title: '金额',
            align: "left",
            dataIndex: 'typeCode',
            scopedSlots: { customRender: 'typeCode' },
          }
        ],
        infoData: null,

      }
    },
    watch: {
      checkedKeys(val,info) {
        let mockQYArr=[]
        for(var i=0;i<val.length;i++){
          let obj={}
          obj.name=val[i]
          obj.id=val[i]
          mockQYArr.push(obj)
        }
        this.mockQY=mockQYArr
      },
    },
    methods: {
      getItmcInfoBureaus(){
        let _self=this
        let projectTypeParmas={}
        projectTypeParmas._json=true
        apiService.getItmcInfoBureaus(projectTypeParmas).then(r => {
          _self.bureaus=r
          if(_self.$route.query.ouId){
            _self.bureausSel=_self.$route.query.ouId
          }else{
            _self.bureausSel=r[0].bureausCode
          }
          var obj=_self.bureaus.find(function (obj) {
            return obj.bureausCode === _self.bureausSel
          })
          _self.bureausSelText=obj.bureaus

        }, r => {
        }).catch(
        )
      },
      handleChangebureaus(value){
        var obj=this.bureaus.find(function (obj) {
          return obj.bureausCode === value
        })
        this.bureausSel=value
        this.bureausSelText=obj.bureaus
        let params={parentCode:this.projectNameSel,ouId:value}
        params._json=true

        this.getItmcProjectDetailTypeList(params)
      },
      handleChangeProName(value){
        var obj=this.projectName.find(function (obj) {
          return obj.code === value
        })

        this.projectNameSel=value
        this.projectNameSelText=obj.name
        let params={parentCode:value,ouId:this.bureausSel,version:this.version}
        // let params={parentCode:value}
        params._json=true

        this.getItmcProjectDetailTypeList(params)
      },
      handleChangeType(value){
        if(!this.bureausSel){
          this.$message.warning("请先选择处室")
          return
        }
        var obj=this.projectType.find(function (obj) {
          return obj.code === value
        })
        let _self=this
        _self.projectName=[]
        if(!value){
          this.$message.warning("请先选择开支类型")
        }
        this.projectTypeSel=value
        this.projectTypeSelText=obj.name
        let projectTypeParmas={"parentCode":value, "version":this.version}
        projectTypeParmas._json=true
        apiService.getItmcProjectTypeList(projectTypeParmas).then(r => {
          _self.projectName=r
          _self.projectNameSel=r[0].code
          _self.handleChangeProName(_self.projectNameSel)
        }, r => {
        }).catch(
        )
      },
      handleChangeDetailType(value){
        let _self=this
        let projectTypeParmas={projectDetailsType:value,version:this.version,ouId:this.ouId}
        projectTypeParmas._json=true
        apiService.getCostBudgetProjectDetails(projectTypeParmas).then(r => {
          if(r.result=='0000'){
            _self.$router.push({path: "/report-edit", query: {currentId:r.itmcCostPlan.id,planYear:_self.planYear}})
          }
        }, r => {
        }).catch(
        )

        var obj=this.ProjectDetailType.find(function (obj) {
          return obj.code === value
        })
        this.ProjectDetailTypeSel=value
        this.ProjectDetailTypeSelText=obj.name
      },
      getItmcProjectTypeList(parmasData){
        let _self=this
        apiService.getItmcProjectTypeList(parmasData).then(r => {
          _self.projectType=r
          if(r.length>0){
            _self.projectTypeSel=r[0].code

            var obj= _self.projectType.find(function (obj) {
              return obj.code === _self.projectTypeSel
            })
            _self.projectTypeSelText=obj.name
            let projectNameParmas={"parentCode": _self.projectTypeSel, version: _self.version}
            projectNameParmas._json=true
            apiService.getItmcProjectTypeList(projectNameParmas).then(r1 => {
              _self.projectName=r1
              if(r1.length>0){
                _self.projectNameSel=r1[0].code
                var obj=_self.projectName.find(function (obj) {
                  return obj.code === _self.projectNameSel
                })
                _self.projectNameSelText=obj.name
                let detaiTypeParmas={parentCode:_self.projectNameSel,ouId:_self.ouId,version: _self.version}
                // let detaiTypeParmas={parentCode:_self.projectNameSel}
                detaiTypeParmas._json=true
                _self.getItmcProjectDetailTypeList(detaiTypeParmas)
              }

            }, r => {
            }).catch(
            )
          }
        }, r => {
        }).catch(
        )
      },
      getItmcProjectDetailTypeList(parmasData){
        let _self=this
        apiService.getItmcProjectDetailTypeList(parmasData).then(r => {
          _self.ProjectDetailType=r;
          this.ProjectDetailTypeSel="";
          this.ProjectDetailTypeSelText="";

        }, r => {
        }).catch(
        )
      },
      onLoadData (treeNode) {
        let _self=this;
        return new Promise((resolve) => {
          if(treeNode.dataRef.children){
            if (treeNode.dataRef.children.length>0) {
              resolve()
              return
            }
          }
          var  nextNode = _self.getUnitByOrgId(treeNode.eventKey,_self.dataOrg)
          setTimeout(() => {
            treeNode.dataRef.children = nextNode
            this.treeData = [...this.treeData]
            resolve()
          }, 1000)
        })
      },
      getUnitByOrgId(orgId,dataOrg){
        let  allObj=[]
        var dataOrg=dataOrg
        for (var i = 0; i < dataOrg.length; i++) {
          if (dataOrg[i].orgLevelName == '单位') {
            if (dataOrg[i].parentId == orgId) {
              dataOrg[i].title = dataOrg[i].orgName
              dataOrg[i].key = dataOrg[i].orgId
              allObj.push(dataOrg[i])
            }
          }
        }
        return allObj
      },
      addTepl(){
        this.modalVisible=true
      },
      setModal1Visible(){
        this.modalVisible=false
      },
      onSelect (selectedKeys, info) {
        this.selectedKeys = selectedKeys
      },
      onExpand (expandedKeys) {
        this.expandedKeys = expandedKeys
        this.autoExpandParent = false
      },
      onCheck (checkedKeys) {
        this.checkedKeys = checkedKeys
      },
      saveEdit(){
        let _self=this
        this.curObj.zbMoney=this.zbMoney
        this.curObj.qyMoney=this.qyMoney
        this.curObj.budgetAmount=this.budgetAmount
        this.curObj.optimizeBudgetAmount=this.OptimizeBudgetAmount
        this.curObj.specificDetails=this.specificDetails
        this.curObj.lastYearBudget=this.LastYearBudget
        this.curObj.ouId=this.bureausSel
        this.curObj.ouName=this.bureausSelText
        this.curObj.feeType=this.projectTypeSel
        this.curObj.feeName=this.projectTypeSelText
        this.curObj.instructions=this.instructions
        this.curObj.projectId=this.projectNameSel
        this.curObj.projectName=this.projectNameSelText
        this.curObj.projectDetailsType=this.ProjectDetailTypeSel
        this.curObj.projectDetailsName=this.ProjectDetailTypeSelText
        this.instructions=this.instructions
        this.curObj.content=this.content
        this.curObj.contentText=this.contentText
        this.curObj.measure=this.contentFY
        this.curObj.measureText=this.contentFYText
        this.curObj.version=this.version
        this.curObj.planYear=this.planYear
        this.curObj.feePlanStatus=this.$route.query.feePlanStatus

        // _self.infactTabMock.parentCode = _self.infactTabMock.parentId
        delete this.curObj['id'];

        var parmasData={itmcCostPlan:this.curObj,itmcCostEnterprise:this.infactTableMock}
        parmasData._json=true
        apiService.saveCostBudgetPlan(parmasData).then(r => {
          if(r.result=='0000'){
            _self.$message.success("保存成功")
            this.$router.go(-1)
          }
          if(r.result=='9999'){
            _self.$message.error(r.msg)
          }
        }, r => {
        }).catch(
        )
      },
      initTable(){
        this.checkMock=[]  //添加时为空
        for(var j=0;j<this.checkedKeys.length;j++){
          for(var i=0;i<this.dataOrg.length;i++){
            if(this.dataOrg[i].orgId==this.checkedKeys[j]&&this.dataOrg[i].orgLevelName=='单位'){
              this.checkMock.push(this.dataOrg[i])
            }
          }
        }

        this.modalVisible=false
        var tabMock=[]
        tabMock = this.unique(this.checkMock,"parentId");
        var infaltablModckAdd=this.getInfactTabMock(tabMock) //获取实际tab信息
        for(var i=0;i<infaltablModckAdd.length;i++){
          for(var j=0;j<this.checkMock.length;j++){
            if(infaltablModckAdd[i].orgCode==this.checkMock[j].parentCode){
              this.checkMock[j].parentOrgName=infaltablModckAdd[i].orgName
            }
          }
        }

        var orgTab=this.loadInfactTabMock1
        var orgTabel=this.infactTableMock1
        this.infactTableMock=orgTabel.concat(this.checkMock)
        this.infactTabMock=orgTab.concat(infaltablModckAdd)
        this.infactTableMock = this.unique(this.infactTableMock,"orgCode");
        this.infactTabMock = this.unique(this.infactTabMock,"orgCode");
        this.currentTabCode=this.infactTabMock[0].tabCode
      },
      getInfactTabMock(arr){
        var infactTabMockAdd=[]
        for(var i=0;i<arr.length;i++){
          for(var j=0;j<this.dataOrg.length;j++){
            if(this.dataOrg[j].orgId ==arr[i].parentId){
              this.dataOrg[j].tabName= this.dataOrg[j].orgName
              this.dataOrg[j].tabCode= this.dataOrg[j].orgCode
              infactTabMockAdd.push(this.dataOrg[j])
              break
            }
          }
        }
        return infactTabMockAdd
      },
      hasSameKey(){
        this.tabSameMock=[]
        for(var j=0;j<this.infactTabMock.length;j++){
          var curType=[]
          for(var i=0;i<this.checkMock.length;i++){
            if(this.infactTabMock[j].orgId==this.checkMock[i].parentId){
              curType.push(this.checkMock[i])
            }
          }
          this.tabSameMock.push(curType)
        }
      },
      unique(arr, name) { // 根据唯一标识orderId来对数组进行过滤
        var hash = {};
        return arr.reduce(function (item, next) {
          hash[next[name]] ? '' : hash[next[name]] = true && item.push(next);
          return item;
        }, []);
      },
      loadMsg(){
        this.ouId=this.$route.query.ouId
        this.version=this.$route.query.version
        this.planYear=this.$route.query.planYear
        if(!this.$route.query.planYear){
          this.planYear=new Date().getFullYear()
        }
      },
      goBack(){
        this.$router.go(-1)
      },
      handleChange(a,b,c){
        const newData = [...this.infoData]
        const target = newData.filter(item => key === item.key)[0]
        if (target) {
          target[column] = value
          this.infoData = newData
        }
      },
      loadTable(parmasData){
        let _self = this
        //主页table数据
        apiService.getDictionaryFList(parmasData).then(r => {
          _self.infoData = r
        }, r => {
        }).catch(
        )
      },
      callback (key) {
        this.currentTabCode=key
      },
      onEditorReady(editor) {
      },
      onEditorBlur(){
      },
      onEditorFocus(){
      },
      onEditorChange(event){
        this.content=event.html
        this.contentText=event.text
      },
      onEditorReadyFY(editor) {

      },
      onEditorBlurFY(){
      },
      onEditorFocusFY(){
      },
      onEditorChangeFY(event){
        this.contentFY=event.html
        this.contentFYText=event.text
      },
      getOrgByOrgTypeCodes(){
        let _self=this
        let parmasData="Itmc_Co_Type2"
        $.ajax({
          type: "POST",
          url: "/project/org/getOrgByOrgTypeCodes?Itmc_Co_Type2",
          contentType: 'application/x-www-form-urlencoded;charset=utf-8',
          dataType: "json",
          success: function(data){
            _self.dataOrgQy=data
            // _self.initTreeData1(data)
            _self.treeDataQy.push(_self.initTreeData1(data))
          }
        })
      },
      initTreeData1(dataOrg){
        var resultArr=dataOrg[0]
        var secArr=[];
        console.log(dataOrg);
        for(var i=0;i<dataOrg.length;i++){
          if(dataOrg[i].orgLevelName=='板块'){
            dataOrg[i].title=dataOrg[i].orgName
            dataOrg[i].key=dataOrg[i].orgId
            dataOrg[i].children=[];
            secArr.push(dataOrg[i])
          }
        }

        for(var j=0;j<secArr.length;j++){
          for(var i=0;i<dataOrg.length;i++){
            if(dataOrg[i].orgLevelName=='单位'){
              if(dataOrg[i].parentId==secArr[j].orgId){
                dataOrg[i].title=dataOrg[i].orgName
                dataOrg[i].key=dataOrg[i].orgId
                // secArr[j].children.push(dataOrg[i])
              }
            }
          }
        }

        resultArr.title=resultArr.orgName
        resultArr.key=resultArr.orgId
        resultArr.children=secArr
        return resultArr
      },
    },
    computed: {
      editor() {
        return this.$refs.myQuillEditor.quill;
      },
      tabSum(){
        let tabSum = 0;
        this.infactTableMock.map((item) => {if(!isNaN(item.qyMoney)){if(item.parentCode==this.currentTabCode) tabSum +=parseInt(item.qyMoney) }})
        if(isNaN(tabSum)){
          return 0
        }
        return parseInt(tabSum)
      },
      totalSumAll(){
        let totalSumAll = 0;
        this.infactTableMock.map((item) => { if(!isNaN(item.qyMoney)){totalSumAll +=parseInt(item.qyMoney)} })
        if(isNaN(totalSumAll)){
          return 0
        }
        return parseInt(totalSumAll)
      },
    },
    created(){
      const _self=this
      this.loadMsg()
      this.getItmcInfoBureaus()
      let projectTypeParmas={"parentCode":'0'}
      projectTypeParmas._json=true
      this.getItmcProjectTypeList(projectTypeParmas)
      this.dataOrg=window.dataOrg
      this.treeData.push(window.dataOrg[0])
      this.getOrgByOrgTypeCodes()
    }
  }
</script>
<style>
  /* .wrap {
     padding: 20px;
     background: #ffffff;
     margin: 10px;
   }*/

  .edit_container {
    background: #ffffff;
  }

  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .common-title {
    font-size: 14px;
    font-weight: 700;
    padding: 5px 15px;
    margin: 10px 0 5px 0;
    position: relative;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    bottom: 0;
    right: 25px;
  }

  .define-table, .table-rt {
    display: flex;
  }

  .define-table {
    border-top: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
  }

  .tbl-rt {
    flex: 7;
  }

  .table-head {
    flex: 1;
  }

  .table-body {
    flex: 2;
  }

  .table-item {
    border-right: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
    padding: 10px;
    color: rgba(0, 0, 0, 0.65);
    height: 45px;
    box-sizing: border-box;
    justify-content: center;
    align-items: center;
    text-align: center;
    display: flex;
  }

  .table-head {
    background: #fafafa;
  }

  .table-item input {
    width: 100%;
    height: 100%;
    outline: none;
  }

  .table-head textarea {
    width: 100%;
    height: 70px;
    padding: 10px;
    border: none;
    outline: none;
  }
  .container{
    padding: 0 15px;
  }
  .shareMount{
    float: right;
    top: 0;
    width: 176px;
    position: relative;
    left: 0;
    display: inline-block;
    text-align: right;
  }
  .shareMount .ant-alert-icon {
    top: 3px;
    left: 16px;
    position: absolute;
  }
  .qymoneyAmout{
    text-align: center;
  }
</style>
