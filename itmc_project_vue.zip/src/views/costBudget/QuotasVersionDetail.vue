 <template>
  <div class="wrap">
    <div class="con-title">
      <span class="divdLine"></span>
      <span>费用预算明细</span>
      <a-button v-if="feePlanStatus != '5'" @click="doAdd()" type="primary" style="margin-left:20px;position: relative;top:-5px" icon="plus">添加</a-button>
      <a-button @click="backVersion()" type="primary" style="margin-left:5px;position: relative;top:-5px">返回</a-button>
    </div>
    <div class="con-title">
      <span v-if="infoData[0]">{{infoData[0].projectName}}</span>
      <span class="unitText">单位：万元</span>
    </div>
    <div class="container" style="padding: 0">
      <div>
        <div>
          <div class="ant-table">
          </div>
          <div>
            <table id="myTable" border="1" cellpadding="15" cellspacing="0" style="width: 100%">　　　
              <thead>
                  <tr>　
                      <th class="k100" rowspan="2">项目</th>
                      <th class="k200" colspan="4">{{parseInt(planYear)-1}}年预计完成</th>
                      <th class="k200" colspan="4">{{planYear}}年预算</th>
                      <!--<th class="k80" rowspan="2">费用变化</th>　-->　
                     <!-- <th class="k80" rowspan="2">变化说明</th>　--> 　　
<!--                      <th class="k150" rowspan="2">内容及工作量</th>　　　　 　　
                      <th class="k150" rowspan="2">费用测算</th>　-->　　 　　
                      <th class="k80" rowspan="2">操作</th>　
                  </tr>
                  <tr>　
                    <th class="k50">预算</th>　　　　
                    <th class="k50">总部</th>　 　　
                    <th class="k50">分摊</th>　　　 　　
                    <th class="k50">预算完成</th>　　　 　　
                    <th class="k50">各处预算</th>　　　　
                    <th class="k50">总部</th>　 　　
                    <th class="k50">分摊</th>　　　 　　
                    <th class="k50">优化预算</th>　　　　
                 </tr>　
              </thead>
              <tbody>
              <template v-for="(item,index) in tabSameMock">
                <tr :key="index">
                  <td :rowspan="item.curArr.length" style="width: 200px">
                    <div style="display: flex;align-items: center;">
                      <div style="width: 150px;text-overflow: ellipsis;overflow: hidden;white-space: nowrap;" :title="item.rowSpanName">{{item.rowSpanName}}</div>
                      <div>
                        <img src="@/assets/sort-up.png" style="cursor: pointer;width: 15px;position: relative;top: -8px;" @click="sortUp(tabSameMock,index)">
                        <img src="@/assets/sort-down.png" style="position: relative;top:3px;cursor: pointer;width: 16px;right: 20px;"  @click="sortDown(tabSameMock,index)">
                      </div>
                    </div>
                  </td>
                  <td >{{(item.curArr[0].lastZbMoney+item.curArr[0].lastQyMoney).toFixed(2)||'0'}}</td>
                  <td >{{item.curArr[0].lastZbMoney||'0'}}</td>
                  <td >{{item.curArr[0].lastQyMoney||'0'}}</td>
                  <td >{{item.curArr[0].lastYearCompleterBudget||'0'}}</td>
                  <td >{{item.curArr[0].budgetAmount||'0'}}</td>
                  <td >{{item.curArr[0].zbOptimizeMoney||'0'}}</td>
                  <td >{{item.curArr[0].qyOptimizeMoney||'0'}}</td>
                  <td >{{item.curArr[0].optimizeBudgetAmount||'0'}}</td>
                  <!--<td >{{item.curArr[0].optimizeBudgetAmount-item.curArr[0].budgetAmount||'0'}}</td>-->
<!--                  <td >
                    <div style="display: flex;">
                      <div style="width: 150px;text-overflow: ellipsis;overflow: hidden;white-space: nowrap;" :title="item.instructions">{{item.curArr[0].instructions||'0'}}</div>
                    </div>
                  </td>-->
<!--                  <td >
                    <div style="display: flex;">
                      <div style="width: 150px;text-overflow: ellipsis;overflow: hidden;white-space: nowrap;" :title="item.contentText">{{item.curArr[0].contentText||'0'}}</div>
                    </div>
                  </td>
                  <td >
                    <div style="display: flex;">
                      <div style="width: 150px;text-overflow: ellipsis;overflow: hidden;white-space: nowrap;" :title="item.measureText">{{item.curArr[0].measureText||'0'}}</div>
                    </div>
                  </td>-->
                  <td style="width: 100px">
                    <span v-if="item.curArr[0].feePlanStatus != '5'" @click="toEdit(item,'-1')">
                      <a>编辑</a>
                    </span>
                    <span v-if="item.curArr[0].feePlanStatus == '5'" style="color: #888">编辑</span>
                    <span>
                  <a-popconfirm
                    title="确定删除吗?"
                    okText="确定"
                    cancelText="取消"
                    @confirm="() => deletArr(item,'-1')">
                       <a v-if="item.curArr[0].feePlanStatus != '5'" href="javascript:;">删除</a>
                       <span style="color: #888" v-if="item.curArr[0].feePlanStatus == '5'">删除</span>
                  </a-popconfirm>
              </span>
                  </td>
                </tr>
                <tr v-for="(ele,inx) in item.curArr.length-1" :key="index+'-'+inx">
                  <td>{{item.curArr[ele].lastYearBudget||'0'}}</td>
                  <td>{{item.curArr[ele].zbMoney||'0'}}</td>
                  <td>{{item.curArr[ele].qyMoney||'0'}}</td>
                  <td >{{item.curArr[0].budgetAmount||'0'}}</td>
                  <td >{{item.curArr[0].optimizeBudgetAmount||'0'}}</td>
                  <td >{{item.curArr[0].optimizeBudgetAmount-item.curArr[0].budgetAmount||'0'}}</td>
                  <td >{{item.curArr[0].instructions}}</td>
                  <td >{{item.curArr[0].contentText}}</td>
                  <td >{{item.curArr[0].measureText}}</td>
                  <td style="width: 100px">
                    <span @click="toEdit(item,inx)"><a>编辑</a></span>
                    <span>
                  <a-popconfirm
                    title="确定删除吗?"
                    okText="确定"
                    cancelText="取消"
                    @confirm="() => deletArr(item,inx)">
                       <a href="javascript:;">删除</a>
                  </a-popconfirm>
              </span>
                  </td>
                </tr>
              </template>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {apiService} from "@/services/apiservice";
  export default {
    name: "QuotasVersionDeail",
    components: {
    },
    data() {
      return {
        tabSameMock:[],
        tabMock:[],
        infoData:[],
        version:"",
        planYear:"",
        projectId:"",
        projectName:"",
        feeName:"",
        feeType:"",
        feePlanStatus:''
      }
    },
    methods: {
      sortUp(item,index){
        let _self=this
        var current=item[index]
        var preCurr=this.tabSameMock[index-1]
        let parmasData={"list":[{"projectDetailsType":current.projectDetailsType,"sort":preCurr.sort,"version":current.version},{"projectDetailsType":preCurr.projectDetailsType,"sort":current.sort,"version":preCurr.version}]}
        parmasData._json=true
        apiService.updateCostProjectBudgetPlan(parmasData).then(r => {
          if(r.result=='0000'){
            _self.$message.success("已排序")
            let parmas={version:this.version,planYear:this.planYear,projectId:this.projectId}
            parmas._json=true
            this.loadTable(parmas)
          }
        }, r => {
        }).catch(
        )
      },
      sortDown(item,index){
        let _self=this
        var current=item[index]
        var preCurr=this.tabSameMock[index+1]
        let parmasData={"list":[{"projectDetailsType":current.projectDetailsType,"sort":preCurr.sort,"version":current.version},{"projectDetailsType":preCurr.projectDetailsType,"sort":current.sort,"version":preCurr.version}]}
        parmasData._json=true
        apiService.updateCostProjectBudgetPlan(parmasData).then(r => {
          if(r.result=='0000'){
            _self.$message.success("已排序")
            let parmas={version:this.version,planYear:this.planYear,projectId:this.projectId}
            parmas._json=true
            this.loadTable(parmas)
          }
        }, r => {
        }).catch(
        )
      },
      doAdd(){
        let item={version:this.version,planYear:this.planYear,projectId:this.projectId,projectName:this.projectName,feeType:this.feeType,feeName:this.feeName,feePlanStatus:this.feePlanStatus}
        // this.$router.push({path: "/report-add", query: {current: JSON.stringify(item),planYear:this.planYear,feePlanStatus:this.feePlanStatus,version:this.version}})
         this.$router.push({path: "/report-addCopy", query: {current: JSON.stringify(item),flag:"1"}})
      },
      backVersion(){
        this.$router.go(-1)
      },
      hasSameKey(){
        this.tabSameMock=[]
        for(var j=0;j<this.tabMock.length;j++){
          var obj={}
          obj.rowSpanName=this.tabMock[j].projectDetailsName
          obj.contentText=this.tabMock[j].contentText
          obj.instructions=this.tabMock[j].instructions
          obj.measureText=this.tabMock[j].measureText
          obj.projectDetailsType=this.tabMock[j].projectDetailsType
          obj.sort=this.tabMock[j].sort
          obj.version=this.tabMock[j].version
          var curArr=[]
          for(var i=0;i<this.infoData.length;i++){
            if(this.tabMock[j].projectDetailsName==this.infoData[i].projectDetailsName){

              var currentDetail = this.infoData[i];
              if(!currentDetail.lastZbMoney) currentDetail.lastZbMoney = 0;
              if(!currentDetail.lastQyMoney) currentDetail.lastQyMoney = 0;
              this.infoData[i].lastBudgetAmount = (parseFloat(currentDetail.lastZbMoney) + parseFloat(currentDetail.lastQyMoney)).toFixed(2);
              curArr.push(this.infoData[i])
              obj.curArr=curArr
            }
          }
          this.tabSameMock.push(obj)
        }
      },
      unique(arr, name) {
        var hash = {};
        return arr.reduce(function (item, next) {
          hash[next[name]] ? '' : hash[next[name]] = true && item.push(next);
          return item;
        }, []);
      },
      loadTable(parmasData){
        let _self = this
        apiService.getCostBudgetProjectList(parmasData).then(r => {
          _self.infoData=r;
          if(r.length == 0){
            this.tabSameMock=[];
             return;
          }
          _self.tabMock=_self.unique(_self.infoData,'projectDetailsName')
          _self.feePlanStatus = r[0].feePlanStatus
          _self.projectName=r[0].projectName;
          _self.feeName=r[0].feeName;
          _self.feeType=r[0].feeType;
          _self.hasSameKey()
        }, r => {
        }).catch(
        )
      },
      deletArr(item,index){
        let currentItem= item.curArr[parseInt(index)+1]
        let _self=this
        let parmasData={id:currentItem.id}
        parmasData._json=true
        apiService.deleteCostBudgetProjectDetails(parmasData).then(r => {
          _self.$message.success("删除成功")
          let parmas={version:_self.version,planYear:_self.planYear,projectId:_self.projectId}
          parmas._json=true
          _self.loadTable(parmas)
        }, r => {
        }).catch(
        )
      },
      toEdit(item,index){
        debugger
        let currentItem= item.curArr[parseInt(index)+1]
        // this.$router.push({path: "/version-edit", query: {current: JSON.stringify(currentItem),planYear:this.planYear}})
        this.$router.push({path: "/report-addCopy", query: {current: JSON.stringify(currentItem),planYear:this.planYear,flag:"0"}})
      }
    },
    computed: {
    },
    created(){
      this.version=this.$route.query.version
      this.planYear=this.$route.query.planYear
      if(!this.$route.query.planYear){
        this.planYear=new Date().getFullYear()
      }
      this.projectId=this.$route.query.projectId
      let parmas={version:this.version,planYear:this.planYear,projectId:this.projectId}
      parmas._json=true
      this.loadTable(parmas)
    }
  }
</script>
<style>
  .wrap {
    padding: 15px;
    background: #ffffff;
    margin: 10px;
  }
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 15px;
    position: relative;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    bottom: 0px;
    right: 25px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .con-head{
    margin-bottom: 20px;
  }


  table {
    width:100%;
    border: 1px solid #ccc;
    border-collapse: collapse;
  }
  table thead{
    background: #fafafa;
  }
  thead th{
    text-align: left;
    background-color: #fafafa;
  }
  th,td {
    padding-left: 20px;
    border: 1px solid #e9eaec;
    line-height: 30px;
  }

  .bottom{
    margin-left: 10px;
    float: left;
    width: 0;
    height: 0;
    border-width: 10px;
    border-style: solid;
    border-color:rgb(24, 144, 255) transparent transparent transparent;
  }
  .top{
    width:0;
    height:0;
    border-right:10px solid transparent;
    border-left:10px solid transparent;
    border-bottom:10px solid rgb(24, 144, 255);
  }
  #myTable tr th,#myTable tr td{
    font-size: 12px;
    text-align: center;
    padding: 0 0 0 3px !important;

  }

  .k150 {
    width: 150px;
  }
  .k200 {
    width: 200px;
  }
</style>
