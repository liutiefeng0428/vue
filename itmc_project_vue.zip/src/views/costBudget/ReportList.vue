<template>
  <div class="wrap">
    <div class="con-head">
      <span>年度:</span>
      <a-select :value=optionDateSelect class="querySelect" @change="handleChangeDate" style="width: 120px">
        <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
      </a-select>
      <a-button type="primary" @click="doExM" icon="upload">导入</a-button>
      <a-button type="primary" @click="officeExport" icon="download">导出</a-button>
      <a-button type="primary" v-if="feePlanStatus == 1" @click="toAdd" icon="plus">添加</a-button>
      <a-button type="primary"  :class="disabledBtn?'ant-btn-primary-disable':''"  v-bind:disabled="disabledBtn"  @click="applyBudget">提交</a-button>
   </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>业务处室年度费用预算填报（{{status}}）</span>
      <span class="unitText">单位：万元</span>
    </div>
    <div>
      <table id="myTable" border="1" cellpadding="15" cellspacing="0">　　　
        <tr>
          <th class="k100" rowspan="2" style="width: 80px">开支类型</th>
          <th class="k100" rowspan="2">项目</th>
          <th class="k100" rowspan="2" style="width: 80px">项目明细</th>
          <th colspan="3" style="width: 250px">{{optionDateSelect}}年预算</th>　
          <th class="k100" rowspan="2">变化说明</th>         　
          <th style="width: 180px" class="" rowspan="2">内容及工作量</th>
          <th style="width: 180px" rowspan="2">费用测算</th>　　　 　　
          <th class="" style="width: 80px" rowspan="2">操作</th>
        </tr>
        <tr>　　　 　　
          <th class="k50">总部</th>　 　　
          <th class="k100" style="width: 100px">分摊金额</th>
          <th class="k50">合计</th>
        </tr>
        <tr v-for="(item,$index) in dataT">　　   　　　　
          <td
            v-if="key!='id'&&(key=='feeName'||key=='projectName'||key=='projectDetailsName'||key=='zbMoney'||key=='qyMoney'||key=='projectId'||key=='instructions'||key=='contentText'||key=='measureText')"
            v-for="(val,key) in item" :rowspan="rowSpanF(key,val)">
            <span :title="val" class="feeName" v-if="key=='feeName'">{{val}}</span>
            <span :title="val" class="projectName" v-if="key=='projectName'">{{val}}</span>
            <span :title="val" class="projectDetailsName" v-if="key=='projectDetailsName'">{{val}}</span>
            <span :title="val" class="zbMoney" v-if="key=='zbMoney'">{{val}}</span>
            <span :title="val" class="qyMoney" v-if="key=='qyMoney'">{{val}}</span>
            <span :title="item['zbMoney']+item['qyMoney']" class="projectId" v-if="key=='projectId'">{{item['zbMoney']+item['qyMoney']}}</span>
            <span :title="val" class="instructions" v-if="key=='instructions'">{{val}} </span>
            <span :title="val" class="contentText" v-if="key=='contentText'">{{val}}</span>
            <span :title="val" class="measureText" v-if="key=='measureText'">{{val}}</span>
          </td>
          <td>
            <div v-if="item.projectDetailsName!='小计:'&&item.projectDetailsName!='合计:'">
              <!--<span @click="toAdd(allItems[$index])"><a>添加</a></span>-->
              <span v-if="feePlanStatus == '1'" @click="toEdit(item)"><a>编辑</a></span>
              <span v-if="feePlanStatus != '1'" style="color: #888">编辑</span>
              <span>
                  <a-popconfirm
                    title="确定删除吗?"
                    okText="确定"
                    cancelText="取消"
                    @confirm="() => deletArr(item)">
                       <a  v-if="feePlanStatus == '1'" href="javascript:;">删除</a>
                  </a-popconfirm>
                  <span  v-if="feePlanStatus != '1'" style="color: #888">删除</span>
              </span>
            </div>
          </td>　　　　
        </tr>
      </table>
      <form action="/project/costBudget/exportTemplate" style="display: none" method="post" enctype="application/x-www-form-urlencoded">
        <input type="text" name="projectDetailList" id="projectDetailList">
        <input type="password" name="companyList" id="companyList">
        <input type="submit" value="提交" id="doSubmit">
      </form>
    </div>
    <a-modal
      title="导入年度费用预算"
      :width="600"
      centered
      v-model="expVisible"
      @ok="() => handleUpload()"
      @cancel="() => setVersionVisible(false)"
      okText="保存"
      cancelText="取消"
    >
      <div>
        <div class="clearfix">
          <a-upload
            :fileList="fileList"
            :remove="handleRemove"
            :beforeUpload="beforeUpload"
          >
            <a-button>
              <a-icon type="upload"/>
               上传
            </a-button>
          </a-upload>
        </div>
        <div style="margin-top: 10px;">
          <a @click="editEx">生成模板</a>
        </div>
      </div>
    </a-modal>
    <a-drawer
      title="操作"
      :width="700"
      @close="onClose"
      :visible="visible"
      :wrapStyle="{height: 'calc(100% - 108px)',overflow: 'auto',paddingBottom: '108px'}"
    >
        <div style="margin-bottom: 40px">
          <div>
            <div class="con-title">
              <span class="divdLine"></span>
              <span>请选择明细</span>
            </div>
            <a-tree
              checkable
              @expand="onExpand"
              :expandedKeys="expandedKeys"
              v-model="checkedKeys"
              @select="onSelect"
              :selectedKeys="selectedKeys"
              :treeData="treeData"
            />
          </div>
<!--          <div style="flex: 1">
            <div class="con-title">
              <span class="divdLine"></span>
              <span>请选择企业</span>
            </div>
            <a-tree
              checkable
              @expand="onExpandQy"
              v-model="checkedKeysQy"
              @select="onSelectQy"
              :selectedKeys="selectedKeysQy"
              :treeData="treeDataQy"
              :loadData="onLoadData"
            />
          </div> -->
        </div>
      <div
        :style="{
          position: 'absolute',
          left: 0,
          bottom: 0,
          width: '100%',
          borderTop: '1px solid #e9e9e9',
          padding: '10px 16px',
          background: '#fff',
          textAlign: 'right',
        }"
      >
        <a-button
          :style="{marginRight: '8px'}"
          @click="onClose"
        >
          取消
        </a-button>
        <a-button @click="downEdtpl" type="primary">下载</a-button>
      </div>
    </a-drawer>
  </div>
</template>
<script>

  import $ from 'jquery'
  import reqwest from 'reqwest'
  import {quillEditor} from "vue-quill-editor"; //调用编辑器
  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css';
  import {apiService} from "@/services/apiservice";

  export default {
    name: 'ReportList',
    data() {
      return {
        disabledBtn:false,
        projectDetailList:[],
        companyList:[],
        currentExpenditureType: {},
        optionDate: [],
        optionDateSelect: "",
        dataT: [],
        infoData: null,
        items: [],
        allItems: [],
        expVisible: false,
        fileList: [],
        files:null,
        visible:false,
        treeData:[],
        initTreeData:[],
        choiceDetails:[],
        thirdArr:[],
        selectedKeys: [],
        checkedKeys:[''],
        status:"未提交",
        feePlanStatus:"1",
        expandedKeys:[""],
        checkedKeysQy: [''],
        expandedKeysQy: [''],
        autoExpandParentQy: true,
        selectedKeysQy: [],
        choiceDetailsQy:[],
        checkMock:[],
        tabMock:[],
        infactTabMock:[],
        tabSameMock:[],
        trArr:[],
        dataOrg:[],
        treeDataQy:[],
      }
    },
    watch: {
      checkedKeys(val,info) {
        let mockQYArr=[]
        this.mockQY=mockQYArr
      },
      checkedKeysQy(val,info) {
      },
      treeDataQy(val){
      }
    },
    components: {
      quillEditor
    },
    computed: {
      editor() {
        return this.$refs.myQuillEditor.quill;
      },
    },
    created: function () {
      var date = new Date();
      var m = date.getMonth() + 1;
      if(m >= 8){
        this.optionDateSelect=(new Date().getFullYear())+1;
        console.log(this.optionDateSelect);
      }else{
        this.optionDateSelect=new Date().getFullYear();
      }
      this.loadDate()
      var params = {"planYear":this.optionDateSelect,"version":this.optionDateSelect}
      params._json = true
      this.loadTable(params)
      this.dataOrg=window.dataOrg
      this.treeDataQy.push(window.dataOrg[0])
    },
    methods: {
      onLoadData (treeNode) {
        let _self=this;
        return new Promise((resolve) => {
          if(treeNode.dataRef.children){
            if (treeNode.dataRef.children.length>0) {
               resolve()
               return
            }
          }
          var  nextNode = _self.getUnitByOrgId(treeNode.eventKey,window.dataOrg)
          setTimeout(() => {
            treeNode.dataRef.children = nextNode
            this.treeDataQy = [...this.treeDataQy]
            resolve()
          }, 1000)
        })
      },
      getUnitByOrgId(orgId,dataOrg){
        let  allObj=[]
        var dataOrg=dataOrg
        for (var i = 0; i < dataOrg.length; i++) {
          if (dataOrg[i].orgLevelName == '单位') {
            if (dataOrg[i].parentId == orgId) {
              dataOrg[i].title = dataOrg[i].orgName
              dataOrg[i].key = dataOrg[i].orgId
              allObj.push(dataOrg[i])
            }
          }
        }
        return allObj
      },
      initQyOther(){
        this.checkMock=this.dataOrg
        this.infactTabMock=[]
        this.tabMock=[]
        this.tabSameMock=[]
        this.checkMock=[]
        for(var j=0;j<this.checkedKeysQy.length;j++){
          for(var i=0;i<this.dataOrg.length;i++){
            if(this.dataOrg[i].orgId==this.checkedKeysQy[j]&&this.dataOrg[i].orgLevelName=='单位'){
              this.checkMock.push(this.dataOrg[i])
            }
          }
        }
        this.getChoiceObj(this.checkMock)
      },
      getChoiceObj(arr){
        this.tabSameMock=[]
        for(var j=0;j<arr.length;j++){
          for(var i=0;i<this.dataOrg.length;i++){
            if(arr[j].parentId==this.dataOrg[i].orgId){
              var obj={parentCode:this.dataOrg[i].orgCode,
                parentOrgName:this.dataOrg[i].orgName,
                orgName:arr[j].orgName,
                orgCode:arr[j].orgCode,
              }
              this.tabSameMock.push(obj)
            }
          }
        }
      },
      unique(arr, name) {
        var hash = {};
        return arr.reduce(function (item, next) {
          hash[next[name]] ? '' : hash[next[name]] = true && item.push(next);
          return item;
        }, []);
      },
      hasSameKey(){
        this.tabSameMock=[]
        for(var j=0;j<this.infactTabMock.length;j++){
          var curType=[]
          for(var i=0;i<this.checkMock.length;i++){
            if(this.infactTabMock[j].orgId==this.checkMock[i].parentId){
              curType.push(this.checkMock[i])
            }
          }
          this.tabSameMock.push(curType)
        }
      },
      getInfactTabMock(arr){
        this.infactTabMock=[]
        for(var i=0;i<arr.length;i++){
          for(var j=0;j<this.dataOrg.length;j++){
            if(this.dataOrg[j].orgId ==arr[i].parentId){
              this.infactTabMock.push(this.dataOrg[j])
              break
            }
          }
        }
      },
      onSelectQy (selectedKeys, info) {
        this.selectedKeysQy = selectedKeys
      },
      onExpandQy (expandedKeys) {
        this.expandedKeysQy = expandedKeys
        this.autoExpandParentQy = false
      },
      onCheckQy (checkedKeys) {
        this.checkedKeysQy = checkedKeys
      },
      onSelect (selectedKeys, info) {
        this.selectedKeys = selectedKeys
      },
      onCheck (checkedKeys) {
        this.checkedKeys = checkedKeys
      },
      onExpand (expandedKeys) {
        this.expandedKeys = expandedKeys
        this.autoExpandParent = false
      },
      getChoiceDetails(arr){
        this.choiceDetails=[]
        for(var i=0;i<arr.length;i++){
          for(var j=0;j<this.thirdArr.length;j++){
            if(this.thirdArr[j].code==arr[i]){
              this.choiceDetails.push(this.thirdArr[j])
            }
          }
        }
      },
      getChoiceDetailsQy(){
          this.choiceDetailsQy=[]
      },
      downEdtpl(){
        this.getChoiceDetails(this.checkedKeys)
        this.initQyOther()
        if(this.choiceDetails.length<=0){
          this.$message.warning("请选择明细")
          return
        }
//        if(this.tabSameMock.length<=0){
//          this.$message.warning("请选择企业")
//          return
//        }
        $("#projectDetailList").val(JSON.stringify(this.choiceDetails))
        $("#companyList").val(JSON.stringify(this.tabSameMock))
        $("#doSubmit").click()
      },
      handleRemove(file) {
        const index = this.fileList.indexOf(file);
        const newFileList = this.fileList.slice();
        newFileList.splice(index, 1);
        this.fileList = newFileList
      },
      beforeUpload(file) {
        this.handleRemove(this.files) //保证只能上传一个文件
        this.files=file
        this.fileList = [...this.fileList, file]
        return false;
      },
      handleUpload() {
        let version=""
        if(this.allItems.length>0){
          version=this.allItems[0].version
        }else{
          version=this.optionDateSelect
        }
        const { fileList } = this;
        const formData = new FormData();
        formData.append('file', this.files);
        formData.append('version', version);
        formData.append('feePlanStatus','1');
        formData.append('planYear',this.optionDateSelect);
        reqwest({
          url: '/project/costBudget/exportfile',
          method: 'post',
          processData: false,
          data: formData,
          success: () => {
            this.fileList = []
            this.$message.success('上传成功');
            this.expVisible=false
            var params = {"planYear":this.optionDateSelect,"version":this.optionDateSelect}
            params._json = true
            this.loadTable(params)
          },
          error: () => {
            this.$message.error('上传失败');
            this.expVisible=false
          },
        });
      },
      doExM(){
         this.expVisible=true
      },
      officeExport(){
          if(this.allItems.length<=0){
            this.$message.warning("未获取到处室信息，请稍后再试......")
            return
          }
          window.location.href='/project/costBudget/officeExport?ouId='+ this.allItems[0].ouId+"&version="+ this.allItems[0].version
      },
      editEx(){
        let _self=this
        this.visible=true
        let parmasData={}
        parmasData._json=true
        apiService.getItmcProjectTypeMenu(parmasData).then(r => {
        _self.initTreeData=r.list
        _self.treeData= _self.reverData(r.list)
        }, r => {
        }).catch(
        )
      },
      reverData(data){
        for (var j = 0; j < data.length; j++) {
          data[j].title = data[j].name
          data[j].key = data[j].code
          if (data[j].children.length > 0) {
            this.reverData(data[j].children)
          }else{
            this.thirdArr.push(data[j])
          }
        }
        return data
      },
      onClose() {
        this.visible = false
      },
      downEx(){
        let _self=this
        let parmasData={}
        parmasData._json=true
        apiService.exportTemplate(parmasData).then(r => {
          _self.$message.success("模板下载成功")
        }, r => {
        }).catch(
        )
      },
      setVersionVisible(){
        this.expVisible=false
      },
      applyBudget(){
        let _self = this
        if(_self.allItems.length<=0){
          this.$message.warning("未获取到处室、版本等相关信息，请稍后再试......")
          return
        }
        let parmasData = {
          "ouId": _self.allItems[0].ouId,
          "planYear": _self.optionDateSelect,
          "version": _self.allItems[0].version,
          "feePlanStatus":"2"
        }
        parmasData._json = true
        apiService.applyCostBudgetProject(parmasData).then(r => {
          if (r.result == '0000') {
            _self.$message.success("提交成功")
            var params = {planYear: _self.optionDateSelect,version:_self.optionDateSelect}
            params._json = true
            this.loadTable(params)
          }
        }, r => {
        }).catch(
        )
      },
      loadDate(){
        var _self = this
        var parmasData = "typeCode=JHND"
        apiService.getDictionary1(parmasData).then(r => {
          _self.optionDate = r
          // _self.optionDateSelect = _self.optionDate[0].optionCode
        }, r => {
        }).catch(
        )
      },
      loadTable(parmasData){
        let _self = this
        apiService.getCostBudgetOfficeList(parmasData).then(r => {
          if(r.length<=0){
            _self.status="未提交"
            _self.disabledBtn=false
          }
          _self.allItems = r
          if(_self.allItems.length<=0){
              return
          }
          if(_self.allItems[0].feePlanStatus=='1'){
            _self.status="未提交"
            _self.disabledBtn=false
          }else if(_self.allItems[0].feePlanStatus>1){
            _self.status="已提交"
            _self.disabledBtn=true
          }
          _self.feePlanStatus=_self.allItems[0].feePlanStatus
          var curItems = r

          _self.items = [];
          for (var i = 0; i < curItems.length; i++) {
            var obj = {
              "id": curItems[i].id,
              "feeName": curItems[i].feeName,
              "projectName": curItems[i].projectName,
              "projectDetailsName": curItems[i].projectDetailsName,
              "zbMoney": curItems[i].zbMoney,
              "qyMoney": curItems[i].qyMoney,
              "projectId": curItems[i].projectId,
              "instructions": curItems[i].instructions,
              "contentText": curItems[i].contentText,
              "measureText": curItems[i].measureText
            }
            if (curItems[i].projectDetailsName == '合计:') {
              obj.projectName = curItems[i - 1].projectName
            }
            _self.items.push(obj)
          }
          _self.initData()
        }, r => {
        }).catch(
        )
      },
      toAdd(item){
        let version=''
        let ouId=""
        if(this.allItems.length>0){
          version=this.allItems[0].version
          ouId=this.allItems[0].ouId
        }

        this.$router.push({path: "/report-add", query: {ouId:ouId,version:version,planYear:this.optionDateSelect,feePlanStatus:this.feePlanStatus}})
      },
      deletArr(item){
        let _self = this
        let parmasData = {id: item.id}
        parmasData._json = true
        apiService.deleteCostBudgetProjectDetails(parmasData).then(r => {
          _self.$message.success("删除成功")
          var params = {"planYear":_self.optionDateSelect,"version":_self.optionDateSelect}
          params._json = true
          _self.loadTable(params)
        }, r => {
        }).catch(
        )
      },
      toEdit(item){
        this.$router.push({path: "/report-edit", query: {currentId: item.id,planYear:this.optionDateSelect}})
      },
      initData(){
        const that = this;
        let arry = [];
        let itemsCopy = JSON.parse(JSON.stringify(that.items));
        for (let i = 0; i < itemsCopy.length; i++) {
          for (let j = (i + 1); j < itemsCopy.length; j++) {
            for (let h in itemsCopy[i]) {
              for (let k in itemsCopy[j]) {
                if (k == 'feeName' || k == 'projectName' || k == 'projectDetailsName') {
                  if (itemsCopy[j][k] != '小计:' && itemsCopy[j][k] != '合计:') {
                    if (h === k && itemsCopy[i][h] === itemsCopy[j][k]) {
                      delete  itemsCopy[j][k]
                    }
                  }
                }
              }
            }
          }
          arry.push(itemsCopy[i]);
        }
        that.dataT = arry;
      },
      rowSpanF: function (key, val) {
        const that = this;
        let num = 0;
        for (let i in that.items) {
          for (let j in that.items[i]) {
            if (j == 'feeName' || j == 'projectName' || j == 'projectDetailsName') {
              if (key === j && val === that.items[i][j]) {
                if (that.items[i][j] == '小计:' || that.items[i][j] == '合计:') {
                  return
                }
                num++;
              }
            }
          }
        }

        if(num==0){
            return 1
        }
        return num;
      },
      handleChangeDate(value){
        this.optionDateSelect = value
        this.dataT=[]
        var params = {planYear: this.optionDateSelect,version:this.optionDateSelect}
        params._json = true
        this.loadTable(params)
      },
    }
  }


</script>
<style>
 /* .wrap {
    margin: 10px;
    border-left: 1px solid rgb(232, 232, 232);
    padding: 20px;
    background: #fff;
    box-shadow: 0 1px 6px rgba(0,0,0,.2);
  }*/

  #myTable {
    width: 100%;
    background: #fff;
    text-align: center;
    border-top: 1px solid #e8e8e8;
    border-left: 1px solid #e8e8e8;
    margin-bottom: 40px;
    table-layout: fixed;
  }

  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 20px;
    position: relative;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    top:5px;
    right: 10px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    /*background: rgb(16, 110, 190);;*/
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  #myTable tr td, #myTable tr th {
    border-bottom: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
    color: rgba(0, 0, 0, 0.65);
    padding: 3px 10px;
    font-size: 12px;
  }

  #myTable tr th {
    background: #F6F5F4;
  }

  .k50 {
    width: 50px;
  }

  .k80 {
    width: 80px;
  }

  .k100 {
    width: 100px;
  }

  .k120 {
    width: 120px;
  }

  .con-head {
    margin-bottom: 20px;
  }

  .flexL {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding-right: 15px;
  }

  .flexR {
    flex: 2;
  }

  .modeInputBox {
    margin-top: 20px;
  }
 .ant-btn-primary-disable{
   background-color: rgb(131, 180, 234)!important;
 }
 #myTable td {
  text-overflow: ellipsis;
  overflow: hidden;
  white-space: nowrap;
 }
</style>
