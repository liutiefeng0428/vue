<template>
  <div class="wrap">
    <div class="con-head">
      <span>年度:</span>

      <a-select  :value=planYear class="querySelect" @change="handleChangeDate" style="width: 120px">
        <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
      </a-select>
      <a-button v-if="feePlanStatus!='5'" type="primary" @click="doExM" icon="upload">导入</a-button>
      <a-button style="margin-bottom: 20px" @click="handleAddDetail" type="primary" icon="plus">添加三级项目类型</a-button>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>编辑年度费用预算</span>
    </div>
    <div class="container" style="padding: 0">
      <div>
        <div class="ant-table-content">
          <div class="ant-table-tbody">
            <table style="width: 100%">
              <thead class="ant-table-thead">
                <tr>
                  <th key="version" class="ant-table-align-left" style="text-align: left;">
                    <div>版本号</div>
                  </th>
                  <th key="optionName" class="ant-table-align-left" style="text-align: left;">
                    <div>时间</div>
                  </th>
                  <th key="content" class="ant-table-align-left" style="text-align: left;">
                    <div>说明</div>
                  </th>
                  <th key="typeCode" class="ant-table-align-left" style="text-align: left;">
                    <div>状态</div>
                  </th>
                  <th key="action" class="ant-table-align-left" style="text-align: left;">
                    <div>操作</div>
                  </th>
                </tr>
              </thead>
              <tbody class="ant-table-tbody">
                <tr v-for="(item,index) in infoData">
                  <td><a @click="toQuVersion(item.version)">{{item.versionName}}</a></td>
                  <td>{{item.createDate|formatDateTime}}</td>
                  <td>{{item.content}}</td>
                  <td>
                    {{item.feePlanName}}
                    <!-- <span v-if="item.feePlanStatus=='0'">未发布</span>
                    <span v-if="item.feePlanStatus=='1'">已发布</span> -->
                  </td>
                  <td><a  @click="officeExport(item.version)">导出</a>
                    <a-popconfirm
                      title="确定删除吗?"
                      okText="确定"
                      cancelText="取消"
                      @confirm="() => deleteVersion(item)">
                      <a v-if="item.feePlanStatus!='5'" href="javascript:;">删除</a>
                    </a-popconfirm>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <form action="/project/costBudget/exportTemplate" style="display: none" method="post" enctype="application/x-www-form-urlencoded">
        <input type="text" name="projectDetailList" id="projectDetailList">
        <input type="password" name="companyList" id="companyList">
        <input type="text" name="planYear" id="planYear">
        <input type="submit" value="提交" id="doSubmit">
      </form>
    </div>
    <a-modal
      title="导入"
      :width="600"
      centered
      v-model="expVisible"
      @ok="() => handleUpload()"
      @cancel="() => setVersionVisible(false)"
      okText="保存"
      cancelText="取消"
    >
      <div>
        <div style="display: flex;margin-bottom: 20px">
          <span style="flex:2;text-align: right;margin-right: 10px">版本名称:</span>
          <a-input style="flex: 8" size="small" v-model="versionNameModal"/>
        </div>
        <div style="display: flex">
          <span style="flex: 2;text-align: right;margin-right: 10px">版本说明:</span>
          <a-textarea style="flex: 8" v-model="versionContentModal" :rows="4"/>
        </div>
        <div style="display: flex;margin-top: 15px">
          <span style="flex: 2;text-align: right;margin-right: 10px">请选择文件:</span>
          <div style="flex: 8">
          <a-upload
            :fileList="fileList"
            :remove="handleRemove"
            :beforeUpload="beforeUpload"
          >
            <a-button>
              <a-icon type="upload"/>
              上传
           </a-button>
          </a-upload>
        </div>
        </div>
        <div style="margin-top: 10px;display: flex">
          <span style="flex: 2;text-align: right;margin-right: 10px"></span>
          <div style="flex: 8">
            <a @click="downloadFile">生成模板</a>
          </div>
        </div>
      </div>
    </a-modal>
    <!--新增项目明细-->
    <a-modal
      title="添加项目明细"
      :width="600"
      centered
      v-model="modalVisibleDetail"
      @ok="() => addBudgetSource()"
      @cancel="() => setModalDetailVisible(false)"
      okText="确认"
      cancelText="关闭">
      <div>
        <div class="ant-spin-container">
          <form class="ant-form ant-form-horizontal">
            <div class="ant-row ant-form-item">
              <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                <label for="projectType" title="开支类型" class="">开支类型</label>
              </div>
              <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                <div class="ant-form-item-control has-success">
                  <span class="ant-form-item-children">
                    <a-select :value=projectTypeSel  class="querySelect" @change="handleChangeType" style="width:100%">
                      <a-select-option v-for="item in projectType" :key="item.code"> {{item.name}}</a-select-option>
                    </a-select>
                  </span>
                </div>
              </div>
            </div>
            <div class="ant-row ant-form-item">
              <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                <label for="projectName" title="项目" class="">项目</label>
              </div>
              <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                <div class="ant-form-item-control has-success">
                    <span class="ant-form-item-children">
                      <a-select :value=projectNameSel @change="handleChangeProName" class="querySelect" style="width:100%">
                        <a-select-option v-for="item in projectName" :key="item.code"> {{item.name}}</a-select-option>
                      </a-select>
                    </span>
                </div>
              </div>
            </div>
            <div class="ant-row ant-form-item">
              <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                <label for="ProjectDetailType" title="项目明细" class="">项目明细</label>
              </div>
              <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                <div class="ant-form-item-control">
                    <span class="ant-form-item-children">
                      <input type="text"  id="" class="ant-input" v-model="ProjectDetailType">
                    </span>
                </div>
              </div>
            </div>
            <div class="ant-row ant-form-item">
              <div class="ant-col-xs-24 ant-col-sm-5 ant-form-item-label">
                <label for="budgetSource" title="预算来源" class="">预算来源</label>
              </div>
              <div class="ant-col-xs-24 ant-col-sm-16 ant-form-item-control-wrapper">
                <div class="ant-form-item-control">
                    <span class="ant-form-item-children">
                      <a-select :value=budgetSourceSel @change="handleChangebudgetSource" class="querySelect" style="width:100%">
                        <a-select-option v-for="item in budgetSource" :key="item.code"> {{item.name}}</a-select-option>
                      </a-select>
                    </span>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </a-modal>
    <a-drawer
      title="操作"
      :width="700"
      @close="onClose"
      :visible="visible"
      :wrapStyle="{height: 'calc(100% - 108px)',overflow: 'auto',paddingBottom: '108px'}"
    >
        <div style="margin-bottom: 40px">
          <div>
            <div class="con-title">
              <span class="divdLine"></span>
              <span>请选择明细</span>
            </div>
            <a-tree
              checkable
              @expand="onExpand"
              :expandedKeys="expandedKeys"
              v-model="checkedKeys"
              @select="onSelect"
              :selectedKeys="selectedKeys"
              :treeData="treeData"
            />
          </div>
<!--          <div style="flex: 1">
            <div class="con-title">
              <span class="divdLine"></span>
              <span>请选择企业</span>
            </div>
            <a-tree
              checkable
              @expand="onExpandQy"
              v-model="checkedKeysQy"
              @select="onSelectQy"
              :selectedKeys="selectedKeysQy"
              :treeData="treeDataQy"
              :loadData="onLoadData"
            />
          </div>-->
        </div>
      <div
        :style="{
          position: 'absolute',
          left: 0,
          bottom: 0,
          width: '100%',
          borderTop: '1px solid #e9e9e9',
          padding: '10px 16px',
          background: '#fff',
          textAlign: 'right',
        }"
      >
        <a-button
          :style="{marginRight: '8px'}"
          @click="onClose"
        >
          取消
        </a-button>
        <a-button @click="downEdtpl" type="primary">下载</a-button>
      </div>
    </a-drawer>
  </div>
</template>

<script>
  import $ from 'jquery'
  import {apiService} from "@/services/apiservice";
  import {quillEditor} from "vue-quill-editor"; //调用编辑器
  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css';
  import reqwest from 'reqwest'
  export default {
    name: "Quotas",
    components: {
    },
    data() {
      return {
        optionDate:[],
        planYear:"",
        feePlanStatus:"",
        infoData: null,
        expVisible:false,
        modalVisibleDetail:false,
        visible:false,
        fileList: [],
        files:null,
        versionNameModal:"",
        versionContentModal:"",
        thirdArr:[],
        expandedKeys:[""],
        checkedKeys:[''],
        selectedKeys: [],
        selectedKeysQy: [],
        treeData:[],
        treeDataQy:[],
        checkedKeysQy: [''],
        projectType:[],//开支类型
        projectTypeSel:"",
        projectTypeSelText:"",
        projectName:[],//项目名称
        projectNameSel:"",
        projectNameSelText:"",
        ProjectDetailType:"",//选择项目明细
      }
    },
    methods: {
      onLoadData (treeNode) {
        let _self=this;
        return new Promise((resolve) => {
          if(treeNode.dataRef.children){
            if (treeNode.dataRef.children.length>0) {
               resolve()
               return
            }
          }
          var  nextNode = _self.getUnitByOrgId(treeNode.eventKey,window.dataOrg)
          setTimeout(() => {
            treeNode.dataRef.children = nextNode
            this.treeDataQy = [...this.treeDataQy]
            resolve()
          }, 1000)
        })
      },
      getUnitByOrgId(orgId,dataOrg){
        let  allObj=[]
        var dataOrg=dataOrg
        for (var i = 0; i < dataOrg.length; i++) {
          if (dataOrg[i].orgLevelName == '单位') {
            if (dataOrg[i].parentId == orgId) {
              dataOrg[i].title = dataOrg[i].orgName
              dataOrg[i].key = dataOrg[i].orgId
              allObj.push(dataOrg[i])
            }
          }
        }
        return allObj
      },
      downloadFile(){
        let _self=this
        this.visible=true
        let parmasData={}
        parmasData._json=true
        apiService.getItmcProjectTypeMenu(parmasData).then(r => {
        _self.initTreeData=r.list
        _self.treeData= _self.reverData(r.list)
        }, r => {
        }).catch(
        )
      //  window.location.href='/project/itmcAut/downloadFile?planYear='+_self.optionDateSelect+"&flagExport=1"
      },
      initQyOther(){
        this.checkMock=this.dataOrg
        this.infactTabMock=[]
        this.tabMock=[]
        this.tabSameMock=[]
        this.checkMock=[]
        for(var j=0;j<this.checkedKeysQy.length;j++){
          for(var i=0;i<this.dataOrg.length;i++){
            if(this.dataOrg[i].orgId==this.checkedKeysQy[j]&&this.dataOrg[i].orgLevelName=='单位'){
              this.checkMock.push(this.dataOrg[i])
            }
          }
        }
        this.getChoiceObj(this.checkMock)
      },
      getChoiceObj(arr){
        this.tabSameMock=[]
        for(var j=0;j<arr.length;j++){
          for(var i=0;i<this.dataOrg.length;i++){
            if(arr[j].parentId==this.dataOrg[i].orgId){
              var obj={parentCode:this.dataOrg[i].orgCode,
                parentOrgName:this.dataOrg[i].orgName,
                orgName:arr[j].orgName,
                orgCode:arr[j].orgCode,
              }
              this.tabSameMock.push(obj)
            }
          }
        }
      },
      downEdtpl(){
        this.getChoiceDetails(this.checkedKeys)
        // this.initQyOther()
        if(this.choiceDetails.length<=0){
          this.$message.warning("请选择明细")
          return
        }
        // if(this.tabSameMock.length<=0){
        //   this.$message.warning("请选择企业")
        //   return
        // }
        $("#projectDetailList").val(JSON.stringify(this.choiceDetails))
        $("#companyList").val(JSON.stringify(this.tabSameMock))
        $("#planYear").val(JSON.stringify(this.planYear))
        $("#doSubmit").click()
      },
      reverData(data){
        for (var j = 0; j < data.length; j++) {
          data[j].title = data[j].name
          data[j].key = data[j].code
          if (data[j].children.length > 0) {
            this.reverData(data[j].children)
          }else{
            this.thirdArr.push(data[j])
          }
        }
        return data
      },
      onClose() {
        this.visible = false
      },
      onSelectQy (selectedKeys, info) {
        this.selectedKeysQy = selectedKeys
      },
      onExpandQy (expandedKeys) {
        this.expandedKeysQy = expandedKeys
        this.autoExpandParentQy = false
      },
      onCheckQy (checkedKeys) {
        this.checkedKeysQy = checkedKeys
      },
      onSelect (selectedKeys, info) {
        this.selectedKeys = selectedKeys
      },
      onExpand (expandedKeys) {
        this.expandedKeys = expandedKeys
        this.autoExpandParent = false
      },
      getChoiceDetails(arr){
        this.choiceDetails=[]
        for(var i=0;i<arr.length;i++){
          for(var j=0;j<this.thirdArr.length;j++){
            if(this.thirdArr[j].code==arr[i]){
              this.choiceDetails.push(this.thirdArr[j])
            }
          }
        }
      },
      officeExport(version){
          window.location.href='/project/costBudget/officeExport?version=' + version+"&planYear="+this.planYear;
      },
      deleteVersion(item){
        let _self = this
        let parmasData = {version: item.version,planYear:item.planYear}
        // parmasData._json = true
        apiService.deleteCostBudgetVersion(parmasData).then(r => {
          if (r.result == '0000') {
            _self.$message.success("删除成功")
             var params = {"planYear":item.planYear}
            _self.loadTable(params)
          }else{
            _self.$message.error("删除失败");
          }
        }, r => {
        }).catch(
        )
      },
      setVersionVisible(){
        this.expVisible=false
      },
      handleRemove(file) {
        const index = this.fileList.indexOf(file);
        const newFileList = this.fileList.slice();
        newFileList.splice(index, 1);
        this.fileList = newFileList
      },
      beforeUpload(file) {
        this.handleRemove(this.files) //保证只能上传一个文件
        this.files=file
        this.fileList = [...this.fileList, file]
        return false;
      },
      handleUpload() {
        const { fileList } = this;
        const formData = new FormData();
        formData.append('file', this.files);
        formData.append('versionName', this.versionNameModal);
        formData.append('instructions', this.versionContentModal);
        formData.append('planYear', this.planYear);

        let feePlanStatus='3'
        // if(this.infoData.length>0){
        // this.feePlanStatus=this.infoData[0].feePlanStatus
        // }
        formData.append('feePlanStatus',feePlanStatus);
        this.uploading = true
        reqwest({
          url: '/project/costBudget/exportfile',
          method: 'post',
          processData: false,
          data: formData,
          success: (r) => {
            if(r.result=='0000'){
              this.fileList = []
              this.expVisible = false
              this.$message.success('导入成功');
              var params = {"planYear":this.planYear}
              params._json = true
              this.loadTable(params)
            }else{
              this.$message.error('导入失败');
              if(r.msg!=''){
                this.$message.error(r.msg);
              }
            }

          },
          error: () => {
            this.uploading = false
            this.$message.error('导入失败');
          },
        });
      },
      doExM(){
        this.expVisible=true
      },
      loadDate(){
        var _self=this
        var parmasData="typeCode=JHND"
        apiService.getDictionary1(parmasData).then(r => {
          _self.optionDate=r
          // _self.planYear=_self.optionDate[0].optionCode
          let parmas={planYear:_self.planYear}
          parmas._json=true
          _self.loadTable(parmas)
        }, r => {
        }).catch(
        )
      },
      judgeCostVersionLists(){
        var _self=this
        let parmasData={planYear:_self.planYear,feePlanStatus: "5"}
        apiService.judgeCostVersionLists(parmasData).then(r => {
          _self.feePlanStatus=r.feePlanStatus;
        }, r => {
        }).catch(
        )
      },
      handleChangeDate(value){
        this.planYear=value
        let parmasData={planYear:value}
        parmasData._json=true
        this.loadTable(parmasData)
        this.judgeCostVersionLists();
      },
      handleAddDetail(){
        this.modalVisibleDetail = true;
      },
      setModalDetailVisible(){
        this.modalVisibleDetail=false
      },
      addBudgetSource(){
        let _self = this
        _self.modalVisibleDetail = false
        let parmasData={parentCode:_self.projectNameSel,name:_self.ProjectDetailType,budgetSource:_self.budgetSourceSel}
        parmasData._json=true
        apiService.saveItmcProjectDetailType(parmasData).then(r => {
          _self.$message.success("添加成功")
        }, r => {
          // _self.$message.success("添加成功")
        }).catch(
        )
      },
      getItmcProjectTypeList(parmasData){
        let _self=this
        apiService.getItmcProjectTypeList(parmasData).then(r => {
          _self.projectType=r
          if(r.length>0){
            _self.projectTypeSel=r[0].code

            var obj= _self.projectType.find(function (obj) {
              return obj.code === _self.projectTypeSel
            })
            _self.projectTypeSelText=obj.name
            let projectNameParmas={"parentCode": _self.projectTypeSel, version: _self.version}
            projectNameParmas._json=true
            apiService.getItmcProjectTypeList(projectNameParmas).then(r1 => {
              _self.projectName=r1
              if(r1.length>0){
                _self.projectNameSel=r1[0].code
                var obj=_self.projectName.find(function (obj) {
                  return obj.code === _self.projectNameSel
                })
                _self.projectNameSelText=obj.name
              }

            }, r => {
            }).catch(
            )
          }
        }, r => {
        }).catch(
        )
      },
      handleChangeType(value){
        var obj=this.projectType.find(function (obj) {
          return obj.code === value
        })
        let _self=this
        _self.projectName=[]
        if(!value){
          this.$message.warning("请先选择开支类型")
        }
        this.projectTypeSel=value
        this.projectTypeSelText=obj.name
        let projectTypeParmas={"parentCode":value, "version":this.version}
        projectTypeParmas._json=true
        apiService.getItmcProjectTypeList(projectTypeParmas).then(r => {
          _self.projectName=r
          _self.projectNameSel=r[0].code

        }, r => {
        }).catch(
        )
      },

      handleChangeProName(value){
        var obj=this.projectName.find(function (obj) {
          return obj.code === value
        })
        this.projectNameSel=value
        this.projectNameSelText=obj.name
      },
      loadTable(parmasData){
        let _self = this
        //主页table数据
        apiService.getCostVersionList(parmasData).then(r => {
          _self.infoData = r
        }, r => {
        }).catch(
        )
      },
      toQuVersion(version){
        localStorage.setItem("version",version);
        this.$router.push({path: "/quotas-ve", query: {planYear:this.planYear ,version:version}})
      },
    },
    computed: {

    },
    filters:{
      formatDateTime (inputTime) {
        var date = new Date(inputTime);
        var y = date.getFullYear();
        var m = date.getMonth() + 1;
        m = m < 10 ? ('0' + m) : m;
        var d = date.getDate();
        d = d < 10 ? ('0' + d) : d;
        var h = date.getHours();
        h = h < 10 ? ('0' + h) : h;
        var minute = date.getMinutes();
        var second = date.getSeconds();
        minute = minute < 10 ? ('0' + minute) : minute;
        second = second < 10 ? ('0' + second) : second;
        return y + '-' + m + '-' + d + ' ' + '　' + h + ':' + minute + ':' + second;
      }
    },
    created(){
      var date = new Date();
      var m = date.getMonth() + 1;
      if(m >= 8){
        this.planYear=(new Date().getFullYear())+1;
      }else{
        this.planYear=new Date().getFullYear();
      }
      this.loadDate()
      this.judgeCostVersionLists();
      var params = {"planYear":this.planYear}
      params._json = true
      this.loadTable(params)
      let projectTypeParmas={"parentCode":'0'}
      projectTypeParmas._json=true
      this.getItmcProjectTypeList(projectTypeParmas)
      this.dataOrg=window.dataOrg
      this.treeDataQy.push(window.dataOrg[0])
    }
  }
</script>
<style>
  .wrap {
    padding: 15px;
    background: #ffffff;
    margin: 10px;
  }
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 15px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .con-head{
    margin-bottom: 20px;
  }
  .ant-table-tbody table{
    border-top: 1px solid #e8e8e8;
    border-left: 1px solid #e8e8e8;
  }
  .ant-table-tbody > tr > td{
    border-bottom: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
    -webkit-transition: all 0.3s, border 0s;
    transition: all 0.3s, border 0s;
  }
  .ant-table-thead > tr > th{
    border-right: 1px solid #e8e8e8;
  }
  .ant-table-thead > tr > th, .ant-table-tbody > tr > td{
    text-align: center;
    font-size: 12px;
  }
  .ant-table-thead>tr>th div{
    text-align: center;
  }
</style>
