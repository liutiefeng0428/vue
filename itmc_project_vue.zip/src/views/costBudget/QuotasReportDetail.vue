<template>
  <div class="wrap">
    <div class="con-title">
      <span class="divdLine"></span>
      <span>卫星、专线租赁费用预算明细</span>
      <a-button @click="doAdd()" type="primary" style="margin-left:20px;position: relative;top:-5px">添加</a-button>
      <a-button @click="backReport()" type="primary" style="margin-left:20px;position: relative;top:-5px">返回</a-button>
    </div>
    <div class="container">
      <div>
        <div>
          <div class="ant-table">
            <table>
              <thead class="ant-table-thead">
                <tr>
                  <th key="optionName" rowspan="2" class=""><div>项目明细</div></th>
                  <th key="typeCode" rowspan="2" class=""><div>2019年预计完成</div></th>
                  <th key="1" colspan="4" class=""><div><span slot="title" style="color: rgb(24, 144, 255);">2020年</span></div></th>
                  <th key="typeCode" rowspan="2" class=""><div><span slot="title" style="color: rgb(24, 144, 255);">费用变化</span></div></th>
                  <th key="typeCode" rowspan="2" class=""><div>变化说明</div></th>
                  <th key="typeCode" rowspan="2" class=""><div>内容及工作量</div></th>
                  <th key="typeCode" rowspan="2" class=""><div>费用测算</div></th>
                  <th key="typeCode" rowspan="2" class="" style="width: 95px"><div>操作</div></th>
                </tr>
                <tr>
                  <th><div>总部</div></th>
                  <th><div>分摊</div></th>
                  <th><div>预算</div></th>
                  <th><div>优化预算</div></th>
                </tr>
              </thead>
              <tbody class="ant-table-tbody">
                <tr v-for="(item,index) in infoData" :key="item.id" class="ant-table-row ant-table-row-level-0" data-row-key="0">
                  <td>
                    {{item.optionName}}
                  </td>
                  <td class="">{{item.typeCode}}</td>
                  <td class="">{{item.typeCode}}</td>
                  <td class="">{{item.typeCode}}</td>
                  <td class="">{{item.typeCode}}</td>
                  <td class="">{{item.typeCode}}</td>
                  <td class="">{{item.typeCode}}</td>
                  <td class="">{{item.typeCode}}</td>
                  <td class="">{{item.typeCode}}</td>
                  <td class="">{{item.typeCode}}</td>
                  <td class="">
                    <span @click="handleEdit(item)"><a>编辑</a></span>
                    <a-popconfirm
                      title="确定删除吗?"
                      okText="确定"
                      cancelText="取消"
                      @confirm="() => doDelete(item)">
                      <a href="javascript:;">删除</a>
                    </a-popconfirm>
                  </td>
                </tr>
                <!--合计-->
                <tr class="ant-table-row ant-table-row-level-0" data-row-key="0">
                  <td class="">
                   合计
                  </td>
                  <td class="">70000</td>
                  <td class="">70000</td>
                  <td class="">70000</td>
                  <td class="">70000</td>
                  <td class="">70000</td>
                  <td class="">70000</td>
                  <td class="">70000</td>
                  <td class="">70000</td>
                  <td class=""></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "QuotasReportDetail",
    components: {
    },
    data() {
      return {
        optionDate:[],
        infoData: null,
      }
    },
    methods: {
      handleChangeDate(value){
        console.log(value);
        console.log(this.optionDateSelect);
      },
      loadTable(parmasData){
        let _self = this
        //主页table数据
        apiService.getDictionaryFList(parmasData).then(r => {
          _self.infoData = r
        }, r => {
        }).catch(
        )
      },
      handleEdit(recode){
          console.log(recode)
         this.$router.push({path:'/quotas-edit',query:{id:recode.id}})
      },
      backReport(){
        this.$router.push({path:'/quotas-rp'})
      },
      doAdd(){
//        let id=$route.query.id
        this.$router.push({
          path:'/quotas-add'
//          ,query:{id:id}
        })
      },
      doDelete(recode){
//        this.infoData.splice()
      }
    },
    computed: {

    },
    created(){
      this.infoData=[
        {
          "id": 67,
          "optionName": "(复核意见/复核驳回)常用语",
          "status": 0,
          "note": "ff",
          "sort": null,
          "typeCode": "FHYJBH",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 68,
          "optionName": "(复核意见/复核同意)常用语",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "FHYJTY",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 69,
          "optionName": "付款单位(中国石化集团资产经营管理有限公司)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "FKDW",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 70,
          "optionName": "付款单位(中国石油化工股份有限公司总部机关财务处)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "FKDW",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 71,
          "optionName": "付款单位(中国石油化工集团有限公司)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "FKDW",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 72,
          "optionName": "付款单位(总部石油化工股份有限公司总部)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "FKDW",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 73,
          "optionName": "反馈",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "FKYJ",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 74,
          "optionName": "公司性质",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "GSXZ",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 75,
          "optionName": "费用合同类型",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "HTLXFY",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 76,
          "optionName": "项目合同类型",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "HTLXXM",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 77,
          "optionName": "甲方",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "JF",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 78,
          "optionName": "计划类型",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "JHLX",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 79,
          "optionName": "下拉框年份",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "JHND",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 80,
          "optionName": "建设性质",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "JSFL",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 81,
          "optionName": "建设意见",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "JSXZ",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 82,
          "optionName": "查询合同付款明细-付款单位",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "PayerName",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 83,
          "optionName": "软件",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "PFZLYS",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 84,
          "optionName": "硬件",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "PFZLYS",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 85,
          "optionName": "省份",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "PROVINC",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 86,
          "optionName": "省份",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "PROVINCE",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 87,
          "optionName": "税码",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "SMD",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 88,
          "optionName": "（项目/系统）所属平台",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "SSPT",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 89,
          "optionName": "资金使用类型",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "SYLX",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 90,
          "optionName": "项目分类",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "XMFL",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 91,
          "optionName": "业务部门(项目批复金额表)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "YWBM",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 92,
          "optionName": "业务种类(可研批复项目上传文件类型)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "YWZL",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 93,
          "optionName": "资金类型(项目批复金额表)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "ZJLX",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        }
      ]
      this.optionDate=[
        {
          "id": 399,
          "optionName": "2019",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 1,
          "typeCode": "JHNDS",
          "optionCode": "2019",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 400,
          "optionName": "2020",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 2,
          "typeCode": "JHNDS",
          "optionCode": "2020",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 401,
          "optionName": "2021",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 3,
          "typeCode": "JHNDS",
          "optionCode": "2021",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        }
      ]
//      let parmas={}
//      this.loadTable(parmas)
    }
  }
</script>
<style>
  .wrap {
    padding: 15px;
    background: #ffffff;
    margin: 10px;
  }
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #333333;
    display: flex;
    margin-bottom: 15px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: rgb(24, 144, 255);
    height: 20px;
    margin-right: 10px;
  }

  .con-head{
    margin-bottom: 20px;
  }
</style>
