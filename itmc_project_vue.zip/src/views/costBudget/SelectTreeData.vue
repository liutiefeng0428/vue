<template>
  <div>
    <a-tree
      :loadData="onLoadData"
      checkable
      @expand="onExpand"
      :expandedKeys="expandedKeys"
      :autoExpandParent="autoExpandParent"
      v-model="checkedKeys"
      @select="onSelect"
      :selectedKeys="selectedKeys"
      :treeData="treeData"
    />
  </div>
</template>
<script>
  import {apiService} from "@/services/apiservice";
  import Vue from 'vue';
  export default {
    name: "SelectTreeData",
    data() {
      return {
        autoExpandParent: true,
        checkedKeys: [''],//企业名称选择的数组
        selectedKeys: [],
      }
    },
    props: ['onLoadData', 'expandedKeys', 'treeData'],
    computed: {
    },
    methods: {
      onExpand (expandedKeys) {
        this.expandedKeys = expandedKeys
        this.autoExpandParent = false
      },
      onCheck (checkedKeys) {
        this.checkedKeys = checkedKeys
      },
      onSelect (selectedKeys, info) {
        this.selectedKeys = selectedKeys
      },selectedKeys
    },
    watch: {
      checkedKeys(val,info) {
        let mockQYArr=[]
        for(var i=0;i<val.length;i++){
          let obj={}
          obj.name=val[i]
          obj.id=val[i]
          mockQYArr.push(obj)
        }
        this.mockQY=mockQYArr
      },
    },
    created(){
      // this.modalVisible = this.modalVisibleDetail;
      // let projectTypeParmas={"parentCode":'0'}
      // projectTypeParmas._json=true
      // this.getItmcProjectTypeList(projectTypeParmas)
    }
  }
</script>