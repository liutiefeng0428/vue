<template>
  <div>
        <a-tabs v-model="activeKey" @change="callback">
          <a-tab-pane v-for="(item,index) in infactTabMock"  :tab="item.tabName"  :key="item.tabCode">
            <!--<div class="ant-table-content">&lt;!&ndash;&ndash;&gt;-->
              <!--<div class="ant-table-body">-->
                <!--<table class="" style="width: 100%"><colgroup><col style="width: 120px; min-width: 120px;"><col><col></colgroup>-->
                  <!--<thead class="ant-table-thead">-->
                  <!--<tr>-->
                    <!--<th key="rowIndex" class="ant-table-align-center" style="text-align: center;"><div>#</div></th>-->
                    <!--<th key="fullName" class="ant-table-align-left" style="text-align: left;"><div>企业名称</div></th>-->
                    <!--<th key="typeCode" class="ant-table-align-left" style="text-align: left;"><div>金额</div></th></tr>-->
                  <!--</thead>-->
                  <!--<tbody class="ant-table-tbody">-->
                    <!--<tr v-for="(itemInner,indexInner) in tabSameMock[index]">-->
                      <!--<td style="text-align: center;"><span class="ant-table-row-indent indent-level-0" style="padding-left: 0px;"></span>{{indexInner+1}}</td>-->
                      <!--<td style="text-align: left;">{{itemInner.orgName}}</td>-->
                      <!--<td style="text-align: left;"><div data-orgcode="record">-->
                        <!--<input type="text" v-model="itemInner.zmony" :data-orgcode="itemInner" class="qymoneyAmout ant-input" style="margin: -5px 0px;"></div>-->
                      <!--</td>-->
                    <!--</tr>-->
                    <!--<tr>-->
                      <!--<td></td>-->
                      <!--<td>合计：</td>-->
                      <!--<td></td>-->
                    <!--</tr>-->
                  <!--</tbody>-->
                <!--</table>-->
            <!--</div>-->
            <!--</div>-->
          </a-tab-pane>
        </a-tabs>
        <div class="ant-table-content">
          <div class="ant-table-body">
            <table class="" style="width: 100%"><colgroup><col style="width: 120px; min-width: 120px;"><col><col></colgroup>
              <thead class="ant-table-thead">
              <tr>
                <th key="rowIndex" class="ant-table-align-center" style="text-align: center;"><div>序号</div></th>
                <th key="fullName" class="ant-table-align-left" style="text-align: left;"><div>企业名称</div></th>
                <th key="typeCode" class="ant-table-align-left" style="text-align: left;"><div>金额</div></th>
                <th key="enterprisesBasis" class="ant-table-align-left" style="text-align: left;"><div>依据</div></th>
              </tr>
              </thead>
              <tbody class="ant-table-tbody">
              <tr v-for="(itemInner,indexInner) in infactTableMock" v-if="itemInner.parentCode==currentTabCode">
                <td style="text-align: center;"><span class="ant-table-row-indent indent-level-0" style="padding-left: 0px;"></span>{{indexInner+1}}</td>
                <td style="text-align: left;">{{itemInner.orgName}}</td>
                <td style="text-align: left;"><div data-orgcode="record">
                  <input type="text" @change="sumQyMoney" v-model="itemInner.qyMoney" :data-orgcode="itemInner" class="qymoneyAmout ant-input" style="margin: -5px 0px;"></div>
                </td>
                <td style="text-align: left;">
                  <div data-orgcode="record">
                    <input type="text" v-model="itemInner.enterprisesBasis" :data-orgcode="itemInner" class="enterprisesBasis ant-input" style="margin: -5px 0px;">
                  </div>
                </td>
              </tr>
              <tr>
                <td></td>
                <td>合计：</td>
                <td>{{tabSum}}</td>
                <td></td>
              </tr>
              </tbody>
            </table>
          </div>
        </div> 
  </div>
</template>

<script>
  import {apiService} from "@/services/apiservice"; 
  import $ from 'jquery' 
  export default {
    name: "ReportAdd",
    components: {
     
    },
    props:
    {
      itmcCostEnterprise:Array 
    },
    data() {
      return {
        loadCurObj:[], //详情后台返回分摊数据
        currentTabCode:"", //tab切换显示对象对应table
        infactTabMock:[],//实际tab信息
        loadInfactTabMock:[],//tab后台返回详情数据
        loadInfactTabMock1:[],
        infactTableMock:[],//实际table的数据
        infactTableMock1:[], 
        treeData:[],//转换成树形结构
        checkedKeys: [''],//企业名称选择的数组
        checkMock:[], //选择的企业对象数组 
        selectedKeys: [],
        tabSameMock:[], //实际每个tab表格内数据
        activeKey: '1',
        tabSum: 0

      }
    },
    methods: {
      onLoadData (treeNode) {
        let _self=this;
        return new Promise((resolve) => {
          if(treeNode.dataRef.children){
            if (treeNode.dataRef.children.length>0) {
              resolve()
              return
            }
          }
          var  nextNode = _self.getUnitByOrgId(treeNode.eventKey,_self.dataOrg)
          setTimeout(() => {
            treeNode.dataRef.children = nextNode
            this.treeData = [...this.treeData]
            resolve()
          }, 1000)
        })
      },
      unique(arr, name) { // 根据唯一标识orderId来对数组进行过滤
        var hash = {};
        return arr.reduce(function (item, next) {
          hash[next[name]] ? '' : hash[next[name]] = true && item.push(next);
          return item;
        }, []);
      },
      loadMsg(){
          let _self =this;
          if(this.itmcCostEnterprise.length>0)
          {
            _self.loadInfactTabMock=_self.unique(this.itmcCostEnterprise,"parentCode");
            for(var i=0;i< _self.loadInfactTabMock.length;i++){
              _self.loadInfactTabMock[i].tabName= _self.loadInfactTabMock[i].parentOrgName
              _self.loadInfactTabMock[i].tabCode= _self.loadInfactTabMock[i].parentCode
            }
            _self.infactTabMock=_self.unique((_self.infactTabMock.concat( _self.loadInfactTabMock)), 'tabName')
            _self.loadInfactTabMock1= _self.loadInfactTabMock
            _self.currentTabCode=_self.infactTabMock[0].tabCode
            _self.activeKey=_self.infactTabMock[0].tabCode

            _self.loadCurObj = _self.itmcCostEnterprise
            _self.infactTableMock=_self.unique((_self.infactTableMock.concat(_self.itmcCostEnterprise)), 'orgName')
            _self.infactTableMock1=_self.loadInfactTabMock
          }
          this.sumQyMoney()
      }, 
      callback (key) {
        this.currentTabCode=key
        this.sumQyMoney()
      },
      sumQyMoney(){
        let tabSum = 0;
        this.infactTableMock.map((item) => {if(!isNaN(item.qyMoney)){if(item.parentCode==this.currentTabCode) tabSum +=parseInt(item.qyMoney) }})
        if(isNaN(tabSum)){
          return 0
        }
        this.tabSum = parseInt(tabSum);
      }
    },
    computed: {
      
      // tabSum(){
      //   let tabSum = 0;
      //   this.infactTableMock.map((item) => {if(!isNaN(item.qyMoney)){if(item.parentCode==this.currentTabCode) tabSum +=parseInt(item.qyMoney) }})
      //   if(isNaN(tabSum)){
      //     return 0
      //   }
      //   return parseInt(tabSum)
      // },
      totalSumAll(){
        let totalSumAll = 0;
        this.infactTableMock.map((item) => { if(!isNaN(item.qyMoney)){totalSumAll +=parseInt(item.qyMoney)} })
        if(isNaN(totalSumAll)){
          return 0
        }
        return parseInt(totalSumAll)
      },
    },
    created(){
      // this.loadMsg()
    
    },
    watch: {
      itmcCostEnterprise(val) {
        console.log('opopopopopopopopopop')
        console.log(val)
        console.log('opopopopopopopopopop')
        this.loadMsg()
      },
    },
  }
</script>
<style>
  .wrap {
    padding:15px;
    background: #ffffff;
    margin: 10px;
  }

  .edit_container {
    background: #ffffff;
  }

  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .common-title {
    font-size: 14px;
    font-weight: 700;
    padding: 5px 15px;
    margin: 10px 0 5px 0;
    position: relative;
  }

  .define-table, .table-rt {
    display: flex;
  }

  .define-table {
    border-top: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
  }

  .tbl-rt {
    flex: 7;
  }

  .table-head {
    flex: 1;
  }

  .table-body {
    flex: 2;
  }

  .table-item {
    border-right: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
    color: rgba(0, 0, 0, 0.65);
    padding: 10px;
    height: 42px;
    box-sizing: border-box;
    justify-content: center;
    text-align: center;
  }

  .table-head {
    background: #fafafa;
  }

  .table-item input {
    width: 100%;
    /*border: none;*/
    height: 100%;
    /*outline: none;*/
  }

  .table-head textarea {
    width: 100%;
    height: 70px;
    padding: 10px;
    border: none;
    outline: none;
  }
  .container{
    padding: 0 15px;
  }
  .shareMount{
    float: right;
    top: 0;
    width: 176px;
    position: relative;
    left: 0;
    display: inline-block;
    text-align: right;
  }
  .shareMount .ant-alert-icon {
    top: 3px;
    left: 16px;
    position: absolute;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    bottom: 0;
    right: 25px;
  }
  .qymoneyAmout{
    text-align: center;
  }
</style>
