<template>
  <div>
    <a-tree
      :loadData="onLoadData"
      checkable
      @expand="onExpand"
      :expandedKeys="expandedKeys"
      :autoExpandParent="autoExpandParent"
      v-model="checkedKeys"
      @select="onSelect"
      :selectedKeys="selectedKeys"
      :treeData="treeDataChild"
    />
  </div>
</template>
<script>
  import {apiService} from "@/services/apiservice";
  import Vue from 'vue';
  export default {
    name: "SelectTreeData",
    data() {
      return {
        autoExpandParent: true,
        checkedKeys: [''],//企业名称选择的数组
        selectedKeys: [],
        expandedKeys: [''],
        treeDataChild:this.treeData,
      }
    },
    props: ['treeData', 'dataOrg'],
    computed: {
    },
    methods: {
      onExpand (expandedKeys) {
        this.expandedKeys = expandedKeys
        this.autoExpandParent = false
      },
      onSelect (selectedKeys, info) {
        this.selectedKeys = selectedKeys
      },
      onLoadData (treeNode) {
        let _self=this;
        return new Promise((resolve) => {
          if(treeNode.dataRef.children){
            if (treeNode.dataRef.children.length>0) {
              resolve()
              return
            }
          }
          var  nextNode = _self.getUnitByOrgId(treeNode,treeNode.eventKey,_self.dataOrg)
          setTimeout(() => {
            treeNode.dataRef.children = nextNode
            this.treeDataChild = [...this.treeDataChild]
            resolve()
          }, 1000)
        })
      },
      getUnitByOrgId(treeNode,orgId,dataOrg){
        let  allObj=[]
        var dataOrg=dataOrg
        console.log(dataOrg);
        for (var i = 0; i < dataOrg.length; i++) {
          if (dataOrg[i].orgLevelName == '单位') {
            if (dataOrg[i].parentId == orgId) {
              dataOrg[i].title = dataOrg[i].orgName
              dataOrg[i].key = dataOrg[i].orgId
              dataOrg[i].parentOrgName =treeNode.title
              allObj.push(dataOrg[i])
            }
          }
        }
        return allObj
      },
      sendMsg(){
         this.$emit('checkedKeys',this.checkedKeys)
      }
    },
    watch: {
      treeData(val) {
        console.log('安玉山')
        console.log(val)
        console.log('安玉山')
        this.treeDataChild = val
      },
      checkedKeys(val,info) {
        this.sendMsg()
      },
    },
    created(){
      console.log('hshshhsh')
      console.log(this.treeData)
      console.log(this.treeDataChild)
      console.log('909090')
    }
  }
</script>