<template>
  <div class="wrap">
    <div class="con-head">
      <span>年份</span>
      <a-select :value=optionDateSelect class="querySelect" @change="handleChangeDate" style="width: 120px">
        <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
      </a-select>
      <!--<a-button type="primary" @click="doExM">导入</a-button>-->
      <a-button type="primary" @click="officeExport">导出</a-button>
      <!--<a-button type="primary" v-if="feePlanStatus=='1'" @click="applyBudget">申报</a-button>-->
      <!--<a-button type="primary" @click="toAdd">添加</a-button>-->
   </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>业务处室年度费用预算申报（{{status}}）</span>
      <span class="unitText">单位：万元</span>
    </div>
    <div>
      <!--<a-spin tip=" 加载中。。。" style="width: 100%">-->
      <table id="myTable" border="1" cellpadding="15" cellspacing="0" style="width: 100%">　　　
        <tr>
          <!--<th>ID</th>-->　　 　　
          <th class="k100" rowspan="2">开支类型</th>
          <th class="k100" rowspan="2">项目</th>
          <th class="k100" rowspan="2">项目明细</th>
          <th colspan="3">{{parseInt(optionDateSelect)-1}}年预算</th>　
          <th colspan="3">{{optionDateSelect}}年预算</th>
          <th colspan="3">{{optionDateSelect+1}}年预算</th>　　
          <th class="k100" rowspan="2">变化说明</th>         　
          <th class="k120" rowspan="2">内容及工作量</th>
          <th rowspan="2">费用测算</th>　　　 　　
          <th class="k120" rowspan="2">操作</th>
        </tr>
        <tr>　　　 　　
          <th class="k50">总部</th>　 　　
          <th class="k100">分摊金额</th>
          <th class="k50">合计</th>
          <th class="k50">总部</th>　 　　
          <th class="k100">分摊金额</th>
          <th class="k50">合计</th>
          <th class="k50">总部</th>　 　　
          <th class="k100">分摊金额</th>
          <th class="k50">合计</th>
        </tr>
        <tr v-for="(item,$index) in dataT">　　   　　　　
          <td v-for="(val,key) in item" :rowspan="rowSpanF(key,val)"
            v-if="key!='id'&&(key=='feeName'||key=='projectName'||key=='projectDetailsName'||key=='zbMoney'||key=='qyMoney'||key=='projectId'||key=='ZbBeforeMoney'||key=='QyBeforeMoney'||key=='projectId1'||key=='BeforeBudgetAmount'||key=='BeforeAmount'||key=='projectId2'||key=='instructions'||key=='contentText'||key=='measureText')"
            >
            <span v-if="key=='feeName'">{{val}}</span>
            <span v-if="key=='projectName'">{{val}}</span>
            <span v-if="key=='projectDetailsName'">{{val}}</span>
            <span v-if="key=='zbMoney'">{{val}}</span>
            <span v-if="key=='qyMoney'">{{val}}</span>
            <span v-if="key=='projectId'">{{item['zbMoney']+item['qyMoney']}}</span>
          <!--<span v-if="key=='ZbBeforeMoney'">{{val}}ZbBeforeMoney</span>-->
          <!--<span v-if="key=='QyBeforeMoney'">{{val}}QyBeforeMoney</span>-->
          <!--<span v-if="key=='projectId1'">{{item['ZbBeforeMoney']+item['QyBeforeMoney']}}projectId1</span>-->
          <!--<span v-if="key=='BeforeBudgetAmount'">{{val}}BeforeBudgetAmount</span>-->
          <!--<span v-if="key=='BeforeAmount'">{{val}}BeforeAmount</span>-->
          <!--<span v-if="key=='projectId2'">{{item['BeforeBudgetAmount']+item['BeforeAmount']}}projectId2</span>-->
            <span v-if="key=='instructions'">{{val}} </span>
            <span v-if="key=='contentText'">{{val}}</span>
            <span v-if="key=='measureText'">{{val}}</span>
          </td>
          <td>
            <div v-if="item.projectDetailsName!='小计'&&item.projectDetailsName!='合计'">
              <!--<span @click="toAdd(allItems[$index])"><a>添加</a></span>-->
              <span @click="toEdit(item)"><a>编辑</a></span>
              <span>
                  <a-popconfirm
                    title="确定删除吗?"
                    okText="确定"
                    cancelText="取消"
                    @confirm="() => deletArr(item)">
                       <a href="javascript:;">删除</a>
                  </a-popconfirm>
              </span>
            </div>
          </td>　　　　
        </tr>
      </table>
      <!--</a-spin>-->
      <form action="/project/costBudget/exportTemplate" style="display: none">
        <input type="text" name="projectDetailList" v-model="template.projectDetailList">
        <input type="password" name="companyList" v-model="template.companyList">
        <input type="submit" value="提交" id="doSubmit">
      </form>
    </div>
    <a-modal
      title="导入年度费用预算"
      :width="600"
      centered
      v-model="expVisible"
      @ok="() => handleUpload()"
      @cancel="() => setVersionVisible(false)"
      okText="保存"
      cancelText="取消"
    >
      <div>
        <div class="clearfix">
          <a-upload
            :fileList="fileList"
            :remove="handleRemove"
            :beforeUpload="beforeUpload"
          >
            <a-button>
              <a-icon type="upload"/>
               上传
            </a-button>
          </a-upload>
          <!--<a-button-->
            <!--type="primary"-->
            <!--@click="handleUpload"-->
            <!--:disabled="fileList.length === 0"-->
            <!--:loading="uploading"-->
            <!--style="margin-top: 16px"-->
          <!--&gt;-->
            <!--{{uploading ? 'Uploading' : 'Start Upload' }}-->
    <!---->
          <!--</a-button>-->
        </div>
        <div style="margin-top: 10px;">
          <a @click="editEx">编辑模板</a>
        </div>
      </div>
    </a-modal>
    <a-drawer
      title="操作"
      :width="700"
      @close="onClose"
      :visible="visible"
      :wrapStyle="{height: 'calc(100% - 108px)',overflow: 'auto',paddingBottom: '108px'}"
    >


        <div style="margin-bottom: 40px">
          <div>
            <div class="con-title">
              <span class="divdLine"></span>
              <span>请选择明细</span>
            </div>
            <a-tree
              checkable
              @expand="onExpand"
              :expandedKeys="expandedKeys"
              v-model="checkedKeys"
              @select="onSelect"
              :selectedKeys="selectedKeys"
              :treeData="treeData"
            />
          </div>
          <div style="flex: 1">
            <div class="con-title">
              <span class="divdLine"></span>
              <span>请选择企业</span>
            </div>
            <a-tree
              checkable
              @expand="onExpandQy"
              :expandedKeys="expandedKeysQy"
              :autoExpandParent="autoExpandParentQy"
              v-model="checkedKeysQy"
              @select="onSelectQy"
              :selectedKeys="selectedKeysQy"
              :treeData="treeDataQy"
            />
          </div>
        </div>
      <div
        :style="{
          position: 'absolute',
          left: 0,
          bottom: 0,
          width: '100%',
          borderTop: '1px solid #e9e9e9',
          padding: '10px 16px',
          background: '#fff',
          textAlign: 'right',
        }"
      >
        <a-button
          :style="{marginRight: '8px'}"
          @click="onClose"
        >
          取消
        </a-button>
        <a-button @click="downEdtpl" type="primary">下载</a-button>
      </div>
    </a-drawer>

  </div>
</template>
<script>
  import $ from 'jquery'
  import reqwest from 'reqwest'
  import {quillEditor} from "vue-quill-editor"; //调用编辑器
  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css';
  import {apiService} from "@/services/apiservice";

  export default {
    name: 'DepartmentCheck',
    data() {
      return {
        template:{},
        currentExpenditureType: {},
        optionDate: [],
        optionDateSelect: "",
        dataT: [],
        infoData: null,
        items: [],
        allItems: [],
        expVisible: false,
        fileList: [],
        files:null,
        visible:false,
        treeData:[],
        initTreeData:[],//接口中获取的treedata原始数据
        choiceDetails:[], //明细选择的对象数组
        thirdArr:[],//明细只有三级的对象数组原始数据
        selectedKeys: [],
        checkedKeys:[''],
        status:"",
        feePlanStatus:"1",
        expandedKeys:[""],
        checkedKeysQy: [''],//选择企业
        expandedKeysQy: [''],
        autoExpandParentQy: true,
        selectedKeysQy: [],
        choiceDetailsQy:[],//选择的企业
        checkMock:[], //选择的企业对象数组
        tabMock:[],
        infactTabMock:[],//实际tab信息
        tabSameMock:[], //实际每个tab表格内数据
        trArr:[],
        dataOrg:[],//模拟接口调用获取到企业名称
        treeDataQy:[],

      }
    },
    watch: {
      checkedKeys(val,info) {
        let mockQYArr=[]
        this.mockQY=mockQYArr
      },
      checkedKeysQy(val,info) {
      },
    },
    components: {
      quillEditor
    },
    computed: {
      editor() {
        return this.$refs.myQuillEditor.quill;
      },
    },
    created: function () {
      this.loadDate()
      this.optionDateSelect=new Date().getFullYear();
      var params = {"planYear":this.optionDateSelect,"version":this.optionDateSelect}
      params._json = true
      this.loadTable(params)
      this.getOrgByOrgTypeCodes()//获取企业信息
    },
    methods: {
      getOrgByOrgTypeCodes(){
        let _self=this
        let parmasData="Itmc_Co_Type2"
        $.ajax({
          type: "POST",
          url: "/project/org/getOrgByOrgTypeCodes?Itmc_Co_Type2",
          contentType: 'application/x-www-form-urlencoded;charset=utf-8',
          dataType: "json",
          success: function(data){
            _self.dataOrg=data
            _self.initTreeData1(data)
            _self.treeDataQy.push(_self.initTreeData1(data))
          }
        })
      },
      initTreeData1(dataOrg){
        var resultArr=dataOrg[0]
        var secArr=[];
        for(var i=0;i<dataOrg.length;i++){
          if(dataOrg[i].orgLevelName=='板块'){
            dataOrg[i].title=dataOrg[i].orgName
            dataOrg[i].key=dataOrg[i].orgId
            dataOrg[i].children=[];
            secArr.push(dataOrg[i])
          }
        }

        for(var j=0;j<secArr.length;j++){
          var childrenName = secArr[j].children
          for(var i=0;i<dataOrg.length;i++){
            if(dataOrg[i].orgLevelName=='单位'){
              if(dataOrg[i].parentId==secArr[j].orgId){
                dataOrg[i].title=dataOrg[i].orgName
                dataOrg[i].key=dataOrg[i].orgId
                childrenName.push(dataOrg[i])
              }
            }
          }
        }

        resultArr.title=resultArr.orgName
        resultArr.key=resultArr.orgId
        resultArr.children=secArr
        return resultArr
      },
      initQyOther(){
        this.checkMock=this.dataOrg
        this.infactTabMock=[]
        this.tabMock=[]
        this.tabSameMock=[]
        this.checkMock=[]
        for(var j=0;j<this.checkedKeysQy.length;j++){
          for(var i=0;i<this.dataOrg.length;i++){
            if(this.dataOrg[i].orgId==this.checkedKeysQy[j]&&this.dataOrg[i].orgLevelName=='单位'){
              this.checkMock.push(this.dataOrg[i])
            }
          }
        }
        this.getChoiceObj(this.checkMock)
      },
      getChoiceObj(arr){
        this.tabSameMock=[]
        for(var j=0;j<arr.length;j++){
          for(var i=0;i<this.dataOrg.length;i++){
            if(arr[j].parentId==this.dataOrg[i].orgId){
              var obj={parentCompanyCode:this.dataOrg[i].orgCode,
                parentCompanyName:this.dataOrg[i].orgName,
                CompanyName:arr[j].orgName,
                CompanyCode:arr[j].orgCode,
              }
              this.tabSameMock.push(obj)
            }
          }
        }
      },
      unique(arr, name) {
        var hash = {};
        return arr.reduce(function (item, next) {
          hash[next[name]] ? '' : hash[next[name]] = true && item.push(next);
          return item;
        }, []);
      },
      hasSameKey(){
        this.tabSameMock=[]
        for(var j=0;j<this.infactTabMock.length;j++){
          var curType=[]
          for(var i=0;i<this.checkMock.length;i++){
            if(this.infactTabMock[j].orgId==this.checkMock[i].parentId){
              curType.push(this.checkMock[i])
            }
          }
          this.tabSameMock.push(curType)
        }
      },
      getInfactTabMock(arr){
        this.infactTabMock=[]
        for(var i=0;i<arr.length;i++){
          for(var j=0;j<this.dataOrg.length;j++){
            if(this.dataOrg[j].orgId ==arr[i].parentId){
              this.infactTabMock.push(this.dataOrg[j])
              break
            }
          }
        }
      },
      onSelectQy (selectedKeys, info) {
        this.selectedKeysQy = selectedKeys
      },
      onExpandQy (expandedKeys) {
        this.expandedKeysQy = expandedKeys
        this.autoExpandParentQy = false
      },
      onCheckQy (checkedKeys) {
        this.checkedKeysQy = checkedKeys
      },
      onSelect (selectedKeys, info) {
        this.selectedKeys = selectedKeys
      },
      onCheck (checkedKeys) {
        this.checkedKeys = checkedKeys

      },
      onExpand (expandedKeys) {
        this.expandedKeys = expandedKeys
        this.autoExpandParent = false
      },
      getChoiceDetails(arr){
        this.choiceDetails=[]
        for(var i=0;i<arr.length;i++){
          for(var j=0;j<this.thirdArr.length;j++){
            if(this.thirdArr[j].code==arr[i]){
              this.choiceDetails.push(this.thirdArr[j])
            }
          }
        }
      },
      getChoiceDetailsQy(){
          this.choiceDetailsQy=[]
      },
      downEdtpl(){
        this.getChoiceDetails(this.checkedKeys)
        this.initQyOther()
        this.template.projectDetailList=this.choiceDetails
        this.template.companyList=this.tabSameMock
        $("#doSubmit").click()
      },
      handleRemove(file) {
        const index = this.fileList.indexOf(file);
        const newFileList = this.fileList.slice();
        newFileList.splice(index, 1);
        this.fileList = newFileList
      },
      beforeUpload(file) {
        this.files=file
        this.fileList = [...this.fileList, file]
        return false;
      },
      handleUpload() {
        const { fileList } = this;
        const formData = new FormData();
        formData.append('file', this.files);
        formData.append('version', this.allItems[0].version);
        formData.append('feePlanStatus','1');
        this.uploading = true
        reqwest({
          url: '/project/itmcAut/exportfile',
          method: 'post',
          processData: false,
          data: formData,
          success: () => {
            this.fileList = []
            this.uploading = false
            this.$message.success('upload successfully.');
          },
          error: () => {
            this.uploading = false
            this.$message.error('upload failed.');
          },
        });
      },
      doExM(){
         this.expVisible=true
      },
      officeExport(){
          window.location.href='/project/costBudget/officeExport?ouId='+ this.allItems[0].ouId+"&version="+ this.allItems[0].version
      },
      editEx(){
        let _self=this
        this.visible=true
        let parmasData={}
        parmasData._json=true
        apiService.getItmcProjectTypeMenu(parmasData).then(r => {
        _self.initTreeData=r.list
        _self.treeData= _self.reverData(r.list)
        }, r => {
        }).catch(
        )
      },
      reverData(data){
        for (var j = 0; j < data.length; j++) {
          data[j].title = data[j].name
          data[j].key = data[j].code
          if (data[j].children.length > 0) {
            this.reverData(data[j].children)
          }else{
            this.thirdArr.push(data[j])
          }
        }
        return data
      },
      onClose() {
        this.visible = false
      },
      downEx(){
        let _self=this
        let parmasData={}
        parmasData._json=true
        apiService.exportTemplate(parmasData).then(r => {
          _self.$message.success("模板下载成功")
        }, r => {
        }).catch(
        )
      },
      setVersionVisible(){
        this.expVisible=false
      },
      applyBudget(){
        let _self = this
        let parmasData = {
          "ouId": _self.allItems[0].ouId,
          "planYear": _self.optionDateSelect,
          "version": _self.allItems[0].version,
          "feePlanStatus":this.feePlanStatus
        }
        parmasData._json = true
        apiService.applyCostBudgetProject(parmasData).then(r => {
          if (r.result == '0000') {
            _self.$message.success("申报成功")
          }
        }, r => {
        }).catch(
        )
      },
      loadDate(){
        var _self = this
        var parmasData = "typeCode=JHNDS"
        apiService.getDictionary1(parmasData).then(r => {
          _self.optionDate = r
          _self.optionDateSelect = _self.optionDate[0].optionCode
        }, r => {
        }).catch(
        )
      },
      loadTable(parmasData){
        let _self = this
        apiService.getItmcBeforeCostPlanList(parmasData).then(r => {
          _self.allItems = r
          if(_self.allItems[0].feePlanStatus=='1'){
            _self.status="未申报"

          }else if(_self.allItems[0].feePlanStatus>1){
            _self.status="已申报"
          }
          _self.feePlanStatus=_self.allItems[0].feePlanStatus

          var curItems = r
          _self.items = [];
          for (var i = 0; i < curItems.length; i++) {
            var obj = {
              "id": curItems[i].id,
              "feeName": curItems[i].feeName,
              "projectName": curItems[i].projectName,
              "projectDetailsName": curItems[i].projectDetailsName,
              "zbMoney": curItems[i].zbMoney,
              "qyMoney": curItems[i].qyMoney,
              "projectId": curItems[i].projectId,
//              "ZbBeforeMoney": curItems[i].ZbBeforeMoney,
//              "QyBeforeMoney": curItems[i].QyBeforeMoney,
              "projectId1": curItems[i].projectId,
//              "BeforeBudgetAmount": curItems[i].BeforeBudgetAmount,
//              "BeforeAmount": curItems[i].BeforeAmount,
              "projectId2": curItems[i].projectId,
              "instructions": curItems[i].instructions,
              "contentText": curItems[i].contentText,
              "measureText": curItems[i].measureText
            }
            if(!curItems[i].ZbBeforeMoney){
              obj.ZbBeforeMoney='0'
            }
            if(!curItems[i].QyBeforeMoney){
              obj.QyBeforeMoney='0'
            }
            if(!curItems[i].BeforeBudgetAmount){
              obj.BeforeBudgetAmount='0'
            }
            if(!curItems[i].BeforeAmount){
              obj.BeforeAmount='0'
            }

            if (curItems[i].projectDetailsName == '合计') {
              obj.projectName = curItems[i - 1].projectName
            }
            _self.items.push(obj)
          }
          _self.initData()
        }, r => {
        }).catch(
        )
      },
      toAdd(item){
        this.$router.push({path: "/report-add", query: {current:JSON.stringify(item),version:this.allItems[0].version,planYear:this.optionDateSelect}})
      },
      deletArr(item){
        let _self = this
        let parmasData = {id: item.id}
        parmasData._json = true
        apiService.deleteCostBudgetProjectDetails(parmasData).then(r => {
          _self.$message.success("删除成功")
          _self.initData()
        }, r => {
        }).catch(
        )
      },
      toEdit(item){
        this.$router.push({path: "/report-edit", query: {currentId: item.id}})
      },
      initData(){
        const that = this;
        let arry = [];
        let itemsCopy = JSON.parse(JSON.stringify(that.items));
        console.log("itemscopy")
        console.log(itemsCopy )
        for (let i = 0; i < itemsCopy.length; i++) {
          for (let j = (i + 1); j < itemsCopy.length; j++) {
            for (let h in itemsCopy[i]) {
              for (let k in itemsCopy[j]) {
                if (k == 'feeName' || k == 'projectName' || k == 'projectDetailsName') {
                  if (itemsCopy[j][k] != '小计' && itemsCopy[j][k] != '合计') {
                    if (h === k && itemsCopy[i][h] === itemsCopy[j][k]) {
                      delete  itemsCopy[j][k]
                    }
                  }
                }

              }
            }
          }

          arry.push(itemsCopy[i]);
        }
        that.dataT = arry;
      },
      rowSpanF: function (key, val) {
        const that = this;
        let num = 0;
        for (let i in that.items) {
          for (let j in that.items[i]) {
            if (j == 'feeName' || j == 'projectName' || j == 'projectDetailsName') {
              if (key === j && val === that.items[i][j]) {
                if (that.items[i][j] == '小计' || that.items[i][j] == '合计') {
                  return
                }
                num++;
              }
            }

          }
        }
        if(num==0){
          return 1
        }
        return num;
//        const that = this;
//        let num = 0;
//        for (let i in that.items) {
//          for (let j in that.items[i]) {
////            if (j == 'feeName' || j == 'projectName' || j == 'projectDetailsName') {
//            if (j == 'feeName' || j == 'projectName' || j == 'projectDetailsName') {
//              if (key === j && val === that.items[i][j]) {
//                if (that.items[i][j] == '小计' || that.items[i][j] == '合计') {
//                  return
//                }
//                num++;
//              }
//            }
//          }
//        }
//        if(num==0){
//            return 1
//        }
//        return num;
      },
      handleChangeDate(value){
        this.optionDateSelect = value
        this.dataT=[]
        var params = {planYear: this.optionDateSelect,version:this.optionDateSelect}
        params._json = true
        this.loadTable(params)
      },
    }
  }


</script>
<style>
  .wrap {
    margin: 10px;
    border-left: 1px solid rgb(232, 232, 232);
    padding: 15px;
    background: #fff;
  }

  #myTable {
    width: 100%;
    background: #fff;
    text-align: center;
    border-top: 1px solid #e8e8e8;
    border-left: 1px solid #e8e8e8;
    margin-bottom: 40px;
  }

  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #333333;
    display: flex;
    margin-bottom: 20px;
    position: relative;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    bottom: 0;
    right: 10px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: rgb(24, 144, 255);
    height: 20px;
    margin-right: 10px;
  }

  #myTable tr td, #myTable tr th {
    border-bottom: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
    color: rgba(0, 0, 0, 0.65);
    padding: 5px 10px;
  }

  #myTable tr th {
    background: #fafafa;
  }

  .k50 {
    width: 50px;
  }

  .k100 {
    width: 100px;
  }

  .k120 {
    width: 120px;
  }

  .con-head {
    margin-bottom: 20px;
  }

  .flexL {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: flex-end;
    padding-right: 15px;
  }

  .flexR {
    flex: 2;
  }

  .modeInputBox {
    margin-top: 20px;
  }
</style>
