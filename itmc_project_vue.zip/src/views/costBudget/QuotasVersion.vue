<template>
  <div class="wrap">
    <div class="con-head">
      <span>当前版本:</span>
      <a-select :value=versionSelect class="querySelect" @change="handleChangeVersion" style="width:200px">
        <a-select-option v-for="item in optionVersion" :key="item.version"> {{item.versionName}}</a-select-option>
      </a-select>
      <a-button v-if="feePlanStatus != '5'" type="primary" @click="saveCostVersion">保存新版本</a-button>
      <a-button type="primary" @click="summaryCostBudgetExport" icon="download">报表打印</a-button>
      <!--<a-button type="primary" @click="officeExport" icon="download">导出</a-button>-->
      <a-button v-if="feePlanStatus != '5'" type="primary" @click="applyBudget">发布</a-button>
      <!--<a-button v-if="feePlanStatus != '5'" type="primary" @click="doAdd">添加</a-button>-->
      <a-button type="primary" @click="backQuotas">返回</a-button>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>{{planYear}}年信息化费用预算表</span>
      <span class="unitText">单位：万元</span>
    </div>
    <div class="container" style="padding: 0">
      <div>
        <div class="ant-table-content">
        <div class="ant-table-body">
        <table style="width: 100%">
          <thead class="ant-table-thead">
          <tr>
            <th  rowspan="2" class="" style="width:115px;"><div>项目</div></th>
            <th key="1" colspan="4" style="border-bottom: 1px solid #e8e8e8">
              <div><span slot="title">{{planYear-1}}年费用预算</span></div></th>
            <th key="2" colspan="4" style="border-bottom: 1px solid #e8e8e8"><div><span slot="title">{{planYear}}年费用预算</span></div></th>
            <th  rowspan="2" class=""><div>预算构成说明</div></th>
            <th  rowspan="2" class=""><div>预算构成明细说明</div></th>
          </tr>
          <tr>
            <th  class="" style="width: 70px;"><div><span slot="title">总预算</span></div></th>
            <th  class="" style="width: 70px;"><div>总部</div></th>
            <th  class="" style="width: 70px;"><div>企业</div></th>
            <th  class="" style="width: 90px;"><div>预计完成</div></th>
            <th  class=""><div><span slot="title">总预算</span></div></th>
            <th  class="" style="width: 81px;"><div>优化预算</div></th>
            <th  class=""><div>总部</div></th>
            <th  class="" style="width: 70px;"><div>企业</div></th>
          </tr>
          </thead>
          <tbody class="ant-table-tbody">
            <tr v-for="(item,index) in infoData">
              <td style="text-align: left">
                <span v-if="item.projectId=='0'">{{item.projectName}}</span>
                <span v-if="item.projectId!='0'" @click="toDetail(item.projectId)"><a>{{item.projectName}}</a></span>
              </td>
              <td>{{item.beforeBudgetAmount||'0'}}</td>
              <td>{{item.zbBeforeMoney||'0'}}</td>
              <td>{{item.qyBeforeMoney||'0'}}</td>
              <td>{{item.lastYearBudget||'0'}}</td>
              <td>{{item.budgetAmount||'0'}}</td>
              <td>{{item.optimizeBudgetAmount||'0'}}</td>
              <td>{{item.zbOptimizeMoney||'0'}}</td>
              <td>{{item.qyOptimizeMoney||'0'}}</td>
              <td>
                 <span v-if="feePlanStatus != '5'" @click="editContent(item)">
                   <a>
                   {{item.content|| '编辑'}}
                  </a>
                 </span>
                 <span v-else >{{item.content|| ''}}</span>
              </td>
              <td>
                 <span v-if="feePlanStatus != '5'" @click="editInstructions(item)">
                   <a>
                   {{item.instructions|| '编辑'}}
                  </a>
                 </span>
                 <span v-else >{{item.instructions|| ''}}</span>
              </td>
            </tr>
          </tbody>
        </table>
        </div>
        </div>
      </div>
    </div>
    <a-modal
      title="编辑预算构成说明"
      :width="600"
      centered
      v-model="modalVisible"
      @ok="() => editExplain()"
      @cancel="() => setModal1Visible(false)"
      okText="保存"
      cancelText="取消"
    >
      <div>
        <div class="con-title">
          <span class="divdLine"></span>
          <span>{{modalItem.projectName}}</span>
        </div>
        <span style="font-weight: 700">预算构成说明</span>
        <div class="edit_container" style="margin-top: 10px">
<!--          <quill-editor
            v-model="content"
            ref="myQuillEditor"
            :options="editorOption"
            @blur="onEditorBlur($event)" @focus="onEditorFocus($event)"
            @change="onEditorChange($event)">
          </quill-editor>-->
          <textarea style="width: 100%;height: 100px" v-model="modalItem.content"></textarea>
        </div>
      </div>
    </a-modal>
    <a-modal
      title="编辑预算构成明细说明"
      :width="600"
      centered
      v-model="modalDetailVisible"
      @ok="() => editExplain()"
      @cancel="() => setModal2Visible(false)"
      okText="保存"
      cancelText="取消"
    >
      <div>
        <div class="con-title">
          <span class="divdLine"></span>
          <span>{{modalItem.projectName}}</span>
        </div>
        <span style="font-weight: 700">预算构成明细说明</span>
        <div class="edit_container" style="margin-top: 10px">
<!--          <quill-editor
            v-model="content"
            ref="myQuillEditor"
            :options="editorOption"
            @blur="onEditorBlur($event)" @focus="onEditorFocus($event)"
            @change="onEditorChange($event)">
          </quill-editor>-->
          <textarea style="width: 100%;height: 100px" v-model="modalItem.instructions"></textarea>
        </div>
      </div>
    </a-modal>
    <a-modal
      title="添加项目"
      :width="600"
      centered
      v-model="versionVisibles"
      @ok="() => saveVersions()"
      @cancel="() => setVersionVisibles(false)"
      okText="确认"
      cancelText="取消"
    >
      <div>
          <div style="display: flex;margin-bottom: 20px">
            <span style="text-align: left;margin-right: 10px;width: 90px">二级项目类型:</span>
            <a-select :value="ProjectDetailTypeSel"  class="querySelect" @change="onChangeDetailType" style="width:250px;">
              <a-select-option v-for="item in ProjectDetailType" :key="item.code"> {{item.name}}</a-select-option>
            </a-select>
          </div>

      </div>
    </a-modal>
    <a-modal
      title="保存新版本"
      :width="600"
      centered
      v-model="versionMVisible"
      @ok="() => saveVersion()"
      @cancel="() => setVersionVisible(false)"
      okText="保存"
      cancelText="取消"
    >
      <div>
          <div style="display: flex;margin-bottom: 20px">
            <span style="flex:1;text-align: right;margin-right: 10px">版本号:</span>
            <a-input style="flex: 8" size="small" v-model="versionName"/>
          </div>
          <div style="display: flex">
            <span style="flex: 1;text-align: right;margin-right: 10px">说明:</span>
            <a-textarea style="flex: 8" v-model="versionContent" :rows="4"/>
          </div>
      </div>
    </a-modal>
  </div>
</template>

<script>
  import {quillEditor} from "vue-quill-editor"; //调用编辑器
  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css';
  import {apiService} from "@/services/apiservice";
  export default {
    name: "QuotasVersion",
    components: {
      quillEditor
    },
    data() {
      return {
        planYear:"",
        version:"",
        feeType:"",
        versionName:"",
        versionContent:"",
        optionVersion:[],
        ProjectDetailType:[],
        ProjectDetailTypeSel:"",
        ProjectDetailTypeSelText:"",
        versionSelect:"",
        modalVisible:false,
        versionVisibles:false,
        modalDetailVisible:false,
        content: "",
        contentText: "",
        modalItem:{projectName:""},
        editorOption: {
          modules:{
            toolbar:[
              ['bold', 'italic', 'underline', 'strike'],
              ['blockquote', 'code-block']
            ]
          },
          placeholder: '请输入说明',
        },
        infoData: null,
        versionMVisible:false,
        feePlanStatus:""
      }
    },
    methods: {
      summaryCostBudgetExport(){
        if(this.infoData.length<=0){
          this.$message.warning("未获取到版本等相关信息，暂时不能导出......")
          return
        }

        window.location.href="/project/costBudget/summaryCostBudgetExport?version="+this.version+"&planYear="+this.planYear
      },
      onChangeDetailType(value){
        // let _self=this
        var obj=this.ProjectDetailType.find(function (obj) {
          return obj.code === value
        })
        this.ProjectDetailTypeSel=value
        this.ProjectDetailTypeSelText=obj.name
        this.feeType=obj.parentCode;
      },
      handleChangeDetailType(){
        // let _self=this
        let projectTypeParmas={code:"11"}
        projectTypeParmas._json=true
        apiService.getItmcProjectTypeList(projectTypeParmas).then(r => {
          this.ProjectDetailType=r;
        }, r => {
        }).catch(
        )
      },
      saveVersions(){
           let item={version:this.version,planYear:this.planYear,projectId:this.ProjectDetailTypeSel,projectName:this.ProjectDetailTypeSelText,feePlanStatus:this.feePlanStatus,feeType:this.feeType,feeName:""}
         // console.log(item);
          // this.$router.push({path: "/report-add", query: {current: JSON.stringify(item),planYear:this.planYear,feePlanStatus:this.feePlanStatus,version:this.version}})
          this.$router.push({path: "/report-addCopy", query: {current: JSON.stringify(item),flag:"1"}})
      },
      setVersionVisibles(value){
        this.versionVisibles=value;
      },
      doAdd(){
        this.versionVisibles=true;
      },
      officeExport(){
        if(this.infoData.length<=0){
          this.$message.warning("未获取到版本等相关信息，暂时不能导出......")
          return
        }
        window.location.href="/project/costBudget/officeExport?version="+ this.version
      },
      applyBudget(){
        let _self = this
        if(_self.infoData.length<=0){
          this.$message.warning("未获取到版本等相关信息，请稍后再试......")
          return
        }
        if(_self.infoData[0].feePlanStatus == '5'){
          this.$message.warning("数据已发布!")
          return
        }
        let parmasData = {
          "planYear": _self.planYear,
          "version": _self.version,
          "feePlanStatus":"5"
        }
        parmasData._json = true
        apiService.applyCostBudgetProject(parmasData).then(r => {
          if (r.result == '0000') {
            _self.$message.success("发布成功")
            this.$router.go(-1);
          }else{
            _self.$message.error(r.msg);
          }
        }, r => {
        }).catch(
        )
      },
      onEditorReady(editor) {
      },
      onEditorBlur(){
      },
      onEditorFocus(){
      },
      onEditorChange(event){
        this.content=event.html
        this.contentText=event.text
      },
      editExplain(){
        let _self=this
        var budgetId=''
        if(_self.modalItem.projectId=='0'){
          budgetId=_self.modalItem.feeType
        }else{
          budgetId=_self.modalItem.projectId
        }
        var budgetContent=_self.modalItem.content;
        var content=_self.modalItem.instructions;
        let parmasData={"budgetId":budgetId,"budgetContent":budgetContent,"content":content,"planYear":this.planYear,"version":this.version}
        parmasData._json=true
        apiService.saveProjectBudgetContent(parmasData).then(r => {
           if(r.result=='9999'){
             _self.$message.error(r.msg)
             // _self.modalVisible=false
             return
           }
          _self.$message.success("编辑成功")
          _self.modalVisible=false
          _self.modalDetailVisible=false
          let parmas={version:_self.versionSelect,planYear:_self.planYear}
          parmas._json=true
          _self.loadTable(parmas)
        }, r => {
        }).catch(
        )
      },
      backQuotas(){
        this.$router.go(-1)
      },
      loadVersionSelect(parmasData){
        let _self = this
        apiService.getCostVersionList(parmasData).then(r => {
          _self.optionVersion = r
          // _self.feePlanStatus = r[0].feePlanStatus
          if(!_self.versionSelect){
            _self.versionSelect=r[0].versionName
          }
        }, r => {
        }).catch(
        )
      },
      loadMsg(){
        this.planYear=this.$route.query.planYear
        if(!this.$route.query.planYear){
          this.planYear=new Date().getFullYear()
        }
        this.version=localStorage.getItem("version");
        // this.versionSelect=localStorage.getItem("version");
      },
      judgeCostVersionLists(){
        var _self=this
        let parmasData={planYear:_self.planYear,feePlanStatus: "5"}
        apiService.judgeCostVersionLists(parmasData).then(r => {
          _self.feePlanStatus=r.feePlanStatus;
        }, r => {
        }).catch(
        )
      },
      saveCostVersion(){
        this.versionMVisible=true
      },
      saveVersion(){
        this.versionMVisible=false
        let _self=this
        let parmasData={planYear:this.planYear,oldVersion:this.version,versionName:this.versionName,content:this.versionContent}
        parmasData._json=true
        apiService.saveCostVersion(parmasData).then(r => {
          if(r.result == '0000'){
            _self.$message.success("新版本已形成!");
            this.$router.go(-1);
            let parmas={version:_self.$route.query.version,planYear:_self.planYear}
            parmas._json=true
            // _self.loadTable(parmas)
            let parmasVersion={planYear:_self.planYear}
            parmasVersion._json=true
            // _self.loadVersionSelect(parmasVersion)
          }else{
            _self.$message.error("新版本形成失败!");
          }
        }, r => {
        }).catch(
        )
      },

      setModal1Visible(){
        this.modalVisible=false
      },
      setModal2Visible(){
        this.modalDetailVisibleVisible=false
      },
      setVersionVisible(){
        this.versionMVisible=false
      },
      handleChangeVersion(value){
        this.versionSelect=value
        this.version=value
        console.log("value:"+value);
        localStorage.setItem('version',value);
        let parmas={version:this.versionSelect,planYear:this.planYear}
        parmas._json=true
        this.loadTable(parmas)
      },
      loadTable(parmasData){
        let _self = this
        apiService.getInformationCostBudgetList(parmasData).then(r => {
          _self.infoData = r;
          // if(_self.infoData.length>0){
          //   _self.feePlanStatus=r[0].feePlanStatus;
          //   console.log("_self.feePlanStatus:"+self.feePlanStatus)
          // }
        }, r => {
        }).catch(
        )
      },
      editInstructions(item){
        let _self=this
        this.modalItem=item
        this.modalDetailVisible=true
        this.instructions=item.instructions
      },
      editContent(item){
        let _self=this
        this.modalItem=item
        this.modalVisible=true
        this.content=item.content
      },
      handleEdit(recode){
        this.$router.push({path:'/version-detail'})
      },
      toDetail(projectId){
        this.$router.push({path:'/version-detail',query:{projectId:projectId,version:this.version,planYear:this.planYear}})
      }
    },
    computed: {
    },
    created(){
      this.loadMsg()
      let parmasVersion={planYear:this.planYear}
      parmasVersion._json=true
      this.loadVersionSelect(parmasVersion)
      this.versionSelect=localStorage.getItem("version");
      let parmas={version:this.versionSelect,planYear:this.$route.query.planYear}
      parmas._json=true
      this.loadTable(parmas)
      this.judgeCostVersionLists();
      this.handleChangeDetailType();
    }
  }
</script>
<style>
  .wrap {
    padding:15px;
    background: #ffffff;
    margin: 10px;
  }
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 15px;
    position: relative;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .con-head{
    margin-bottom: 20px;
  }
  .ant-table-tbody table{
    border-top: 1px solid #e8e8e8;
    border-left: 1px solid #e8e8e8;
  }
  .ant-table-tbody > tr > td{
    border-bottom: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
    -webkit-transition: all 0.3s, border 0s;
    transition: all 0.3s, border 0s;
  }
  .ant-table-thead > tr > th{
    border-right: 1px solid #e8e8e8;
  }
  /*.ant-table-thead > tr > th, .ant-table-tbody > tr > td{*/
    /*padding: 8px 16px;*/
  /*}*/
  .ant-table-body table{
    border-left:1px solid #e8e8e8;
    border-top: 1px solid #e8e8e8;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    top:10px;
    right: 25px;
  }
</style>
