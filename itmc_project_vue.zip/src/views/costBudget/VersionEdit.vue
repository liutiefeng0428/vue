<template>
  <div class="wrap">
    <div class="con-title">
      <span class="divdLine"></span>
      <span>编辑{{parseInt(planYear)}}年度费用预算——{{curObj.feeName}}</span>
    </div>
    <div class="common-title">
      <span>基本信息</span>
      <span class="unitText" style="top:10px;right: 15px;position: absolute;">单位：万元</span>
    </div>
    <div class="container">
      <div class="define-table">
        <div class="table-head" style=" border-left: 1px solid #ccc;">
          <!-- <div class="table-item">开支类型</div> -->
          <div class="table-item">项目</div>
          <div class="table-item">{{parseInt(planYear)}}年总预算</div>
          <div class="table-item">具体明细</div>
          <div class="table-item">{{parseInt(planYear) - 1}}年预计完成</div>
          <div class="table-item" style="border-bottom: none; height: 70px;">变化说明</div>
        </div>
        <div class="tbl-rt" style="border-right: 1px solid #ccc;border-right: 1px solid #ccc;">
          <div class="table-rt">
            <div class="table-body">
              <!-- <div class="table-item">{{curObj.feeName}}</div> -->
              <div class="table-item">{{curObj.projectName}}</div>
              <div class="table-item">
                {{curObj.budgetAmount||'0'}}
              </div>
              <div class="table-item" style="display: flex;align-items: center">
                <input class="lastYearBudget ant-input" type="text" v-model="curObj.specificDetails">
              </div>
              <div class="table-item">
               <input class="qymoneyAmout ant-input"  type="text" v-model="curObj.lastYearBudget" style="border-right:none;height: 29px">
              </div>
            </div>
            <div class="table-head">
              <!-- <div class="table-item">项目</div> -->
              <div class="table-item">项目明细</div>
              <div class="table-item">总部优化预算</div>
              <div class="table-item"></div>
              <div class="table-item"></div>
              <!-- <div class="table-item">{{parseInt(planYear) - 1}}优化预算</div> -->
            </div>
            <div class="table-body">
              <!-- <div class="table-item">{{curObj.projectName}}</div> -->
              <div class="table-item">{{curObj.projectDetailsName}}</div>
              <div class="table-item"><input class="qymoneyAmout ant-input"  type="text" v-model="curObj.zbOptimizeMoney"></div>
              <div class="table-item">
               <!-- {{Number(curObj.zbOptimizeMoney)+Number(totalSumAll)}} -->
              </div>
              <div class="table-item"></div>
            </div>
            <div class="table-head">
              <!-- <div class="table-item">项目明细</div> -->
              <div class="table-item">{{parseInt(planYear)}}优化预算</div>
              <div class="table-item">企业分摊</div>
              <div class="table-item"></div>
              <div class="table-item"></div>
            </div>
            <div class="table-body">
              <!-- <div class="table-item" style="border-right:none;">{{curObj.projectDetailsName}}</div> -->
              <div class="table-item" style="border-right:none;">
               {{Number(curObj.zbOptimizeMoney)+Number(curObj.qyOptimizeMoney)}}
              </div>
              <div class="table-item" style="border-right:none;">{{totalSumAll||curObj.qyOptimizeMoney||'0'}}</div>
              <!--<div class="table-item"><input class="qymoneyAmout ant-input"  type="text" v-model="curObj.qyOptimizeMoney"></div>-->
              <div class="table-item" style="border-right:none;"></div>
              <div class="table-item" style="border-right:none;"></div>
            </div>
          </div>

          <div class="table-head" style="border-bottom:none;box-sizing: border-box">
            <textarea name="" id="" cols="30" rows="10" placeholder="请输入变化说明" v-model="curObj.instructions"></textarea>
          </div>
        </div>
      </div>
    </div>
    <div class="common-title">
      <span>内容及工作量</span>
    </div>
    <div class="container">
      <div class="edit_container">
        <quill-editor
          v-model="content"
          ref="myQuillEditor"
          :options="editorOption"
          @blur="onEditorBlur($event)" @focus="onEditorFocus($event)"
          @change="onEditorChange($event)">
        </quill-editor>
      </div>
    </div>
    <div class="common-title">
      <span>费用预算</span>
    </div>
    <div class="container">
      <div class="edit_container">
        <quill-editor
          v-model="contentFY"
          ref="myQuillEditorFY"
          :options="editorOptionFY"
          @blur="onEditorBlurFY($event)" @focus="onEditorFocusFY($event)"
          @change="onEditorChangeFY($event)">
        </quill-editor>
      </div>
    </div>
    <div class="common-title">
      <span>企业分摊</span>
      <a-button type="primary" @click="addTepl()" icon="plus">添加</a-button>
      <a-button type="primary" @click="addTepl()" icon="plus">添加股份</a-button>
      <a-button type="primary"  icon="plus">添加集团</a-button>
      <span class="unitText1" style="top:10px;position: absolute;right: 0">单位：万元</span>
    </div>
    <div class="container">
      <div>
        <a-tabs defaultActiveKey="1" @change="callback">
          <a-tab-pane v-for="(item,index) in infactTabMock"  :tab="item.tabName"  :key="item.tabCode">
          </a-tab-pane>
        </a-tabs>
        <div class="ant-table-content">
          <div class="ant-table-body">
            <table class="" style="width: 100%"><colgroup><col style="width: 120px; min-width: 120px;"><col><col></colgroup>
              <thead class="ant-table-thead">
              <tr>
                <th key="rowIndex" class="ant-table-align-center" style="text-align: center;"><div>序号</div></th>
                <th key="fullName" class="ant-table-align-left" style="text-align: left;"><div>企业名称</div></th>
                <th key="typeCode" class="ant-table-align-left" style="text-align: left;"><div>金额</div></th>
                <th key="enterprisesBasis" class="ant-table-align-left" style="text-align: left;"><div>依据</div></th>
              </tr>
              </thead>
              <tbody class="ant-table-tbody">
              <tr v-for="(itemInner,indexInner) in infactTableMock" v-if="itemInner.parentCode==currentTabCode">
                <td style="text-align: center;"><span class="ant-table-row-indent indent-level-0" style="padding-left: 0px;">{{indexInner+1}}</span>
                </td>
                <td style="text-align: left;">{{itemInner.orgName}}</td>
                <td style="text-align: left;">
                  <div data-orgcode="record">
                    <input type="text" v-model="itemInner.qyMoney" :data-orgcode="itemInner" class="qymoneyAmout ant-input" style="margin: -5px 0px;">
                  </div>
                </td>
                <td style="text-align: left;">
                  <div data-orgcode="record">
                    <input type="text" v-model="itemInner.enterprisesBasis" :data-orgcode="itemInner" class="enterprisesBasis ant-input" style="margin: -5px 0px;">
                  </div>
                </td>
              </tr>
              <tr>
                <td></td>
                <td>合计：</td>
                <td style="text-align: center">{{tabSum}}</td>
                <td></td>
              </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="container" style="text-align: center;margin-top: 20px">
      <div>
        <a-button type="primary" @click="saveEdit()">保存</a-button>
        <a-button @click="goBack()">返回</a-button>
      </div>
    </div>
    <a-modal
      title="添加企业分摊"
      :width="600"
      centered
      v-model="modalVisible"
      @ok="() => initTable()"
      @cancel="() => setModal1Visible(false)"
      okText="确认"
      cancelText="关闭"
    >
      <div>
        <div style="flex: 1">
          <div class="con-title">
            <span class="divdLine"></span>
            <span>请选择企业</span>
          </div>
          <a-tree
            checkable
            @expand="onExpand"
            :expandedKeys="expandedKeys"
            :autoExpandParent="autoExpandParent"
            v-model="checkedKeys"
            @select="onSelect"
            :selectedKeys="selectedKeys"
            :treeData="treeData"
            :loadData="onLoadData"
          />
        </div>
      </div>
    </a-modal>
  </div>
</template>

<script>
  import {quillEditor} from "vue-quill-editor";
  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css';
  import {apiService} from "@/services/apiservice";

  export default {
    name: "ReportAdd",
    components: {
      quillEditor
    },
    data() {
      return {
        loadCurObj:[],
        currentTabCode:"",
        infactTabMock:[],
        loadInfactTabMock:[],
        loadInfactTabMock1:[],
        infactTableMock:[],
        infactTableMock1:[],
        curObj:{},
        dataOrg:[],
        treeData:[],
        checkedKeys: [''],
        checkMock:[],
        planYear:"",
        currentObj:null,
        content: "",
        editorOption: {
          modules:{
            toolbar:[
              ['bold', 'italic', 'underline', 'strike'],
              ['blockquote', 'code-block']
            ]
          },
          placeholder: '请输入内容及工作量',
        },
        contentFY: "",
        editorOptionFY: {
          modules:{
            toolbar:[
              ['bold', 'italic', 'underline', 'strike'],
              ['blockquote', 'code-block']
            ]
          },
          placeholder: '请输入费用预算',
        },
        zbMoney:"",
        budgetAmount:"",
        instructions:"",
        optionDateSelect:"",
        modalVisible:false,
        expandedKeys: [''],
        autoExpandParent: true,
        selectedKeys: [],
        tabSameMock:[],
      }
    },
    watch: {
      curObj(){
      },
      checkedKeys(val,info) {
        let mockQYArr=[]
        for(var i=0;i<val.length;i++){
          let obj={}
          obj.name=val[i]
          obj.id=val[i]
          mockQYArr.push(obj)
        }
        this.mockQY=mockQYArr
      },
    },
    methods: {
      onLoadData (treeNode) {
        let _self=this;
        return new Promise((resolve) => {
          if (treeNode.dataRef.children.length>0) {
            resolve()
            return
          }
          var  nextNode = _self.getUnitByOrgId(treeNode.eventKey,window.dataOrg)
          setTimeout(() => {
            treeNode.dataRef.children = nextNode
            this.treeDataQy = [...this.treeDataQy]
            resolve()
          }, 1000)
        })
      },
      getUnitByOrgId(orgId,dataOrg){
        let  allObj=[]
        var dataOrg=dataOrg
        for (var i = 0; i < dataOrg.length; i++) {
          if (dataOrg[i].orgLevelName == '单位') {
            if (dataOrg[i].parentId == orgId) {
              dataOrg[i].title = dataOrg[i].orgName
              dataOrg[i].key = dataOrg[i].orgId
              allObj.push(dataOrg[i])
            }
          }
        }
        return allObj
      },
      addTepl(){
        this.modalVisible=true
      },
      setModal1Visible(){
        this.modalVisible=false
      },
      onSelect (selectedKeys, info) {
        this.selectedKeys = selectedKeys
      },
      onExpand (expandedKeys) {
        this.expandedKeys = expandedKeys
        this.autoExpandParent = false
      },
      onCheck (checkedKeys) {
        this.checkedKeys = checkedKeys
      },
      saveEdit(){
        let _self=this
        this.curObj.optimizeBudgetAmount=Number(this.curObj.zbOptimizeMoney)+Number(this.curObj.qyOptimizeMoney)
/*        this.curObj.qyOptimizeMoney=this.qyOptimizeMoney
        this.curObj.optimizeBudgetAmount=this.totalSumAllBuggetAmount*/
       /* delete this.curObj['id'];*/
        var parmasData={itmcCostPlan:this.curObj,itmcCostEnterprise:this.infactTableMock}
        parmasData._json=true
        apiService.updateCostBudgetPlan(parmasData).then(r => {
          if(r.result=='0000'){
            _self.$message.success("保存成功")
          }
        }, r => {
        }).catch(
        )
      },
      initTable(){
        this.checkMock=[]  //添加时为空
        for(var j=0;j<this.checkedKeys.length;j++){
          for(var i=0;i<this.dataOrg.length;i++){
            if(this.dataOrg[i].orgId==this.checkedKeys[j]&&this.dataOrg[i].orgLevelName=='单位'){
              this.checkMock.push(this.dataOrg[i])

            }
          }
        }

        this.modalVisible=false
        var tabMock=[]
        tabMock = this.unique(this.checkMock,"parentId");
        var infaltablModckAdd=this.getInfactTabMock(tabMock) //获取实际tab信息
        for(var i=0;i<infaltablModckAdd.length;i++){
          for(var j=0;j<this.checkMock.length;j++){
            if(infaltablModckAdd[i].orgCode==this.checkMock[j].parentCode){
              this.checkMock[j].parentOrgName=infaltablModckAdd[i].orgName
            }
          }
        }

        var orgTab=this.loadInfactTabMock1
        var orgTabel=this.infactTableMock1
        this.infactTableMock=orgTabel.concat(this.checkMock)
        this.infactTabMock=orgTab.concat(infaltablModckAdd)
        this.infactTableMock = this.unique(this.infactTableMock,"orgCode");
        this.infactTabMock = this.unique(this.infactTabMock,"orgCode");
        if(this.infactTabMock.length>0){
          this.currentTabCode=this.infactTabMock[0].tabCode
        }

      },
      getInfactTabMock(arr){
        var infactTabMockAdd=[]
        for(var i=0;i<arr.length;i++){
          for(var j=0;j<this.dataOrg.length;j++){
            if(this.dataOrg[j].orgId ==arr[i].parentId){
              this.dataOrg[j].tabName= this.dataOrg[j].orgName
              this.dataOrg[j].tabCode= this.dataOrg[j].orgCode
              infactTabMockAdd.push(this.dataOrg[j])
              break
            }
          }

        }
        return infactTabMockAdd
      },
      unique(arr, name) { // 根据唯一标识orderId来对数组进行过滤
        var hash = {};
        return arr.reduce(function (item, next) {
          hash[next[name]] ? '' : hash[next[name]] = true && item.push(next);
          return item;
        }, []);
      },
      loadMsg(){
        let _self=this
        this.planYear=this.$route.query.planYear
        if(!this.$route.query.planYear){
          this.planYear=new Date().getFullYear()
        }
        var parmasData={"id":JSON.parse(this.$route.query.current).id}
        parmasData._json=true
        apiService.getCostBudgetProjectDetails(parmasData).then(r => {
          let itmcCostEnterprise=r.itmcCostEnterprise
          if(itmcCostEnterprise.length>0){
            _self.loadInfactTabMock=_self.unique(itmcCostEnterprise,"parentCode");
            for(var i=0;i< _self.loadInfactTabMock.length;i++){
              _self.loadInfactTabMock[i].tabName= _self.loadInfactTabMock[i].parentOrgName
              _self.loadInfactTabMock[i].tabCode= _self.loadInfactTabMock[i].parentCode
            }
            _self.infactTabMock=_self.infactTabMock.concat( _self.loadInfactTabMock)
            _self.loadInfactTabMock1= _self.loadInfactTabMock
            _self.currentTabCode=_self.infactTabMock[0].tabCode

            _self.loadCurObj = r.itmcCostEnterprise
            _self.infactTableMock=_self.infactTableMock.concat(r.itmcCostEnterprise)
            _self.infactTableMock1=_self.loadInfactTabMock
          }

          _self.currentObj=r
          _self.curObj = r.itmcCostPlan   //可删除
          _self.content=r.itmcCostPlan.content
          _self.contentFY=r.itmcCostPlan.measure
        }, r => {
        }).catch(
        )
      },
      goBack(){
        this.$router.go(-1)
      },
      handleChange(a,b,c){
        const newData = [...this.infoData]
        const target = newData.filter(item => key === item.key)[0]
        if (target) {
          target[column] = value
          this.infoData = newData
        }
      },

      loadTable(parmasData){
        let _self = this
        apiService.getDictionaryFList(parmasData).then(r => {
          _self.infoData = r
        }, r => {
        }).catch(
        )
      },
      callback (key) {
        this.currentTabCode=key
      },
      onEditorReady(editor) {

      },
      onEditorBlur(){
      },
      onEditorFocus(){
      },
      onEditorChange(event){
        this.curObj.content=event.html
        this.curObj.contentText=event.text
      },
      onEditorReadyFY(editor) {
      },
      onEditorBlurFY(){
      },
      onEditorFocusFY(){
      },
      onEditorChangeFY(event){
        this.curObj.measure=event.html
        this.curObj.measureText=event.text
      },
    },
    computed: {
      editor() {
        return this.$refs.myQuillEditor.quill;
      },
      tabSum(){
        let tabSum = 0;
        this.infactTableMock.map((item) => {if(!isNaN(item.qyMoney)){if(item.parentCode==this.currentTabCode) tabSum +=parseInt(item.qyMoney) }})
        if(isNaN(tabSum)){
          return 0
        }
        return parseInt(tabSum)
      },
      totalSumAll(){
        let totalSumAll = 0;
        this.infactTableMock.map((item) => { if(!isNaN(item.qyMoney)){totalSumAll +=parseInt(item.qyMoney)} })
        if(isNaN(totalSumAll)){
          return 0
        }
        return parseInt(totalSumAll)
      },
    },
    created(){
      this.loadMsg()
      this.dataOrg=window.dataOrg
      //console.log(window.dataOrg);
      this.treeData.push(window.dataOrg[0])
    }
  }
</script>
<style>
  .wrap {
    padding:15px;
    background: #ffffff;
    margin: 10px;
  }

  .edit_container {
    background: #ffffff;
  }

  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .common-title {
    font-size: 14px;
    font-weight: 700;
    padding: 5px 15px;
    margin: 10px 0 5px 0;
    position: relative;
  }

  .define-table, .table-rt {
    display: flex;
  }

  .define-table {
    border-top: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
  }

  .tbl-rt {
    flex: 7;
  }

  .table-head {
    flex: 1;
  }

  .table-body {
    flex: 2;
  }

  .table-item {
    border-right: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
    color: rgba(0, 0, 0, 0.65);
    padding: 10px;
    height: 42px;
    box-sizing: border-box;
    text-align: center;
  }

  .table-head {
      background: #fafafa;
  }

  .table-item input {
    width: 100%;
    /*border: none;*/
    height: 100%;
    /*outline: none;*/
  }

  .table-head textarea {
    width: 100%;
    height: 70px;
    padding: 10px;
    border: none;
    outline: none;
  }
  .container{
    padding: 0 15px;
  }
  .shareMount{
    float: right;
    top: 0;
    width: 176px;
    position: relative;
    left: 0;
    display: inline-block;
    text-align: right;
  }
  .shareMount .ant-alert-icon {
    top: 3px;
    left: 16px;
    position: absolute;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    right: 25px;
    top:10px
  }
  unitText1{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    right: 25px;
  }
  .qymoneyAmout{
    text-align: center;
  }
</style>
