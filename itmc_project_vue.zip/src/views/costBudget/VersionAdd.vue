<template>
  <div class="wrap">
    <div class="con-title">
      <span class="divdLine"></span>
      <span>编辑年度费用预算</span>
    </div>
    <div class="common-title">
      <span>费用预算信息</span>
    </div>
    <div class="container">
      <div class="define-table">
        <div class="table-head" style=" border-left: 1px solid #ccc;">
          <div class="table-item">项目明细</div>
          <div class="table-item" style=" height:70px;border-bottom: none">变化说明</div>
        </div>
        <div class="tbl-rt" style="border-right: 1px solid #ccc;border-right: 1px solid #ccc;">
          <div class="table-rt">
            <div class="table-body">
              <div class="table-item" style="min-height: 21px">{{editObj.projectDetail}}</div>
            </div>
            <div class="table-head">
              <div class="table-item" style="width: 120px;">2019年预计完成</div>
            </div>
            <div class="table-body">
              <div class="table-item"><a-input size="small" v-model="editObj.estimatedCplt" placeholder="200" /></div>
            </div>
            <div class="table-body">
              <div class="table-item">2020年总预算</div>
            </div>
            <div class="table-head">
              <div class="table-item"><a-input size="small" v-model="editObj.budget" placeholder="200" /></div>
            </div>
            <div class="table-body">
              <div class="table-item">优化预算</div>
            </div>
            <div class="table-head">
              <div class="table-item"><a-input size="small" v-model="editObj.optimized" placeholder="200" /></div>
            </div>
          </div>
          <div class="table-head" style="border-bottom:none;box-sizing: border-box">
            <textarea name="" id="" cols="30" rows="10" placeholder="请输入变化说明" v-model="editObj.explain"></textarea>
          </div>
        </div>
      </div>
    </div>
    <div class="common-title">
      <span>内容及工作量</span>
    </div>
    <div class="container">
      <div class="edit_container">
        <quill-editor
          v-model="content"
          ref="myQuillEditor"
          :options="editorOption"
          @blur="onEditorBlur($event)" @focus="onEditorFocus($event)"
          @change="onEditorChange($event)">
        </quill-editor>
      </div>
    </div>
    <div class="common-title">
      <span>费用报价测算：</span>
    </div>
    <div class="container">
      <div class="edit_container">
        <quill-editor
          v-model="contentFY"
          ref="myQuillEditorFY"
          :options="editorOptionFY"
          @blur="onEditorBlurFY($event)" @focus="onEditorFocusFY($event)"
          @change="onEditorChangeFY($event)">
        </quill-editor>
      </div>
    </div>
    <div class="common-title">
      <span>企业分摊</span>
      <a-button @click="addShare" type="primary" class="saveBtn">添加</a-button>
    </div>
    <div class="container" style="position: relative">
      <div>
        <a-tabs defaultActiveKey="1" @change="callback">
          <a-tab-pane tab="油田" key="1">
            <div class="ant-table-content">
              <div class="ant-table-body">
                <table>
                  <thead class="ant-table-thead">
                  <tr>
                    <th key="rowIndex" class="ant-table-align-left" style="text-align: left;"><div>序号</div></th>
                    <th key="optionName" class="ant-table-align-left" style="text-align: left;"><div>企业名称</div></th>
                    <th key="typeCode" class="ant-table-align-left" style="text-align: left;"><div>金额</div></th>
                    <th key="typeCode" class="ant-table-align-left" style="text-align: left;"><div>操作</div></th>
                  </tr>
                  </thead>
                  <tbody class="ant-table-tbody">
                  <tr class="ant-tr">
                    <td>1</td>
                    <td>11</td>
                    <td><a-input placeholder=" " /></td>
                    <td @click="deleteCurrent()">删除</td>
                  </tr>
                  <tr class="ant-tr">
                    <td></td>
                    <td>合计</td>
                    <td>140</td>
                    <td></td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>

          </a-tab-pane>
          <a-tab-pane tab="炼化" key="2" forceRender>
            <div class="ant-table-content">
              <div class="ant-table-body">
                <table>
                  <thead class="ant-table-thead">
                  <tr>
                    <th key="rowIndex" class="ant-table-align-left" style="text-align: left;"><div>#</div></th>
                    <th key="optionName" class="ant-table-align-left" style="text-align: left;"><div>企业名称</div></th>
                    <th key="typeCode" class="ant-table-align-left" style="text-align: left;"><div>金额</div></th>
                  </tr>
                  </thead>
                  <tbody class="ant-table-tbody">
                  <tr class="ant-tr">
                    <td>11</td>
                    <td>11</td>
                    <td><a-input placeholder=" " /></td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </a-tab-pane>
          <a-tab-pane tab="销售" key="3">
            <div class="ant-table-content">
              <div class="ant-table-body">
                <table>
                  <thead class="ant-table-thead">
                  <tr>
                    <th key="rowIndex" class="ant-table-align-left" style="text-align: left;"><div>#</div></th>
                    <th key="optionName" class="ant-table-align-left" style="text-align: left;"><div>企业名称</div></th>
                    <th key="typeCode" class="ant-table-align-left" style="text-align: left;"><div>金额</div></th>
                  </tr>
                  </thead>
                  <tbody class="ant-table-tbody">
                  <tr class="ant-tr">
                    <td>11</td>
                    <td>11</td>
                    <td><a-input placeholder=" " /></td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </a-tab-pane>
          <a-tab-pane tab="科研" key="4">
            <div class="ant-table-content">
              <div class="ant-table-body">
                <table>
                  <thead class="ant-table-thead">
                  <tr>
                    <th key="rowIndex" class="ant-table-align-left" style="text-align: left;"><div>#</div></th>
                    <th key="optionName" class="ant-table-align-left" style="text-align: left;"><div>企业名称</div></th>
                    <th key="typeCode" class="ant-table-align-left" style="text-align: left;"><div>金额</div></th>
                  </tr>
                  </thead>
                  <tbody class="ant-table-tbody">
                  <tr class="ant-tr">
                    <td>1</td>
                    <td>11</td>
                    <td><a-input placeholder=" " /></td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </a-tab-pane>
        </a-tabs>
      </div>
      <span class="unit">单位：万元</span>
    </div>
    <div class="container" style="margin-top:15px">
      <div class="footerBtn">
        <a-button @click="saveEdit" type="primary" class="saveBtn">保存</a-button>
        <a-button @click="backToDetail">取消</a-button>
      </div>
    </div>
  </div>
</template>

<script>
  import {quillEditor} from "vue-quill-editor"; //调用编辑器
  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css';

  import $ from 'jquery'

  export default {
    name: "VersionAdd",
    components: {
      quillEditor
    },
    data() {
      return {
        editObj:{projectDetail:"",estimatedCplt:"",budget:"",optimized:"",explain:""},
        content: `<p></p>`,
        editorOption: {},
        contentFY: `<p></p>`,
        editorOptionFY: {},
      }
    },
    methods: {
      loadTable(parmasData){
        let _self = this
        //主页table数据
        apiService.getDictionaryFList(parmasData).then(r => {
          _self.infoData = r
        }, r => {
        }).catch(
        )
      },
      callback (key) {
        console.log(key)
      },
      onEditorReady(editor) { // 准备编辑器

      },
      onEditorBlur(){
      }, // 失去焦点事件
      onEditorFocus(){
      }, // 获得焦点事件
      onEditorChange(){
        console.log(this.content)
      }, // 内容改变事件
      onEditorReadyFY(editor) { // 准备编辑器

      },
      onEditorBlurFY(){
      }, // 失去焦点事件
      onEditorFocusFY(){
      }, // 获得焦点事件
      onEditorChangeFY(){
        console.log(this.contentFY)
      }, // 内容改变事件
      saveEdit(){
        console.log(this.editObj)
        console.log(this.content)
        console.log(this.contentFY)
      },
      backToDetail(){
        this.$router.go(-1)
      },
      callback (key) {
        console.log(key)
        var antTr=$(".ant-table-tbody .ant-tr");
        var tab1=[];
        for(var i=0;i<antTr.length;i++){
          var tabTdObj={}
          tabTdObj.projectName=$(antTr[i]).find("td").eq(1).text()
          tabTdObj.projectAmout=$(antTr[i]).find("td input").val()
          tab1.push(tabTdObj)
        }
        console.log(tab1)
      },
      deleteCurrent(){

      },
      addShare(){
          //添加一条tab数据
      }
    },
    computed: {
      editor() {
        return this.$refs.myQuillEditor.quill;
      },
    },
    created(){
//        let id=this.$router.query.id
//      let parmas={}
//      this.loadTable(parmas)
    }
  }
</script>
<style scoped>
  .wrap {
    padding:15px;
    background: #ffffff;
    margin: 10px;
  }

  .edit_container {
    background: #ffffff;
  }

  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #333333;
    display: flex;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: rgb(24, 144, 255);
    height: 20px;
    margin-right: 10px;
  }

  .common-title {
    font-size: 14px;
    font-weight: 700;
    padding: 5px 15px;
    margin: 10px 0 5px 0;
  }

  .define-table, .table-rt {
    display: flex;
  }

  .define-table {
    border-top: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
  }

  .tbl-rt {
    flex: 7;
  }

  .table-head {
    flex: 1;
  }

  .table-body {
    flex:1;
  }

  /*.table-item {*/
    /*border-right: 1px solid #ccc;*/
    /*border-bottom: 1px solid #ccc;*/
    /*padding: 10px;*/
    /*color: rgba(0, 0, 0, 0.65);*/
    /*box-sizing: content-box;*/
    /*justify-content: center;*/
    /*text-align: center;*/
  /*}*/

  .table-head {
    background: #fafafa;
  }

  .table-item input {
    width: 100%;
    border: none;
    height: 100%;
    outline: none;
  }

  .table-head textarea {
    width: 100%;
    height: 70px;
    padding: 10px;
    border: none;
    outline: none;
  }
  .container{
    padding: 0 15px;
  }
  .unit{
    position: absolute;
    right: 30px;
    top:20px;
  }
  .secondBox{
    display: flex;
  }
  .secondItem{
    flex: 1;
    text-align: center;
  }
  .secondItemLf{
    border-right: 1px solid #ccc;
  }
  .table-item input{
    text-align: center;
  }

  .ant-table-body table{
    margin-top: 20px;
    width: 100%;
  }
  .footerBtn{
    text-align: center;
    margin-top: 40px;
  }
  .saveBtn{
    margin-right: 20px;
  }
</style>
