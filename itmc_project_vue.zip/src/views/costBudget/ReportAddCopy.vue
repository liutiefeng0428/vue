<template>
  <div class="wrap">
    <div class="con-title">
      <span>{{projectName}}</span>
    </div>
    <div class="con-head">
      <span>项目名称:</span>
      <span v-if="flag==1">
        <a-select  v-model="projectNameSelText" class="querySelect"  @change="handleChangeDetailType" style="width: 150px">
          <a-select-option v-for="item in projectDetailsList" :key="item.code"> {{item.name}}</a-select-option>
        </a-select>
      </span>
      <span v-if="flag==0">{{projectDetailTypeSelText}}</span>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>年度费用预算</span>
    </div>
    <div>
      <p>
        <span>{{parseInt(planYear)-1}}年: </span>
        <span style="margin-left: 5px;">总部预算</span>
        <input style="width: 150px;" class="LastZbMoney ant-input" type="text" v-model="curObj.lastZbMoney">
        <span>万元</span>
        <span style="margin-left: 20px;">企业分摊</span>
        <input style="width: 150px;" class="LastQyMoney ant-input" type="text" v-model="curObj.lastQyMoney">
        <span>万元</span>
      </p>
      <p>
        <span>{{planYear}}年: </span>
        <span style="margin-left: 5px;">总部预算</span>
        <input style="width: 150px;" class="zbOptimizeMoney ant-input" type="text" v-model="curObj.zbOptimizeMoney">
        <span>万元</span>
        <span style="margin-left: 20px;">企业分摊</span>
        <input style="width: 150px;" class="qyOptimizeMoney ant-input" type="text" v-model="curObj.qyOptimizeMoney">
        <span>万元</span>
      </p>
    </div>
    <div class="con-title" style="position: relative;">
      <span class="divdLine"></span>
      <span>项目明细</span>
      <a-button type="primary"  @click="toAdd()" style="height: 22px !important;margin-left: 15px;padding: 0 8px;line-height: 20px;" icon="plus">添加</a-button>
      <span class="unitText">单位：万元</span>
    </div>
    <div class="container" style="padding: 0">
      <div>
        <div>
          <div class="ant-table">
          </div>
          <div>
            <table id="detailTable" border="1" cellpadding="15" cellspacing="0" style="width: 100%">
              <thead>
                  <tr>　
                      <th class="k150" rowspan="2">项目明细</th>
                      <th class="k100" colspan="2">{{parseInt(planYear)-1}}年</th>
                      <th class="k100" colspan="2">{{planYear}}年</th>
                      <th class="k80" rowspan="2">费用变化</th>　　
                      <th class="k80" rowspan="2">变化说明</th>
                      <th class="k150" rowspan="2">内容及工作量</th>
                      <th class="k150" rowspan="2">费用测算</th>
                      <th class="k100" rowspan="2">处室</th>
                      <th class="k50" rowspan="2">操作</th>
                  </tr>
                  <tr>
                    <th class="k50">预算</th>
                    <th class="k50">预计完成</th>
                    <th class="k50">各处预算</th>　　　　
                    <th class="k50">优化预算</th>　　　　
                 </tr>　
              </thead>
              <tbody>
                  <tr v-for="(item,index) in costDetailsPlanList" :key="index">
                    <td><a-input v-model="item.specificDetails"></a-input></td>
                    <td><a-input v-model="item.lastYearBudget"></a-input></td>
                    <td><a-input @blur="changeAmount(index)" v-model="item.lastYearCompleterBudget"></a-input></td>
                    <td><a-input v-model="item.budgetAmount"></a-input></td>
                    <td><a-input @blur="changeAmount(index)" v-model="item.optimizeBudgetAmount"></a-input></td>
                    <td>{{item.changeAmount}}</td>
                    <td><a-input v-model="item.instructions"></a-input></td>
                    <td><a-input v-model="item.content"></a-input></td>
                    <td><a-input v-model="item.measure"></a-input></td>
                    <td>
                      <a-select :value="item.ouName ? item.ouName : bureausSelText"   @change="(v) => changeBureaus(v, index)"  class="querySelect"  style="width:100%">
                        <a-select-option v-for="item in bureaus" :key="item.bureausCode" name="item.bureaus"> {{item.bureaus}}</a-select-option>
                      </a-select>
                    </td>
                    <td>
                      <!--<a-button  type="primary" style="height: 22px !important;padding: 0 8px;line-height: 10px;width: 45px" @click="doDetele(index)" >删除</a-button>-->
                      <span  @click="doDetele(index)">
                        <a>删除</a>
                      </span>
                    </td>
                  </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <div class="container" style="text-align: right;margin-top: 5px;">

    </div>
    <div class="container" style="text-align: center;margin-top: 20px">
      <div>
        <a-button v-if="flag==0" type="primary" @click="saveEdit()">保存</a-button>
        <a-button v-if="flag==1" type="primary" @click="saveAdd()">保存</a-button>
        <a-button @click="goBack()">返回</a-button>
      </div>
    </div>
  </div>
</template>

<script>

  import {quillEditor} from "vue-quill-editor"; //调用编辑器
  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css';
  import {apiService} from "@/services/apiservice";
  import $ from 'jquery'
  import Vue from 'vue';
  export default {
    name: "ReportAdd",
    components: {
      quillEditor
    },
    data() {
      return {
        curObj:{},
        planYear:"",
        ouId:"",
        version:"",
        bureaus:[],//处室
        bureausSel:"",
        bureausSelText:"",
        projectType:[],//开支类型
        projectTypeSel:"",
        projectTypeSelText:"",
        projectDetailsList:[],//项目名称
        projectNameSel:"",
        projectNameSelText:"",
        zbMoney:"",
        specificDetails:"",
        budgetAmount:"",
        OptimizeBudgetAmount:"",
        qyMoney:"",
        costDetailsPlanList:[{"specificDetails":"","lastYearCompleterBudget":"","lastYearBudget":"","budgetAmount":"","optimizeBudgetAmount":"","instructions":"","content":"","measure":"","ouId":"","ouName":"","changeAmount":""}],
        addDetail:{"specificDetails":"","lastYearCompleterBudget":"","lastYearBudget":"","budgetAmount":"","optimizeBudgetAmount":"","instructions":"","content":"","measure":"","ouId":"","ouName":"","changeAmount":""},
        projectName:"",
        projectId:"",
        feeType:"",
        feeName:"",
        zbOptimizeMoney:"",
        qyOptimizeMoney:"",
        lastQyMoney:"",
        lastZbMoney:"",
        flag:"",
        id:"",
      }
    },
    watch: {
      checkedKeys(val,info) {
        let mockQYArr=[]
        for(var i=0;i<val.length;i++){
          let obj={}
          obj.name=val[i]
          obj.id=val[i]
          mockQYArr.push(obj)
        }
        debugger;
        this.mockQY=mockQYArr

      },
    },
    methods: {
      // 获取处室
      getItmcInfoBureaus(){
        let _self=this
        let projectTypeParmas={}
        projectTypeParmas._json=true
        apiService.getItmcInfoBureaus(projectTypeParmas).then(r => {
          _self.bureaus=r
          _self.bureausSel=r[0].bureausCode
          _self.bureausSelText=r[0].bureaus
        }, r => {
        }).catch(
        )
      },
      // 表格新增一条数据
      toAdd(){
        var length = this.costDetailsPlanList.length
        var addDetail = {"specificDetails":"","lastYearCompleterBudget":"","lastYearBudget":"","budgetAmount":"","optimizeBudgetAmount":"","instructions":"","content":"","measure":"","ouId":"","ouName":"","changeAmount":""}
        Vue.set(this.costDetailsPlanList, length, addDetail);
      },
      doDetele(i){
        this.costDetailsPlanList.splice(i,1);
      },
      getItmcProjectTypeList(parmasData){
        let _self=this
        // let parmasDatas={version:this.version,parentCode:this.projectId};
        apiService.getItmcProjectDetailTypeList(parmasData).then(r => {
          _self.projectDetailsList=r;
          _self.projectNameSelText=_self.projectDetailsList[0].name;
          _self.projectNameSel=_self.projectDetailsList[0].code;
          _self.curObj.projectDetailsType=_self.projectDetailsList[0].code;
          _self.curObj.projectDetailsName=_self.projectDetailsList[0].name;
        }, r => {
        }).catch(
        )
      },
      getCostBudgetProjectDetails(parmasData){
        let _self=this
        // let parmasDatas={version:this.version,parentCode:this.projectId};
        apiService.getCostBudgetProjectDetails(parmasData).then(r => {
          // _self.projectDetailsList=r
          _self.curObj=r.itmcCostPlan;
          _self.costDetailsPlanList=r.itmcCostDetailsPlanList;
        }, r => {
        }).catch(
        )
      },
      handleChangeDetailType(value){
        let _self=this
        var obj=this.projectDetailsList.find(function (obj) {
          return obj.code === value
        })
        _self.projectDetailTypeSel=value
        _self.projectDetailTypeSelText=obj.name
        this.curObj.projectDetailsType=value
        this.curObj.projectDetailsName=obj.name
      },
      changeBureaus(value, index){
        var _self = this
        var obj= _self.bureaus.find(function (obj) {
          return obj.bureausCode === value
        })
       /* var obj = _self.bureaus.find((item) => function(){
          return item.bureausCode === value
        })*/
        this.costDetailsPlanList[index].ouName = obj.bureaus
        this.costDetailsPlanList[index].ouId = obj.bureausCode
        // console.log(this.costDetailsPlanList)
      },
      changeAmount(index){
        var currentDetail = this.costDetailsPlanList[index]
        if(!currentDetail.optimizeBudgetAmount) currentDetail.optimizeBudgetAmount = 0
        if(!currentDetail.lastYearCompleterBudget) currentDetail.lastYearCompleterBudget = 0
        currentDetail.changeAmount = (parseFloat(currentDetail.optimizeBudgetAmount) - parseFloat(currentDetail.lastYearCompleterBudget)).toFixed(2)
      },
      saveAdd(){
        let _self=this
        // this.curObj.lastQyMoney=this.lastQyMoney;
        // this.curObj.lastZbMoney=this.lastZbMoney;
        // this.curObj.zbOptimizeMoney=this.zbOptimizeMoney;
        // this.curObj.qyOptimizeMoney=this.qyOptimizeMoney;
        var lastMenoy=0 ;
        var menoy=0 ;
        var budgetMenoy=0;
        var lastMenoy1=parseFloat(this.curObj.lastQyMoney)+parseFloat(this.curObj.lastZbMoney) ;
        var menoy1=parseFloat(this.curObj.zbOptimizeMoney)+parseFloat(this.curObj.qyOptimizeMoney) ;
        var lastYearCompleterBudget = 0;
        for(var i in _self.costDetailsPlanList){
          lastMenoy+=parseFloat(_self.costDetailsPlanList[i].lastYearBudget);
          menoy+=parseFloat(_self.costDetailsPlanList[i].optimizeBudgetAmount);
          budgetMenoy+=parseFloat(_self.costDetailsPlanList[i].budgetAmount);
          lastYearCompleterBudget+=parseFloat(_self.costDetailsPlanList[i].lastYearCompleterBudget);
        }
        if(lastMenoy != lastMenoy1){
          _self.$message.error((parseInt(this.curObj.planYear)-1)+"年 数据不一致 \n 预算合计不等于总部预算与企业预算之和")
          return;
        }
        if(menoy != menoy1){
          _self.$message.error(this.curObj.planYear+"年 数据不一致 \n 优化预算合计不等于总部预算与企业预算之和")
          return;
        }
        this.curObj.lastYearBudget=lastMenoy1;
        this.curObj.lastYearCompleterBudget=lastYearCompleterBudget;
        this.curObj.optimizeBudgetAmount=menoy1;
        this.curObj.budgetAmount=budgetMenoy;
        var parmasData={itmcCostPlan:this.curObj,itmcCostDetailsPlan:_self.costDetailsPlanList}
        parmasData._json=true
        apiService.saveCostBudgetPlan(parmasData).then(r => {
            if(r.result=='0000'){
              _self.$message.success("保存成功")
              this.$router.go(-1)
            }
            if(r.result=='9999'){
              _self.$message.error(r.msg)
            }
        }, r => {
        }).catch(
        )
      },
      saveEdit(){
        let _self=this
        // this.curObj.lastQyMoney=this.lastQyMoney;
        // this.curObj.lastZbMoney=this.lastZbMoney;
        // this.curObj.zbOptimizeMoney=this.zbOptimizeMoney;
        // this.curObj.qyOptimizeMoney=this.qyOptimizeMoney;
        var lastMenoy=0 ;
        var menoy=0 ;
        var budgetMenoy=0;
        var lastMenoy1=parseFloat(this.curObj.lastQyMoney)+parseFloat(this.curObj.lastZbMoney) ;
        var menoy1=parseFloat(this.curObj.zbOptimizeMoney)+parseFloat(this.curObj.qyOptimizeMoney) ;
        var lastYearCompleterBudget = 0;
        for(var i in _self.costDetailsPlanList){
          lastMenoy+=parseFloat(_self.costDetailsPlanList[i].lastYearBudget);
          menoy+=parseFloat(_self.costDetailsPlanList[i].optimizeBudgetAmount);
          budgetMenoy+=parseFloat(_self.costDetailsPlanList[i].budgetAmount);
          lastYearCompleterBudget+=parseFloat(_self.costDetailsPlanList[i].lastYearCompleterBudget);
        }
        if(lastMenoy != lastMenoy1){
          _self.$message.error((parseInt(this.curObj.planYear)-1)+"年 数据不一致 \n 预算合计不等于总部预算与企业预算之和")
            return;
        }
        if(menoy != menoy1){
          _self.$message.error(this.curObj.planYear+"年 数据不一致 \n 优化预算合计不等于总部预算与企业预算之和")
            return;
        }
        this.curObj.lastYearBudget=lastMenoy1;
        this.curObj.lastYearCompleterBudget=lastYearCompleterBudget;
        this.curObj.optimizeBudgetAmount=menoy1;
        this.curObj.budgetAmount=budgetMenoy;
        var parmasData={itmcCostPlan:this.curObj,itmcCostDetailsPlan:_self.costDetailsPlanList}
        parmasData._json=true
        apiService.updateCostBudgetPlan(parmasData).then(r => {
            if(r.result=='0000'){
              _self.$message.success("保存成功")
              this.$router.go(-1)
            }
            if(r.result=='9999'){
              _self.$message.error(r.msg)
            }
        }, r => {
        }).catch(
        )
      },
      unique(arr, name) { // 根据唯一标识orderId来对数组进行过滤
        var hash = {};
        return arr.reduce(function (item, next) {
          hash[next[name]] ? '' : hash[next[name]] = true && item.push(next);
          return item;
        }, []);
      },
      loadMsg(){
        // this.ouId=this.$route.query.ouId
        var cur = JSON.parse(this.$route.query.current);
        // console.log("cur:"+JSON.parse(cur));
        this.version=cur.version;
        this.planYear=cur.planYear;
        this.projectName=cur.projectName;
        this.projectId=cur.projectId;
        this.feeType=cur.feeType;
        this.feeName=cur.feeName;
        this.flag=this.$route.query.flag;
        if(this.flag==0){
          this.projectDetailTypeSel=cur.projectDetailsType;
          this.projectDetailTypeSelText=cur.projectDetailsName;
          this.id=cur.id;
        }
        this.curObj.version=this.version;
        this.curObj.planYear=this.planYear;
        this.curObj.projectName=this.projectName;
        this.curObj.projectId=this.projectId;
        this.curObj.feeType=this.feeType;
        this.curObj.feeName=this.feeName;
        this.curObj.feePlanStatus=cur.feePlanStatus;

      },
      goBack(){
        this.$router.go(-1)
      },
    },
    computed: {
    },
    created(){
      const _self=this
      this.loadMsg()
      this.getItmcInfoBureaus()
      let projectTypeParmas={"parentCode":_self.projectId,version:_self.version}
      projectTypeParmas._json=true
      this.getItmcProjectTypeList(projectTypeParmas)
      if(this.flag==0){
        let projectParma={"id":_self.id}
        this.getCostBudgetProjectDetails(projectParma);
      }
      // this.addDetail = this.costDetailsPlanList[0]
      // console.log(this.planYear)
    }
  }
</script>
<style>
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    bottom: 0;
    right: 25px;
  }

  .define-table, .table-rt {
    display: flex;
  }

  .define-table {
    border-top: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
  }

  .tbl-rt {
    flex: 7;
  }

  .table-head {
    flex: 1;
  }

  .table-body {
    flex: 2;
  }

  .table-item {
    border-right: 1px solid #ccc;
    border-bottom: 1px solid #ccc;
    padding: 10px;
    color: rgba(0, 0, 0, 0.65);
    height: 45px;
    box-sizing: border-box;
    justify-content: center;
    align-items: center;
    text-align: center;
    display: flex;
  }

  .table-head {
    background: #fafafa;
  }

  .table-item input {
    width: 100%;
    height: 100%;
    outline: none;
  }

  .table-head textarea {
    width: 100%;
    height: 70px;
    padding: 10px;
    border: none;
    outline: none;
  }
  .container{
    padding: 0 15px;
  }
  .qymoneyAmout{
    text-align: center;
  }


  #detailTable {
      width: 100%;
      background: #fff;
      text-align: center;
      border-top: 1px solid #e8e8e8;
      border-left: 1px solid #e8e8e8;
      table-layout: fixed;
  }
  #detailTable tr th,#detailTable tr td{
    font-size: 12px;
    text-align: center;
    padding: 0 0 0 3px !important;

  }
  #detailTable td .ant-input{
    font-size: 12px;
    padding: 4px 2px;
  }
</style>
