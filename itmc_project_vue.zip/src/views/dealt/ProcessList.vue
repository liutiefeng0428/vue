<template>
  <div class="wrap">
    <div class="con-title">
      <span class="divdLine"></span>
      <span>流程列表</span>
    </div>
    <div class="container">
      <div>
        <div class="ant-table-content">
          <div class="ant-table-tbody">
            <table style="width: 100%">
              <thead class="ant-table-thead"><tr>
                <th class="ant-table-align-left" style="text-align: center;"><div>名称</div></th>
                <th class="ant-table-align-left" style="text-align: center;"><div>key</div></th>
                <th class="ant-table-align-left" style="text-align: center;"><div>分类</div></th>
                <th class="ant-table-align-left" style="text-align: center;"><div>版本</div></th>
                <th class="ant-table-align-left" style="text-align: center;"><div>操作</div></th></tr></thead>
              <tbody class="ant-table-tbody">
               <tr v-for="(item,index) in infoData">
                 <td style="text-align: center;">{{item.processDefName}}</td>
                 <td style="text-align: center;">{{item.defKey}}</td>
                 <td style="text-align: center;">{{item.processDepCategory}}</td>
                 <td style="text-align: center;">{{item.processVersion}}</td>
                 <td style="text-align: center;">
                   <a @click="viewProcessDiagram(item)">流程图</a>
                   <a @click="toLimitsApply(item)">流程配置</a>
                 </td>
               </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <a-modal
        title="流程图"
        :width="900"
        v-model="showImg"
        @ok="closeModal"
      >
        <img style="margin-bottom: 20px;" :src="imgUrl">
      </a-modal>
    </div>
  </div>
</template>

<script>
  import reqwest from 'reqwest'
  import {apiService} from "@/services/apiservice";
  export default {
    name: "DealtList",
    components: {
    },
    data() {
      return {
        infoData:[],
        showImg: false,
        imgUrl:'',
      }
    },
    methods: {
      toLimitsApply(item){
          // this.$router.push({path:'/limits-apply',query:{taskId:taskId,processId:processId}})
          this.$router.push({path:'/ky-process',query:{processDefId:item.processId}})
      },
      viewProcessDiagram(item){
          // this.$router.push({path:'/limits-apply',query:{taskId:taskId,processId:processId}})
        this.showImg = true
        this.imgUrl = '/project/processEngine/processDiagram?processDefId=' + item.processId
        //window.location.href='/project/processEngine/processDiagram?processDefId=' + item.processDefId+"&taskId="+item.taskId;
      },
      getProcessList(){
        let _self=this
        var parmasData={}
        parmasData._json=true
        apiService.getProcessList(parmasData).then(r => {
          // console.log(r);
          _self.infoData=r;
        }, r => {
        }).catch(
        )
      },
      closeModal(){
        this.showImg = false
      }
    },
    computed: {

    },
    filters:{
      formatDateTime (inputTime) {
        var cur=  inputTime*1000 //毫秒数转日期
        var date = new Date(cur);
        var y = date.getFullYear();
        var m = date.getMonth() + 1;
        m = m < 10 ? ('0' + m) : m;
        var d = date.getDate();
        d = d < 10 ? ('0' + d) : d;
        var h = date.getHours();
        h = h < 10 ? ('0' + h) : h;
        var minute = date.getMinutes();
        var second = date.getSeconds();
        minute = minute < 10 ? ('0' + minute) : minute;
        second = second < 10 ? ('0' + second) : second;
        return y + '-' + m + '-' + d + ' ' + '　' + h + ':' + minute + ':' + second;
      }
    },
    created(){
      this.getProcessList();
      let parmasData={"processDefId":"dalingTask:2:b5855562-d371-11e9-8b37-847beb28e63b"}
      apiService.getTaskDodeList(parmasData).then(r => {
        console.log(r);
        // _self.infoData=r;
      }, r => {
      }).catch(
      )
    }
  }
</script>
<style>
  .wrap {
    padding: 15px;
    background: #ffffff;
    margin: 10px;
  }
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 15px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .con-head{
    margin-bottom: 20px;
  }
  .ant-table-tbody table{
    border-top: 1px solid #e8e8e8;
    border-left: 1px solid #e8e8e8;
  }
  .ant-table-tbody > tr > td{
    border-bottom: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
    -webkit-transition: all 0.3s, border 0s;
    transition: all 0.3s, border 0s;
  }
  .ant-table-thead > tr > th{
    border-right: 1px solid #e8e8e8;
  }
  /*.ant-table-thead > tr > th, .ant-table-tbody > tr > td{*/
    /*padding: 8px 16px;*/
  /*}*/
</style>
