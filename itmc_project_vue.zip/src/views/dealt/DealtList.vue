<template>
  <div class="wrap">
    <div class="con-title">
      <span class="divdLine"></span>
      <span>待办列表</span>
    </div>
    <div class="container">
      <div>
        <div class="ant-table-content">
          <div class="ant-table-tbody">
            <table style="width: 100%">
              <thead class="ant-table-thead"><tr>
                <th class="ant-table-align-left" style="text-align: center;"><div>节点名称</div></th>
                <th class="ant-table-align-left" style="text-align: center;"><div>审核人</div></th>
                <th class="ant-table-align-left" style="text-align: center;"><div>审核时间</div></th>
                <th class="ant-table-align-left" style="text-align: center;"><div>优先级</div></th>
                <th class="ant-table-align-left" style="text-align: center;"><div>操作</div></th></tr></thead>
              <tbody class="ant-table-tbody">
               <tr v-for="(item,index) in infoData">
                 <td style="text-align: center;">{{item.taskName}}</td>
                 <td style="text-align: center;">{{item.taskAssigin}}</td>
                 <td style="text-align: center;">{{item.startTime || formatDateTime}}</td>
                 <td style="text-align: center;">{{item.priority}}</td>
                 <td style="text-align: center;">
                   <a @click="viewProcessDiagram(item)">流程图</a>
                   <a @click="toLimitsApply(item)">办理任务</a>
                 </td>
               </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <a-modal
        title="流程图"
        :width="900"
        v-model="showImg"
        @ok="closeModal"
      >
        <img style=" margin-bottom: 20px;" :src="imgUrl">
      </a-modal>
    </div>
  </div>
</template>

<script>
  import reqwest from 'reqwest'
  import {apiService} from "@/services/apiservice";
  export default {
    name: "DealtList",
    components: {
    },
    data() {
      return {
        infoData:[],
        showImg: false,
        imgUrl:'',
      }
    },
    methods: {
      toLimitsApply(item){
          // this.$router.push({path:'/limits-apply',query:{taskId:taskId,processId:processId}})
          this.$router.push({path:'/operation-menu',query:{taskId:item.taskId,processId:item.processId,processDefId:item.processDefId,taskName:item.taskName,nodeKey:item.taskDefKey}})
      },
      viewProcessDiagram(item){
          // this.$router.push({path:'/limits-apply',query:{taskId:taskId,processId:processId}})
        this.showImg = true
        this.imgUrl = '/project/processEngine/processDiagram?processDefId=' + item.processDefId+"&taskId="+item.taskId
        //window.location.href='/project/processEngine/processDiagram?processDefId=' + item.processDefId+"&taskId="+item.taskId;
      },
      getUserAuthApplyList(){
        let _self=this
        var parmasData={}
        parmasData._json=true
        apiService.queryTaskList(parmasData).then(r => {
          // console.log(r);
          _self.infoData=r.list;
        }, r => {
        }).catch(
        )
      },
      closeModal(){
        this.showImg = false
      }
    },
    computed: {

    },
    filters:{
      formatDateTime (inputTime) {
        var cur=  inputTime*1000 //毫秒数转日期
        var date = new Date(cur);
        var y = date.getFullYear();
        var m = date.getMonth() + 1;
        m = m < 10 ? ('0' + m) : m;
        var d = date.getDate();
        d = d < 10 ? ('0' + d) : d;
        var h = date.getHours();
        h = h < 10 ? ('0' + h) : h;
        var minute = date.getMinutes();
        var second = date.getSeconds();
        minute = minute < 10 ? ('0' + minute) : minute;
        second = second < 10 ? ('0' + second) : second;
        return y + '-' + m + '-' + d + ' ' + '　' + h + ':' + minute + ':' + second;
      }
    },
    created(){
      this.getUserAuthApplyList()
    }
  }
</script>
<style>
  .wrap {
    padding: 15px;
    background: #ffffff;
    margin: 10px;
  }
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #666666;
    display: flex;
    margin-bottom: 15px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }

  .con-head{
    margin-bottom: 20px;
  }
  .ant-table-tbody table{
    border-top: 1px solid #e8e8e8;
    border-left: 1px solid #e8e8e8;
  }
  .ant-table-tbody > tr > td{
    border-bottom: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
    -webkit-transition: all 0.3s, border 0s;
    transition: all 0.3s, border 0s;
  }
  .ant-table-thead > tr > th{
    border-right: 1px solid #e8e8e8;
  }
  /*.ant-table-thead > tr > th, .ant-table-tbody > tr > td{*/
    /*padding: 8px 16px;*/
  /*}*/
</style>
