<template>
  <div class="wrap">
    <div class="con-head">

      <div id="headSearch" style="display: flex">
        <span>年度</span>
        <a-select
          mode="multiple"
          :size="size"
          placeholder="请选择年份"
          :defaultValue="[optionDate[0].optionName]"
          style="width: 200px"
          @change="handleChangeDate"
        >
          <a-select-option v-for="item in optionDate" :key="item.optionCode">
            {{item.optionName}}

          </a-select-option>
        </a-select>
        <span>关键字搜索</span>
        <span><a-input placeholder="请输入关键字"/></span>
        <span>项目名称</span>
        <span><a-input placeholder="请输入项目名称"/></span>
        <span>合同类型</span>
        <a-select class="querySelect" @change="handleChangeVersion" style="width: 120px">
          <a-select-option v-for="item in optionDate" :key="item.id"> {{item.optionName}}</a-select-option>
        </a-select>
      </div>
    </div>
    <div style="margin:16px 0;">
            <span class="table-page-search-submitButtons">
              <a-button type="primary">查询</a-button>
              <!--<a-button @click="triggerImport()">导入</a-button>-->
            </span>
      <!--<button @click="toAdd" data-v-227ef8f8="" type="button" class="ant-btn ant-btn-primary">-->
      <!--<i class="anticon anticon-plus">-->
      <!--<svg viewBox="64 64 896 896" data-icon="plus" width="1em" height="1em" fill="currentColor"-->
      <!--aria-hidden="true" class="">-->
      <!--<path d="M482 152h60q8 0 8 8v704q0 8-8 8h-60q-8 0-8-8V160q0-8 8-8z"></path>-->
      <!--<path d="M176 474h672q8 0 8 8v60q0 8-8 8H176q-8 0-8-8v-60q0-8 8-8z"></path>-->
      <!--</svg>-->
      <!--</i>-->
      <!--<span>新增</span>-->
      <!--</button>-->
      <button @click="exportToExcel()" data-v-227ef8f8="" type="button" class="ant-btn ant-btn-primary">
        <i class="anticon anticon-import">
          <svg viewBox="64 64 896 896" data-icon="plus" width="1em" height="1em" fill="currentColor"
               aria-hidden="true" class="">
            <path d="M482 152h60q8 0 8 8v704q0 8-8 8h-60q-8 0-8-8V160q0-8 8-8z"></path>
            <path d="M176 474h672q8 0 8 8v60q0 8-8 8H176q-8 0-8-8v-60q0-8 8-8z"></path>
          </svg>
        </i>
        <span>导出</span>
      </button>
    </div>
    <div>
      <!--<a-table :columns="columns" :dataSource="data" bordered>-->
      <!--<template slot="operation" slot-scope="text, record">-->
      <!--<a-popconfirm-->
      <!--title="确定删除?"-->
      <!--@confirm="() => onDelete(record.key)">-->
      <!--<a href="javascript:;">删除</a>-->
      <!--</a-popconfirm>-->
      <!--</template>-->
      <!--</a-table>-->
      <div class="ant-table-content">
        <div class="ant-table-body">
          <table border="1">
            <thead class="ant-table-thead">
            <tr>
              <th v-for="name of json.fieldNames" :key="name">{{name}}</th>
              <th>操作</th>
            </tr>
            </thead>
            <tbody class="ant-table-tbody">
            <template v-for="(tr,index) of json.items">
              <tr v-for="(item,i) of tr.items" :key="index">
                <td v-if="i===0" :rowspan="tr.items.length">{{tr.name}}</td>
                <td v-if="i===0" :rowspan="tr.items.length">{{tr.type}}</td>
                <td v-if="i===0" :rowspan="tr.items.length">{{tr.name}}</td>
                <td v-if="i===0" :rowspan="tr.items.length">{{tr.name}}</td>
                <td v-for="td of item" :key="index+'_'+i">{{td}}</td>
                <td><a>新增</a><a>编辑</a>
                  <a-popconfirm
                    title="确定删除?"
                    @confirm="() => onDelete(index,i)">
                    <a href="javascript:;">删除</a>
                  </a-popconfirm>
                </td>
              </tr>
            </template>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

  //  const columns = [
  //    {
  //      title: '项目名称',
  //      dataIndex: 'optionName',
  //      width: 150,
  //    }, {
  //      title: '总投资',
  //      dataIndex: 'optionName',
  //      width: 150,
  //    }, {
  //      title: '本次申请',
  //      dataIndex: 'optionName',
  //    }, {
  //      title: '累计下达',
  //      dataIndex: 'optionName',
  //    }, {
  //      title: '剩余',
  //      dataIndex: 'optionName',
  //    }, {
  //      title: '建设年限',
  //      dataIndex: 'optionName',
  //    }, {
  //      title: '建设性质',
  //      dataIndex: 'optionName',
  //    }, {
  //      title: '所属平台',
  //      dataIndex: 'optionName',
  //    }, {
  //      title: '建设内容',
  //      dataIndex: 'optionName',
  //    },
  //    {
  //      title: '操作',
  //      dataIndex: 'operation',
  //      scopedSlots: { customRender: 'operation' },
  //      width:100,
  //    }
  //  ];
  //
  //  const data = [
  //    {
  //      "id": 67,
  //      "optionName": "(复核意见/复核驳回)常用语",
  //      "status": 0,
  //      "note": "ff",
  //      "sort": null,
  //      "typeCode": "FHYJBH",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 68,
  //      "optionName": "(复核意见/复核同意)常用语",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "FHYJTY",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 69,
  //      "optionName": "付款单位(中国石化集团资产经营管理有限公司)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "FKDW",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 70,
  //      "optionName": "付款单位(中国石油化工股份有限公司总部机关财务处)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "FKDW",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 71,
  //      "optionName": "付款单位(中国石油化工集团有限公司)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "FKDW",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 72,
  //      "optionName": "付款单位(总部石油化工股份有限公司总部)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "FKDW",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 73,
  //      "optionName": "反馈",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "FKYJ",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 74,
  //      "optionName": "公司性质",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "GSXZ",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 75,
  //      "optionName": "费用合同类型",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "HTLXFY",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 76,
  //      "optionName": "项目合同类型",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "HTLXXM",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 77,
  //      "optionName": "甲方",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "JF",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 78,
  //      "optionName": "计划类型",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "JHLX",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 79,
  //      "optionName": "下拉框年份",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "JHND",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 80,
  //      "optionName": "建设性质",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "JSFL",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 81,
  //      "optionName": "建设意见",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "JSXZ",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 82,
  //      "optionName": "查询合同付款明细-付款单位",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "PayerName",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 83,
  //      "optionName": "软件",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "PFZLYS",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 84,
  //      "optionName": "硬件",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "PFZLYS",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 85,
  //      "optionName": "省份",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "PROVINC",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 86,
  //      "optionName": "省份",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "PROVINCE",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 87,
  //      "optionName": "税码",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "SMD",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 88,
  //      "optionName": "（项目/系统）所属平台",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "SSPT",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 89,
  //      "optionName": "资金使用类型",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "SYLX",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 90,
  //      "optionName": "项目分类",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "XMFL",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 91,
  //      "optionName": "业务部门(项目批复金额表)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "YWBM",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 92,
  //      "optionName": "业务种类(可研批复项目上传文件类型)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "YWZL",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    },
  //    {
  //      "id": 93,
  //      "optionName": "资金类型(项目批复金额表)",
  //      "status": 0,
  //      "note": null,
  //      "sort": null,
  //      "typeCode": "ZJLX",
  //      "optionCode": null,
  //      "creUserId": null,
  //      "creUserName": null,
  //      "creTime": null
  //    }
  //  ];

  export default {
    name: "ContractList",
    data() {
      return {
        optionDate: [],
        optionDateSelect: '',
//        columns,
//        data,
        json: {
          "fieldNames": [
            "项目名称",
            "总批复金额",
            "已用金额",
            "可用金额",
            "合同编号",
            "合同名称",
            "合同类型",
            "合同金额",
            "合同状态",
            "创建时间",
          ],
          "items": [
            {
              "name": "aaaaaa",
              "type": "某某合同",
              "items": [
                [
                  "0.5",
                  "0.0",
                  "-",
                  "-",
                  "-",
                  "-",
                ],
                [
                  "1.0",
                  "0.0",
                  "-",
                  "-",
                  "-",
                  "-",
                ],
                [
                  "1.0",
                  "0.0",
                  "-",
                  "-",
                  "-",
                  "-",
                ],
              ]
            },
            {
              "name": "bbbbbb",
              "type": "某某合同",
              "items": [
                [
                  "0.5",
                  "0.04",
                  "-",
                  "-",
                  "-",
                  "-",
                ],
                [
                  "0.5",
                  "0.04",
                  "-",
                  "-",
                  "-",
                  "-",
                ],
              ]
            }
          ]
        }
      }
    },
    methods: {
      handleChangeVersion(value){
        this.optionDateSelect = value
        console.log(value);
        console.log(this.optionDateSelect);
      },
      onDelete(outerIndex, innerIndex){
        console.log(outerIndex)
        console.log(innerIndex)
      },
    },
    computed: {},
    created(){
      this.optionDate = [
        {
          "id": 399,
          "optionName": "2019",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 1,
          "typeCode": "JHNDS",
          "optionCode": "2019",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 400,
          "optionName": "2020",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 2,
          "typeCode": "JHNDS",
          "optionCode": "2020",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 401,
          "optionName": "2021",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 3,
          "typeCode": "JHNDS",
          "optionCode": "2021",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        }
      ]
    }
  }
</script>
<style>
  .wrap {
    background: #ffffff;
    padding: 20px;
  }

  #headSearch > span {
    margin-left: 10px;
  }

  #headSearch {
    align-items: center;
  }

  .ant-table-tbody > tr > td {
    border: 1px solid #e8e8e8;
  }

  .ant-table-thead > tr > th {
    border-left: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
  }

  .ant-table-thead tr {
    border-top: 1px solid #e8e8e8;
  }
  .ant-table-thead > tr > th, .ant-table-tbody > tr > td{
    padding: 6px 16px;
  }
</style>
