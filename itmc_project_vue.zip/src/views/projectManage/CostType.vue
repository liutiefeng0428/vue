<template>
  <div class="wrap">
    <div class="con-head">

      <div id="headSearch" style="display: flex">
        <span>年度</span>
        <a-select
          mode="multiple"
          :size="size"
          placeholder="请选择年份"
          :defaultValue="[optionDate[0].optionName]"
          style="width: 200px"
          @change="handleChangeDate"
          @popupScroll="popupScroll"
        >
          <a-select-option v-for="item in optionDate" :key="item.optionCode">
            {{item.optionName}}

          </a-select-option>
        </a-select>
        <span>关键字搜索</span>
        <span><a-input placeholder="请输入关键字"/></span>
        <span>开支类型</span>
        <a-select class="querySelect" @change="handleChangeType" style="width: 120px">
          <a-select-option v-for="item in optionDateType" :key="item.id"> {{item.optionName}}</a-select-option>
        </a-select>
        <span>合同类型</span>
        <a-select class="querySelect" @change="handleChangeVersion" style="width: 120px">
          <a-select-option v-for="item in optionDate" :key="item.id"> {{item.optionName}}</a-select-option>
        </a-select>
      </div>
    </div>
    <div style="margin:16px 0;">
            <span class="table-page-search-submitButtons">
              <a-button type="primary">查询</a-button>
              <!--<a-button @click="triggerImport()">导入</a-button>-->
            </span>
      <!--<button @click="toAdd" data-v-227ef8f8="" type="button" class="ant-btn ant-btn-primary">-->
      <!--<i class="anticon anticon-plus">-->
      <!--<svg viewBox="64 64 896 896" data-icon="plus" width="1em" height="1em" fill="currentColor"-->
      <!--aria-hidden="true" class="">-->
      <!--<path d="M482 152h60q8 0 8 8v704q0 8-8 8h-60q-8 0-8-8V160q0-8 8-8z"></path>-->
      <!--<path d="M176 474h672q8 0 8 8v60q0 8-8 8H176q-8 0-8-8v-60q0-8 8-8z"></path>-->
      <!--</svg>-->
      <!--</i>-->
      <!--<span>新增</span>-->
      <!--</button>-->
      <button @click="exportToExcel()" data-v-227ef8f8="" type="button" class="ant-btn ant-btn-primary">
        <i class="anticon anticon-import">
          <svg viewBox="64 64 896 896" data-icon="plus" width="1em" height="1em" fill="currentColor"
               aria-hidden="true" class="">
            <path d="M482 152h60q8 0 8 8v704q0 8-8 8h-60q-8 0-8-8V160q0-8 8-8z"></path>
            <path d="M176 474h672q8 0 8 8v60q0 8-8 8H176q-8 0-8-8v-60q0-8 8-8z"></path>
          </svg>
        </i>
        <span>导出</span>
      </button>
    </div>
    <div>
      <!--<table id="myTable" border="1" cellpadding="15" cellspacing="0">-->
        <!--　　　　-->
        <!--<tr>-->
          <!--&lt;!&ndash;<th>ID</th>&ndash;&gt;　　 　　-->
          <!--<th class="k100">项目名称</th>　　　　-->
          <!--<th class="k100">总批复金额</th>　　 　　-->
          <!--<th class="k100">已用金额</th>　　 　　-->
          <!--<th>可用金额</th>　　　 　　-->
          <!--<th class="k100">合同编号</th>　　　 　　-->
          <!--<th class="k120">合同名称</th>　　　 　　-->
          <!--<th>合同类型</th>-->
          <!--<th>合同金额</th>　　　 　　-->
          <!--<th>合同状态</th>　　　 　　-->
          <!--<th>创建时间</th>　　　 　　-->
          <!--<th class="k120">操作</th>　-->
        <!--</tr>-->
        <!--　　　　-->
        <!--<tr v-for="item in dataT">-->
          <!--　　   　　　　-->
          <!--<td v-if="key!='id'" v-for="(val,key) in item" :rowspan="rowSpanF(key,val)">{{val}}</td>-->
          <!--<td>-->
            <!--<div v-if="item.projectDetail!='小计'&&item.projectDetail!='合计'">-->
              <!--<span @click="toAdd(item)"><a>添加</a></span>-->
              <!--<span @click="toEdit(item)"><a>编辑</a></span>-->
              <!--<span>-->
                            <!--<a-popconfirm-->
                              <!--title="确定删除吗?"-->
                              <!--okText="确定"-->
                              <!--cancelText="取消"-->
                              <!--@confirm="() => deletArr(item)">-->
                              <!--<a href="javascript:;">删除</a>-->
                            <!--</a-popconfirm>-->
                          <!--</span>-->
            <!--</div>-->
          <!--</td>　　　　-->
        <!--</tr>-->
      <!--</table>-->
      <div class="ant-table-content">
        <div class="ant-table-body">
          <table border="1">
            <thead class="ant-table-thead">
            <tr>
              <th v-for="name of json.fieldNames" :key="name">{{name}}</th>
              <th>操作</th>
            </tr>
            </thead>
            <tbody class="ant-table-tbody">
            <template v-for="(tr,index) of json.items">
              <tr v-for="(item,i) of tr.items" :key="index">
                <td v-if="i===0" :rowspan="tr.items.length">{{tr.name}}</td>
                <td v-if="i===0" :rowspan="tr.items.length">{{tr.type}}</td>
                <td v-if="i===0" :rowspan="tr.items.length">{{tr.name}}</td>
                <td v-if="i===0" :rowspan="tr.items.length">{{tr.name}}</td>
                <td v-for="td of item" :key="index+'_'+i">{{td}}</td>
                <td><a>新增</a><a>编辑</a>
                  <a-popconfirm
                    title="确定删除?"
                    @confirm="() => onDelete(index,i)">
                    <a href="javascript:;">删除</a>
                  </a-popconfirm>
                </td>
              </tr>
            </template>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

  export default {
    name: "ContractList",
    data() {
      return {
        optionDate: [],
        optionDateSelect: '',
        optionDateType: [],
        optionDateTypeSelect: '',
        json: {
          "fieldNames": [
            "项目名称",
            "总批复金额",
            "已用金额",
            "可用金额",
            "合同编号",
            "合同名称",
            "合同类型",
            "合同金额",
            "合同状态",
            "创建时间",
          ],
          "items": [
            {
              "name": "aaaaaa",
              "type": "某某合同",
              "items": [
                [
                  "0.5",
                  "0.0",
                  "-",
                  "-",
                  "-",
                  "-",
                ],
                [
                  "1.0",
                  "0.0",
                  "-",
                  "-",
                  "-",
                  "-",
                ],
                [
                  "1.0",
                  "0.0",
                  "-",
                  "-",
                  "-",
                  "-",
                ],
              ]
            },
            {
              "name": "bbbbbb",
              "type": "某某合同",
              "items": [
                [
                  "0.5",
                  "0.04",
                  "-",
                  "-",
                  "-",
                  "-",
                ],
                [
                  "0.5",
                  "0.04",
                  "-",
                  "-",
                  "-",
                  "-",
                ],
              ]
            }
          ]
        }

      }
    },
    methods: {
//      initData(){
//        const that = this;
//        let arry = [];
//        let itemsCopy = JSON.parse(JSON.stringify(that.items));
//        for (let i = 0; i < itemsCopy.length; i++) {
//          for (let j = (i + 1); j < itemsCopy.length; j++) {
//            for (let h in itemsCopy[i]) {
//              for (let k in itemsCopy[j]) {
//                    if (h === k && itemsCopy[i][h] === itemsCopy[j][k]) {
//                      delete  itemsCopy[j][k]
//                }
//              }
//            }
//          }
//          arry.push(itemsCopy[i]);
//        }
//        that.dataT = arry;
//      },
//      rowSpanF: function (key, val) {
//        const that = this;
//        let num = 0;
//        for (let i in that.items) {
//          for (let j in that.items[i]) {
//              if (key === j && val === that.items[i][j]) {
//                  return
//                num++;
//              }
//          }
//        }
//        return num;
//      },
      handleChangeVersion(value){
        this.optionDateSelect = value
        console.log(value);
        console.log(this.optionDateSelect);
      },
      handleChangeType(value){
        this.optionDateTypeSelect = value
        console.log(value);
        console.log(this.optionDateSelect);
      },
    },
    computed: {},
    created(){
      this.optionDate = [
        {
          "id": 399,
          "optionName": "2019",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 1,
          "typeCode": "JHNDS",
          "optionCode": "2019",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 400,
          "optionName": "2020",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 2,
          "typeCode": "JHNDS",
          "optionCode": "2020",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 401,
          "optionName": "2021",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 3,
          "typeCode": "JHNDS",
          "optionCode": "2021",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        }
      ]
      this.optionDateType = [
        {
          "id": 399,
          "optionName": "2019",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 1,
          "typeCode": "JHNDS",
          "optionCode": "2019",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 400,
          "optionName": "2020",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 2,
          "typeCode": "JHNDS",
          "optionCode": "2020",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 401,
          "optionName": "2021",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 3,
          "typeCode": "JHNDS",
          "optionCode": "2021",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        }
      ]

    }
  }
</script>
<style>
  .wrap {
    background: #ffffff;
    padding: 20px;
  }

  #headSearch > span {
    margin-left: 10px;
  }

  #headSearch {
    align-items: center;
  }

  .ant-table-tbody > tr > td {
    border: 1px solid #e8e8e8;
  }

  .ant-table-thead > tr > th {
    border-left: 1px solid #e8e8e8;
    border-right: 1px solid #e8e8e8;
  }

  .ant-table-thead tr {
    border-top: 1px solid #e8e8e8;
  }
  .ant-table-thead > tr > th, .ant-table-tbody > tr > td{
    padding: 6px 16px;
  }
</style>
