<template>
  <div class="wrap">
    <div class="con-head">
      <span>项目名称</span>
      <a-select  @change="handleChangeVersion" style="width: 120px">
        <a-select-option v-for="item in optionDate" :key="item.id"> {{item.optionName}}</a-select-option>
      </a-select>
      <a-button type="primary">查询</a-button>
      <a-button type="primary" @click="backToSumSug">返回</a-button>
    </div>
    <div class="con-title">
      <span class="divdLine"></span>
      <span>项目一处建议计划（版本2.0）</span>
    </div>
    <div class="container tableTitle">
      <div>
        <a-table :columns="columns" :dataSource="infoData" :pagination="{ pageSize: 50 }" >
          <template slot="operation" slot-scope="text, record">
            <a-popconfirm
              title="确定删除?"
              @confirm="() => onDelete(record.key)">
              <a href="javascript:;">删除</a>
            </a-popconfirm>
          </template>
        </a-table>
      </div>
      <div class="tableUnit"><span>单位：万元</span></div>
    </div>
  </div>
</template>

<script>
  const columns = [{
    title: '项目名称',
    dataIndex: 'optionName',
    width: 150,
  }, {
    title: '总投资',
    dataIndex: 'id',
    width: 150,
  }, {
    title: '建议计划',
    dataIndex: 'id',
  }, {
    title: '建设年限',
    dataIndex: 'id',
  }, {
    title: '所属平台',
    dataIndex: 'id',
  }, {
    title: '所属处室',
    dataIndex: 'id',
  }, {
    title: '建设内容',
    dataIndex: 'id',
  },
    {
      title: '操作',
      dataIndex: 'operation',
      scopedSlots: { customRender: 'operation' },
    }
  ];
  export default {
    name: "GatherVersion",
    components: {
    },
    data() {
      return {
        optionDate:[],
        infoData: null,
        columns,
      }
    },
    methods: {
      backToSumSug(){
        this.$router.push({path:'/sum-suggestion',query:{}})
      },
      handleChangeVersion(value){
        this.optionDateSelect=value
        console.log(value);
        console.log(this.optionDateSelect);
      },
      loadTable(parmasData){
        let _self = this
        //主页table数据
        apiService.getDictionaryFList(parmasData).then(r => {
          _self.infoData = r
        }, r => {
        }).catch(
        )
      },
      onDelete(recode){
          console.log(recode)
      },
    },
    computed: {

    },
    created(){
      this.infoData=[
        {
          "id": 67,
          "optionName": "(复核意见/复核驳回)常用语",
          "status": 0,
          "note": "ff",
          "sort": null,
          "typeCode": "FHYJBH",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 68,
          "optionName": "(复核意见/复核同意)常用语",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "FHYJTY",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 69,
          "optionName": "付款单位(中国石化集团资产经营管理有限公司)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "FKDW",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 70,
          "optionName": "付款单位(中国石油化工股份有限公司总部机关财务处)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "FKDW",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 71,
          "optionName": "付款单位(中国石油化工集团有限公司)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "FKDW",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 72,
          "optionName": "付款单位(总部石油化工股份有限公司总部)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "FKDW",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 73,
          "optionName": "反馈",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "FKYJ",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 74,
          "optionName": "公司性质",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "GSXZ",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 75,
          "optionName": "费用合同类型",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "HTLXFY",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 76,
          "optionName": "项目合同类型",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "HTLXXM",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 77,
          "optionName": "甲方",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "JF",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 78,
          "optionName": "计划类型",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "JHLX",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 79,
          "optionName": "下拉框年份",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "JHND",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 80,
          "optionName": "建设性质",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "JSFL",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 81,
          "optionName": "建设意见",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "JSXZ",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 82,
          "optionName": "查询合同付款明细-付款单位",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "PayerName",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 83,
          "optionName": "软件",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "PFZLYS",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 84,
          "optionName": "硬件",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "PFZLYS",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 85,
          "optionName": "省份",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "PROVINC",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 86,
          "optionName": "省份",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "PROVINCE",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 87,
          "optionName": "税码",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "SMD",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 88,
          "optionName": "（项目/系统）所属平台",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "SSPT",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 89,
          "optionName": "资金使用类型",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "SYLX",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 90,
          "optionName": "项目分类",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "XMFL",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 91,
          "optionName": "业务部门(项目批复金额表)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "YWBM",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 92,
          "optionName": "业务种类(可研批复项目上传文件类型)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "YWZL",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 93,
          "optionName": "资金类型(项目批复金额表)",
          "status": 0,
          "note": null,
          "sort": null,
          "typeCode": "ZJLX",
          "optionCode": null,
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        }
      ]
      this.optionDate=[
        {
          "id": 399,
          "optionName": "2019",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 1,
          "typeCode": "JHNDS",
          "optionCode": "2019",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 400,
          "optionName": "2020",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 2,
          "typeCode": "JHNDS",
          "optionCode": "2020",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        },
        {
          "id": 401,
          "optionName": "2021",
          "status": 0,
          "note": "上报与批复下拉框年份",
          "sort": 3,
          "typeCode": "JHNDS",
          "optionCode": "2021",
          "creUserId": null,
          "creUserName": null,
          "creTime": null
        }
      ]
//      let parmas={}
//      this.loadTable(parmas)
    }
  }
</script>
<style>
  .wrap {
    padding: 20px;
    background: #ffffff;
    margin: 10px;
  }
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #333333;
    display: flex;
    margin-bottom: 15px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: rgb(24, 144, 255);
    height: 20px;
    margin-right: 10px;
  }

  .con-head{
    margin-bottom: 20px;
  }
  .ant-table-thead > tr > th, .ant-table-tbody > tr > td{
    padding: 8px 11px;
    border: 1px solid #e8e8e8;
  }
  .tableTitle{
    padding: 20px 0;
    position: relative;
  }
  .tableUnit{
    position: absolute;
    top: 0;
    right: 0;
  }
</style>
