<template>
  <div class="wrap">
    <div style="margin-bottom: 10px;font-weight: 700">编辑建议项目计划</div>
    <div class="container tableTitle" style="padding: 0">
      <div class="con-title" style="margin-bottom: 0">
        <span class="divdLine"></span>
        <span>基本信息</span>
      </div>
      <div class="baseInfoBox">
        <div class="flexItemBox">
          <div class="flexItem flexItemT">项目名称： </div>
          <div class="flexItem flexItemB"><a-input v-model="baseInfo.projectName" style="margin: -5px 0"/> </div>
          <div class="flexItem flexItemT">业务类别：</div>
          <div class="flexItem flexItemB">
            <a-select labelInValue :defaultValue="{key:businesType[0].key }" style="width: 100%" @change="handleChangeType ">
              <a-select-option :value="item.key" v-for="(item,index) in businesType" :key="item.id">{{item.val}}</a-select-option>
            </a-select>
          </div>
          <div class="flexItem flexItemT">业务部门：</div>
          <div class="flexItem flexItemB">
            <a-select labelInValue :defaultValue="{key:businesDep[0].key }" style="width: 100%" @change="handleChangeBusiness">
              <a-select-option :value="item.key" v-for="(item,index) in businesDep" :key="item.id">{{item.val}}</a-select-option>
            </a-select>
          </div>
        </div>
        <div class="flexItemBox">
          <div class="flexItem flexItemT">项目总投资： </div>
          <div class="flexItem flexItemB"><a-input v-model="baseInfo.gross" style="margin: -5px 0"/> </div>
          <div class="flexItem flexItemT">本次申请：</div>
          <div class="flexItem flexItemB"><a-input v-model="baseInfo.apply" style="margin: -5px 0"/> </div>
          <div class="flexItem flexItemT">累计下达：</div>
          <div class="flexItem flexItemB"><a-input v-model="baseInfo.cumulative" style="margin: -5px 0"/></div>
        </div>
        <div class="flexItemBox">
          <div class="flexItem flexItemT">剩余金额： </div>
          <div class="flexItem flexItemB"><a-input v-model="baseInfo.chargeBalance"  style="margin: -5px 0"/> </div>
          <div class="flexItem flexItemT">所属平台</div>
          <div class="flexItem flexItemB">
            <a-select labelInValue :defaultValue="{ key:plateForm[0].key}" style="width: 100%" @change="handleChangePlat">
              <a-select-option :value="item.key" v-for="(item,index) in plateForm" :key="item.id">{{item.val}}</a-select-option>
            </a-select>
          </div>
          <div class="flexItem flexItemT">建设年限</div>
          <div class="flexItem flexItemB">
            <a-range-picker @change="onChange" />
          </div>
        </div>
        <div class="flexItemBox">
          <div class="flexItem flexItemT">项目识别码： </div>
          <div class="flexItem flexItemB"><a-input v-model="baseInfo.identificationCode" style="margin: -5px 0"/> </div>
          <div class="flexItem flexItemT">开工年份：</div>
          <div class="flexItem flexItemB">
            <a-date-picker @change="onChangeDate"  style="width: 100%"/>
          </div>
          <div class="flexItem flexItemT">主管处室：</div>
          <div class="flexItem flexItemB">
            <a-select labelInValue :defaultValue="{key:managerDpt[0].key}" style="width: 100%" @change="handleChange">
              <a-select-option :value="item.key" v-for="(item,index) in managerDpt" :key="item.id">{{item.val}}</a-select-option>
            </a-select>
          </div>
        </div>
      </div>
      <div class="tableUnit"><span>单位：万元</span></div>
    </div>
    <div class="con-title" style="margin:10px 0">
      <span>建设内容</span>
    </div>
    <div class="edit_container">
      <quill-editor
        v-model="content"
        ref="myQuillEditor"
        :options="editorOption"
        @blur="onEditorBlur($event)" @focus="onEditorFocus($event)"
        @change="onEditorChange($event)">
      </quill-editor>
    </div>
    <div class="con-title" style="margin:20px 0">
      <span class="divdLine"></span>
      <span>投资构成</span>
    </div>
    <div class="container">
      <a-table
        :columns="columns"
        :dataSource="data"
        bordered
        size="middle"
      />
    </div>
    <div class="container">
      <div class="footer-btn">
        <a-button @click="saveData()" type="primary" class="btnLeft">保存</a-button>
        <a-button @click="goBack()">返回</a-button>
      </div>
    </div>

  </div>
</template>

<script>
  import {quillEditor} from "vue-quill-editor"; //调用编辑器
  import 'quill/dist/quill.core.css';
  import 'quill/dist/quill.snow.css';
  import 'quill/dist/quill.bubble.css';

  const columns = [
   {
    title: '投资构成',
    dataIndex: 'name',
    key: 'name',
  },
    {
    title: '2020年建议计划',
    children: [{
      title: '总部',
      dataIndex: 'age',
      key: 'age',
//      width: 200,
      sorter: (a, b) => a.age - b.age,
    }, {
      title: '企业',
      children: [
          {
        title: '油田板块',
        dataIndex: 'street',
        key: 'street',
        width: 200,
      },{
        title: '炼化板块',
        dataIndex: 'street',
        key: 'street',
        width: 200,
      },{
        title: '科研板块',
        dataIndex: 'street',
        key: 'street',
        width: 200,
      },  {
        title: '销售板块',
        dataIndex: 'street',
        key: 'street',
        width: 200,
      }, {
        title: '专业公司',
        dataIndex: 'street',
        key: 'street',
        width: 200,
      }, ],
    },{
      title: '小计',
      dataIndex: 'age',
      key: 'age',
//      width: 200,
      sorter: (a, b) => a.age - b.age,
    },],
  },{
      title: '项目总投资',
      children: [{
        title: '总部',
        dataIndex: 'age',
        key: 'age',
//        width: 200,
        sorter: (a, b) => a.age - b.age,
      }, {
        title: '企业',
        children: [
          {
            title: '油田板块',
            dataIndex: 'street',
            key: 'street',
            width: 200,
          },{
            title: '炼化板块',
            dataIndex: 'street',
            key: 'street',
            width: 200,
          },{
            title: '科研板块',
            dataIndex: 'street',
            key: 'street',
            width: 200,
          },  {
            title: '销售板块',
            dataIndex: 'street',
            key: 'street',
            width: 200,
          }, {
            title: '专业公司',
            dataIndex: 'street',
            key: 'street',
            width: 200,
          }, ],
      },{
        title: '小计',
        dataIndex: 'age',
        key: 'age',
//        width: 200,
        sorter: (a, b) => a.age - b.age,
      },],
    },{
      title: '累计下达投资',
      dataIndex: 'name',
      key: 'name',
//      width: 100,
    },{
      title: '剩余投资',
      dataIndex: 'name',
      key: 'name',
//      width: 100,
    },
  ];

  const data = [];
  for (let i = 0; i < 100; i++) {
    data.push({
      key: i,
      name: 'John Brown',
      age: i + 1,
      street: 'Lake Park',
      building: 'C',
      number: 2035,
      companyAddress: 'Lake Street 42',
      companyName: 'SoftLake Co',
      gender: 'M',
    });
  }



  export default {
    name: "NewSubmission",
    components: {
      quillEditor
    },
    data() {
      return {
        editorOption: {},
        content: `<p>中卫十二号卫星（东经87.5度）Ku频段转发器20MHz频段租用</p><p>中卫十二号卫星（东经87.5度）Ku频段转发器20MHz频段租用</p>`,
        baseInfo:{projectName:"",gross:"",apply:"",cumulative:"",chargeBalance:"",identificationCode:""},
        businesDep:[{key:"one",val:"部门1"},{key:"two",val:"部门2"},{key:"three",val:"部门3"}],
        businesDepSel:null,
        plateForm:[{key:"one",val:"平台1"},{key:"two",val:"平台2"},{key:"three",val:"平台3"}],
        plateFormSel:null,
        businesType:[{key:"one",val:"类型1"},{key:"two",val:"类型2"},{key:"three",val:"类型3"}],
        businesTypeSel:null,
        managerDpt:[{key:"one",val:"处室1"},{key:"two",val:"处室2"},{key:"three",val:"处室3"}],
        managerDptSel:null,
        data,
        columns,
      }
    },
    methods: {
      handleChangeBusiness(value){
        this.businesDepSel=value
      },
      handleChangeType(value){
        this.businesTypeSel=value
      },
      handleChangePlat(value){
        this.plateFormSel=value
      },
      handleChangeManagerDpt(value){
        this.managerDptSel=value
      },
      handleChange(value) {
        console.log(value);
      },
      onChange(date, dateString) {
        console.log(date, dateString);
      },
      onChangeDate(date,dateString){
         console.log(date)
        console.log(date, dateString);
      },
      onEditorReady(editor) { // 准备编辑器

      },
      onEditorBlur(){
      }, // 失去焦点事件
      onEditorFocus(){
      }, // 获得焦点事件
      onEditorChange(){
        console.log(this.content)
      }, // 内容改变事件
      loadTable(parmasData){
        let _self = this
        //主页table数据
        apiService.getDictionaryFList(parmasData).then(r => {
          _self.infoData = r
        }, r => {
        }).catch(
        )
      },
      saveData(){
          console.log(this.baseInfo)
          console.log(this.businesDepSel)
          console.log(this.plateFormSel)
          console.log(this.businesTypeSel)
          console.log(this.managerDptSel)
          console.log(this.content)
      },
      goBack(){
        this.$router.push({path:"/submission-plan"})
      }
    },
    computed: {
      editor() {
        return this.$refs.myQuillEditor.quill;
      },
    },
    created(){
        //默认选中
       this.businesDepSel=this.businesDep[0]
       this.plateFormSel=this.plateForm[0]
       this.businesTypeSel=this.businesType[0]
       this.managerDptSel=this.managerDpt[0]


//      let parmas={}
//      this.loadTable(parmas)
    }
  }
</script>
<style>
  .wrap {
    padding: 20px;
    background: #ffffff;
    margin: 10px;
  }
  .con-title {
    font-size: 14px;
    font-weight: 700;
    color: #333333;
    display: flex;
    margin-bottom: 15px;
  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: rgb(24, 144, 255);
    height: 20px;
    margin-right: 10px;
  }

  .baseInfoBox{
    margin-top: 20px;
  }
  .flexItemBox{
    display: flex;
    text-align: left;
    border-left: 1px solid #e8e8e8;
    border-top: 1px solid #e8e8e8;
  }
  .flexItem{
    padding: 10px;
    border-right: 1px solid #e8e8e8;
    border-bottom: 1px solid #e8e8e8;
  }
  .flexItemT{
    text-align: right;
    flex: 1;
  }
  .flexItemB{
    flex:2;
  }
  .tableTitle{
    position: relative;
  }
  .tableUnit{
    position: absolute;
    right: 0;
    top: 0;
  }
  .footer-btn{
    text-align: center;
    margin: 20px;
  }
  .btnLeft{
    margin-right: 20px;
  }
</style>
