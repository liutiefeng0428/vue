/**
 * Created by Think on 2019/6/26.
 */
import PlanForm from '@/components/operation/PlanForm'
import CostForm from '@/components/operation/CostForm'
export const commonCom = {
  PlanForm,
  CostForm,
}
