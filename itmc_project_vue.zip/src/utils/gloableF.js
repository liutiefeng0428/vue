/**
 * 全局方法添加
 */
import Blob from '../assets/js/Blob'
import Export2Excel from '../assets/js/Export2Excel'
function exportToExcel (tHeader,filterVal,tableData) {
  //excel数据导出
  require.ensure([], () => {
    const {
      export_json_to_excel
    } = require('../assets/js/Export2Excel');
    const tHeader = ['合同名称', '合同金额','合同编号','甲方'];
    const filterVal = [ 'contractName', 'contractNotTaxAmount','contractCode','partyA'] ;
    const list = tableData;
    const data = formatJson(filterVal, list);
    export_json_to_excel(tHeader, data, '合同列表');
  })
}
function formatJson (filterVal, jsonData) {
  return jsonData.map(v => filterVal.map(j => v[j]))
}
export default {
  exportToExcel,
}
