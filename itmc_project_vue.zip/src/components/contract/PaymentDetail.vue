<template>
  <div>
    <div style="margin-bottom: 10px">
      <a-button v-if="!isEdit" @click="showPayModal" class="ant-btn ant-btn-primary">付款</a-button>
    </div>
    <div>
      <div>
        <a-table ref="deleteMore" :pagination="false" bordered :columns="columns" :dataSource="paymentDetail" :rowSelection="rowSelection" rowKey="uuid">
          <span slot="action" slot-scope="text, record, index">
            <a @click="doAdd(record,text,index)">添加</a>
            <a v-if="index" @click="doDelete(record,text,index)">删除</a>
          </span>
          <span v-if="isEdit" slot="paymentAmount" slot-scope="text, record, index">
            <a-input v-model="record.paymentAmount" />
          </span>
          <span v-if="isEdit" slot="paymentRatio" slot-scope="text, record, index">
            <a-input v-model="record.paymentRatio" />
          </span>
          <span v-if="isEdit" slot="paymentCondition" slot-scope="text, record, index">
            <a-input v-model="record.paymentCondition" />
          </span>
          <span v-if="isEdit" slot="remarks" slot-scope="text, record, index">
            <a-input v-model="record.remarks"/>
          </span>
        </a-table>
      </div>
      <span class="">合计：{{totalSum}}</span>
    </div>
    <!-- 付款确认模态框 -->
    <a-modal
      title="付款确认"
      :width="900"
      centered
      :footer="null"
      v-model="payModal">
      <div>
        <div style="flex: 1">
          <div>
            <span>单位:</span>
            <a-select :value=optionDepartSelect class="querySelect" @change="handleChangeDepart" style="width:300px">
              <a-select-option v-for="item in optionDepart" :key="item.optionCode"> {{item.optionName}}</a-select-option>
            </a-select>
          </div>
          <div style="margin-top: 10px">
            <div class="ant-table-content">
              <div class="ant-table-body">
                <table style="width: 100%">
                  <thead class="ant-table-thead">
                  <tr>
                    <th class=""></th>
                    <th class=""><div>付款条件</div></th>
                    <th class=""><div>合同总金额</div></th>
                    <th class=""><div>合同剩余金额</div></th>
                    <th class=""><div>条款金额</div></th>
                    <th class=""><div>投资构成</div></th>
                    <th class=""><div>金额</div></th>
                    <th class=""><div>付款金额</div></th>
                    <th class=""><div>付款内容</div></th>
                  </tr>
                  </thead>
                  <tbody class="ant-table-tbody">
                  <!--<tr>-->
                    <!--<td>{{item.replyName}}1</td>-->
                    <!--<td>{{item.totalAmount}}2</td>-->
                    <!--<td>{{item.serviceName}}3</td>-->
                    <!--<td>{{item.taxCode}}4</td>-->
                    <!--<td>{{item.amount}}5</td>-->
                    <!--<td>{{item.serviceName}}3</td>-->
                    <!--<td>{{item.taxCode}}4</td>-->
                    <!--<td>{{item.amount}}5</td>-->
                  <!--</tr>-->
                  <!--<tr>-->
                    <!--<td>{{item.replyName}}1</td>-->
                    <!--<td>{{item.totalAmount}}2</td>-->
                    <!--<td>{{item.serviceName}}3</td>-->
                    <!--<td>{{item.taxCode}}4</td>-->
                    <!--<td>{{item.amount}}5</td>-->
                    <!--<td>{{item.serviceName}}3</td>-->
                    <!--<td>{{item.taxCode}}4</td>-->
                    <!--<td>{{item.amount}}5</td>-->
                  <!--</tr>-->
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div style="margin-top: 20px">
            <a-button @click="createBill()" class="ant-btn ant-btn-primary">服务确认 </a-button>
            <a-button @click="fuWuDianJi()" class="ant-btn ant-btn-primary">创建报销单</a-button>
            <a-button @click="goBack()" class="ant-btn ant-btn-primary">返回</a-button>
          </div>
        </div>
      </div>
    </a-modal>
  </div>
</template>
<script>
const columns_paymentDetail = [
  {
    title: '状态',
    dataIndex: 'stateName',
  }, {
    title: '金额',
    dataIndex: 'paymentAmount',
    scopedSlots: { customRender: 'paymentAmount' }
  }, {
    title: '比例（%）',
    dataIndex: 'paymentRatio',
    scopedSlots: { customRender: 'paymentRatio' }
  }, {
    title: '付款条件',
    dataIndex: 'paymentCondition',
    scopedSlots: { customRender: 'paymentCondition' }
  }, {
    title: '备注',
    dataIndex: 'remarks',
    scopedSlots: { customRender: 'remarks' }
  }, {
    title: '操作',
    dataIndex: 'action',
    key: 'action',
    scopedSlots: { customRender: 'action' },
  }
];

import {apiService} from "@/services/apiservice";
import store from '@/store';
import Vue from 'vue';
export default {
    name: "PaymentDetail",
    data () {
        return {
            columns: columns_paymentDetail,
            selectedRowKeys: [], 
            payModal:false, // 付款确认模态框
            selectedRows: [], // 模态框中选中的行数据
            optionDepart:[],
            optionDepartSelect:"",
        }
    },
    props: ['isEdit','contractId','contractType','paymentDetail','outuuid'],
    computed: {
      rowSelection() {
        const { selectedRowKeys } = this;
        return {
          onChange: (selectedRowKeys, selectedRows) => {
            this.selectedRows = selectedRows;
          }
        }
      },
      totalSum: function(){
        var money = 0;
        for(var i=0; i<this.paymentDetail.length; i++){
          money += parseFloat(this.paymentDetail[i].paymentAmount);
        }
        return money;
      }
    },
    // watch: {
    //   // 如果 `question` 发生改变，这个函数就会运行
    //   question: function (newQuestion, oldQuestion) {
    //     this.answer = 'Waiting for you to stop typing...'
    //     this.debouncedGetAnswer()
    //   }
    // },
    mounted(){
      // if(!this.isEdit) columns_paymentDetail.splice((columns_paymentDetail.length-1), 1);
      if(!this.isEdit){
        columns_paymentDetail.splice((columns_paymentDetail.length-1), 1);
        for(var i=0; i<columns_paymentDetail.length; i++){
          if(columns_paymentDetail[i].scopedSlots){
            columns_paymentDetail[i].scopedSlots = ''
          }
        }
      }
    },
    methods: {
        reset() {
        },
        doDelete(record,text,index){
          this.paymentDetail.splice(index, 1);
        },
        doAdd(record,text,index){
          var source = Object.assign({},record);
          source.uuid = this.outuuid();
          source.paymentAmount = 0;
          source.paymentRatio = '';
          source.paymentCondition = '';
          source.remarks = '';
          this.paymentDetail.splice(index+1, 0, source);
        },
        onSelectChange (selectedRowKeys) {
          console.log('selectedRowKeys changed: ', selectedRowKeys);
          this.selectedRowKeys = selectedRowKeys
        },
        handleChangeDepart(val){
          this.optionDepartSelect=val
        },
        showPayModal(){
          this.payModal=true
          console.log(this.selectedRowKeys);
          let parmas={typeCode:"PayerName",dictionaryCode:""}
          this.getPayerNameFormDic(parmas);
          console.log(this.selectedRows);
        },
        getPayerNameFormDic(parmasData){
          let _self=this
          apiService.getPayerNameFormDic(parmasData).then(r => {
              if(r.status=='200'){
                _self.optionDepart=r.data
                // _self.optionDepartSelect=r.data[0].optionCode
              }
          }, r => {
          }).catch(
          )
        },
        createBill(){
          let _self=this
          let parmasData={contractId:contractId}
          parmasData._json=true
          apiService.createBill(parmasData).then(r => {
            if(r.status=='200'){
              _self.$message.success("确认成功")
            }
          }, r => {
          }).catch(
          )
        },
        fuWuDianJi(){
          let _self=this
          let parmasData={}
          parmasData._json=true
          apiService.fuWuDianJi(parmasData).then(r => {
            if(r.status=='200'){
              _self.$message.success("报销单创建成功")
            }
          }, r => {
          }).catch(
          )
        },
        goBack(){
          this.$router.go(-1)
        },
    }
}
</script>