<template>
  <div>
    <div style="margin-bottom: 10px">
      <a-button v-if="isEdit" @click="showSelectModal" class="ant-btn ant-btn-primary">选择</a-button>
      <a-button v-if="isEdit" @click="showAddModal" class="ant-btn ant-btn-primary">添加</a-button>
    </div>
    <div>
      <div>
        <!-- <a-table bordered :columns="columns" :dataSource="contractAssetsDetail">
        </a-table> -->
        <div class="ant-table-content">
          <div class="ant-table-body">
            <table style="width: 100%">
              <thead class="ant-table-thead">
              <tr>
                <th style="width: 50px;" class=""><div>序号</div></th>
                <th class=""><div>种类</div></th>
                <th class=""><div>类型名称</div></th>
                <th class=""><div>配置名称</div></th>
                <th class=""><div>产品名称/型号</div></th>
                <th class=""><div>单价</div></th>
                <th class=""><div>数量（台、套）</div></th>
                <th class=""><div>总价</div></th>
                <th style="width: 50px;" v-if="isEdit" class=""><div>操作</div></th>
              </tr>
              </thead>
              <tbody class="ant-table-tbody" v-if="!isEdit">
                <tr v-if="contractAssetsDetail.length>0" v-for="(item,index) in contractAssetsDetail">
                  <td>{{index+1}}</td>
                  <td>{{item.assetsType}}</td>
                  <td>{{item.assetsTypeName}}</td>
                  <td>{{item.configureName}}</td>
                  <td>{{item.productName}}</td>
                  <td>{{item.unitPrice}}</td>
                  <td>{{item.number}}</td>
                  <td>{{item.totalPrice}}</td>
                </tr>
                <tr>
                  <td colspan="7" style="text-align: right;">资金金额小计：</td>
                  <td>11</td>
                </tr>
                <tr>
                  <td colspan="5" style="text-align: right;">集成费（设备价的%）：</td>
                  <td>11</td>
                  <td style="text-align: right;">金额</td>
                  <td>11</td>
                </tr>
                <tr>
                  <td colspan="7" style="text-align: right;">合同最终价：</td>
                  <td>11</td>
                </tr>
              </tbody>
              <tbody class="ant-table-tbody" v-if="isEdit">
                <tr v-if="contractAssetsDetail.length>0" v-for="(item,index) in contractAssetsDetail">
                  <td>{{index+1}}</td>
                  <td>{{item.assetsType}}</td>
                  <td>
                    <a-input v-model="item.assetsTypeName" />
                  </td>
                  <td>
                    <a-input v-model="item.configureName" />
                  </td>
                  <td>
                    <a-input v-model="item.productName" />
                  </td>
                  <td>
                    <a-input v-model="item.unitPrice" />
                  </td>
                  <td>
                    <a-input v-model="item.number" />
                  </td>
                  <td>
                    <a-input v-model="item.totalPrice" />
                  </td>
                  <td>
                    <a @click="doDelete(index)">删除</a>
                  </td>
                </tr>
                <tr>
                  <td colspan="7" style="text-align: right;">资金金额小计：</td>
                  <td colspan="2">11</td>
                </tr>
                <tr>
                  <td colspan="5" style="text-align: right;">集成费（设备价的%）：</td>
                  <td>11</td>
                  <td style="text-align: right;">金额</td>
                  <td colspan="2">11</td>
                </tr>
                <tr>
                  <td colspan="7" style="text-align: right;">合同最终价：</td>
                  <td colspan="2">11</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <!-- 选择模态框 -->
    <a-modal
      title="选择设备"
      :width="900"
      centered
      :footer="null"
      :height="400"
      v-model="selectModal">
      <div>
        <div id="affixTableBox">
          <div id="affixTableTree">
          <div >
            <span class="demandline"></span>
            <span class="demandtitle">设备分类</span>
          </div>
            <div id="affixTreeList" class="ztree mt10" style="border: none;">
              {{treeData}}
              <a-tree
                showLine
                :treeData="treeData"
              />
            </div>
          </div>
          <div id="affixTableData">
            <div class="table-page-search-wrapper">
              <a-form layout="inline">
                <div>
                  <a-form-item label="设备名称">
                    <a-input placeholder="请输入设备名称" />
                  </a-form-item>
                  <a-form-item label="产品名称">
                    <a-input placeholder="产品名称"/>
                  </a-form-item>
                  <a-form-item>
                  <span class="table-page-search-submitButtons">
                    <a-button type="primary" icon="search">查询</a-button>
                  </span>
                  </a-form-item>
                </div>
              </a-form>
            </div>
            <div class="con-title">
              <span class="unitText" style="bottom: -15px;">单位：万元</span>
            </div>
            <div id="affixTableList">
              <div>
                <a-table ref="deleteMore" :pagination="false" bordered :columns="columns_deviceList" :dataSource="deviceListData" :rowSelection="rowSelection" rowKey="id">
                </a-table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </a-modal>
    <!-- 添加模态框 -->
    <a-modal
      :width="900"
      centered
      :footer="null"
      v-model="addModal">
      <div>
      </div>
    </a-modal>
  </div>
</template>
<script>
const columns_assetsDetail = [
  {
    title: '种类',
    dataIndex: 'assetsType',
  }, {
    title: '类型名称',
    dataIndex: 'assetsTypeName',
  }, {
    title: '配置名称',
    dataIndex: 'configureName',
  }, {
    title: '产品名称/型号',
    dataIndex: 'productName',
  }, {
    title: '单价',
    dataIndex: 'unitPrice',
  }, {
    title: '数量（台、套）',
    dataIndex: 'number',
  }, {
    title: '总价',
    dataIndex: 'totalPrice',
  }
];
const columns_deviceList = [
  {
    title: '配置名称',
    dataIndex: 'deviceConfig',
  }, {
    title: '产品名称',
    dataIndex: 'deviceName',
  }, {
    title: '品牌',
    dataIndex: 'pinPai',
  }, {
    title: '型号',
    dataIndex: 'deviceModel',
  }, {
    title: '价格',
    dataIndex: 'unitPrice',
  }
];
import {apiService} from "@/services/apiservice";
import store from '@/store';
import Vue from 'vue';
export default {
    name: "AmountDetail",
    data () {
        return {
            columns: columns_assetsDetail,
            columns_deviceList: columns_deviceList,
            deviceListData: [],
            // data: data,
            // isEdit: true,
            selectedRowKeys: [], 
            selectedRows:[],
            optionDepart:[],
            optionDepartSelect:"",
            selectModal:false,
            addModal:false,
            treeList:{},
            treeData: [
              { title: '硬件分类', key: '0'},
              { title: '软件分类', key: '1'},
            ],
            equipmentData:[],
            softwareData:[],
        }
    },
    props: ['isEdit','contractId','contractType','contractAssetsDetail'],
    computed: {
      rowSelection() {
        const { selectedRowKeys } = this;
        return {
          onChange: (selectedRowKeys, selectedRows) => {
            this.selectedRows = selectedRows;
          }
        }
      },
    },
    mounted(){
    },
    methods: {
        reset() {
        },
        doDelete(record,text,index){
          console.log(record);
          console.log(text);
          this.data.splice(index, 1);
        },
        doAdd(key,text,index){
          const num = this.data[(this.data.length - 1)].key;
          this.data.push({
            key: (parseInt(num)+1),
            stateName: 'John Brown',
            paymentAmount: '随意',
            paymentRatio: 'New York',
            paymentCondition: 'New York',
            remarks: 'New York',
          })
          console.log(this.data);
        },
        onSelectChange (selectedRowKeys) {
          console.log('selectedRowKeys changed: ', selectedRowKeys);
          this.selectedRowKeys = selectedRowKeys
        },
        handleChangeDepart(val){
          this.optionDepartSelect=val
        },
        showSelectModal(){
          this.selectModal=true
          this.getItmcInvestmentDevicetypeList()
          let parmas={contractId:"b788df05-6ae2-4f1b-9945-d77b03839085",amountIds:"3363c9b46d374861ac31ee967a41c397"}
        },
        showAddModal(){
          this.selectModal=true
          let parmas={contractId:"b788df05-6ae2-4f1b-9945-d77b03839085",amountIds:"3363c9b46d374861ac31ee967a41c397"}
        },
        getItmcInvestmentDevicetypeList(){
          let _self=this
          let parmasData={deviceType:0, deviceTypeId:''}
          apiService.getItmcInvestmentDevicetypeList(parmasData).then(r => {
            _self.treeList = {...r}
            var equipmentData = r.investmentEquipmenttypeList[0].deviceTypeList;
            for(var i=0; i<equipmentData.length; i++){ // 循环二级列表
              var equipmentDataChildren = [],
                  equipmentChildrenList = equipmentData[i].deviceTypeList; // 三层列表
              _self.equipmentData.push({
                title:equipmentData[i].deviceTypeName,
                key:equipmentData[i].deviceTypeId,
                children: equipmentDataChildren,
              });
              if(equipmentChildrenList){
                for(var j=0; j<equipmentChildrenList.length; j++){
                  equipmentDataChildren.push({
                    title:equipmentChildrenList[j].deviceTypeName,
                    key:equipmentChildrenList[j].deviceTypeId,
                  })
                }
              }
            }
            console.log(_self.equipmentData);
            _self.treeData[0].children = _self.equipmentData;
            console.log(_self.treeData);
          }, r => {
          }).catch(
          )
        },
        goBack(){
          this.$router.go(-1)
        }
    }
}
</script>
<style>
    #affixTableBox {
      display: flex;
      height: 100%;
    }
    #affixTableTree {
      padding-right: 10px;
      width: 23%;
      overflow-x: hidden;
      border-right: 1px solid #EDEDED;
    }
    #affixTableData {
      width: 77%;
      padding: 10px;
      flex: 1;
    }
    .demandline {
      border-right: 6px solid #409EFF;
      height: 20px;
    }
    .demandtitle {
      font-size: 14px;
      font-weight: bold;
      margin-left: 10px;
    }
    #affixTableList{
      overflow:  scroll;
      overflow-x:hidden;
      height:200px;
      border:1px solid #ddd;
      border-left:none;
    }
    #affixTableList .table tbody tr td{
      overflow: hidden;
      text-overflow:ellipsis;
      white-space: nowrap;
    }
</style>