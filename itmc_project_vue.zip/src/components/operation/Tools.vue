<template>
     <div class="operationToolsBox">
        <div class="operation-con">
          <div class="operation-btngroup">
            <a-button v-if="btnApprove == '0'" type="primary" icon="save" @click="submitObj">提交</a-button>
            <a-button v-if="btnTransfer == '0'" type="default" icon="save" @click="">转办</a-button>
            <a-button type="default" icon="save" @click="goback">返回</a-button>
          </div>
          <div>
            <div>
              <div class="tools-header-line" style="cursor: pointer">
                <span><a-icon type="credit-card"/></span>
                <span>去向：</span>
              </div>
            </div>
          </div>
          <div v-if="segmentArr.length!=0" class="toolWrap">
            <a-radio-group @change="getwhere" :defaultValue="1">
              <a-radio :style="radioStyle" :value="item.name"  v-for="(item,index) in segmentArr"  :key="item.id">{{item.name}}</a-radio>
            </a-radio-group>
          </div>
          <div>
            <div>
              <div class="tools-header-line" style="cursor: pointer">
                <span><a-icon type="credit-card"/></span>
                <span>即将进入下一环节：{{parameter}}</span>
              </div>
            </div>
          </div>
          <div>
            <div>
              <div class="tools-header-line" style="cursor: pointer">
                <span><a-icon type="credit-card"/></span>
                <span>下一环节办理人：</span>
              </div>
            </div>
          </div>
          <div class="toolWrap">
            <div style="display:flex;">
              <span class="showTerName ecllipsis">
                <a-tooltip placement="top" >
                  <template slot="title">
                    <span>{{segmentSelName}}</span>
                  </template>
                 {{segmentSelName}}
                </a-tooltip>
              </span>
              <a-button type="primary" @click="getNodeAuditorList(true)">选择</a-button>
            </div>
          </div>
          <div>
            <div>
              <div class="tools-header-line">
                <span><a-icon type="credit-card"/></span>
                <span>处理意见：</span>
              </div>
            </div>
          </div>
          <div class="toolWrap radioGroup">
            <a-radio-group name="radioGroup" :defaultValue="1"  @change="onChangeResolution">
              <a-radio :value="1">同意</a-radio>
              <a-radio :value="0">退回</a-radio>
            </a-radio-group>
          </div>
          <div v-if="isSendBack">
            <div>
              <div>
                <div class="tools-header-line">
                  <span><a-icon type="credit-card"/></span>
                  <span>选择退回意见：</span>
                </div>
              </div>
            </div>
            <div class="toolWrap radioGroup">
              <a-radio-group name="radioGroup" :defaultValue="0"  @change="onChangeResTo">
                <a-radio :value="0">驳回(上一节点)</a-radio>
                <a-radio :value="1">驳回(指定节点)</a-radio>
                <!--<a-radio :value="2">驳回(发起人)</a-radio>-->
              </a-radio-group>
            </div>
            <div v-if="isBackSpecifiedNode">
              <div>
                <div class="tools-header-line" style="cursor: pointer">
                  <span><a-icon type="credit-card"/></span>
                  <span>退回节点：{{targetName}}</span>
                </div>
              </div>
            </div>
          </div>
<!--          <div class="toolWrap">
            <a-select :value=optionComwordsSelect class="querySelect" @change="handleChangeComwords" style="width:100%">
              <a-select-option v-for="item in optionComwords" :key="item.optionCode"> {{item.optionName}}</a-select-option>
            </a-select>
          </div>-->
          <div class="toolWrap">
            <a-textarea placeholder="请填写意见" :rows="4" v-model="optionComwordsSelect"/>
          </div>
          <div v-if="mailNotice=='0'">
            <div>
              <div class="tools-header-line">
                <span><a-icon type="credit-card"/></span>
                <span>是否通知知会人？</span>
              </div>
            </div>
          </div>
          <div v-if="mailNotice=='0'" class="toolWrap radioGroup">
            <a-radio-group name="radioGroup" :defaultValue="1"  @change="onChangeTermName">
              <a-radio :value="1">是</a-radio>
              <a-radio :value="0">否</a-radio>
            </a-radio-group>
          </div>
<!--          <div v-if="referenceDataTermName" class="toolWrap">
            <div style="display:flex;">
              <span class="showTerName ecllipsis">
                <a-tooltip placement="top" >
                  <template slot="title">
                    <span>{{terNameSelect}}</span>
                  </template>
                 {{terNameSelect}}
                </a-tooltip>
              </span>
              <a-button type="primary" @click="setReferenceModal(true)">选择</a-button>
            </div>
          </div>-->
        </div>
       <a-modal
         title="选择办理人"
         :width="800"
         centered
         v-model="segmentModal"
         @ok="() => confirmSegmentVisible()"
         @cancel="() => setsegmentVisible(false)"
         okText="确认"
         cancelText="关闭"
       >
         <div>
           <div style="flex: 1;min-height: 200px">
             <div class="con-title">
               <span class="divdLine"></span>
               <span>选择办理人</span>
             </div>
             <div>
               <table style="width: 100%" class="elTable">
                 <thead class="ant-table-thead">
                 <tr>
                   <th class="" style="text-align: center"><div>办理人</div></th>
                   <th class="" style="text-align: center"><div>角色</div></th>
                 </tr>
                 </thead>
                 <tbody class="ant-table-tbody">
                 <tr v-for="(item,index) in NodeAuditorList" @click="getNodeAuditor(index,item)">
                   <td style="text-align: center">{{item.reviewerName}}</td>
                   <td style="text-align: center">{{item.jobName}}</td>
                 </tr>
                 </tbody>
               </table>
             </div>
           </div>
         </div>
       </a-modal>
       <a-modal
         title="退回选择活动节点列表"
         :width="800"
         centered
         v-model="elNodeModal"
         @ok="() => setModal1Visible(true)"
         @cancel="() => setModal1Visible(false)"
         okText="确认"
         cancelText="关闭"
       >
         <div>
           <div style="flex: 1;min-height: 200px">
             <div class="con-title">
               <span class="divdLine"></span>
               <span>选择活动节点</span>
             </div>
             <div>
               <table style="width: 100%" class="elTable">
                 <thead class="ant-table-thead">
                 <tr>
                   <th class=""  style="text-align: center"><div>节点名称</div></th>
                   <th class=""  style="text-align: center"><div>节点用户</div></th>
                 </tr>
                 </thead>
                 <tbody class="ant-table-tbody">
<!--                  <tr>
                    <td>1</td>
                    <td>1</td>
                  </tr>-->
                  <tr v-for="(item,index) in historicalTaskNodeList" @click="onHistoricalTaskNode(index,item)">
                    <td style="text-align: center">{{item.name}}</td>
                    <td style="text-align: center">{{item.assignee}}</td>
                  </tr>
                 </tbody>
               </table>
             </div>
           </div>
         </div>
       </a-modal>
       <a-modal
         title="选择知会人"
         :width="1000"
         centered
         v-model="referenceModel"
         @ok="() => confrimReferenceModal()"
         @cancel="() => setReferenceModal(false)"
         okText="确认"
         cancelText="关闭"
       >
         <div>
           <div style="flex: 1">
             <div class="con-title">
               <span class="divdLine"></span>
               <span>请选择知会人</span>
             </div>
             <div>
               <div class="reference-boxs">
<!--                 <div class="reference-boxs-item">
                   <div class="reference-boxs-item-title"><span>组织结构</span></div>
                   <div class="reference-boxs-item-con">
                     <a-tree
                       checkable
                       :treeData="treeData"
                     />
                   </div>
                 </div>-->
                 <div class="reference-boxs-item">
                   <div class="reference-boxs-item-title"><span>可选人员</span></div>
                   <div class="reference-boxs-item-con">
                     <table style="width: 100%">
                       <thead class="ant-table-thead">
                       <tr>
                         <th>用户id</th>
                         <th>姓名</th>
                       </tr>
                       </thead>
                       <tbody class="ant-table-tbody">
                         <tr v-for="(item,index) in list" :class="item.check?'active':''" :data-index="index"  @click="setListCheck(index,item.id)">
                           <td>{{item.label}}</td>
                           <td>{{item.label}}</td>
                         </tr>
                       </tbody>
                     </table>
                   </div>
                 </div>
                 <div class="operBox">
                   <div>
                     <div class="operBtn" @click="handlerRight()"><a-icon type="right-square"/></div>
                     <div class="operBtn" @click="handlerLeft"><a-icon type="left-square"/></div>
                   </div>
                 </div>
                 <div class="reference-boxs-item">
                   <div class="reference-boxs-item-title"><span>已选人员</span></div>
                   <div class="reference-boxs-item-con">
                     <table style="width: 100%">
                       <thead class="ant-table-thead">
                       <tr>
                         <th>用户id</th>
                         <th>姓名</th>
                       </tr>
                       </thead>
                       <tbody class="ant-table-tbody">
                       <tr v-for="(item,index) in list1" :class="item.check1?'active1':''" :data-index="index"  @click="setListCheck1(index,item.id)">
                         <td>{{item.label}}</td>
                         <td>{{item.label}}</td>
                       </tr>
                       </tbody>
                     </table>
                   </div>
                 </div>
               </div>
             </div>
           </div>
         </div>
       </a-modal>
       <a-drawer
         title="操作"
         :width="700"
         @close="onClose"
         :visible="visible"
         :wrapStyle="{height: 'calc(100% - 108px)',overflow: 'auto',paddingBottom: '108px'}"
       >
         <div style="margin-bottom: 40px">
           <div>
             <div class="con-title">
               <span class="divdLine"></span>
               <span>请选择办理人</span>
             </div>
             <a-tree
               checkable
               @expand="onExpand"
               :expandedKeys="expandedKeys"
               v-model="checkedKeys"
               @select="onSelect"
               :selectedKeys="selectedKeys"
               :treeData="treeData"
             />
           </div>
           <!--          <div style="flex: 1">
                       <div class="con-title">
                         <span class="divdLine"></span>
                         <span>请选择企业</span>
                       </div>
                       <a-tree
                         checkable
                         @expand="onExpandQy"
                         v-model="checkedKeysQy"
                         @select="onSelectQy"
                         :selectedKeys="selectedKeysQy"
                         :treeData="treeDataQy"
                         :loadData="onLoadData"
                       />
                     </div>-->
         </div>
         <div
           :style="{
          position: 'absolute',
          left: 0,
          bottom: 0,
          width: '100%',
          borderTop: '1px solid #e9e9e9',
          padding: '10px 16px',
          background: '#fff',
          textAlign: 'right',
        }"
         >
           <a-button
             :style="{marginRight: '8px'}"
             @click="onClose"
           >
             取消
           </a-button>
           <a-button @click="downEdtpl" type="primary">下载</a-button>
         </div>
       </a-drawer>
     </div>
</template>

<script>
  import {apiService} from "@/services/apiservice";
  export default {
    name: "Tools",
    props:['labelCol','wrapperCol'],
    components: {

    },
    data () {
      return {
        taskId:"",
        btnApprove:"0",
        mailNotice:"0",
        btnTransfer:"1",
        processId:"",
        processDefId:"",
        taskName:"",
        exclusivegateway:"",
        node:"",
        segmentSelName:"请选择办理人",
        assignee:"",
        transactorList:[],//办理人
        NodeAuditorList:[],//节点审核人列表
        historicalTaskNodeList:[],//历史任务节点
        segmentArr:[],
        parameter:"",
        targetKey:"",//退回节点显示
        targetName:"",//退回节点显示
        isBack:true,//true为退回到发起人，false为退回到指定节点
        isBackSpecifiedNode:false,
        segmentModal:false,
        isSendBack:false,
        optionComwords:[{optionName:"意见有歧义",optionCode:"1"},{optionName:"请各部门参与会签",optionCode:"2"}],
        optionComwordsSelect:"",
        elNodeModal:false,
        referenceModel:false,
        referenceDataTermName:true,
        terNameSelect:"请选择知会人",
        showTimeline:true,
        radioStyle: {
          display: 'block',
          height: '30px',
          lineHeight: '30px',
        },
        treeData:[{
          title: '测试',
          key: '0-0',
          children: [{
            title: '测试1',
            key: '0-0-0',
            children: [
              { title: '测试2', key: '0-0-0-0' },
              { title: '测试3', key: '0-0-0-1' },
              { title: '测试4', key: '0-0-0-2' },
            ],
          }, {
            title: '测试10',
            key: '0-0-1',
            children: [
              { title: '测试11', key: '0-0-1-0' },
              { title: '测试12', key: '0-0-1-1' },
              { title: '测试13', key: '0-0-1-2' },
            ],
          }, {
            title: '测试14',
            key: '0-0-2',
          }],
        },],
        list: [
          {id:6, label: '苹果',check:false,check1:false},
          {id:7, label: '香蕉',check:false,check1:false},
          {id:8, label: '橘子',check:false,check1:false}
        ],
        list1: [
          {id:1, label: '1苹果',check:false,check1:false},
          {id:2, label: '1香蕉',check:false,check1:false},
          {id:3, label: '1橘子',check:false,check1:false}
        ],
        operationObj:{
            type:"退回",
            instrution:"退回说明理由"
        }
      }
    },
    created () {
      this.taskId = this.$route.query.taskId;
      this.processId=this.$route.query.processId;
      this.processDefId=this.$route.query.processDefId;
      this.taskName=this.$route.query.taskName;
      this.onChangeDirection();
      let parmasData={procDefKey:this.processDefId,nodeId:this.$route.query.nodeKey};
      this.getProcessNodeConfiguration(parmasData);
      // this.getNodeAuditor();
      // this.optionComwordsSelect=this.optionComwords[0].optionName
    },
    methods: {
      loadData(){
        var _self = this
        var parmasData = "typeCode=JHNDS"
        apiService.getDictionary1(parmasData).then(r => {
          _self.optionDate = r
          _self.optionDateSelect = _self.optionDate[0].optionCode
        }, r => {
        }).catch(

        )
      },
      getProcessNodeConfiguration(parmasData){

        apiService.getProcessNodeConfiguration(parmasData).then(r => {
          debugger;
          if(r.hasOwnProperty("btnApprove")){
            this.btnApprove=r.btnApprove;
          }
          if(r.hasOwnProperty("btnTransfer")){
            this.btnTransfer=r.btnTransfer;
          }
          if(r.hasOwnProperty("btnReject")){
            this.btnReject=r.btnReject;
          }
          if(r.hasOwnProperty("lastNode")){
            this.lastNode=r.lastNode;
          }
          if(r.hasOwnProperty("directionNode")){
            this.directionNode=r.directionNode;
          }
          if(r.hasOwnProperty("originateNode")){
            this.originateNode=r.originateNode;
          }
          if(r.hasOwnProperty("mailNotice")){
            this.mailNotice=r.mailNotice;
          }
          if(r.hasOwnProperty("time")){
            this.time=r.time;
          }
          this.reviewerList=r.actNodeAuditorList;
          // this.reviwer="1";

          // console.log(">>>"+r);
          // _self.projectDetailsList=r
          // _self.taskDodeList=r.userTaskList;

        }, r => {
        }).catch(
        )
      },
      submitObj(){
          //this.$emit('submitObj',this.operationObj)
        if(this.node == 'ExclusiveGateway'){
          if(this.segmentSel == ''){
            this.$message.error("请选择去向");
            return;
          }
        }
        if(this.segmentSelName=='请选择办理人'){
          this.$message.error("请选择办理人");
          return;
        }
        let _self = this
        //审核结果1：同意  ， 0为不同意
        let flag=1
        if(this.isSendBack){
          flag=0
          //退回指定节点
          let parmasData ={taskId:this.taskId,targetKey:this.targetKey ,message:this.optionComwordsSelect,flag:this.isBack}
          // console.log("parmasData:"+parmasData);
          parmasData._json=true
          apiService.rollbaskTask(parmasData).then(r => {
            // _self.optionDate = r
            // _self.optionDateSelect = _self.optionDate[0].optionCode
          }, r => {
          }).catch(

          )
        }else{
          //提交下一步审核
          let parmasData ={taskId:this.taskId,parameter:this.parameter ,assignee:this.assignee,message:this.optionComwordsSelect}
          // console.log("parmasData:"+parmasData);
          parmasData._json=true
          apiService.complete(parmasData).then(r => {
            // _self.optionDate = r
            // _self.optionDateSelect = _self.optionDate[0].optionCode
          }, r => {
          }).catch(

          )
        }
        // this.taskId='1231231';

      },
      getNodeAuditorList(e){
        this.segmentModal=e;
        let parmasData ={
          procDefKey:this.processDefId,//流程定义ID
          nodeName:this.taskName//节点名称
                          }
        apiService.getNodeAuditorList(parmasData).then(r => {
          this.NodeAuditorList=r;
        }, r => {
        }).catch(

        )
      },
      getHistoricalTaskNodeList(){

        let parmasData ={
          procDefId:"f0ad8fb2-c7cd-11e9-99d7-847beb28e63b",//流程定义ID
          nodeName:""//节点名称
        }
        apiService.getHistoricalTaskNodeList(parmasData).then(r => {
          this.historicalTaskNodeList=r;
        }, r => {
        }).catch(

        )
      },
      getNodeAuditor(index,itmc){
        this.segmentSelName = itmc.reviewerName;
        this.assignee = itmc.reviewerId;
      },
      onHistoricalTaskNode(index,itmc){
        this.targetName = itmc.name;
        this.targetKey = itmc.taskDefinitionKey;

      },
      //处理意见
      onChangeResolution(e){
        if(!e.target.value){
          this.isSendBack=true
        }else{
          this.isSendBack=false
        }
      },
      //查询已完成任务节点
      onChangeResTo(e){
        if(!e.target.value){
          this.isBack = true;
          this.elNodeModal=false
        }else{
          this.isBack = false;
          this.elNodeModal=true;
          let parmasData ={
            proInstanceId:"f0ad8fb2-c7cd-11e9-99d7-847beb28e63b",//流程定义ID
            nodeName:""//节点名称
          }
          apiService.getHistoricalTaskNodeList(parmasData).then(r => {
            this.historicalTaskNodeList=r;
          }, r => {
          }).catch(

          )
        }
      },
      onChangeTermName(e){
        if(e.target.value){
          this.referenceDataTermName=true
        }else{
          this.referenceDataTermName=false
        }
      },
      onChangeDirection(e){
        // console.log('radio checked', e.target.value)
        let parmasData ={taskId:this.taskId}
        apiService.nextNodeInformation(parmasData).then(r => {
          // console.log(r);
          this.segmentArr=r.list;
          this.node=r.node;
          if(this.node=='userTask'){
            this.parameter=r.name;
          }else if(this.node=='EndEvent'){
            this.parameter="任务结束";
          }

        }, r => {
        }).catch(

        )
      },
      getwhere(e){
        // console.log('radio checked', e.target);
        this.exclusivegateway=e.target.value;
        this.parameter = e.target.value;
      },
      goback(){
        this.$router.go(-1)
      },
      setModal1Visible(flag){
        if(flag){
          this.isBackSpecifiedNode=true;
        }else{
          this.isBackSpecifiedNode=false;
        }
        this.elNodeModal=false
      },
      setsegmentVisible(){
        this.segmentModal=false;
        this.segmentSelName='已选择的办理人'
      },
      confirmSegmentVisible(){
        this.segmentModal=false
        // this.segmentSelName='已选择的办理人'
      },
      handleChangeComwords(value){
        var obj=this.optionComwords.find( (obj) =>{
          return obj.optionCode === value
        })
        this.optionComwordsSelect=obj.optionName
      },
      setReferenceModal(type){
          this.referenceModel=type
      },
/*      setSegmentModal(){
        this.segmentModal=true;
        let parmasData={};
        apiService.getTransactorList(parmasData).then(r => {
          // console.log(r);
          this.transactorList=r;
        }, r => {
        }).catch(

        )
      },*/
      confrimReferenceModal(){
        this.referenceModel=false
        this.terNameSelect=""
        this.list1.forEach((item,index)=>{
          this.terNameSelect+=item.label+","
        })
        this.terNameSelect=this.terNameSelect.slice(0,-1)
      },
      setListCheck (idx) {
        var check = this.list[idx].check;
        this.list[idx].check = !check;
      },
      setListCheck1(idx){
        var check1 = this.list1[idx].check1;
        this.list1[idx].check1 = !check1;
      },
      handlerRight(){
        let _self=this
        console.log("_self:"+_self);
        var selecArr=[]
        this.list.map(function(v){
            if(v.check){
              selecArr.push(v)
            }
        });
       for(var i=0;i<this.list.length;i++){
           for(var j=0;j<selecArr.length;j++){
               if(this.list[i].id==selecArr[j].id){
                 this.list.splice(i,1)
                 this.list.check=false
               }
           }
       }
        this.list1=this.list1.concat(selecArr)
      },
      handlerLeft(){
        let _self=this
        var selecArr=[]
        this.list1.map(function(v){
          if(v.check1){
            selecArr.push(v)
          }
        });
        for(var i=0;i<this.list1.length;i++){
          for(var j=0;j<selecArr.length;j++){
            if(this.list1[i].id==selecArr[j].id){
              this.list1.splice(i,1)
            }
          }
        }
        this.list=this.list.concat(selecArr)
      },

    },
    watch: {

    }
  }
</script>
<style>
  .wrap {
    margin: 10px;
    border-left: 1px solid rgb(232, 232, 232);
    padding: 20px;
    background: #fff;
    box-shadow: 0 1px 6px rgba(0,0,0,.2);
    margin-right: 350px;
  }
  .operationToolsBox{
    position: absolute;
    height: 91%;
    width: 300px;
    top:75px;
    right: 20px;
    overflow: scroll;
    background: #ffffff;
  }
  .operationToolsBox::-webkit-scrollbar {/*滚动条整体样式*/
    width: 5px;     /*高宽分别对应横竖滚动条的尺寸*/
    height: 1px;
  }

  .operationToolsBox::-webkit-scrollbar-thumb {/*滚动条里面小方块*/

    border-radius: 5px;

    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);

    background: #535353;

  }

  .operationToolsBox::-webkit-scrollbar-track {/*滚动条里面轨道*/

    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);

    border-radius: 10px;

    background: #EDEDED;

  }
  .tools-header-line{
    padding: 20px 10px 10px 10px;
    border-bottom: 1px solid  #d9d9d9;
    color: #657180;
    font-size: 12px;
  }
  .operation-btngroup{
    margin: 10px;
    margin-bottom: 0;
  }

  .toolWrap{
    padding: 10px;
  }
  .showTerName{
    display: inline-block;
    width: 200px;
    border: 1px solid #d9d9d9;
    height: 28px;
    color: #999;
    border-radius: 3px;
    border-left: 1px solid rgb(232, 232, 232);
  }
  .reference-boxs{
    display: flex;
    padding: 5px 0;
  }
  .reference-boxs-item{
    /*flex: 1;*/
    width: 300px;
    border: 1px solid #d9d9d9;
    margin-left:5px;
  }
  .reference-boxs-item-title{
    padding: 5px;
    background: #e8e8e8;
  }
  .reference-boxs-item-con{
    padding: 5px;
    min-height: 200px;
  }
  .reference-boxs-item-con table,.elTable{
    border-left: 1px solid #e8e8e8;
    border-top: 1px solid #e8e8e8;
  }
  .operBox{
    display: flex;
    align-items: center;
    margin-left: 5px;
  }
  .operBtn{
    cursor: pointer;
  }
  .active{
    background: #e6f7ff;
  }
  .active1{
    background: #e6f7ff;
  }
  .reference-boxs table tr{
    cursor: pointer;
  }
  .no-top-border{
    color: #657180;
  }
  .clearfix{
    display: flex;
    color: #C3CBD6;
  }
  .ivu-form-item-label-lg{
    display: inline-block;
    width: 30px;
  }
  .ivu-form-item-label-lg img{
    width: 100%;
    height: 100%;
  }
  .time{
    border-right: 1px solid #e8e8e8;
    padding: 5px;
    margin-right: 5px;
  }
</style>
