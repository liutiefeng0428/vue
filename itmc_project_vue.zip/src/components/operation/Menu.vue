<template>
  <div class="wrapAppl" style="margin-right:330px">
    <form-component :dataInfo="dataInfo" :FormType="FormType"></form-component>
    <tools :labelCol="labelCol" :wrapperCol="wrapperCol" @submitObj="submitObj" ></tools>
  </div>
</template>

<script>
  import Tools from './Tools'
  import FormComponent from  './FormComponent'
  export default {
    name: "Menu",
    components: {
      Tools,
      FormComponent
    },
    data () {
      return {
        right:0,
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 12 },
        },
//        list: [
//          {id:6, label: '苹果',check:false,check1:false},
//          {id:7, label: '香蕉',check:false,check1:false},
//          {id:8, label: '橘子',check:false,check1:false}
//        ],
        tableData:"",
        taskId:"",
        processId:"",
        FormType:"PlanForm",
//        FormType:"CostForm",
        dataInfo:{"id":"ce7e5432061e4559b47a2d2bc3d35f87","planYear":"2019","belongPlat":"生产营运平台","constrNature":"新开","projectName":"中国石化集团公司票据池及专项功能提升项目","projectContent":"加强对集团商业汇票管控，充分发挥非银行金融机构优势，深化财务公司核心系统作为集团公司资金集中管理平台的作用，实现企业应收应付票据纳入集团资金集中管理，为集团公司总部和所属企业提供优质高效的票据池管理服务，降低企业票据使用成本，深化电子票据系统应用，跟踪纸质票据交付和托管过程，优化集团公司票据流转和结算的流程","approvalNum":"中石化【2020】","businessArea":"电子商务","versionsName":"测试","versionsState":"12234","constarYear":null,"conendYear":null,"conYear":null,"investmentChannel":"B01","totalZbSort":9.0,"totalZbHardware":9.0,"totalZbService":9.0,"totalZbOther":9.0,"totalQySort":9.0,"totalQyHardware":9.0,"totalQyService":9.0,"totalQyOther":9.0,"totalSum":99.0,"nyZbSort":9.0,"nyZbHardware":9.0,"nyZbService":9.0,"nyZbOther":9.0,"nyQylhSort":9.0,"nyQylhHardware":9.0,"nyQylhService":9.0,"nyQylhOther":9.0,"nyQyytSort":9.0,"nyQyytHardware":9.0,"nyQyytService":9.0,"nyQyytOther":9.0,"nyQyxsSort":9.0,"nyQyxsHardware":9.0,"nyQyxsService":9.0,"nyQyxsOther":9.0,"nyQykySort":9.0,"nyQykyHardware":9.0,"nyQykyService":9.0,"nyQykyOther":9.0,"nyQyzySort":9.0,"nyQyzyHardware":9.0,"nyQyzyService":9.0,"nyQyzyOther":9.0,"remark":"测试股份","nyTotalSum":99.0,"lyZbSort":9.0,"lyZbHardware":9.0,"lyZbService":9.0,"lyZbOther":9.0,"lyQySort":9.0,"lyQyHardware":9.0,"lyQyService":9.0,"lyQyOther":9.0,"nowZbSort":9.0,"nowZbHardware":9.0,"nowZbService":9.0,"nowZbOther":9.0,"nowQySort":9.0,"nowQyHardware":9.0,"nowQyService":9.0,"nowQyOther":9.0,"finTotalSum":99.0,"bureaus":"系统管理处","isDel":"0","creUserId":"1300178","creUserName":"张捷","creTime":1561358897652,"updUserId":0.0,"updUserName":null,"updTime":1561454832437,"reportStatue":"0","versionTime":null}
      }
    },
    created () {
      this.processId=this.$route.query.processId;
      this.taskId=this.$route.query.taskId;
      console.log("processId:"+this.processId)
    },
    methods: {
      submitObj(operationObj){
          // console.log(operationObj)
      },
    },
    watch: {

    },
    mounted(){
//      this.list.forEach((item,index)=>{
//        this.set(item,'check',false)
//      })
    }
  }


</script>
<style>
/*  .wrapAppl {
    margin: 10px;
    border-left: 1px solid rgb(232, 232, 232);
    padding: 20px;
    background: #fff;
    box-shadow: 0 1px 6px rgba(0,0,0,.2);
    height: 100%;

  }*/
  .operationToolsBox{
    position: fixed;
    height: 100%;
    width: 300px;
    top:75px;
    right: 20px;
    overflow: scroll;
  }
  .operationToolsBox::-webkit-scrollbar {/*滚动条整体样式*/

    width: 10px;     /*高宽分别对应横竖滚动条的尺寸*/

    height: 1px;

  }

  .operationToolsBox::-webkit-scrollbar-thumb {/*滚动条里面小方块*/

    border-radius: 10px;

    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);

    background: #535353;

  }

  .operationToolsBox::-webkit-scrollbar-track {/*滚动条里面轨道*/

    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);

    border-radius: 10px;

    background: #EDEDED;

  }

  .divdLine {
    display: inline-block;
    width: 5px;
    background: #fa621e;
    height: 20px;
    margin-right: 10px;
  }
  .flexBox{
    display: flex;
  }
  .flexTitle{
    flex: 2;
    text-align: right;
    padding: 5px;
  }
  .flexCon{
    flex: 8;
    text-align: left;
    padding: 5px;
  }
  .unitText{
    position: absolute;
    font-weight: normal;
    font-size: 12px;
    top: 5px;
    right: 25px;
  }
</style>
