<template>
     <div>
       <div class="con-title">
         <span class="divdLine"></span>
         <span>企业表单111</span>
       </div>
       <div>
         <div>
           <div class="flexBox">
             <div class="flexTitle">项目名称:</div>
             <div class="flexCon">{{dataInfo.projectName}}</div>
             <div class="flexTitle">建设年限:</div>
             <div class="flexCon">{{dataInfo.conYear}}</div>
           </div>
           <div class="flexBox">
             <div class="flexTitle">所属平台:</div>
             <div class="flexCon">{{dataInfo.belongPlat}}</div>
             <div class="flexTitle">业务领域:</div>
             <div class="flexCon">{{dataInfo.businessArea}}</div>
           </div>
           <div class="flexBox">
             <div class="flexTitle">建设性质:</div>
             <div class="flexCon">{{dataInfo.constrNature}}</div>
             <div class="flexTitle">业务处室:</div>
             <div class="flexCon">{{dataInfo.bureaus}}</div>
           </div>
           <div class="flexBox">
             <div class="flexTitle">项目内容:</div>
             <div class="flexCon" style="flex: 18">{{dataInfo.projectContent}}</div>
           </div>
         </div>
       </div>
     </div>
</template>

<script>

  export default {
    name: "CostForm",
    props:['dataInfo'],
    components: {

    },
    data () {
      return {

      }
    },
    created () {

    },
    methods: {

    },
    watch: {

    }
  }
</script>
<style>
  .flexBox{
    display: flex;
  }
  .flexTitle{
    flex: 2;
    text-align: right;
    padding: 5px;
  }
  .flexCon{
    flex: 8;
    text-align: left;
    padding: 5px;
  }
</style>
