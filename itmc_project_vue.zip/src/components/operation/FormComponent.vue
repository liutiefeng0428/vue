<template>
     <div>
       <div>
       </div>
       <component v-bind:is="who" :dataInfo="dataInfo"></component>
     </div>
</template>

<script>

  import PlanForm from './PlanForm'
  import CostForm from './CostForm'
  import {commonCom} from '@/utils/operation/commonComponents'

  export default {
    name: "FormComponent",
    props:['FormType','dataInfo'],
    data () {
      return {
        who:'',
        rootSubmenuKeys: ['sub1', 'sub2', 'sub4'],
        openKeys: ['sub1'],
      }
    },
    components:{
      "PlanForm":PlanForm,
      "CostForm":CostForm
    },
    created () {
      this.who=this.FormType
      console.log(this.FormType)
    },
    methods: {
      onOpenChange (openKeys) {
        const latestOpenKey = openKeys.find(key => this.openKeys.indexOf(key) === -1)
        if (this.rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
          this.openKeys = openKeys
        } else {
          this.openKeys = latestOpenKey ? [latestOpenKey] : []
        }
      },
    },
    watch: {

    }
  }
</script>
<style>
  .wrap {
    margin: 10px;
    border-left: 1px solid rgb(232, 232, 232);
    padding: 20px;
    background: #fff;
    box-shadow: 0 1px 6px rgba(0,0,0,.2);
    margin-right: 350px;
  }
  .operationToolsBox{
    position: fixed;
    height: 100%;
    width: 300px;
    top:75px;
    right: 20px;
    overflow: scroll;
  }
  .operationToolsBox::-webkit-scrollbar {/*滚动条整体样式*/

    width: 10px;     /*高宽分别对应横竖滚动条的尺寸*/

    height: 1px;

  }

  .operationToolsBox::-webkit-scrollbar-thumb {/*滚动条里面小方块*/

    border-radius: 10px;

    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);

    background: #535353;

  }

  .operationToolsBox::-webkit-scrollbar-track {/*滚动条里面轨道*/

    -webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);

    border-radius: 10px;

    background: #EDEDED;

  }
</style>
