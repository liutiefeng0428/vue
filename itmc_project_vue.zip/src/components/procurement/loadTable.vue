<template>
    <div>
        <div class="con-title">
        <span class="divdLine"></span>
        <span>采购管理列表</span>
        <span class="unitText" style="top:15px">单位：万元</span>
        </div>
        <div>
            <div class="ant-table-content">
                <div class="ant-table-body">
                    <table style="width: 100%">
                        <thead class="ant-table-thead">
                        <tr>
                            <th rowspan="1" class=""><div>序号</div></th>
                            <th rowspan="1" class=""><div>采购方式</div></th>
                            <th rowspan="1" class=""><div>名称</div></th>
                            <th rowspan="1" class=""><div>项目名称/开支类型</div></th>
                            <th rowspan="1" class=""><div>有效期</div></th>
                            <th rowspan="1" class=""><div>有效性</div></th>
                            <th colspan="1" class=""><div>操作</div></th>
                        </tr>
                        </thead>
                        <tbody class="ant-table-tbody">
                        <tr  v-for="(item,index) in dataInfo" :key="index">
                            <td>{{index+1}}</td>
                            <td v-if="item.biddingType=='1'">询比价</td>
                            <td v-else-if="item.biddingType=='2'">招投标</td>
                            <td v-else-if="item.biddingType=='3'">商务谈判</td>
                            <td>
                            <span class="ecllipsis">
                                <a @click="toDetail(index)">{{item.name}}</a>
                            </span>
                            </td>
                            <td>{{item.applyName}}</td>
                            <td>{{item.validity}}</td>
                            <td v-if="item.isValid=='0'">无效</td>
                            <td v-else>有效</td>
                            <td style="width: 160px">
                            <a @click="handleEdit('0')">
                                <a-icon type="edit"/>
                                编辑
                            </a>
                            <a-divider type="vertical"/>
                            <a-popconfirm title="确定删除吗?"  okText="确定" cancelText="取消" @confirm="() => handleDelete(record.id)">
                                <a>删除</a>
                            </a-popconfirm>
                            </td>
                        </tr>
                        </tbody>
                        <tbody>
                            <tr>
                                <td colspan='7'>
                                    <div class='nodata' v-show='showTable'>暂无数据</div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    import {apiService} from "@/services/apiservice";
    export default {
        name:'loadTable',
        data(){
            return {
                showTable:false,
                dataInfo:[],
                params:{
                    "year": this.year,//年度
                    "biddingType": this.biddingType,//采购方式
                    "name": this.name,//名称
                    "applyName": this.applyName,//项目名称/开支类型
                }
            }
        },
        methods: {
            handleEdit(type){
                if(type=='0'){
                this.$router.push({path: "/compariso-add", query: {id:type}})
                }else if(type=='1'){
                this.$router.push({path: "/tendering-add", query: {id:type}})
                }else if(type=='2'){
                this.$router.push({path: "/business-add", query: {id:type}})
                }

            },
            handleDelete(id){},
            toDetail(type){
                if(type=='0'){
                this.$router.push({path: "/compariso-detail", query: {id:type}})
                }else if(type=='1'){
                this.$router.push({path: "/tendering-detail", query: {id:type}})
                }else if(type=='2'){
                this.$router.push({path: "/business-detail", query: {id:type}})
                }

            },
            loadTable(params){
                let _self = this
                apiService.getItmcPurchaseList(params).then(r => {
                console.log(r)
                if(r.result.length <= 0){
                    this.showTable = true
                }else {
                    this.showTable = false
                }
                _self.dataInfo = r.result
                })
            },
        },
        created(){
            this.params._json = true
            this.loadTable(this.params)
        },
        props: {
            "year": {type: String, default: '0'},
            "biddingType": '',
            "name": '',
            "applyName": ''
        },
        watch: {
            year:function(newVal,oldVal){
                console.log('执行'+newVal)
                if (newVal != oldVal && oldVal != '') {
                    this.params.year = newVal
                }
                this.params._json = true
                this.loadTable(this.params)
            },
            biddingType:function(newVal,oldVal){
                console.log('执行'+newVal)
                if (newVal != oldVal && oldVal != '') {
                    this.params.biddingType = newVal
                }
                this.params._json = true
                this.loadTable(this.params)
            },
            name:function(newVal,oldVal){
                console.log('执行'+newVal)
                if (newVal != oldVal && oldVal != '') {
                    this.params.name = newVal
                }
                this.params._json = true
                this.loadTable(this.params)
            },
            applyName:function(newVal,oldVal){
                console.log('执行'+newVal)
                if (newVal != oldVal && oldVal != '') {
                    this.params.applyName = newVal
                }
                this.params._json = true
                this.loadTable(this.params)
            }
        }
    }
</script>
<style>
    .nodata {
        text-align: center;
        padding-top: 70px;
    }
    .unitText{
        position: absolute;
        font-weight: normal;
        font-size: 12px;
        right: 25px;
    }
    .ant-table-tbody > tr > td {
        border: 1px solid #e8e8e8;
        text-align: center;
    }
    .ant-table-thead > tr > th {
        border-left: 1px solid #e8e8e8;
        border-right: 1px solid #e8e8e8;
        text-align: center;
    }
    .ant-table-thead tr {
        border-top: 1px solid #e8e8e8;
    }
</style>