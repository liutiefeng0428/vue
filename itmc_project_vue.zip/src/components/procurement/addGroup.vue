<template>
    <div style="margin-bottom: 20px">
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="toAdd('0')" icon="plus">添加询比价申请</a-button>
      </span>
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="toAdd('1')" icon="plus">添加招投标方案</a-button>
      </span>
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="toAdd('2')" icon="plus">添加商务谈判单</a-button>
      </span>
    </div>
</template>
<script>
    import {apiService} from "@/services/apiservice";
    export default {
        data(){
            return {
                optionDate:[],
                plateArr:[]
            }
        },
        methods: {
            toAdd(type){
                if(type=='0'){
                this.$router.push({path: "/compariso-add", query: {id:type}})
                }else if(type=='1'){
                this.$router.push({path: "/tendering-add", query: {id:type}})
                }else if(type=='2'){
                this.$router.push({path: "/business-add", query: {id:type}})
                }
            },
        },
        props: {

        }
    }
</script>
<style>

</style>