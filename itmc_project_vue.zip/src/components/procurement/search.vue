<template>
    <div style="margin-bottom:16px;">
      <span>年度:</span>
      <a-select :value="optionDateSelect" defaultValue="" class="querySelect" @change="handleChangeDate" style="width:160px">
        <a-select-option v-for="item in optionDate" :key="item.optionCode"> {{item.optionName}}</a-select-option>
      </a-select>
      <span style="margin-left: 15px;">采购方式:</span>
      <a-select :value="plateSelect" class="querySelect" @change="handleChangePlate" style="width:160px">
        <a-select-option v-for="item in plateArr" :key="item.id"> {{item.plateType}}</a-select-option>
      </a-select>
      <span style="margin-left: 15px;">名称:</span>
      <a-input v-model="proName" style="width: 160px"></a-input>
      <span style="margin-left: 15px;">项目名称/开支类型:</span>
      <a-input v-model="proType" style="width: 160px"></a-input>
      <span class="table-page-search-submitButtons">
        <a-button type="primary" @click="queryTable" icon="search">查询</a-button>
      </span>
    </div>
</template>
<script>
    import {apiService} from "@/services/apiservice";
    export default {
        name:'search',
        data(){
            return {
                optionDate:[],
                plateArr:[
                    {id:'',plateType:"--请选择--"},
                    {id:'1',plateType:"询比价"},
                    {id:'2',plateType:"招投标"},
                    {id:'3',plateType:"商务谈判"}
                ],
                optionDateSelect: '全部',//年度
                plateSelect:"",//采购方式
                proName:"",//名称
                proType:"",//项目名称/开支类型
            }
        },
        methods: {
            handleChangePlate(value){
                console.log(value)
                if(value != ''){
                this.plateSelect = value
                }
            },
            handleChangeDate(value){
                if(value != null && value != ''){
                    this.optionDateSelect = value
                }
                console.log(this.optionDateSelect)
            },
            loadDate(){
                var _self = this
                var parmasData = "typeCode=JHNDM"
                apiService.getDictionary1(parmasData).then(r => {
                console.log(r)
                _self.optionDate = r
                // _self.optionDateSelect = _self.optionDate[0].optionCode

                }, r => {
                }).catch(

                )
            },
            queryTable:function(){ 
                let optionDateSelect=this.optionDateSelect
                let _self = this
                var ItmcPurDTO = {
                    year: _self.optionDateSelect,//年度
                    biddingType:_self.plateSelect,//采购方式
                    name:_self.proName,//名称
                    applyName:_self.proType,//项目名称/开支类型
                }
                if(this.optionDateSelect == '全部') {
                    ItmcPurDTO.year = '0'
                }
                this.$emit("listenQueryDate",ItmcPurDTO)
            }
        },
        created(){
            this.loadDate()
        },
        props: {

        }
    }
</script>
<style scoped>
    @import '../../assets/css/common.css'
</style>